#ifndef OUTBREAK_DOORKIT_WINDOW_H
#define OUTBREAK_DOORKIT_WINDOW_H

#pragma warning(disable:4786)

namespace doorkit {

class Doorkit;

class Window {
protected:

	bool	gotFocus;
	Window	*parentWindow;

public:

	Window(Window *newParentWindow);
	virtual ~Window();

	virtual void draw() = 0;

	// Messages from the parent
	virtual void parentAdd(Doorkit *newDoorkit);
	virtual void parentRemove();
	
	virtual void parentGiveFocus();
	virtual void parentTakeFocus();

	// Messages from the childrens (if any)
};

}

#endif