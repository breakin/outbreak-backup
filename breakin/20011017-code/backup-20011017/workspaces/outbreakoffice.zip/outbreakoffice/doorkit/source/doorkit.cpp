#include "doorkit.h"

doorkit::Doorkit::Doorkit() : windowFocus(NULL) {
}

doorkit::Doorkit::~Doorkit() {
}

void doorkit::Doorkit::add(Window *window) {
	windowList.insert(0,window);
	window->parentAdd(this);

	childTakeFocus(window);
}

void doorkit::Doorkit::remove(Window *window) {
	if (windowFocus==window) {
		childGiveFocus(window);
	}

	window->parentRemove();
	windowList.erase(window);
}

void doorkit::Doorkit::childTakeFocus(Window *window) {
	windowFocus=window;
	window->parentGiveFocus();
}

void doorkit::Doorkit::childGiveFocus(Window *window) {
	if (window==windowFocus) {
		window->parentTakeFocus();

		// Give focus to another window, whichever :)
	}
}

void doorkit::Doorkit::start() {
	// Process all messages from the system and send to active window
	// Validate all invalidates areas by redrawing	
}