#include "window.h"

doorkit::Window::Window() : gotFocus(false), parentWindow(0) {
}

doorkit::Window::~Window() {
}

void doorkit::Window::parentAdd(Window *newParentWindow) {
	parentWindow=newParentWindow;
}

void doorkit::Window::parentRemove() {
	doorkit=0;
}

void doorkit::Window::parentGiveFocus() {
	gotFocus=true;
}

void doorkit::Window::parentTakeFocus() {
	gotFocus=false;
}
