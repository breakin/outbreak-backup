#ifndef OUTBREAK_DOORKIT_H
#define OUTBREAK_DOORKIT_H

#pragma warning(disable:4786)

#include "window.h"
#include <set>

namespace doorkit {

	class Doorkit : public Window {
	private:

		Window				*windowFocus;
		std::set<Window*>	windowList;

	public:

		Doorkit();
		~Doorkit();

		void add(Window *window);
		void remove(Window *window);

		void start();
	};

}

#endif
