
#include <doorkit>
#include "tracker"

#include <exception>
#include <string>
#include "wininclude.h"

using tracker::Tracker;

int APIENTRY WinMain(HINSTANCE hInst,HINSTANCE hPrevInst,LPSTR lpCmdLine,int nCmdShow) {
	try	{

		// Create a doorkit
		// This will include doorkit initialization
		// However imageloading will be postponed til controls that use the images
		// are added
		doorkit::Doorkit dk;

		// Create a tracker window
		Tracker t(lpCmdLine);

		// Add the tracker window to the doorkit object
		dk.add(&t);

		// Start the doorkit and give it control of this thread
		dk.start();
	}

	catch (std::exception &e) {
		MessageBox(0, e.what(), "Exception", MB_ICONERROR);
	}

	return false;
}