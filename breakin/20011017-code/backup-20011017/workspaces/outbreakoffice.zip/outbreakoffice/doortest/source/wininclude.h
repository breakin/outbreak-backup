// Exclude mfc
#define WIN32_LEAN_AND_MEAN

// Said to reduce buildtime (windows.h)
#define NOGDICAPMASKS
#define NOMENUS
#define NOICONS
#define NORASTEROPS
#define NOATOM
#define NOCOLOR
#define NOCTLMGR
#define NODRAWTEXT
#define NOGDI
#define OEMRESOURCE
#define NONLS
//#define NOMB
#define NOMEMMGR
#define NOMETAFILE
#define NOMINMAX
#define NOMSG
#define NOOPENFILE
#define NOSCROLL
#define NOSERVICE
#define NOSOUND
#define NOTEXTMETRIC
#define NOWH
#define NOWINOFFSETS
#define NOCOMM
#define NOKANJI
#define NOHELP
#define NOPROFILER
#define NODEFERWINDOWPOS
#define NOMCX
#define NOWINMESSAGES
#define NOWINSTYLES
#define NOSYSMETRICS
#define NOKEYSTATES
#define NOSYSCOMMANDS

#include <windows.h>

#undef WIN32_LEAN_AND_MEAN

#undef NOGDICAPMASKS
#undef NOMENUS
#undef NOICONS
#undef NORASTEROPS
#undef NOATOM
#undef NOCOLOR
#undef NOCTLMGR
#undef NODRAWTEXT
#undef NOGDI
#undef OEMRESOURCE
#undef NONLS
//#undef NOMB
#undef NOMEMMGR
#undef NOMETAFILE
#undef NOMINMAX
#undef NOMSG
#undef NOOPENFILE
#undef NOSCROLL
#undef NOSERVICE
#undef NOSOUND
#undef NOTEXTMETRIC
#undef NOWH
#undef NOWINOFFSETS
#undef NOCOMM
#undef NOKANJI
#undef NOHELP
#undef NOPROFILER
#undef NODEFERWINDOWPOS
#undef NOMCX
#undef NOWINMESSAGES
#undef NOWINSTYLES
#undef NOSYSMETRICS
#undef NOKEYSTATES
#undef NOSYSCOMMANDS

/*
 *  NOVIRTUALKEYCODES - VK_*
 *  NOCLIPBOARD       - Clipboard routines
 *  NOKERNEL          - All KERNEL defines and routines
 *  NOUSER            - All USER defines and routines
*/ 