#include "tracker.h"

tracker::Tracker::Tracker(const std::string &commandLine) : Window() {
}

tracker::Tracker::~Tracker() {
}