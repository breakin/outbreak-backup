#ifndef OUTBREAK_TRACKER_H
#define OUTBREAK_TRACKER_H

#pragma warning(disable:4786)

#include <doorkit>
#include <string>

namespace tracker {

	class Tracker : public doorkit::Window {
	private:
	public:

		Tracker(const std::string &commandLine);
		~Tracker();
	};
}

#endif