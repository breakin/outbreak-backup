#ifndef HELPER_DEMO_SCRIPT_EFFECT_H
#define HELPER_DEMO_SCRIPT_EFFECT_H

#include <string>
#include <helper/core/typedefs.h>

namespace Helper {

	class Effect {
	public:
		Effect() { }
		virtual ~Effect() { }
		
		// Executes a trigger within the script.
		// A value can be passed, could be used for splines!
		virtual void executeTrigger(const std::string& name, const std::string& value) { }
		virtual void updateSpline(const std::string& name, const float64 value) { }

		// Update effect
		virtual void update(const float64 delta, const float64 percent) { }
	};

}

#endif