#include "log.h"

using namespace Helper;

/**
 * Set debug state - enabled or disabled
 * depending if compiled in DEBUG mode
 */
#ifdef HELPER_DEBUG
#define DEBUG_STATE true
#else
#define DEBUG_STATE false
#endif

/**
 * Declare static class members
 */
FILE*	Log::m_file			= NULL;
bool	Log::m_initialized	= false;
bool	Log::m_enabled		= DEBUG_STATE;
Clock	Log::m_clock;
int     Log::m_filter		= Log::ALL;

//=========================================================================

void Log::open() {

	// open logfile
	m_file = fopen("debug.log","a+");
}

//=========================================================================

void Log::close() {

	// close logfile
	fclose(m_file);
}

//=========================================================================

void Log::log(int msgType, const char method[], const char message[]) {

	if (m_enabled) {
		
		// check if msgType is in filter
		if (m_filter & msgType) {

			if (!m_initialized) {
				// log top file header
				logHeader();
				m_initialized = true;
			}
			
			// log message to file
			open();
			fprintf (m_file,"[%f]\t%s->[%s]\n",m_clock.get(),method,message);
			close();
		}
	}
}

//=========================================================================

void Log::logHeader() {
	
	open();
	fprintf (m_file,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	fprintf (m_file," ,      ..    .           . \n");
	fprintf (m_file,". oOoOo        .   BB   ..\n");
	fprintf (m_file," oO###oO#    .   . B#BB#\n");
	fprintf (m_file," Oo#  Oo#(Outbreak)B#  BB#\n");
	fprintf (m_file," Oo#  Oo# OoOOoooO BBBB##\n");
	fprintf (m_file," Oo#  Oo#  #OoO### B###BB#\n");
	fprintf (m_file,"  Ooooo#    ooo#   B#BB###\n");
	fprintf (m_file,"   ####     OoO#   BB###\n");
	fprintf (m_file,"  .     .    ###  . ##\n");
	fprintf (m_file,".    .      . .       .    \n");
	fprintf (m_file,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");


	close();
}

//=========================================================================

void Log::enable() {

	m_enabled = true;
}

//=========================================================================

void Log::disable() {
	
	m_enabled = false;
}
