#ifndef HELPER_CLOCK_H
#define HELPER_CLOCK_H

#include "typedefs.h"

/*
  
  Author: Breakin (code from Thec, ideas from Tooon)
  Remark: Needs ansi-c rewrite

*/

namespace Helper {

	class Clock {
	private:

		float64 startTime;

		static const float64 getTime();
		static void initTime();

	public:

		Clock();

		~Clock() {
		}

		inline const float64 get() const { return getTime()-startTime; }
		inline void reset() { startTime=getTime(); }
	};
};

#endif