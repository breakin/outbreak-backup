#include "win32_device2d.h"

using namespace Helper;

//============================================================================================
// Class or method implementations
//============================================================================================
Win32Device2D::Win32Device2D()
{
	reset();
}

//============================================================================================
Win32Device2D::~Win32Device2D()
{
	close();
}

//============================================================================================
void Win32Device2D::open()
{
	// read configuration
	// check if device is already opened, then we need to reconfigure
	if (m_opened)  
	{
		if (checkReconfig()) return;
	}

	// convert config params to proper types
	m_config.get("WIDTH"  ,m_width);
	m_config.get("HEIGHT" ,m_height);
	m_config.get("XPOS"   ,m_xpos);
	m_config.get("YPOS"   ,m_ypos);
	m_config.get("CAPTION",m_caption);
	m_config.get("TITLE"  ,m_title);

	// open window
	m_window.open(m_title.c_str(),AreaInt(m_xpos,m_ypos,m_width,m_height),m_caption,false);
	// tell window to send message's to this device when events occur
	m_window.setMsgQueue(*this);
	// center window
	// if (m_config["ALIGN"] == "CENTER") m_window.center();
	// now show window
	m_window.show();
	// create a backbufer.
	m_backBuffer.create(m_width,m_height,PixelFormat::BPP_32);
	
	m_opened = true;
}

//============================================================================================
void Win32Device2D::close()
{
	if (m_opened)
	{
		m_window.close();
		m_backBuffer.release();
		m_opened = false;
	}
}

//============================================================================================
void Win32Device2D::reset()
{
	// default win32 configuration
	m_config["ALIGN"]   = WIN32_DEVICE2D_DEFAULT_ALIGN;
	m_config["WIDTH"]   = WIN32_DEVICE2D_DEFAULT_WIDTH;
	m_config["HEIGHT"]  = WIN32_DEVICE2D_DEFAULT_HEIGHT;
	m_config["CAPTION"] = WIN32_DEVICE2D_DEFAULT_CAPTION;
	m_config["TITLE"]   = WIN32_DEVICE2D_DEFAULT_TITLE;
	m_config["XPOS"]    = WIN32_DEVICE2D_DEFAULT_XPOS;
	m_config["YPOS"]    = WIN32_DEVICE2D_DEFAULT_YPOS;
	m_opened = false;
	m_width  = 0;
	m_height = 0;
	m_xpos   = 0;
	m_xpos   = 0;
}

//============================================================================================
bool Win32Device2D::checkReconfig()
{
	bool changeRes = false;
	bool changeCaption = false;
	int  temp_xpos,temp_ypos,temp_width,temp_height;
	bool temp_caption;
		
		m_config.get("WIDTH"  ,temp_width);
		m_config.get("HEIGHT" ,temp_height);
		m_config.get("CAPTION",temp_caption);
		m_config.get("XPOS"   ,temp_xpos);
  		m_config.get("YPOS"   ,temp_ypos);
		
		// check for changes in configuration
		if ((temp_width  != m_width) || (temp_height!=m_height)) changeRes = true;
		if (temp_caption != m_caption)  changeCaption = true;

		// resolution switch
		if (changeRes)
		{
			m_window.resize(AreaInt(0,0,temp_width,temp_height),true);
			m_width  = temp_width;
			m_height = temp_height;
			m_backBuffer.release();
			m_backBuffer.create(m_width,m_height,PixelFormat::BPP_32);
			m_window.center();
			// return true to break open method
			// return true;
		}
		
		// caption on/off
		if (changeCaption) 
		{
			m_caption = temp_caption;
			m_window.showCaption(m_caption);
			m_window.center();
		}

		// always make ::open break by return true
		return true;
}


//============================================================================================
void Win32Device2D::update(Image32 &image, bool needScreenUpdate)
{
	// update scrreen if invalid
	if (needScreenUpdate)
	{
		m_blitter.copy(image,m_backBuffer);
		m_backBuffer.blt(m_window.getHandle());
	}
	// poll messages
	m_window.update();
}

//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================
//============================================================================================



