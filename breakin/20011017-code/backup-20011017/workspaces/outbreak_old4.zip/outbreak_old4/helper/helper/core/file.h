#ifndef HELPER_FILE_H
#define HELPER_FILE_H

#include "typedefs.h"
#include <string>
#include "blob.h"

namespace Helper {
	
	class File {
	private:

		int  mSize;
		bool mReadable;
		bool mWriteable;
		std::string mName;

	public:

		const std::string& getName()     const { return mName; }
		const int          getSize()     const { return mSize; }
		const bool         isReadable()  const { return mReadable; }
		const bool         isWriteable() const { return mWriteable; }

		void setName(const std::string &name) { mName=name; }
		void setSize(const int size) { mSize=size; }
		void setReadable(const bool readable) { mReadable=readable; }
		void setWriteable(const bool writeable) { mWriteable=writeable; }

		//virtual void set(Blob &data) = 0;
		virtual Blob get() const = 0;
		virtual void remove() = 0;
	};
}

#endif
