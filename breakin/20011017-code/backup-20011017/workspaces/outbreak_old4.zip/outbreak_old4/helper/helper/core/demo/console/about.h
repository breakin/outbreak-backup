#ifndef HELPER_DEMO_ABOUT_H
#define HELPER_DEMO_ABOUT_H

/*
	This is the about box for the console.
*/

#include "application.h"
#include "console.h"

#include <helper/core/typedefs.h>

namespace Helper {

	class About : public Application {

	private:
	public:
		About(const ConsoleData& consoleData);
		~About();

		void refresh();
		Application* update();
	};

}

#endif
