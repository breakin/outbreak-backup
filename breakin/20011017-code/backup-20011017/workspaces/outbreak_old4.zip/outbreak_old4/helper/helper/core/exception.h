
#ifndef HELPER_EXCEPTION_H
#define HELPER_EXCEPTION_H

#include <exception>

namespace Helper {

	class Exception : public exception {
	public:
		Exception(const char * const message) : exception(message) {
		};
	};
}

#endif