#include "imagecoder.h"

// ---------------------------------------------------------------------------

const Helper::ImageCoder::DecodeSettings Helper::ImageCoder::defaultDecodeSettings;
const Helper::ImageCoder::EncodeSettings Helper::ImageCoder::defaultEncodeSettings;

// ---------------------------------------------------------------------------

const bool Helper::ImageCoder::isExtension(const std::string &fileName,
										   const std::string &extension) const {

	if (fileName.size()<extension.size()) return false;

	for (int C=0; C<extension.size(); C++) {
		if (tolower(fileName[fileName.size()-extension.size()+C])!=extension[C]) {
			return false;
		}
	}

	return true;
}	

// ---------------------------------------------------------------------------