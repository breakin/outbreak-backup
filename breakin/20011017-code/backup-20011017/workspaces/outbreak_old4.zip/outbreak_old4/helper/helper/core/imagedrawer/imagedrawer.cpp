
#include "imagedrawer.h"
#include "..\log.h"

using namespace Helper;


//=============================================================================================================

void ImageDrawer::copy(Image32 &srcSurface, Image32 &dstSurface)
{
	if ((srcSurface.getWidth() == dstSurface.getWidth()) && (srcSurface.getHeight() == dstSurface.getHeight()))
	m_drawer->copy((uint32*)srcSurface.getPixels(),
				   (uint32*)dstSurface.getPixels(), 
				   srcSurface.getArea().getSize());
}

//=============================================================================================================

void ImageDrawer::clear(Image32 &dstSurface,const AreaInt &dstArea, int clearCaps)
{
	uint32 *pixelOffset;
	
	// calculate offset
	pixelOffset =  (uint32*)dstSurface.getPixels();
	pixelOffset += ( dstArea.getLeft() + dstArea.getTop() * dstSurface.getWidth() );

	// check if we should keep alpha
	if (clearCaps == CLEAR_ARGB)
	{
		m_drawer->clearARGB(pixelOffset,
							dstArea.getWidth(), dstArea.getHeight(),
							dstSurface.getPitch());
	}	
	else
	{
		m_drawer->clearRGB (pixelOffset,
							dstArea.getWidth(), dstArea.getHeight(),
							dstSurface.getPitch());
	}
}


//=============================================================================================================

void ImageDrawer::draw(Image32 &srcSurface, const AreaInt &srcArea, Image32 &dstSurface, const AreaInt &dstArea, int blitFlags)
{
	uint32  *src_data, *dst_data;
	int     src_pitch, dst_pitch;
	int     dst_width, dst_height;
	Image32 zoomSurface;

	// check if we need to zoom srcSurface
	if ((dstArea.getWidth () != srcArea.getWidth()) || (dstArea.getHeight() != srcArea.getHeight()))
	{
		
		debugLog(Log::SYS,"ImageDrawer::draw","Scaling srcSurface");
		debugLog(Log::SYS,"ImageDrawer::draw","Scaled size = %d, %d",dstArea.getWidth(), dstArea.getHeight());
		
		// create new surface and area - rearanged to new zoomed surface
		zoomSurface.create(dstArea.getWidth(), dstArea.getHeight());
		
		// zoom srcsurface to fit in the dstArea
		m_drawer->scale_bilinear((uint32*)srcSurface.getPixels() , srcArea, srcSurface.getPitch(),
								 (uint32*)zoomSurface.getPixels(), dstArea, zoomSurface.getPitch());				

		// calc pixel's address and pitch
		src_pitch = zoomSurface.getPitch();
		src_data  = (uint32*)zoomSurface.getPixels();
	}
	else
	{
		// get address and pitch from original source surface
		src_pitch = srcSurface.getPitch();
		src_data  = (uint32*)srcSurface.getPixels();
		src_data += srcArea.getLeft() + srcArea.getTop() * (src_pitch>>2);			
	}

		
	/* calc first pixels address in dest data.
	   and set pitch and dimensions of dest surface */
	dst_pitch = dstSurface.getPitch();
	dst_width = dstArea.getWidth();
	dst_height= dstArea.getHeight();
	dst_data  = (uint32*)dstSurface.getPixels();
	dst_data += dstArea.getLeft() + dstArea.getTop() * (dst_pitch>>2);

		
	// check bitflags, and route to proper internal blit method
	switch (blitFlags)
	{
		case BLIT_NORMAL:
		m_drawer->blit(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;
		
		case BLIT_SATURATION:
		break;

		case BLIT_ALPHABLEND:
		m_drawer->blit_alpha(src_data,dst_data,dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_COLORKEY:
		m_drawer->blit_colorkey(src_data,dst_data,dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_SATURATION|BLIT_COLORKEY:
		break;

		case BLIT_COLORKEY|BLIT_ALPHABLEND:
		//m_drawer->blit_colorkey_alpha(src_data,dst_data,dst_width, dst_height, src_pitch, dst_pitch);
		break;

		default:
		// TODO : throw exception
		break;
	}
}


//=============================================================================================================
void ImageDrawer::draw(Image32 &srcSurface, const AreaInt &srcArea, Image32 &dstSurface, int x, int y, int blitFlags)
{
	uint32 *src_data,*dst_data;
	int  src_pitch,dst_pitch;
	int  dst_width,dst_height;
	
	/* get address and pitch from source surface
		 and set correct offsets */
	src_pitch = srcSurface.getPitch();
	src_data  = (uint32*)srcSurface.getPixels();
	src_data += srcArea.getLeft() + srcArea.getTop() * (src_pitch>>2);			

	/* calc first pixels address in dest data.
	   and set pitch and dimensions of dest surface */
	dst_pitch = dstSurface.getPitch();
	dst_width = srcArea.getWidth();
	dst_height= srcArea.getHeight();
	dst_data  = (uint32*)dstSurface.getPixels();
	dst_data += x + y * (dst_pitch>>2);
	
	// route to proper internal blit routine...
	switch (blitFlags)
	{
		case BLIT_NORMAL:
		m_drawer->blit(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;
		
		case BLIT_SATURATION:
		break;

		case BLIT_ALPHABLEND:
		m_drawer->blit_alpha(src_data,dst_data,dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_COLORKEY:
		//m_drawer->blit_colorkey(src_data,dst_data,dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_SATURATION|BLIT_COLORKEY:
		break;

		case BLIT_COLORKEY|BLIT_ALPHABLEND:
		//m_drawer->blit_colorkey_alpha(src_data,dst_data,dst_width, dst_height, src_pitch, dst_pitch);
		break;

		default:
		// TODO : throw exception
		break;
	}

}

//=============================================================================================================
void ImageDrawer::setAlphaMode(int alphaMode)
{
	m_alphaMode = alphaMode;
}

//=============================================================================================================
void ImageDrawer::setAlphaChannel(uint8 alphaVal)
{
	m_alphaChannel = alphaVal;
}

//=============================================================================================================
void ImageDrawer::setScaleMode( int scaleMode)
{
	// sanity check
	if ((scaleMode == SCALE_BILINEAR) || (scaleMode == SCALE_LINEAR))
	m_scaleMode = scaleMode;
}