#include "imagecoder_jpg.h"
#include "../../exception.h"
#include <string>
#include <vector>

static const int DEST_BUFFER_SIZE=16000;

// ---------------------------------------------------------------------------

/**
 *
 * Jpeglib is all about understanding all the different kinds of callbacks
 * and do something quick before you die from the experience. Move in quick,
 * do it and go out while you are still sane.
 * I've learned some more about callbacks while doing the D3D-device for
 * the 3d-engine and from that experiences I've managed to produce
 * far better code than my last jpeglib implementation had. I will try to
 * put a comment here and there, along with some notes about how to compile
 * jpeglib.
 *
 **/

// ---------------------------------------------------------------------------

/**
 *
 * jpeglib.h must be in jpeglib/
 * jpeglib/jconfig.vc must be copied to jpeglib/jconfig.h (for msvc)
 * refine RGB_PIXELSIZE as 4 (not 3) int jpeglib/jmorecfg.h (to skip 
 *   alpha-values)
 * Reverse RGB_RED,GREEN,BLUE so we have bgr instead of rgb 
 *   (2,1,0 - not 0,1,2)
 *
 * Just throw everything from jpeglib/ into your workspace. Remove all 
 * files with a main() method and you are on the right track.
 * Remove jmem[ansi,name,dos,mac].c from the project and you are all done.
 *
 **/

// ---------------------------------------------------------------------------

extern "C" {
	
	#include "jpeglib/jpeglib.h"

	// -[ERROR-HANDLER]-------------------------------------------------------

	// Override standard error-handlers
	// Call output_message
	METHODDEF(void) ImageCoder_JPG_error_exit (j_common_ptr cinfo) {
		(*cinfo->err->output_message) (cinfo);
	}

	// -----------------------------------------------------------------------

	// Destroy the cinfo-object and throw an exception
	METHODDEF(void) ImageCoder_JPG_output_message (j_common_ptr cinfo) {
		char buffer[JMSG_LENGTH_MAX];

		(*cinfo->err->format_message) (cinfo, buffer);

		jpeg_destroy(cinfo);
		std::string message("ImageCoder_JPG; Jpeglib says; ");
		message+=buffer;

		throw Helper::Exception(message.c_str());
	}

	// -[DEST-MANAGER]--------------------------------------------------------
	
	struct MyDestMgr : public jpeg_destination_mgr {

	  Helper::uint8 temp[DEST_BUFFER_SIZE+1];
	  Helper::Blob* blob;
	  
	} ;

	// -----------------------------------------------------------------------
	
	METHODDEF(void)    ImageCoder_JPG_init_destination (j_compress_ptr cinfo) {
		MyDestMgr* m=reinterpret_cast<MyDestMgr*>(cinfo->dest);

		m->next_output_byte = m->temp;
		m->free_in_buffer   = DEST_BUFFER_SIZE;
		m->blob->clear();
	}

	// -----------------------------------------------------------------------

	METHODDEF(boolean) ImageCoder_JPG_empty_output_buffer (j_compress_ptr cinfo) {
		MyDestMgr* m=reinterpret_cast<MyDestMgr*>(cinfo->dest);

		const int oldSize=m->blob->getSize();

		// Add data to our result-buffer
		m->blob->resize(oldSize+DEST_BUFFER_SIZE, true);
		memcpy(m->blob->get()+oldSize, m->temp, DEST_BUFFER_SIZE);

		// Reset pointer and free bytes in buffer counters
		m->next_output_byte=m->temp;
		m->free_in_buffer=DEST_BUFFER_SIZE;

		return TRUE;
	}

	// -----------------------------------------------------------------------

	METHODDEF(void)	   ImageCoder_JPG_term_destination (j_compress_ptr cinfo) {
		MyDestMgr* m=reinterpret_cast<MyDestMgr*>(cinfo->dest);

		const int oldSize=m->blob->getSize();

		m->blob->resize(oldSize+DEST_BUFFER_SIZE-m->free_in_buffer, true);
		memcpy(m->blob->get()+oldSize, m->temp, DEST_BUFFER_SIZE-m->free_in_buffer);
	}

	// -[SOURCE MANAGER]------------------------------------------------------
	
	typedef struct {
	  struct jpeg_source_mgr pub;       /* public fields */

	} MySourceMgr;
	
	// -----------------------------------------------------------------------

	METHODDEF(void)	   ImageCoder_JPG_init_source (j_decompress_ptr cinfo) {
	}

	// -----------------------------------------------------------------------

	METHODDEF(boolean) ImageCoder_JPG_fill_input_buffer (j_decompress_ptr cinfo) {
		return TRUE;
	}

	// -----------------------------------------------------------------------

	METHODDEF(void)	   ImageCoder_JPG_skip_input_data (j_decompress_ptr cinfo, long num_bytes) {
	}

	// -----------------------------------------------------------------------

	METHODDEF(void)	   ImageCoder_JPG_term_source (j_decompress_ptr cinfo) {
	}

	// -----------------------------------------------------------------------
}

// ---------------------------------------------------------------------------

Helper::ImageCoder_JPG::ImageCoder_JPG() : ImageCoder() {
}

// ---------------------------------------------------------------------------

Helper::ImageCoder_JPG::~ImageCoder_JPG() {
}

// ---------------------------------------------------------------------------

const bool Helper::ImageCoder_JPG::isEncoder(const std::string &fileName) const {
	return (fileName.empty() || isExtension(fileName, ".jpg"));
}

// ---------------------------------------------------------------------------

const bool Helper::ImageCoder_JPG::isDecoder(const std::string &fileName) const {
	return (fileName.empty() || isExtension(fileName, ".jpg"));
}

// ---------------------------------------------------------------------------

/* Seperate greyscale and color into two inner methods */

Helper::Blob Helper::ImageCoder_JPG::encode(const Image32 &sourceImage, const EncodeSettings &settings) const {

	Blob returnBlob;

	struct jpeg_compress_struct cinfo;
	
	try {

		MyDestMgr destManager;
		destManager.blob=&returnBlob;
		destManager.init_destination=ImageCoder_JPG_init_destination;
		destManager.empty_output_buffer=ImageCoder_JPG_empty_output_buffer;
		destManager.term_destination=ImageCoder_JPG_term_destination;

		// Initialize a jpeglib error handler with standard methods and the override 
		// the methods for outputting and exiting on error-messages.
		struct jpeg_error_mgr jerr;
  		cinfo.err=jpeg_std_error(&jerr);
		cinfo.err->error_exit=ImageCoder_JPG_error_exit;
		cinfo.err->output_message=ImageCoder_JPG_output_message;

		// Create the compression object
		jpeg_create_compress(&cinfo);
		cinfo.dest=(jpeg_destination_mgr*)(&destManager);

		// Tell jpeglib the dimensions of the image to be written
		cinfo.image_width=sourceImage.getWidth();
		cinfo.image_height=sourceImage.getHeight();

		// Shall we save the alpha channel as an grayscale jpeg, or an 24-bit?
		if (settings.saveAlphaChannelAsGreyScale) {

			// Save alpha as grayscale
			cinfo.input_components=1;
			cinfo.in_color_space=JCS_GRAYSCALE;

		} else {

			// Save 24-bit
			cinfo.input_components=4;
			cinfo.in_color_space=JCS_RGB;
		}

		// Set the rest of the compression settings based on the defaults (depends on in_color_space)
		// Default settings might be overrided later (such as quality)
		jpeg_set_defaults(&cinfo);

		// Set the quality for the output image. Quality ranges from 0.0 to 1.0 where 1.0 is best quality
		int qualityInt=static_cast<int>(settings.colorQuality*100.0);
		if (qualityInt<0) qualityInt=0;
		if (qualityInt>100) qualityInt=100;

		jpeg_set_quality(&cinfo, qualityInt, TRUE);

		// After this no more settings or changes can be made to cinfo		
		jpeg_start_compress(&cinfo, TRUE);

		// Jpeglib wants a list with a pointer to each scanline
		std::vector<JSAMPROW> row_pointers(cinfo.image_height);

		// Will only be used if we are saving the alphachannel to an Grayscale jpeg
		Blob grayScaleBuffer;

		if (cinfo.input_components==1) {

			grayScaleBuffer.resize(cinfo.image_width*cinfo.image_height);

			// Grayscale jpeg (from alphachannel)
			// We must unconst the souce-texture since jpeglib wants row_pointers to be const, well...
			uint32 *sourceData=const_cast<uint32*>(sourceImage.getReadOnly());
			
			// Move the alphachannel of the image to a temporary buffer
			for (unsigned int Y=0, O=0; Y<cinfo.image_height; Y++)
				for (unsigned int X=0; X<cinfo.image_width; X++, O++) {
					grayScaleBuffer.set(O, static_cast<uint8>(sourceData[O]>>24));
				}
			
			for (int C=0; C<cinfo.image_height; C++) {
				row_pointers[C]=grayScaleBuffer.get()+C*cinfo.image_width*cinfo.input_components;
			}

		} else {
			
			// Full color jpeg
			// We must unconst the souce-texture since jpeglib wants row_pointers to be const, well...
			uint8 *sourceData=(uint8*)(sourceImage.getReadOnly());

			for (int C=0; C<cinfo.image_height; C++) {
				row_pointers[C]=&sourceData[C*cinfo.image_width*cinfo.input_components];
			}
		}

		// Write all scanlines
		while (cinfo.next_scanline < cinfo.image_height) {
			jpeg_write_scanlines(&cinfo, &row_pointers[0]+cinfo.next_scanline, cinfo.image_height-cinfo.next_scanline);
		}

		// Clean up
		jpeg_finish_compress(&cinfo);
		jpeg_destroy_compress(&cinfo);
	}

	catch (...) {
		jpeg_destroy_compress(&cinfo);
		throw;
	}

	return returnBlob;
}

// ---------------------------------------------------------------------------

Helper::Image32 Helper::ImageCoder_JPG::decode(const Blob &sourceBlob, const DecodeSettings &settings) const {
	return Image32();
}

// ---------------------------------------------------------------------------