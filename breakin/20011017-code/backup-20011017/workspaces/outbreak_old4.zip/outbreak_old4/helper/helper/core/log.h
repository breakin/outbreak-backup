#ifndef __HELPER_LOG_H__
#define __HELPER_LOG_H__

#include <stdarg.h>
#include <stdio.h>
#include "clock.h"


#ifdef	_DEBUG
#define HELPER_DEBUG
#endif

#ifdef	WIN32 
#define INLINE_API __forceinline
#else
#define INLINE_API inline
#endif


namespace Helper {


class Log {
		
	public:
		
		enum {
	
			APPL		= 0x01,
			SYS 		= 0x02,
			EXCEPTION	= 0x04,
			ALL			= 0xff,
		};

	
		static void log (int msgType, const char method[], const char message[]);

		static int	getFilter() { return m_filter; }
		static void setFilter(int filter) { m_filter = filter; }
		
		/**
		 * Enables/ Disables logging to file
		 */
		static void enable();
		static void disable();
		
	private:
			
		/**
		 * Log's properties
		 */
		static int		m_filter;
		static bool		m_enabled;
		static bool		m_initialized;
		static FILE*	m_file;
		static Clock	m_clock;
		
		/**
		 * Private meths 
		 */
		static void open();
		static void close();
		static void logHeader();

		// let debug method has access to private members
		friend void debugLog(int msgType, const char method[], const char message[]...);

};


// debug method, parses a string and send it Log::log
INLINE_API void debugLog(int msgType, const char method[], const char message[],...) {

	#ifdef HELPER_DEBUG
	if (Log::m_enabled) {

		va_list		args;
		static char logmsg[256];

		// parse arguments
		va_start(args,message);
		vsprintf(logmsg,message,args);
		
		// log to file
		Log::log(msgType, method, logmsg);
	}
	#endif
}

// enable logging
INLINE_API void debugEnable() {

	Log::enable();
}

// disable logging
INLINE_API void debugDisable() {
	
	Log::disable();
}

// set debug filter
INLINE_API void debugSetFilter(int filter) {

	Log::setFilter(filter);
}

// get debug filter
INLINE_API int debugGetFilter(int filter) {

	return Log::getFilter();
}


}// end namespace Helper


#endif
