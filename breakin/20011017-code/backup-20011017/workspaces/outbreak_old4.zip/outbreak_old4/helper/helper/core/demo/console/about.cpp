#include "about.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::About::About(const ConsoleData& consoleData) : Helper::Application(consoleData) {

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::About::~About() {

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::About::refresh() {
	C64& c64 = *consoleData.c64;

	c64.setColor(C64::COLOR_FRAME, C64::COLOR_FRAMEBACKGROUND);
	c64.drawWindow(30,6,49,21, "ABOUT");

	c64.setColor(C64::COLOR_TEXT, C64::COLOR_FRAMEBACKGROUND);

	for (int x=32; x<48; x++) c64.drawLetter(c64.screen, x, 11, 148);
	c64.drawString(c64.screen, 32, 12, "OUTBREAK CONSOLE");
	c64.drawString(c64.screen, 32, 13, "   SYSTEM 0.1   ");
	for (x=32; x<48; x++) c64.drawLetter(c64.screen, x, 14, 148);

	c64.setColor(C64::COLOR_SELECTED, C64::COLOR_SELECTEDBACKGROUND);
	c64.drawString(c64.screen, 32, 19, "      EXIT      ");

	c64.winDevice.update(c64.screen);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Application* Helper::About::update() {
	C64& c64 = *consoleData.c64;

	c64.winDevice.update(c64.screen, false);

	Msg msg;
	while(c64.winDevice.getMessage(msg, true)) {
		if (msg.message == Helper::Msg::MSG_KEYDOWN) {
			
			// Escape or return
			if ((msg.param == 27) || (msg.param == 13)) {
				return 0;
			}
		}
	}

	return this;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
