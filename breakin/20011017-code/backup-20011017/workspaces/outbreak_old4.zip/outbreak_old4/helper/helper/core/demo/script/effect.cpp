#include "effect.h"

Effect() {

}

~Effect() {

}
		
virtual void executeTrigger(const std::string& name, const std::string& value);
		virtual void updateSpline(const std::string& name, const float64 value);

		// Update effect
		virtual void update(const float64 delta, const float64 percent);
