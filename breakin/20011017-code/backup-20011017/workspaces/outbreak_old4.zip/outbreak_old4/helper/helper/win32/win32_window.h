#ifndef __AGLWIN32WINDOW_INCLUDED__
#define __AGLWIN32WINDOW_INCLUDED__

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <string>
#include "win32_image.h"
#include "..\core\message\message.h"
#include "..\core\area.h"


namespace Helper {


class Win32Window
{

	public:
		
		/** 
		 * Constuctors & destuctor 
		 */
		Win32Window ();
		Win32Window (const std::string &title, int width, int height, DWORD style=0);
		~Win32Window();
	
		/**
		 * open, close methods,
		 */
		void open(const char title[], const AreaInt &clientArea, bool caption, bool visible = true);
		void close();
		
		/**
		 * Visibility control methods,
		 */
		void show();
		void hide();

  		/**
		 * Shows and hides caption-runtime
		 */
		void showCaption(bool captionShow);
		
		/**
		 * Cursor visibility;
		 */
		void showCursor(bool CursorShow) const;

		/**
		 * resize the window's client and window area.
	     */
		void resize(AreaInt &newClientArea, bool keepPosition);
		void center();
	 
		/**
		 * Each window pushes it's messages on a message queue
		 * One has to provide a msgqueue to be signalled and pushed with events
		 * before the window is opened.
	     */
		void setMsgQueue(MsgQueue &msgQueue);
	  
		/**
		 * get a window's properties methods
		 */
		void getClientArea(AreaInt &area) const;
		HWND getHandle() const;		
		HDC  getDC();		
		void releaseDC();

		// Pops messages from message queue and updates the windows client area as well
		void update();

		// Winproc, static to obtain address of non instanciated class...
		static LRESULT CALLBACK win32WindowProcMsg  (HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
		static LRESULT CALLBACK win32WindowProcEvent(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

	protected:

		void createWindow();
		void destroyWindow();
		static void registerClass();
		static void unregisterClass();
    
		/**
		 * CWindow properties
		 */
		bool        m_caption;			  // window has a caption bar 
		bool        m_registered;  	      // class registered flag
		bool		m_opened;			  // window opened flag
		bool        m_visible;			  // visible flag
		AreaInt 	m_clientArea;		  // window's client area
		int			m_width;			  // Width of Window in pixels
		int			m_height;			  // Heigth of Window in pixels
		int			m_windowID;			  // Unique instance ID
		HDC         m_windowHDC;		  // Window's Device Context handle
		HWND		m_windowHandle;		  // Handle to the window0
	    DWORD		m_windowStyle;		  // Window styles, WS_POPUP etc...
		std::string	m_windowTitle;		  // Window title...
		MsgQueue	*m_msgQueue;		  // pointer to provieded message queue
		
	   /**
		* static class members, all windows share the same 
		* windowclass.
		*/
	    static WNDCLASSEX	m_windowClass;		// Window class structure...
		static char*     	m_windowClassName;  // Window class name
		static int	    	m_referenceCount; 	// reference counter
		static bool			m_windowRegistered; // Window registered flag
};

}// end namespace Aurora

#endif
