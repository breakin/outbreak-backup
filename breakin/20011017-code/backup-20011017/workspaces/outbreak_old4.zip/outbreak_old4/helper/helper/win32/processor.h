#ifndef HELPER_WIN32_PROCESSOR_H
#define HELPER_WIN32_PROCESSOR_H

#include "../x86/processor.h"

#endif