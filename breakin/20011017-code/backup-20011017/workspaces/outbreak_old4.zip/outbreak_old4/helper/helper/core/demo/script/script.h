#ifndef HELPER_DEMO_SCRIPT_SCRIPT_H
#define HELPER_DEMO_SCRIPT_SCRIPT_H

#include <helper/core/typedefs.h>
#include <helper/core/xml/xmlbase.h>
#include <helper/core/demo/script/effect.h>
#include <vector>

namespace Helper {

	class Script {
	public:

		// SAttribute
		struct SAttribute {
			std::string name;
			std::string value;

			inline XmlTag getTag() const;
		};
		
		// One time execution only.
		struct STrigger {
			int         running;
			int         executedCount;

			std::string name;
			float64     start;
			int         repeat;
			float64     delay;

			inline XmlTag getTag() const;
			void setRunning(const float64 timer);
		};

		// SEffect.
		class SEffect {
		public:
			float64		current;
			
			std::string name;
			float64     start;
			float64     end;

			// SEffect callback
			Effect*     effect;

			std::vector<SAttribute*>   attributeList;
			std::vector<STrigger*>     triggerList;

			const std::string& getAttribute(const std::string name);
		};

		// Scene, demo-part.
		class SScene {
		public:
			std::string name;
			float64     current;
			float64     start;
			float64     end;

			std::vector<SAttribute*>   attributeList;
			std::vector<STrigger*>     triggerList;
			std::vector<SEffect*>      effectList;

			SEffect& getEffect(const std::string& name);
			const std::string& getAttribute(const std::string name);
		};

	private:
		// Update() control variables.
		SScene*  activeScene;
		float64  lastTime;

		void loadAttribute(std::vector<SAttribute*> &attributeList, const XmlBase::IteratorConst& attribute);
		void loadTrigger(std::vector<STrigger*> &triggerList, const XmlBase::IteratorConst& trigger);
		void loadEffect(std::vector<SEffect*> &effectList, const XmlBase::IteratorConst& effect, const float64 sceneEnd);

		void load(const XmlBase& xmlObject);

	public:
		// List of scenes.
		std::vector<SScene*> sceneList;

		// Initialize the script object 
		Script();
		Script(const XmlBase& xmlObject);
		~Script();
	
		SScene& getScene(const std::string& name);

		void addCallback(const std::string& sceneName, const std::string& effectName, Effect* effect);

		void save(XmlBase& xmlObject);

		const bool update(const float64 timer);
		SScene& getActiveScene();
	};

}

#endif

