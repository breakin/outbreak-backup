/*
==============================================================================================
																	AURORA GFX LIBRARY 1.0	          												 
	_________________________________________________________________________________________	 
																																														 
			File        : win32_device2d.h  								            														   	
			Copyright(c): Peter Nordlander - 2000
			Author      :	Peter Nordlander	  																										 	
			Created     :	2000-12-31																															 
			Last Update :		               																							 
			Descr				: CWin32Device2D - A pure Win32Device, uding GDI and DIB Sections.

			Rev History : 2000-12-31 - File created

==============================================================================================
*/
#ifndef __WIN32_DEVICE2D_H__
#define __WIN32_DEVICE2D_H__

//============================================================================================
// Includes
//================================================================================
#include "..\core\if_device2d.h"
#include "..\core\core_format.h"
#include "..\core\core_blitter.h"
#include "win32_surf.h"
#include "win32_win.h"

//================================================================================
// Default config params
//================================================================================
#define WIN32_DEVICE2D_DEFAULT_ALIGN   "CENTER"
#define WIN32_DEVICE2D_DEFAULT_WIDTH	 "640"
#define WIN32_DEVICE2D_DEFAULT_HEIGHT	 "480"
#define WIN32_DEVICE2D_DEFAULT_TITLE	 "Win32 Device Application"
#define WIN32_DEVICE2D_DEFAULT_CAPTION "TRUE"
#define WIN32_DEVICE2D_DEFAULT_XPOS    "320"
#define WIN32_DEVICE2D_DEFAULT_YPOS    "200"

//============================================================================================
// Namespace Aurora
//============================================================================================
namespace Aurora {

//============================================================================================
// Class or method implementations
//============================================================================================
	class CWin32Device2D : public CDevice2D
	{
	
	public:
    /**
     * Constructor, Destructor
     */
		CWin32Device2D::CWin32Device2D();
		virtual ~CWin32Device2D();

    /**
     * open, close...
     */
		void open();
		void close();

    /**
     * update() updates screen with <surface>,
     * and check window's message queue for qued messages,
     */
		void update(CSurface &surface);
		
    /**
     * Methods for retrieving a device's properties
     */
		int	 getWidth () const { return m_width; }
		int	 getHeight() const { return m_height;}
		int	 getPitch () const { return m_pitch; }
		void getPixelFormat(CPixelFormat &pixelformat) const {pixelformat = m_pixelFormat; }	
	
	protected:
    /**
     * checkReconfig() - when opening an already opened device
     * this method is called to see if any configuration has
     * occured, and does then takes appropriate actions
     * returns false and closes the device if needed,
     * otherwise makes the changes runtime and return true - 
     * indicating to the device that it do not need to be reopened
     */
    bool checkReconfig();

		/**
     * reset all properties to default
     */
		void reset();

		/**
     * Win32Device2D properties
     */
		bool					m_opened;				// device open state
		bool					m_caption;			// window has caption (true or false)
    int           m_xpos;         // window's x position
    int           m_ypos;         // window's y position
		int						m_width;				// width of window
		int						m_height;				// height of window
		int						m_pitch;				// bytes per pixel
		CPixelFormat	m_pixelFormat;	// device's pixelformat.
		CWin32Window  m_window;				// device output window
		CWin32Surface m_backBuffer;		// device backbuffer
		CBlitter      m_blitter;			// device blitter
		std::string   m_title;				// window's title
    static int    m_refCount;     // reference counter, keeps track of amout of allocated devices
	};

} // end namespace Aurora

#endif