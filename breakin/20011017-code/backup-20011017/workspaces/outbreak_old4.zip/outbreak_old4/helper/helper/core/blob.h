#ifndef HELPER_BLOB_H
#define HELPER_BLOB_H

#include "typedefs.h"

/* Author: Breakin
   Remark: (TODO; comment on design pattern)
   Ideas:  Perhaps do a sub-blob-design so that one can construct a blob from a part
           of another blob w/o allocating memory.

           Blob a(1000);
		   Blob b(a, 10, 60);

           Might be very good for ICP-decoders, archive not using compression (byte 1000-100000 is one file)
		   and so on. Til then a Blob(a,10,60) that _does_ a copy might be good.
*/

namespace Helper {
	
	class Blob {
	private:

		class BlobRef {
		public:

			uint8 *mBuffer;
			int    mSize;
			int    refCount;
		};

		BlobRef *blobRef;

		inline void makeUniqueCopy();

	public:

		Blob();
		Blob(const Blob &other);
		Blob(const int size);
		Blob(const uint8 * const memory, const int size);
		~Blob();

		void operator=(const Blob &other);

		// This method will resize the blob
		void resize(const int newSize, const bool keepData=false);

		// This will clear the Blob, making it a null-blob
		inline void clear();

		// This will init the Blob with a copy of memory/size
		void setMemory(const uint8 * const memory, const int size);

		// This will give the Blob memory/size. Blob will delete the pointer by itself using delete []
		void giveMemory(uint8 *memory, const int size);

		// Give the pointer and the ownership (the one that deletes) to the user (delete using delete[])
		// The blob will be a null-blob from this on.
		uint8* takePointer();

		inline const bool isEmpty() const { return (blobRef==0 || blobRef->mBuffer==0); }
		inline const int  getSize() const { return ((blobRef==0) ? 0 : blobRef->mSize); }
		
		// get is not allowed on null-blobs!
		inline const uint8 * const getReadOnly() const { return (blobRef ? blobRef->mBuffer : 0); }

		inline uint8 * get() {
			makeUniqueCopy();
			return blobRef->mBuffer;
		}

		inline const uint8 get(const int index) const { return blobRef->mBuffer[index]; }

		inline void set(const int index, const uint8 value) {
			makeUniqueCopy();
			blobRef->mBuffer[index]=value;
		}
	};
}

#endif