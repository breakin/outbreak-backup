#ifndef HELPER_DEMO_C64_H
#define HELPER_DEMO_C64_H

#include <helper\core\imagedrawer\imagedrawer.h>
#include <helper\win32\win32_device2d.h>

#include <string>

namespace Helper {

	class C64 {
	private:
		// Font stuff
		int32 fontWidth, fontHeight;
		int32 color[16];
		int32 foreground, background;

		// Fontdata and colordata for the images.
		Helper::Image32 fontData[256];
		int32 fontDataColor[256];

		// Drawer used by font and various.
		Helper::ImageDrawer drawer;

		// Functions to help drawLetter to set the right colour on the fontData.
		void clearBackground(Helper::Image32& dest, const int32 x, const int32 y);
		void clearFontRGB(const uint8 sign);
		void clear(const uint32 clearColor);

	public:
		enum {
			COLOR_BLACK      = 0,
			COLOR_WHITE      = 1,
			COLOR_RED        = 2,
			COLOR_CYAN       = 3,
			COLOR_PURPLE     = 4,
			COLOR_GREEN      = 5,
			COLOR_BLUE       = 6,
			COLOR_YELLOW     = 7,
			COLOR_ORANGE     = 8,
			COLOR_BROWN      = 9,
			COLOR_LIGHTRED   = 10,
			COLOR_DARKGREY   = 11,
			COLOR_GREY       = 12,
			COLOR_LIGHTGREEN = 13,
			COLOR_LIGHTBLUE  = 14,
			COLOR_LIGHTGREY  = 15,

			// Window colors
			COLOR_FRAME              = 2,
			COLOR_FRAMEBACKGROUND    = 1,

			// Actionbutton colors.
			COLOR_ACTION             = 0,
			COLOR_SELECTED           = 1,
			COLOR_SELECTEDBACKGROUND = 2,

			// Standard colour for text
			COLOR_TEXT               = 6,
		};

		// 2d-device to be used as the c64.
		Helper::Win32Device2D winDevice;
		Helper::Image32 screen;
		Helper::Msg     msg;

		// Constructor / Destructor.
		C64(Helper::Image32& fontImage);
		~C64();

		// Font-routines.
		uint32 getRGBColor(const uint8 index);
		void setColor(const int32 foreground, const int32 background);

		void drawLetter(Helper::Image32& dest, const int32 x, const int32 y, const uint8 sign);
		void drawString(Helper::Image32& dest, const int32 x, const int32 y, const std::string input);

		void Helper::C64::drawWindow(const int left, const int top, const int right, const int bottom, const std::string caption="");
	};

}

#endif