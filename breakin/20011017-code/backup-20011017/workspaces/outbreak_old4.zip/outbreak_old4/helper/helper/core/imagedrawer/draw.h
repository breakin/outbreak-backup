#ifndef __STANDARD_BLITTER__
#define __STANDARD_BLITTER__

//============================================================================================
// Includes
//============================================================================================
#include "..\image32.h"
#include "..\area.h"

 
//============================================================================================
// Namespace Aurora
//============================================================================================
namespace Helper {

//============================================================================================
// Class or method implementations
//============================================================================================
class Drawer
{		
 
	public:

	/**
	 * scale/zoom methods, bilinear and linear
	 */
	virtual void scale			(uint32 *srcSurface, const AreaInt &srcArea, int srcPitch,
								 uint32 *dstSurface, const AreaInt &dstArea, int dstPitch);
	virtual void scale_bilinear	(uint32 *srcSurface, const AreaInt &srcArea, int srcPitch, 
								 uint32 *dstSurface, const AreaInt &dstArea, int dstPitch);

	/**
	 * copy and clear
	 */
	virtual void copy		(uint32 *srcPixels, uint32 *dstPixels, int pixelCount);
	virtual void clearRGB	(uint32 *dstPixels, int width, int height, int pitch);
	virtual void clearARGB	(uint32 *dscPixels, int width, int height, int pitch);

	/**
	 * blit methods, copies data and applies some sort of maniuplation
	 * of data as well.
	 */
	virtual void blit				(uint32 *srcPixels, uint32 *dstPixels, int width, int height, int srcPitch, int dstPitch);
	virtual void blit_alpha			(uint32 *srcPixels, uint32 *dstPixels, int width, int height, int srcPitch, int dstPitch);
	virtual void blit_colorkey		(uint32 *srcPixels, uint32 *dstPixels, int width, int height, int srcPitch, int dstPitch);
	virtual void blit_colorkey_alpha(uint32 *srcPixels, uint32 *dstPixels, int width, int height, int srcPitch, int dstPitch);

};


}// end namespace

#endif