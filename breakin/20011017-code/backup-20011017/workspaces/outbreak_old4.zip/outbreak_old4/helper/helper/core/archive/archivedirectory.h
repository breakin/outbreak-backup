#ifndef HELPER_ARCHIVE_ARCHIVEDIRECTORY_H
#define HELPER_ARCHIVE_ARCHIVEDIRECTORY_H

#include "archive.h"
#include <map>

namespace Helper {

	class ArchiveDirectory : public Archive {
	private:

		// ---------------------------------------
		class FileDirectory : public File {
		private:

			ArchiveDirectory *mContext;

		public:

			void setContext(ArchiveDirectory *context) { mContext=context; }

			virtual Blob get() const;
			virtual void remove();
		};
		
		// ---------------------------------------
		std::string                          mDirectoryName;
		std::map<std::string, FileDirectory> mFileList;		

		// Implementation dependant methods
		void   initialize();
		void   createRootDirectory(const std::string &directoryName);

		void   remove (const std::string &fileName);
		Blob   getData(const std::string &fileName, const int bytesToRead) const;

		friend FileDirectory;

	public:

		ArchiveDirectory(const std::string &directoryName="");
		virtual ~ArchiveDirectory();

		// Creates a directory relative to mDirectoryName, not relative working path.
		void createDirectory(const std::string &directoryName);

		virtual const int   getFileCount() const;

		virtual const File &getFile(const std::string &fileName) const;
		virtual const File &getFile(const int fileIndex) const;

		virtual const bool  isExist(const std::string &fileName) const;

		virtual void createFile(const std::string &fileName, const Blob &source);
	};
}

#endif
