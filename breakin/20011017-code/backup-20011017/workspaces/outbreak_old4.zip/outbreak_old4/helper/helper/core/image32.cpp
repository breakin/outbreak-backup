#include "image32.h"
#include "exception.h"
#include <memory.h>

// ---------------------------------------------------------------------------

Helper::Image32::Image32() : image32Ref(0) {
}

// ---------------------------------------------------------------------------

Helper::Image32::Image32(const Image32 &other) : image32Ref(other.image32Ref) {
	if (this==&other) throw Helper::Exception("Image32::Image32(other); this==&other");
	if (image32Ref) image32Ref->refCount++;
}

// ---------------------------------------------------------------------------

Helper::Image32::Image32(const int width, const int height) : image32Ref(0) {
	resize(width,height);
}

// ---------------------------------------------------------------------------

Helper::Image32::~Image32() {
	clear();
}

// ---------------------------------------------------------------------------

void Helper::Image32::operator=(const Image32 &other) {
	if (image32Ref==other.image32Ref) return; // this will also reject this=&other

	clear();

	image32Ref=other.image32Ref;
	if (image32Ref) image32Ref->refCount++;	
}

// ---------------------------------------------------------------------------

void Helper::Image32::clear() {
	
	if (image32Ref) {
		if (image32Ref->refCount==1) {
			delete [] image32Ref->mBuffer;
			delete image32Ref;
		} else {
			image32Ref->refCount--;
		}

		image32Ref=0;
	}	
}

// ---------------------------------------------------------------------------

void Helper::Image32::makeUniqueCopy() {
	if (image32Ref && image32Ref->refCount!=1) {

		// We've gotta make a copy in order to get the image32 unique		
		Image32Ref *temp=new Image32Ref;

		temp->refCount=1;
		temp->mWidth=image32Ref->mWidth;
		temp->mHeight=image32Ref->mHeight;
		
		temp->mArea.set(0,0,image32Ref->mWidth,image32Ref->mHeight);
		
		temp->mBuffer=new uint32[image32Ref->mWidth*image32Ref->mHeight];

		memcpy(temp->mBuffer, image32Ref->mBuffer, (image32Ref->mWidth*image32Ref->mHeight)*sizeof(uint32));

		image32Ref->refCount--;

		image32Ref=temp;
	}
}

// ---------------------------------------------------------------------------

void Helper::Image32::resize(const int width, const int height) {

	if (width<=0 || height<=0) throw Helper::Exception("Image32::resize; width or height <=0");

	if (!image32Ref) {
		image32Ref=new Image32Ref;
		image32Ref->mBuffer=new uint32[width*height];
		image32Ref->mWidth=width;
		image32Ref->mHeight=height;
		image32Ref->mArea.set(0,0,width,height);
		image32Ref->refCount=1;
	} else {
		if (image32Ref->refCount==1) {
			delete [] image32Ref->mBuffer;
			image32Ref->mBuffer=new uint32[width*height];
			image32Ref->mWidth=width;
			image32Ref->mHeight=height;
			image32Ref->mArea.set(0,0,width,height);
		} else {
			clear();
			Image32Ref *temp=new Image32Ref;
			temp->refCount=1;
			temp->mBuffer=new uint32[width*height];
			temp->mWidth=width;
			temp->mHeight=height;
			temp->mArea.set(0,0,width,height);
			image32Ref=temp;
		}
	}    
}

// ---------------------------------------------------------------------------