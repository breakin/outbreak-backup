/*
	Author  : Albert Sandberg (thec^outbreak)
	Purpose : Demonstrate the script system with unique effect classes.
*/

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/win32/win32_device2d.h>

#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include <helper/core/xml/xmlparser.h>
#include <helper/core/clock.h>
#include <helper/core/exception.h>

#include <fstream>
#include <conio.h>
#include <windows.h>
#include <math.h>

using namespace Helper;
using namespace std;



class EffectBackground : public Effect {
private:
	Helper::Image32* screen;
public:
	EffectBackground(Helper::Image32& screen) {
		this->screen = &screen;
	}

	void update(const float64 delta, const float64 percent) {
		uint32* pixel = (uint32*)screen->getPixels();
		for (int y=0, o=0; y<screen->getHeight(); y++) {
			for (int x=0; x<screen->getWidth(); x++, o++) {
				pixel[o] = x^(int(y*percent));
			}			
		}
	}
};



class EffectCircle : public Effect {
private:
	Helper::Image32* screen;
	float64 angle;

	void drawDot(int x, int y) {

		uint32* pixel = (uint32*)screen->getPixels();

		pixel[y*screen->getWidth()+x]     = 0xffff00;
		pixel[(y+1)*screen->getWidth()+x] = 0xffff00;
		pixel[(y-1)*screen->getWidth()+x] = 0xffff00;
		pixel[y*screen->getWidth()+x-1]   = 0xffff00;
		pixel[y*screen->getWidth()+x+1]   = 0xffff00;
	}

public:
	EffectCircle(Helper::Image32& screen) {
		angle = 0;
		this->screen = &screen;
	}

	void update(const float64 delta, const float64 percent) {
		int halfx = screen->getWidth()>>1;
		int halfy = screen->getHeight()>>1;

		for (int i=0; i<20; i++) {
			drawDot(halfx + sin(angle + (6.28/8)*i)*150, halfy + cos(angle + (6.28/8)*i)*150);
		}
		angle+=0.04;
	}
};


	
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevinst, LPSTR cmdline, int showstate)
//void main(void)
{
	try {

		XmlParser in(std::ifstream("script/script.xml"));

		// Open 2d -device
		Helper::Win32Device2D	device2d;
		device2d.config("width","640");
		device2d.config("height","480");
		device2d.config("caption","true");
		device2d.open();

		// Create backbuffer
		Helper::Image32 screen(640,480);

		// Create effects.
		EffectBackground effectBackground(screen);
		EffectCircle     effectCircle(screen);

		// Initialize script, the effects are drawn in the order they are entered.
		// We will be able to move the effects around in the editor later.
		Script script(in);
		script.addCallback("intro", "background", &effectBackground);
		script.addCallback("intro", "circle",     &effectCircle);

		Clock timer;
		bool  exit = false;

		while (!exit) {
			exit = !script.update(timer.get());

			device2d.update(screen);
			Msg msg;
			if (device2d.getMessage(msg)) {
				if (msg.message == Helper::Msg::MSG_QUIT) break;
			}
		}

		XmlParser out;
		script.save(out);
		out.writeXml(std::ofstream("script/script_out.xml"));
	}
	
	// Helper::Exception is derived from std::exception so this handler is redundant, included it anyway
	catch (Helper::Exception &e) {
		MessageBox(NULL, e.what(), "Helper::Exception", MB_OK);
	}

	catch (...) {
		MessageBox(NULL, "Unknown exception", "...::Exception", MB_OK);
	}

	return 42;
}