#include <helper/core/xml/xmltag.h>
#include <helper/core/exception.h>
#include <iostream>
#include <conio.h>

using namespace Helper;

void main(void) {

	try {

		char test[500];

		sprintf(test, "<test namn1=%cvalue1 value2%c param2=value3><tag2 / >", '"','"');

		Blob blob((unsigned char*)test, strlen(test));

		XmlTag t1,t2;
		int a=t1.parse(blob, 0);
		      t2.parse(blob, a);

		std::cout << "Tag1: " << t1 << std::endl;
		std::cout << "Tag2: " << t2 << std::endl;
	}

	catch (Exception &e) {
		std::cout << "Error: " << e.what() << std::endl;
	}

	getch();
}