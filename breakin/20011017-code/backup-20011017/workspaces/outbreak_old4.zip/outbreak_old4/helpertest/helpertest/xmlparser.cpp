#include <helper/core/xml/xmlparser.h>
#include <helper/core/exception.h>
#include <iostream>
#include <fstream>
#include <conio.h>

using namespace Helper;

void main(void) {

	try {

		char test[500];
		sprintf(test, "<test a=b><hejsan c=d><aaa/><bbb/><ccc/><aga></aga></hejsan></test>");
		Blob blob((unsigned char*)test, strlen(test));

		XmlParser x(blob);

		x.writeXml(std::ofstream("test.xml"));
	}

	catch (Exception &e) {
		std::cout << "Error: " << e.what() << std::endl;
	}

	getch();
}