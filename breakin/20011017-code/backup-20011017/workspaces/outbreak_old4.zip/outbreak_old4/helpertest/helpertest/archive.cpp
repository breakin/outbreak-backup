#include <helper/archive/archive.h>
#include <conio.h>
#include <helper/archive/archivedirectory.h>
#include <iostream>

using namespace Helper;
using namespace std;

void main(void) {
	
	ArchiveDirectory a("test/hejsan/mojsan");

	cout << a.getFiles() << endl;
	cout << "true;  " << a.isExist("mapp2/mapp2file.txt") << endl;
	cout << "false; " << a.isExist("finns ej.txt") << endl;

	cout << "size;  " << a.getFileSize("mapp2/mapp2file.txt") << endl;
	cout << "size;  " << a.getFileSize("mapp2/mapp2filef.txt") << endl;

	int b;
	const uint8 *gah=a.getFile("mapp2/hej.txt", b);

	cout << "Bytes: " << b << endl << "[";
	for (int C=0; C<b; C++) cout << gah[C];
	cout << "]" << endl;	

	getch();
}