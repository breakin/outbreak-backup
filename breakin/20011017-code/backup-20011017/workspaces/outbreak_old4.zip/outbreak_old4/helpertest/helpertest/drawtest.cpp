#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/win32/win32_device2d.h>
#include <helper/core/tga/tga.h>
#include <helper/core/log.h>
#include <math.h>

using namespace Helper;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevinst, LPSTR cmdline, int showstate)
//void main()
{
	
	Helper::Image32			texture;
	Helper::Image32			backbuffer;
	Helper::Win32Device2D	device2d;
	Helper::Msg				msg;
	Helper::TGALoader		loader;
	Helper::ImageDrawer     drawer;


	/**
	 * Initialize and config 2d device
	 */
	

	device2d.config("width","640");
	device2d.config("height","480");
	device2d.config("caption","true");
	device2d.open();

	/**
	 * Create Images
	 */
	
	debugLog(Log::APPL,"MAIN", "Creating Images");

	texture.create(256,256);
	backbuffer.create(640,480);

	debugLog(Log::APPL,"MAIN", "Load TGA texture");

	loader.load("helpertest/texture.tga",texture);

	bool run = true;
	Helper::AreaInt dstArea;

	dstArea.top    = 0;
	dstArea.left   = 0;
	dstArea.width  = 128;
	dstArea.height = 128;
	
	float deg = 0;

	debugLog(Log::APPL,"MAIN", "Entering Mainloop");
	//drawer.draw(texture,texture.getArea(),backbuffer,0,0,drawer.BLIT_ALPHABLEND);
	drawer.draw(texture,texture.getArea(),backbuffer,backbuffer.getArea(),drawer.BLIT_ALPHABLEND);
	device2d.update(backbuffer);

	while (run)
	{
		
		if (device2d.getMessage(msg,true))
		{
			debugLog(Log::APPL,"MAIN", "Got Message from device");
			switch (msg.message)
			{
				case Helper::Msg::MSG_QUIT:
				case Helper::Msg::MSG_KEYDOWN:
				debugLog(Log::APPL,"MAIN", "Gettin outofhere!!");
				run = false;
				break;
			}
		}

		dstArea.width = (int)(128.0 + sin(deg) * 64.0);
		dstArea.height= (int)(128.0 + cos(deg) * 64.0);
		
		deg += 0.05;
		if (deg>6.28) deg = 0;


		device2d.update(backbuffer,false);
		drawer.clear(backbuffer,backbuffer.getArea());
	}

	return 1;
}
