#include <windows.h>
#include <helper/core/exception.h>
#include <helper/core/imagetool/imagetool.h>
#include <helper/core/archive/archivedirectory.h>

using namespace Helper;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevinst, LPSTR cmdline, int showstate) {

	try {

		ImageTool it;
		ArchiveDirectory a("target");

		Image32 inputImage=it.decode(a.getFile("a"));

		Blob outputFile=it.encode(inputImage, ".tga");

		a.createFile("texture_out2.tga", outputFile);
	}

	catch (Helper::Exception &e) {
		MessageBox(NULL, e.what(), "Helper::Exception", MB_OK);
	}

	return true;
}