#include <helper\core\imagedrawer\imagedrawer.h>
#include <helper\core\demo\console\c64.h>
#include <helper\win32\win32_device2d.h>
#include <helper\core\tga\tga.h>
#include <windows.h>
#include <math.h>

using namespace Helper;
using namespace std;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevinst, LPSTR cmdline, int showstate)
//int main()
{
	/**
	 * use a win32device2d, until we have a devicemanager,
	 * we can use the API specific devices.
	 */
	Helper::Win32Device2D winDevice;
	Helper::Win32Device2D winDevice2;
	Helper::Image32 image;
	Helper::Image32 image2;
	Helper::Msg     msg;
	Helper::Config  cfg;
	Helper::ImageDrawer drawer;
	Helper::TGALoader tgaLoader;
	
	// image data 
	Helper::uint32 *pixelsz;
	
	
	/**
	* The devices are configured by calling the config(std::string, std::string)
	* method.
	* A config map can also be exported and imported into the devices by
	* using setConfig(Helper::Config&) and getConfig(Helper::Config&)
	*/
	
	// config device
	winDevice.config("CAPTION","TRUE");
	winDevice.config("TITLE","Hey it works!");
	winDevice.config("XPOS","600");
	winDevice.config("YPOS","100");
	winDevice.config("WIDTH","320");
	winDevice.config("HEIGHT","240");
	
	/**
	* Lets say that we now want to create another,
	* almost identical device. We can then export
	* a device's config map, change it, and then
	* import it to a new device
	*/
	winDevice.getConfig(cfg);
	
	// just change left position
	// and import the cfg
	winDevice.config("TITLE","Subwindow maniac!");
	cfg.set("XPOS","100");
	cfg.set("WIDTH","128");
	cfg.set("HEIGHT","128");
	winDevice2.setConfig(cfg);
	
	/**
	* When configured,
	* open devices
	*/
	winDevice.open();
	winDevice2.open();
	
	
	// create the images
	image.create(320,240);
	image2.create(128,128);
	
	// clear both images
	drawer.clear(image,image.getArea());
	drawer.clear(image2,image2.getArea());
	
	// Load the font image.
	Helper::Image32 font;
	font.resize(128,128);
	tgaLoader.load("test\\c64.tga",font);

	uint32* pixels = (uint32*)font.getPixels();
	uint32* pixels2 = (uint32*)image2.getPixels();
	for (int ix=0; ix<128*128; ix++) {
		uint8 alpha  = pixels[ix]>>24;
		pixels2[ix]  = (alpha<<16) + (alpha<<8) + alpha;
	}

	// Create the c64 "device".
	Helper::C64 c64(font);

	/**
	 * All devices inherits from MsgQueue, so
	 * you can easily add and get messages from
	 * them.
	 */
	while (1)
	{
		// put out some dots
		pixelsz = (Helper::uint32*) image.getPixels();
		for (int Y=0, offset=0; Y<240; Y++) {
			Helper::uint32 color2 = ((rand()%255)<<8) + ((rand()%255));
			for (int X=0; X<320; X++, offset++) {
				pixelsz[offset] = color2;
			}
		}
	
		// Change color with random and draw letter.
		for (int a=0; a<27; a++) {
			for (int b=0; b<16; b++) {
				c64.setColor(rand()%16, rand()%16);
				c64.drawLetter(image, 50+a*8,50+b*8, rand()%256);
			}
		}

		/**
		 * set to last parameter to true <infiniteWait>
		 * if msgqueue is busy adding a message,
		 * getMessage will wait for it to be done
		 * set to false to return imediately
		 * getMessage returns true if message was retrieved
		 */
		
		// let then first windevice control both devices
		// and poll messages from that one only
		
		if (winDevice.getMessage(msg,true)) {
			if (msg.message == Helper::Msg::MSG_QUIT) break;
			if (msg.message == Helper::Msg::MSG_KEYDOWN) break;
		}
		if (winDevice2.getMessage(msg,true)) {
			if (msg.message == Helper::Msg::MSG_QUIT) break;
			if (msg.message == Helper::Msg::MSG_KEYDOWN) break;
		}
		
		winDevice.update(image,true);
		winDevice2.update(image2,true);
	}
	
	return 1;
}
