#ifndef PLURAL_PLURAL_H
#define PLURAL_PLURAL_H

#include "plural/object/object.h"

#include "plural/object/scene/scene.h"

#include "plural/object/camera/camera.h"

#include "plural/object/light/light.h"
#include "plural/object/light/lightomni.h"

#include "plural/device3d/device3d.h"
#include "plural/device3d/opengl/opengl.h"

#include "plural/common/exception.h"

#ifdef WIN32
	#include "plural/device3d/d3d/d3d.h"
#endif

#endif
