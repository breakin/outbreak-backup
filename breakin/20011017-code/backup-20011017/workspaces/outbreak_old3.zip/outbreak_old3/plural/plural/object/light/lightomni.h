#ifndef PLURAL_LIGHT_LIGHTOMNI_H
#define PLURAL_LIGHT_LIGHTOMNI_H

#include "light.h"

namespace Plural {

	class LightOmni : public Light {
	private:

		double				fallOff;

	public:

		LightOmni(const std::string &newName="unknown");
		LightOmni(const std::string &newName, const MathFreak::Vector &newPosition, const MathFreak::Vector &newColor, const double newStrength, const double newFallOff);
		virtual ~LightOmni();

		const double &getFallOff() const { return fallOff; }
		void setFallOff(const double newFallOff) {	fallOff=newFallOff;	}

		void set(MathFreak::Vector &newPosition, MathFreak::Color &newColor, const double newStrength, const double newFallOff) {
			Light::set(newPosition,newColor,newStrength);
			setFallOff(newFallOff);
		}

		void lighten(Object *object) { object->lighten(*this); }
	};
}

#endif