#include "opengl.h"
#include "../../common/exception.h"

Plural::Device3dOpenGL::Device3dOpenGL() : Device3d(), running(false) {
	reset();
}

Plural::Device3dOpenGL::~Device3dOpenGL() {
	if (running==true) close();
}

void Plural::Device3dOpenGL::reset() {
	if (running==true) close();
}

void Plural::Device3dOpenGL::init() {
	if (running==true) throw Exception("Plural::Device3dOpenGL::close; Already running!");

	running=true;
}

void Plural::Device3dOpenGL::close() {
	if (running==false) throw Exception("Plural::Device3dOpenGL::close; Not running!");

	running=false;
}

void Plural::Device3dOpenGL::update() {
	if (running==false) throw Exception("Plural::Device3dOpenGL::update; Not running!");
}

void Plural::Device3dOpenGL::config(const std::string &field, const std::string &value) {
}

void Plural::Device3dOpenGL::drawPolygons(std::vector<StandardFace> &faceList, 
									   std::vector<StandardVertex> &vertexList,
									   std::vector<MathFreak::Vector3> &normalList,
									   std::vector<MathFreak::Vector2> &textureCoordinateList) {

	if (running==false) throw Exception("Plural::Device3dOpenGL::drawPolygons; Not running!");
}