#ifndef PLURAL_OBJECT_H
#define PLURAL_OBJECT_H

#include <fmath/vector.h>
#include <fmath/bsphere.h>
#include <fmath/frustum.h>
#include <fmath/matrix.h>
#include <string>

namespace Plural {

	class LightOmni;
	class Device3d;

	class Object {
	public:

		enum RenderMode { OBJECT, CHILDREN };

	protected:

		std::string				name;
		std::vector<Object*>	childrens;

		MathFreak::BSphere		boundingSphere;

		// Contains the transform to be used when rendering (to-worlspace)
		// Multiplied with parent-matrix
		MathFreak::Matrix		transform;

		// Contains the transform to translate vertices into object-space
		MathFreak::Matrix		transformObjectSpace;

	public:

		Object(const std::string &newName="unknown");
		virtual ~Object();

		// Return value BSphere::{OUTSIDE|INSIDE|PARTIALLY}
		const int isInside(const MathFreak::Frustum &frustum) const { return frustum.test(boundingSphere); }

		// Return value BSphere::{OUTSIDE|INSIDE|PARTIALLY}
		const int isInside(const MathFreak::BSphere &bSphere) const { return bSphere.test(boundingSphere); }

		const std::string &getName() const { return name; }
		const MathFreak::Matrix &getTransformObjectSpace() const { return transformObjectSpace; }
		const MathFreak::Matrix &getTransform() const { return transform; }

		// Add a child to this object (notice, give pointer!)
		void addChild(Object *other);

		// Render
		virtual void render(Device3d &device3d, const int renderMode=OBJECT|CHILDREN);

		// Update keyframing to time 'time'
		// Here is were hiarchies are fixed too
		// An object should calculate transformObjectSpace from keyframing infromation
		// and then call Object::keyframe(time,parent,renderMode);
		virtual void keyframe(const double time, const MathFreak::Matrix &parent, const int renderMode=OBJECT|CHILDREN);
		virtual void keyframe(const double time, const int renderMode=OBJECT|CHILDREN);

		// Lighten by different light-types.
		// We define lighten as a NULL method so that all objects that don't define lighten(x) still will work
		virtual void lighten(const LightOmni &lightOmni, const int renderMode=OBJECT|CHILDREN);
	};
}

#endif