
#include "d3d.h"
#include <iostream.h> // TODO

void Plural::Device3dD3D::enumerate() {

	// Devicemodes, move to enumerate
	configData["device"].value="0,0,0";
	std::string &type=configData["device"].type;

	type="multilist<combo<s>,combo<s>,list<n=Width{{The width of the display window}},n=Height{{The height of the display windom}},n=Bitdepth{{The bitdepth of the display window}},n=Zbuffer{{Bitdepth of the z-buffer}},n=Refresh Rate{{The refreshrate for the requested display mode - frames per second}}>>";

	OutputDebugString("->Enumerate\n");

	DirectDrawEnumerateEx(	DriverEnumCallback, this, 
							DDENUM_ATTACHEDSECONDARYDEVICES |
							DDENUM_DETACHEDSECONDARYDEVICES |
							DDENUM_NONDISPLAYDEVICES );

	type+="<";	
	for (int C=0; C<driverList.size(); C++) {
		if (C!=0) type+="|";
		driverList[C].createSetupInfo(type);
	}
	type+=">";	

	cout << type.c_str() << endl;
}

static HRESULT WINAPI Plural::EnumZBufferFormatsCallback( DDPIXELFORMAT* pddpf, VOID* parent ) {

	OutputDebugString("menzbuf\n");
	
	Device3dD3D::Driver::Device3d *device3d=static_cast<Device3dD3D::Driver::Device3d*>(parent);
	device3d->addZBuffer(pddpf);

    return D3DENUMRET_OK;
}

static HRESULT WINAPI Plural::DeviceEnumCallback( char* strDesc, char* strName, D3DDEVICEDESC7* pDesc,VOID* parent) {

	OutputDebugString("      Device3d\n");

	Device3dD3D::Driver	*driver=static_cast<Device3dD3D::Driver*>(parent);

	/* TODO
	//Avoid duplicates: only enum HW devices for secondary DDraw drivers.
	if( NULL != pDeviceInfo->pDriverGUID && FALSE == pDeviceInfo->bHardware ) {
		cout << "  ignore due to duplication" << endl;
		return D3DENUMRET_OK;
	}
	*/

	Device3dD3D::Driver::Device3d *device3d=NULL;
	driver->addDevice3d(pDesc, strName, strDesc, device3d);

    driver->getLPDIRECT3D7()->EnumZBufferFormats( pDesc->deviceGUID, EnumZBufferFormatsCallback, device3d );
	
	return DDENUMRET_OK;
}

static HRESULT WINAPI Plural::ModeEnumCallback( DDSURFACEDESC2* pddsd,VOID* parent) {
	OutputDebugString("      Mode\n");

	Device3dD3D::Driver	*driver=static_cast<Device3dD3D::Driver*>(parent);

	driver->addMode(pddsd);

	return DDENUMRET_OK;
}

static BOOL WINAPI Plural::DriverEnumCallback( GUID* guid, char* strDesc,char* strName, VOID* parent, HMONITOR ) {
	OutputDebugString("    Driver\n");

	Device3dD3D	*device=static_cast<Device3dD3D*>(parent);

	LPDIRECTDRAW7 pDD;

	Device3dD3D::Driver *driver=NULL;
    
	// Use the GUID to create the DirectDraw object
	if(FAILED(DirectDrawCreateEx( guid, (VOID**)&pDD, IID_IDirectDraw7, NULL ))) {
		OutputDebugString("Can't create DDraw during enumeration!");
		return D3DENUMRET_OK;
	}

	DDCAPS caps, helCaps;
	pDD->GetCaps( &caps, &helCaps);
	device->addDriver(guid, strName, strDesc, caps, helCaps, driver);

    // Enumerate the fullscreen display modes.
    pDD->EnumDisplayModes(DDEDM_REFRESHRATES, NULL, driver, ModeEnumCallback );

	LPDIRECT3D7 pD3D;
	
	// Create a D3D object, to enumerate the d3d devices
    if(FAILED(pDD->QueryInterface( IID_IDirect3D7, (VOID**)&pD3D ))) {
		pDD->Release();
		OutputDebugString("Can't query IDirect3D7 during enumeration!");
		return D3DENUMRET_OK;
    }

	driver->setLPDIRECT3D7(pD3D);

	// Now, enumerate all the 3D devices
	pD3D->EnumDevices( DeviceEnumCallback, driver );

	driver->setLPDIRECT3D7(0);
	pD3D->Release();
	pDD->Release();
 
	return DDENUMRET_OK;
}
