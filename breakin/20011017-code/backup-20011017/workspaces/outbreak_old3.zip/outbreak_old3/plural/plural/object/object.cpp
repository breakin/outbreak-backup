#include "Object.h"
#include <helper/debug.h>

Plural::Object::Object(const std::string &newName) : name(newName), transformObjectSpace(MathFreak::Matrix::ENTITY) {
	#ifdef LOGGER
		Helper::Debug log("Plural::Object::Object");
		log << "Name     [" << getName() << "]" << std::endl;
	#endif
}

Plural::Object::~Object() { 
	#ifdef LOGGER
		Helper::Debug log("Plural::Object::~Object");
		log << "Name     [" << getName() << "]" << std::endl;
	#endif

	for (int C=0; C<childrens.size(); C++) {
		delete childrens[C]; 
	}
}

void Plural::Object::addChild(Object *other) { 
	#ifdef LOGGER
		Helper::Debug log("Plural::Object::addChild");
		log << "Adding   [" << other->getName() << "] to [" << name << "]" << std::endl;
	#endif

	childrens.push_back(other); 
}

void Plural::Object::render(Device3d &device3d, const int renderMode) {
	if ((renderMode & CHILDREN) != 0) {
		for (int C=0; C<childrens.size(); C++) childrens[C]->render(device3d, renderMode);
	}
}

void Plural::Object::keyframe(const double time, const MathFreak::Matrix &parent, const int renderMode) {
	transformObjectSpace.multiply(parent,transform);

	if ((renderMode & CHILDREN) != 0) {
		for (int C=0; C<childrens.size(); C++) childrens[C]->keyframe(time,transform,renderMode);
	}
}

void Plural::Object::keyframe(const double time, const int renderMode) {
	transform=transformObjectSpace;

	if ((renderMode & CHILDREN) != 0) {
		for (int C=0; C<childrens.size(); C++) childrens[C]->keyframe(time,transform,renderMode);
	}
}

void Plural::Object::lighten(const LightOmni &lightOmni, const int renderMode) {
}

