#ifndef PLURAL_LIGHT_LIGHT_H
#define PLURAL_LIGHT_LIGHT_H

#include "../object.h"
#include <fmath/color.h>

namespace Plural {

	class Light : public Object {
	private:

		MathFreak::Vector	position;
		MathFreak::Color	color;
		double				strength;

	public:

		Light(const std::string &newName);
		Light(const std::string &newName, const MathFreak::Vector &newPosition, const MathFreak::Color &newColor, const double newStrength);

		virtual ~Light();

		const MathFreak::Vector &getPosition() const { return position; }
		const MathFreak::Color &getColor() const { return color; }
		const double &getStrength() const { return strength; }

		void set(MathFreak::Vector &newPosition, MathFreak::Color &newColor, const double newStrength) {
			setPosition(newPosition);
			setColor(newColor);
			setStrength(newStrength);
		}

		void setPosition(const MathFreak::Vector &newPosition) { position=newPosition; }
		void setColor(const MathFreak::Color &newColor) { color=newColor; }
		void setStrength(const double newStrength) { strength=newStrength;	}

		virtual void lighten(Object *object) = 0;
	};
};

#endif
