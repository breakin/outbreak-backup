
#ifndef PLURAL_COMMON_EXCEPTION_H
#define PLURAL_COMMON_EXCEPTION_H

#include <exception>

namespace Plural {

	class Exception : public exception {
	public:
		Exception(const char *message) : exception(message) {};
	};
}

#endif