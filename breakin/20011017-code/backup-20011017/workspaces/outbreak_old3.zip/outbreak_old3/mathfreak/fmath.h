
#ifndef MATHFREAK_MATHFREAK_H
#define MATHFREAK_MATHFREAK_H

#include "fmath/vector.h"
#include "fmath/matrix.h"
#include "fmath/plane.h"
#include "fmath/quat.h"
#include "fmath/bsphere.h"
#include "fmath/frustum.h"
#include "fmath/color.h"

#endif
