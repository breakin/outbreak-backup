
#ifndef MATHFREAK_MATRIX_H
#define MATHFREAK_MATRIX_H

#include "vector.h"
#include <cstring>
#include <exception>

class Vector;

// TODO: Make sure this is D3D-compatible matrix

namespace MathFreak {

	class Matrix {
	public:

		enum MatrixMode { NONE, ENTITY };

		Matrix(const MatrixMode mode=NONE);
		~Matrix();

		void clear(const MatrixMode mode=ENTITY);

		operator=(const Matrix &other);

		Matrix transform(const Matrix &other) const;
		void   transform(const Matrix &other, Matrix &result) const;

		void multiply(const Matrix &other, const Matrix &dest) {}; // TODO

		void   transform4x4(const Vector &other, Vector &result) const;
		void   transform3x3(const Vector &other, Vector &result) const;
		Vector transform4x4(const Vector &other) const;
		Vector transform3x3(const Vector &other) const;

		//Quat convertToQuat() const; // TODO	

		Matrix transponate4x4() const;
		Matrix transponate3x3() const;
		void   transponate4x4(Matrix &result) const;
		void   transponate3x3(Matrix &result) const;

		Matrix gaussInverse() const;
		void   gaussInverse(Matrix &result) const;	// DO

	protected:

		union {	// TODO: Make sure we've got d3d-matrix-style here
			float matrixDataArray[16];

			float e[4][4];					// Elements

			struct {
				float xx, xy, xz, xw;
				float yx, yy, yz, yw;
				float zx, zy, zz, zw;
				float wx, wy, wz, ww;
			};

			struct {
				float xVector[4];
				float yVector[4];
				float zVector[4];
				float wVector[4];
			};
		};
	};
}

//************************************************************************

inline MathFreak::Matrix::Matrix(const MatrixMode mode) {
	clear(mode);
}

//************************************************************************

inline MathFreak::Matrix::~Matrix() {
}

//************************************************************************

inline void MathFreak::Matrix::clear(const MatrixMode mode) {
	if (mode==ENTITY) {
		memset(matrixDataArray, 0, 16*sizeof(float));
		xx=yy=zz=ww=1.0;
	}
}

//************************************************************************

inline MathFreak::Matrix::operator=(const Matrix &other) {
	memcpy(matrixDataArray, other.matrixDataArray, 16*sizeof(float));
}

//************************************************************************

inline void MathFreak::Matrix::transform3x3(const Vector &other, Vector &result) const {
	result.x=other.x*xx+other.y*xy+other.z*xz;
	result.y=other.x*yx+other.y*yy+other.z*yz;
	result.z=other.x*zx+other.y*yz+other.z*zz;
}

inline void MathFreak::Matrix::transform4x4(const Vector &other, Vector &result) const {
	result.x=other.x*xx+other.y*xy+other.z*xz+xw;
	result.y=other.x*yx+other.y*yy+other.z*yz+yw;
	result.z=other.x*zx+other.y*yz+other.z*zz+zw;
}

inline MathFreak::Vector MathFreak::Matrix::transform3x3(const Vector &other) const {
	Vector result;
	transform3x3(other, result);
	return result;
}

inline MathFreak::Vector MathFreak::Matrix::transform4x4(const Vector &other) const {
	Vector result;
	transform4x4(other,result);
	return result;
}

//************************************************************************

inline void MathFreak::Matrix::transponate4x4(Matrix &result) const {
	result.xx=xx;
	result.xy=yx;
	result.xz=zx;
	result.yx=xy;
	result.yy=yy;
	result.yz=zy;
	result.zx=xz;
	result.zy=yz;
	result.zz=zz;

	result.xw=(-result.xw)*xx+(-result.yw)*xy+(-result.zw)*xz;
	result.yw=(-result.xw)*yx+(-result.yw)*yy+(-result.zw)*yz;
	result.zw=(-result.xw)*zx+(-result.yw)*zy+(-result.zw)*zz;
}

inline void MathFreak::Matrix::transponate3x3(Matrix &result) const {
	result.xx=xx;
	result.xy=yx;
	result.xz=zx;
	result.yx=xy;
	result.yy=yy;
	result.yz=zy;
	result.zx=xz;
	result.zy=yz;
	result.zz=zz;
}

inline MathFreak::Matrix MathFreak::Matrix::transponate4x4() const {
	Matrix result;
	transponate4x4(result);
	return result;
}

inline MathFreak::Matrix MathFreak::Matrix::transponate3x3() const {
	Matrix result;
	transponate3x3(result);
	return result;
}

//************************************************************************

inline void MathFreak::Matrix::transform(const Matrix &other, Matrix &result) const {
	for (int j=0; j<4; j++)
		for (int i=0; i<4; i++)
			result.e[i][j]=e[i][0]*other.e[0][j]+e[i][1]*other.e[1][j]+
						   e[i][2]*other.e[2][j]+e[i][3]*other.e[3][j];
}

inline MathFreak::Matrix MathFreak::Matrix::transform(const Matrix &other) const {
	Matrix result;
	transform(other, result);
	return result;
}

//************************************************************************

inline void MathFreak::Matrix::gaussInverse(Matrix &result) const { // TODO	
	throw exception("MathFreak::Matrix::gaussInverse has not been done yet!");
}

inline MathFreak::Matrix MathFreak::Matrix::gaussInverse() const {
	Matrix result;
	gaussInverse(result);
	return result;
}

//************************************************************************

#endif