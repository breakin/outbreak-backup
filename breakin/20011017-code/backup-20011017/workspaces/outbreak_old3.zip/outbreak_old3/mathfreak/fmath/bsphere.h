
#ifndef MATHFREAK_BSPHERE_H
#define MATHFREAK_BSPHERE_H

#include "vector.h"
#include "matrix.h"

namespace MathFreak {

	class BSphere
	{
	public:

		enum { OUTSIDE, PARTIALLY, INSIDE };

	protected:

		Vector	position;
		Vector	size;

		Vector	positionRotated;
		Vector	sizeRotated;

	public:

		const Vector &getPosition() const {
			return position;
		}

		const Vector &getSize() const {
			return size;
		}

		const Vector &getPositionRotated() const {
			return positionRotated;
		}

		const Vector &getSizeRotated() const {
			return sizeRotated;
		}

		void setPosition(const Vector &newPosition) {
			position=newPosition;
		}

		void setSize(const Vector &newSize) {
			size=newSize;
		}

		void transform(const Matrix &matrix) {
			//positionRotated=matrix.mul4x4(position);
			//sizeRotated=matrix.mul3x3(size);
		}

		const int test(const BSphere &other) const { return INSIDE; }
	};
}

#endif