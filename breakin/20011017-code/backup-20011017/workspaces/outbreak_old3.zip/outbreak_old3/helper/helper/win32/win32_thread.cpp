#include "win32_thread.h"

// use namespace Aurora
using namespace Helper;


// Thread router function - routs the thread to the objects
// overridden run method.
DWORD WINAPI Win32ThreadRouter(LPVOID threadInstance)
{
	((Win32Thread*)threadInstance)->run();
	return 0;
}


// Win32Thread methods
void Win32Thread::start()
{
	if (!m_isRunning)
	{
		m_threadHandle = CreateThread(0,0,(DWORD(WINAPI*)(LPVOID))Win32ThreadRouter,(LPVOID)this,0,&m_threadID);
	}
}

// Win32Thread stop
void Win32Thread::stop()
{
	if (m_isRunning && m_threadHandle!=NULL)
	{
		WaitForSingleObject(m_threadHandle,INFINITE);
		m_threadPriority= THREAD_PRIORITY_NORMAL;
		m_isRunning			= false;
		m_threadID			= 0;
		m_threadHandle	= NULL;			
	}
}

// Set Thread Priority
void Win32Thread::setThreadPriority(DWORD _priority)
{
	SetThreadPriority(m_threadHandle,_priority);
}

