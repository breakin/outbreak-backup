#ifndef HELPER_HELPER_IMAGETOOL_H
#define HELPER_HELPER_IMAGETOOL_H

/* 

  Author: Breakin
  
  ImageTool keeps a list of ImageCoder:ers and let you forget about what formats
  you are dealing with. Merely an interface to several ImageCoder:ers.

  All ImageCoders from Helper will be added automatically
 
 */

#include <vector>
#include <string>
#include "imagecoder/imagecoder.h"

namespace Helper {

	class ImageTool {
	private:

		std::vector<ImageCoder*> mCoders;

		inline ImageCoder* getDecoder(const std::string &extension) const;
		inline ImageCoder* getEncoder(const std::string &extension) const;

	public:

		ImageTool();
		~ImageTool();

		Blob encode(const std::string &destinationExtension, const Image32 &sourceImage, const ImageCoder::EncodeSettings &encodeSettings=ImageCoder::defaultEncodeSettings) const;
		void decode(Image32 &destinationImage, const Blob &sourceBlob, const std::string &sourceExtension, const ImageCoder::DecodeSettings &decodeSettings=ImageCoder::defaultDecodeSettings) const;

		// NOTICE! The ImageCoder will be deleted by ImageTool
		inline void addImageCoder(ImageCoder* imageCoder);

		inline const bool isEncoder(const std::string &extension) const;
		inline const bool isDecoder(const std::string &extension) const;
	};
};

#endif