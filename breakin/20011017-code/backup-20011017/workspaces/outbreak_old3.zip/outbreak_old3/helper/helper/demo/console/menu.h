#ifndef HELPER_DEMO_MENU_H
#define HELPER_DEMO_MENU_H

/*
	This is the menu for the console.
*/

#include "application.h"
#include "console.h"

#include <helper/typedefs.h>

namespace Helper {

	class Menu : public Application {

	private:
	public:
		Menu(const ConsoleData& consoleData);
		Application* update();
	};

}

#endif
