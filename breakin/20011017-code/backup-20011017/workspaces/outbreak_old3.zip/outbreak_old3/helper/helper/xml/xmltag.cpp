#include "xmltag.h"
#include "../exception.h"

namespace Helper {
	
	// We need to return a const reference to a string when getting a value, but if there is not value
	// for the name passed we must return a referece to an empty string and here it is!
	// Keeping a static in a namespace is silly, but ... :)

	static const std::string emptyString;
}

Helper::XmlTag::XmlTag() : closed(false) {
}

Helper::XmlTag::XmlTag(const std::string &newName) : name(newName), closed(true) {
}

Helper::XmlTag::~XmlTag() {
}

const std::string &Helper::XmlTag::getValue(const std::string &name) const {
	for (int C=0; C<arg.size(); C++) {
		if (arg[C].getName()==name) {
			return arg[C].getValue();
		}
	}

	return emptyString;
}

const bool Helper::XmlTag::getClosed() const { 
	return closed; 
}

void Helper::XmlTag::setClosed(const bool newClosed) {
	closed=newClosed;
}

void Helper::XmlTag::setName(const std::string &newName) {
	name=newName;
}

const std::string &Helper::XmlTag::getName() const { 
	return name;
}

void Helper::XmlTag::setValue(const std::string &name, const std::string &value) {

	for (int C=0; C<arg.size(); C++) {
		if (arg[C].getName()==name) {
			arg[C].setValue(value);
			return;
		}
	}

	arg.push_back(Argument(name,value));
}

void Helper::XmlTag::setValue(const std::string &name, const int value) {
	char buffer[256];
	sprintf(buffer, "%0d", value);
	setValue(name, buffer);
}

void Helper::XmlTag::setValue(const std::string &name, const float64 value) {
	char buffer[256];
	sprintf(buffer, "%.25g", value);
	setValue(name, buffer);
}

const std::vector<Helper::XmlTag::Argument> &Helper::XmlTag::getArg() const {
	return arg;
}

std::vector<Helper::XmlTag::Argument> &Helper::XmlTag::getArg() {
	return arg;
}

void Helper::XmlTag::setTag(const XmlTag &tag) {
	*this=tag;
}

// Output a XmlTag on a output-stream
std::ostream &operator<<(std::ostream &s, const Helper::XmlTag &t) {
	const std::vector<Helper::XmlTag::Argument> &a=t.getArg();

	if (a.empty()) {
		s << "<";
		if (t.getClosed()) s << "/";		
		s << t.getName();
	} else {
		s << "<" << t.getName();

		for (int C=0; C<a.size(); C++) {
			s << " " << a[C].getName() << "=" << '"' << a[C].getValue() << '"';
		}

		if (t.getClosed()) s << "/";
	}

	s << ">";

	return s;
}

// Input an xml-tag from an input stream
std::istream &operator>>(std::istream &s, Helper::XmlTag &t) {

	// Check the start-bracket
	char checkStartBracket;
	s >> checkStartBracket;
	if (checkStartBracket!='<') throw Helper::Exception("Missing '<' (eventually after whitespaces) while parsing a tag from istream.");

	std::string i;

	// Erase the current argumentlist (might be a used tag)
	t.getArg().clear();
	t.setClosed(false);

	// Read a string
	// Might be (a=b), or (a="bbbabsd/>") or (/) or > or (/>)

	enum state {
		TAGNAME,
		NAME,
		EQUALS,
		VALUE,
	} currentState=TAGNAME;
	
	std::string name, value, tagName;

	while (true) {
		if (!s) throw Helper::Exception("Unexpected end of istream while parsing a tag!");
		
		s >> i;
		
		while (!i.empty()) {

			if (!i.empty() && i[0]=='/') { t.setClosed(true); i.erase(0,1); }
			if (!i.empty() && i[0]=='>') { return s; }

			int C;

			if (!i.empty()) switch (currentState) {
			case TAGNAME:
				for (C=0; C<i.length(); C++) if (!isalnum(i[C])||i[C]=='>') break;

				if (C>0) {
					tagName=i.substr(0, C);
					for (int D=0; D<tagName.length(); D++) tagName[D]=tolower(tagName[D]);
					t.setName(tagName);
					i.erase(0,C);
					currentState=NAME;
				}
				break;

			case NAME:
				for (C=0; C<i.length(); C++) if (!isgraph(i[C]) || i[C]=='=') break;

				if (C>0) {
					name=i.substr(0, C);
					for (int D=0; D<name.length(); D++) name[D]=tolower(name[D]);
					i.erase(0,C);
					currentState=EQUALS;
				}
				break;

			case EQUALS:
				if (i[0]=='=') {
					currentState=VALUE;
					i.erase(0,1);
				}
				break;

			case VALUE:
				if (i[0]=='"') {
					i.erase(0,1);

					bool endHere=false;
					for (C=0; C<i.length(); C++) if (i[C]=='"') { endHere=true; break; }

					if (endHere) {
						value=i.substr(0, C);
						i.erase(0, C+1);
					} else {
						value=i;
						i.erase();

						char buffer[256];
						if (!s) throw Helper::Exception("Unexpected end of istream while parsing a tag!");
						s.getline(buffer, 255,'"');
						value+=buffer;
						i.erase(0,strlen(buffer));
					}
				} else {
					for (C=0; C<i.length(); C++) if (!isgraph(i[C])||i[C]=='>'||i[C]=='/') break;

					if (C>=0) {
						value=i.substr(0, C);
						for (int D=0; D<value.length(); D++) value[D]=tolower(value[D]);
						i.erase(0,C);
					}
				}

				t.setValue(name,value);
				currentState=NAME;
				break;
			}
		}
	}	
}