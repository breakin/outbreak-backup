#include "scripter.h"

#include <helper/exception.h>

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const int Helper::Scripter::findTriggerGroup(const std::string name) {
	for (int C=0; C<triggerGroupList.size(); C++) {
		if (triggerGroupList[C].name == name) {
			return C;
		}
	}
	return -1;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::Scripter::loadGroups() {
	// Loop throught the scenes and load underlying effects and triggers.
	for (int S=0; S<consoleData.script->sceneList.size(); S++) {
		Helper::Script::Scene tempScene = *consoleData.script->sceneList[S];

		for (int T=0; T<tempScene.triggerList.size(); T++) {

			Helper::Script::Trigger tempTrigger = *consoleData.script->sceneList[S]->triggerList[T];

			int triggerGroupIndex = findTriggerGroup(tempTrigger.name);

			if (triggerGroupIndex == -1) {
				// New trigger, add to grouplist.
				TriggerGroup temp;
				temp.name = tempTrigger.name;

				temp.triggerList.push_back(consoleData.script->sceneList[S]->triggerList[T]);
				triggerGroupList.push_back(temp);
			} else {
				triggerGroupList[triggerGroupIndex].triggerList.push_back(consoleData.script->sceneList[S]->triggerList[T]);
			}
		}


		// Also count the effect triggers.
		for (int E=0; E<tempScene.effectList.size(); E++) {
			for (int T=0; T<tempScene.effectList[E]->triggerList.size(); T++) {
				Helper::Script::Trigger tempTrigger = *consoleData.script->sceneList[S]->effectList[E]->triggerList[T];

				int triggerGroupIndex = findTriggerGroup(tempTrigger.name);

				if (triggerGroupIndex == -1) {
					// New trigger, add to grouplist.
					TriggerGroup temp;
					temp.name = tempTrigger.name;


					temp.triggerList.push_back(consoleData.script->sceneList[S]->effectList[E]->triggerList[T]);
					triggerGroupList.push_back(temp);
				} else {
					triggerGroupList[triggerGroupIndex].triggerList.push_back(consoleData.script->sceneList[S]->effectList[E]->triggerList[T]);
				}
			}

		}

	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Scripter::Scripter(const ConsoleData& consoleData) : Helper::Application(consoleData) {
	//if (consoleData.script == 0) throw Exception("Scripter::Scripter(); Cannot initialize scripter without a valid script.");

	//loadGroups();

	/*for (int T=0; T<triggerGroupList.size(); T++) {
		std::cout << "[" << T << "] : " << "\"" << triggerGroupList[T].name << "\" nr:" << triggerGroupList[T].triggerList.size() << std::endl;
	}
	*/
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Application* Helper::Scripter::update() {
	C64& c64 = *consoleData.c64;

	Msg msg;
	while(c64.winDevice.getMessage(msg, true)) {
		
	}

	c64.winDevice.update(c64.screen);

	// Continue to live.
	return this;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
