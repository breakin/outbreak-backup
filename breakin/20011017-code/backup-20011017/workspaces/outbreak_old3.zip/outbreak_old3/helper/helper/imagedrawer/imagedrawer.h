#ifndef __HELPER_IMAGEDRAWER_H___
#define __HELPER_IMAGEDRAWER_H___

//============================================================================================
// Includes
//============================================================================================
#include <helper\image\image32.h>
#include <helper\area.h>
#include "draw.h"

//============================================================================================
// Namespace Helper
//============================================================================================
namespace Helper {

//============================================================================================
// Class or method implementations
//============================================================================================
class ImageDrawer
{		
    public:

		enum {
			
			BLIT_NORMAL		= 0x00,
			BLIT_ALPHABLEND = 0x01,
			BLIT_SATURATION = 0x02,
			BLIT_COLORKEY	= 0x04,
		};

		enum {
			
			CLEAR_ARGB,
			CLEAR_RGB ,
		};

		enum {
		
			SCALE_BILINEAR,
			SCALE_LINEAR,
		};

		ImageDrawer()
		{
			// for now, allocate an ANSI type
			m_drawer = new Drawer;
		}

		/**
		* Standard blit, able to scale surfaces into given areas,
		* To exclude scaling (to gain performance), use the blit 
		* method with an x,y pair
		* as a destination point instead.
		* Both methods can use either BLIT_COLORKEY,BLIT_ALPHA_BLEND or BLIT_SATURATION
		* as theit blit flags.
		*/ 
		void draw (Image32 &srcSurface,const AreaInt &srcArea, Image32 &dstSurface,const AreaInt &dstArea, int bltCaps);
		void draw (Image32 &srcSurface,const AreaInt &srcArea, Image32 &dstSurface, int x, int y, int bltCaps); 

		/**
		* Copies a source surface into a destination surface.
		* Both surfaces must have same properties and Area size. 
		*/
		void copy (Image32 &srcSurface, Image32 &dstSurface); 

		/**
		* Clears a specifig Area of the surface with color 0x00000000.
		* To only clear the RGB parts, set clrFlags to CLEAR_NOT_ALPHA.
		*/
		void clear(Image32 &dstSurface, const AreaInt &dstArea, int clrCaps = CLEAR_ARGB);

		/** 
		* Set the AlphaBlend mode. Blitter uses either 
		* Per Pixel Alpha blending or a constant alphavalue
		* for the whole surface
		* set alphaMode to ALPHA_CONSTANT or ALPHA_PER_PIXEL
		*
		* To specify which way the blitter should scale surfaces
		* use setScaleMode() to choose SCALE_BILINEAR or SCALE_LINEAR
		*/
		void setAlphaMode(int alphaMode);
		void setAlphaChannel(uint8 alphaChannel);
		void setScaleMode(int scaleMode);

		/**
		* Methods for getting information about current blitter settings
		*/
		int  getScaleMode()   const { return m_scaleMode; }
		int  getAlphaMode()   const { return m_alphaMode; }
		int  getAlphaChannel()const { return m_alphaChannel;}


	protected:
	  
		/**
		 * CBlitter properties
		 */
		Helper::Drawer*	m_drawer;
		int				m_scaleMode;
		int				m_alphaMode;
		uint8			m_alphaChannel;
};


}// end namespace

#endif