#ifndef HELPER_PROFILE_TEST_H
#define HELPER_PROFILE_TEST_H

namespace Helper {

	class Profile;

	class Test {
	public:
		Test(Profile &context);
	};
}

#endif