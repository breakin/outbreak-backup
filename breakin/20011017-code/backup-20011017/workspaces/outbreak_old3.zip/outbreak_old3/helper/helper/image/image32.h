/*
==============================================================================================
																																													 
	File        : image.h 								            														   	
	Copyright(c): Peter Nordlander - 2000
	Author      : Peter Nordlander	  																										 	
	Created     : 2000-03-12																																 
	Last Update :		               																							 
	Descr		: CSurface - A Basic memorysurface - used to store images, icons and other 
							 other kinds of large memory block resources. 
							 Also very useful as a backbuffer.
							 This is the pure C/C++ version.
							 CSurface inherits from ISurface which ALL surfaces inhertits from.
							 This design issue was mostly implemented to allow the Blitter to
							 handle any kinds of surfaces, wiether its a DIRECTDRAWSURFACE, 
							 a DibSection etc. Just as they are wrapped around in a class, 
							 inheriting ISurface.

==============================================================================================
*/
#ifndef __ASURFACE_CLASS_INCLUDED__
#define __ASURFACE_CLASS_INCLUDED__

#include <stdio.h>
#include <helper\typedefs.h>
#include <helper\pixelformat.h>
#include <helper\area.h>

namespace Helper {


class Image32
{
	
	public:

		/**
		 * CSurface constructors
		 */
		Image32(int width, int height, int pixelFormatType = PixelFormat::BPP_32);
		Image32();
		~Image32();

		/**
		 * Method for creating and release a surface, pixelformat is default set 
		 * to PF_32BPP. CSurface only support 32bit surfaces
		 * Release free's all allocated surface memory
		 */
		virtual void	create(int width, int height, int pixelFormatType = PixelFormat::BPP_32);
		virtual void	release();	
		virtual void	resize(int width, int height);

		/**
		 * Set Surface transparency color
		 */
		void   setColorKey(uint32 colorkey) {m_colorKey = colorkey;}

		/**
		 * Methods for getting surface properties
		 */
		int    getPitch () const { return m_pitch ;}
		int	   getWidth () const { return m_width ;}		
		int	   getHeight() const { return m_height;}	
		void*  getPixels() const { return m_data;  }	
		void   getPixelFormat(PixelFormat &pixelformat) const { pixelformat = m_pixelFormat;}
		const  AreaInt& getArea() const { return m_area;}
	
	protected:
							
		/**
		 * CSurface properties
		 */
		PixelFormat m_pixelFormat;
		AreaInt     m_area;
		int	    	m_pitch;
		int			m_width;
		int			m_height;
		uint32		*m_data;
		uint32  	m_colorKey;

		/**
		 * CBlitterC has exclusive access to all important
		 * surface properties. 
		 */

};

} // end namespace
	
#endif __ASURFACE_CLASS_INCLUDED__

