#ifndef HELPER_STATISTICS_H
#define HELPER_STATISTICS_H

namespace Helper {

	class Statistics {
	private:

		int current, peek, total;

	public:

		Statistics() : current(0), peek(0), total(0) {
		}

		virtual ~Statistics() {};

		inline void add(const int amount) { current+=amount; total+=amount; if (current>peek) peek=current; }
		inline void subtract(const int amount) { current-=amount; }

		inline const int getCurrent() const { return current; }
		inline const int getTotal() const { return total; }
		inline const int getPeek() const { return peek; }
	};
};

#endif