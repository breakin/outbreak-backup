#ifndef HELPER_ARCHIVE_ARCHIVERAR_H
#define HELPER_ARCHIVE_ARCHIVERAR_H

#include "archive.h"
#include <map>

namespace Helper {

	class ArchiveRAR : public Archive {
	private:

		// ---------------------------------------
		class FileRAR : public Archive::File {
		private:

			ArchiveRAR *mContext;

		public:

			void setContext(ArchiveRAR *context) { mContext=context; }

			virtual Blob getData() const;
			virtual void remove();
		};
		
		// ---------------------------------------
		std::string                    mArchiveName;
		std::string                    mArchivePassword;
		std::map<std::string, FileRAR> mFileList;		

		friend FileRAR;

	public:

		ArchiveRAR(const std::string &archiveName, const std::string &archivePassword="");
		virtual ~ArchiveRAR();

		virtual const int   getFileCount() const;

		virtual const File &operator[](const std::string &fileName) const;
		virtual const File &operator[](const int fileIndex) const;

		virtual const bool  isExist(const std::string &fileName) const;

		virtual void createFile(const std::string &fileName, const Blob &source);
	};
}

#endif
