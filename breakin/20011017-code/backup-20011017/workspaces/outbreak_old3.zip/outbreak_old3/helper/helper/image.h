
#ifndef HELPER_IMAGE_H
#define HELPER_IMAGE_H

#include "typedefs.h"
#include "area.h"
#include "exception.h"
#include <vector>

namespace Helper {

	template<class channelType, int channels=4> class Image{
	private:

		channelType*	imageData;
		int				width, height;

		// We keep the area here so we don't need to create 'em all the time
		Area<int>		area;

	public:

		// Default constructor
		Image(const int initWidth=0, const int initHeight=0, const channelType * const initImageData=0)
			: imageData(0), area(), width(0), height(0) {

			resize(initWidth,initHeight,initImageData);
		}


		// Default constructor
		Image(Image<channelType, channels> &other) 
			: imageData(0), area(), width(0), height(0) {

			resize(other);
		}

		~Image() {
			if (imageData!=0) free(imageData);
			
			// By resetting to zeroes might
			// crash everything if invalid references are kept, and we want that so
			// we find em nasty bugs, especially the imageData=0-pointer
			imageData=0;
			area.setWidth(0);
			area.setHeight(0);
			height=0;
			width=0;
		}

		// Resize image, copy if data
		void resize(const int newWidth, const int newHeight, const channelType *const newImageData=0) {

			const int oldSize=width*height*channels;
			const int newSize=newWidth*newHeight*channels;

			if (newSize!=oldSize || imageData==0) {
				imageData=(uint8*)realloc(imageData, newSize*sizeof(channelType));
			
				// TODO: Maybe return badalloc, or make new have that behavior itself
				if (imageData==0) throw Helper::Exception("Could not (re)allocate memory for an Image");
			}

			if (newSize>0) {
				if (newImageData!=0) {
					memcpy(imageData, newImageData, newSize*sizeof(channelType));
				} else {
					clear();
				}
			}
				
			width=newWidth;
			height=newHeight;
			area.set(0,0,newWidth,newHeight);
		}

		void resize(Image<channelType, channels> &other) {
			resize(other.getWidth(), other.getHeight(), other.get());
		}

		// Operator[]
		inline channelType *operator[](const int index) { return &imageData[index*channels]; }
		inline const channelType *const operator[](const int index) const { return &imageData[index*channels]; }

		inline channelType *get() { return static_cast<uint8*>(imageData); }
		inline const channelType *get() const { return static_cast<uint8*>(imageData) }

		inline uint8 *getByte() { return static_cast<uint8*>(imageData); }
		inline const uint8 *getByte() const { return static_cast<uint8*>(imageData); }

		inline uint32 *getDword() { return reinterpret_cast<uint32*>(imageData); }
		inline const uint32 *getDword() const { return reinterpret_cast<uint32*>(imageData); }

		// Area
		inline const Area<int> &getArea() const { return area; }

		// getDimensions
		inline const int getWidth() const { return width; }
		inline const int getHeight() const { return height; }
		
		// TODO: Maybe specify first/last channel (so it could be used for alpha clear and so on
		// Clear image
		void clear(const channelType fillValue=channelType(0)) {
			const int size=area.getSize()*channels;
			for (int C=0; C<size; C++) imageData[C]=fillValue;
		}
		
		const bool isInside(const Point<int> &p) { return area.isInside(p); }
	};

	typedef Image<uint8,4>		Image32;
	typedef Image<uint8,3>		Image24;
	typedef Image<uint8,1>		Image8;
	typedef Image<float32,1>	ImageHeightFloat32;
	typedef Image<float64,1>	ImageHeightFloat64;
};

#endif