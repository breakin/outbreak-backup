#include "imagecoder.h"

const Helper::ImageCoder::DecodeSettings Helper::ImageCoder::defaultDecodeSettings;
const Helper::ImageCoder::EncodeSettings Helper::ImageCoder::defaultEncodeSettings;