#ifndef __TGA_DECODER_H__
#define __TGA_DECODER_H__

#include "..\image\image32.h"


namespace Helper {
 

	class TGALoader
	{

		public:
		/**
		* enum, specifying, byte offsets in the TGA
		* header.
		*/
		enum 
		{
		TGA_VERSION     =   2,
		TGA_WIDTH_LOW   =  12,
		TGA_WIDTH_HIGH  =  13,
		TGA_HEIGHT_LOW  =  14,
		TGA_HEIGHT_HIGH =  15,
		TGA_BPP         =  16,
		TGA_ID_LENGTH   =   0,
		};


		/**
		 * decode, decodes the memfile into dstSurface
		 * and rizeses if it needs to
		 */

		void load(const char filename[], Image32 &dstImage);
	};


}

#endif
