#include "archiverar.h"
#include "urarfilelib/urarlib.h"
#include "../exception.h"

// TEMP (debugging only)
#include <iostream>

// ---------------------------------------------------------------------------

Helper::ArchiveRAR::ArchiveRAR(const std::string &archiveName, const std::string &archivePassword) :
	mArchiveName(archiveName), mArchivePassword(archivePassword), Archive() {

	// TODO: Set up the file-list here
}

// ---------------------------------------------------------------------------

Helper::ArchiveRAR::~ArchiveRAR() {
}

// ---------------------------------------------------------------------------

const int Helper::ArchiveRAR::getFileCount() const {
	return mFileList.size();
}

// ---------------------------------------------------------------------------

const bool Helper::ArchiveRAR::isExist(const std::string &filename) const {
	if (mFileList.find(filename)==mFileList.end()) return false;
		else return true;
}

// ---------------------------------------------------------------------------

const Helper::ArchiveRAR::File& Helper::ArchiveRAR::operator[](const std::string &filename) const {
	const std::map<std::string, ArchiveRAR::FileRAR>::const_iterator i=mFileList.find(filename);

	if (i==mFileList.end()) throw Exception("ArchiveRAR::getFileInfo; File does not exist!");
		else return i->second;
}

// ---------------------------------------------------------------------------

const Helper::ArchiveRAR::File& Helper::ArchiveRAR::operator[](const int fileIndex) const {

	std::map<std::string, ArchiveRAR::FileRAR>::const_iterator i=mFileList.begin();

	for (int C=0; C<fileIndex; C++, i++);	

	return i->second;
}

// ---------------------------------------------------------------------------

void Helper::ArchiveRAR::FileRAR::remove() {
	throw Helper::Exception("ArchiveRAR::FileRAR::remove; No write access to rar-files at all!");
}

// ---------------------------------------------------------------------------

// TODO: Better solution with new/delete here (due to rarlib uses malloc)

void Helper::ArchiveRAR::FileRAR::getData(Blob &destination) const {
	if (!isReadable()) throw Helper::Exception("ArchiveRAR::FileRAR; Cant read a file since not allowed to read!");

	uint8 *result_ptr=0;

	char *data_ptr=0;
	unsigned long data_size;

	// Read the file
	if(urarlib_get(&data_ptr, &data_size, getName().c_str(),
		mContext->mArchiveName.c_str(), mContext->mArchivePassword.c_str())) {

		if (data_size!=getSize()) {
			std::cout << "New size!" << std::endl;
			delete [] data_ptr;
			throw Exception("ArchiveRAR::FileRAR::getData; Could not read file!");
		}

		result_ptr=new uint8[data_size];
		memcpy(result_ptr, data_ptr, data_size);
		free(data_ptr);

		std::cout << "OK" << std::endl;

	} else {
		std::cout << "NOT OK" << std::endl;
	}

	return result_ptr;
}

// ---------------------------------------------------------------------------

void Helper::ArchiveRAR::createFile(const std::string &fileName, const Blob &source) {
	throw Helper::Exception("ArchiveRAR::FileRAR::createFile; No write access to rar-files at all!");
}