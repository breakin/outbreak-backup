//============================================================================================
// Includes
//============================================================================================
#include "pixelformat.h"

//============================================================================================
// Namespace Aurora
//============================================================================================
using namespace Helper;

//============================================================================================
// method implementations
//============================================================================================
void PixelFormat::set(int pf_type)
{	
    /**
     * set all alpha properties in struct to 0
     * will be set if pf_type = BPP_32
     */
    m_valueAlpha   = 0;
    m_shiftAlpha   = 0;
    m_bitMaskAlpha = 0;

		switch (pf_type)
		{

		case BPP_UNSPEC:

		/**
		* 32 bpp format - set alpha values and fall through to
		* 24 bpp format case
		*/
		case BPP_32:

		m_valueAlpha   = 0xff;
		m_shiftAlpha   = 24;
		m_bitMaskAlpha = 0xff000000;

		/**
		* 24 bpp format - set alpha values and fall through to
		*/
		case BPP_24:
		m_bitMaskRed   = 0x00ff0000;
		m_bitMaskGreen = 0x0000ff00;
		m_bitMaskBlue  = 0x000000ff;
		m_valueRed     = 0xff;
		m_valueGreen   = 0xff;
		m_valueBlue    = 0xff;
		m_shiftRed     = 16;
		m_shiftGreen   = 8;
		m_shiftBlue    = 0;
		m_bpp = 32;
		break;

		/**
		* 16_565 bpp format specification
		*/
		case BPP_16_565:
		m_bitMaskRed   = 0xf800;
		m_bitMaskGreen = 0x07e0;
		m_bitMaskBlue  = 0x1f;
		m_valueRed     = 31;
		m_valueGreen   = 63;
		m_valueBlue    = 31;
		m_shiftRed     = 11;
		m_shiftGreen   = 5;
		m_shiftBlue    = 0;
		m_bpp = 16;
		break;

		/**
		* 16_155 bpp format specification
		*/
		case BPP_16_1555:
		m_bitMaskRed   = 0x7c00;
		m_bitMaskGreen = 0x03e0;
		m_bitMaskBlue  = 0x1f;
		m_valueRed     = 31;
		m_valueGreen   = 31;
		m_valueBlue    = 31;
		m_shiftRed     = 10;
		m_shiftGreen   = 5;
		m_shiftBlue    = 0;
		m_bpp = 16;	
		break;
		}
		
    /**
     * Set format type to selected enum
     */
		m_formatType = pf_type;
}


