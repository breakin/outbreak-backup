#ifndef HELPER_ARCHIVE_ARCHIVE_H
#define HELPER_ARCHIVE_ARCHIVE_H

#include "../typedefs.h"
#include "../blob.h"
#include <string>

/* The entire archive directory belongs to Breakin. */

/* TODO: Maybe replace uint8* / fileSize with a blob-class (simple buffer/size). */

namespace Helper {

	class Archive {
	public:

		// ----------------------------
		class File {
		private:

			int  mSize;
			bool mReadable;
			bool mWriteable;
			std::string mName;

		public:

			const std::string& getName()     const { return mName; }
			const int          getSize()     const { return mSize; }
			const bool         isReadable()  const { return mReadable; }
			const bool         isWriteable() const { return mWriteable; }

			void setName(const std::string &name) { mName=name; }
			void setSize(const int size) { mSize=size; }
			void setReadable(const bool readable) { mReadable=readable; }
			void setWriteable(const bool writeable) { mWriteable=writeable; }

			virtual Blob getData() const = 0;
			virtual void remove() = 0;
		};
		// ----------------------------

	private:
	public:

		virtual ~Archive() {
		}

		virtual const bool  isExist(const std::string &filename) const =0;
		virtual const int   getFileCount() const = 0;

		virtual const File &operator[](const std::string &fileName) const = 0;
		virtual const File &operator[](const int fileIndex) const = 0;

		virtual void createFile(const std::string &fileName, const Blob &source) = 0;
	};
}

#endif