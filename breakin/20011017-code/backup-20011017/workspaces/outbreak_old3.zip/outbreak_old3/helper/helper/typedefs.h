#ifndef HELPER_TYPEDEFS_H
#define HELPER_TYPEDEFS_H

#ifdef WIN32
	// Disable debug-info truncated to 255 characters warning
	
	#pragma warning(disable:4786)

#endif

namespace Helper {

	typedef char				int8;
	typedef unsigned char		uint8;

	typedef float				float32;
	typedef double				float64;

	typedef short				int16;
	typedef unsigned short		uint16;

	typedef int					int32;
	typedef unsigned int		uint32;

	//typedef long long				int64;
	//typedef unsigned long long	uint64;
};

#endif