#ifndef HELPER_X86_PROCESSOR_H
#define HELPER_X86_PROCESSOR_H

namespace Helper {

	class Processor {
	private:

		static bool initialized;

	public:

		Processor() {
			if (!initialized) {

				// Check hardware
				// Made once for all instances of this class.				
				
				initialized=true;
			}
		}

		~Processor() {
		}

		const bool getMMX() const { return false; }
	};
};

#endif
