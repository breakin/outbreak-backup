//=============================================================================================
// Image32 Includes
//=============================================================================================

#include "image32.h"
#include <stdlib.h>
#include <dos.h>
#include <malloc.h>
#include <string.h>


//=============================================================================================
// Image32 Method declarations...
//=============================================================================================

using namespace Helper;

//=============================================================================================
// Image32 Method declarations...
//=============================================================================================
Image32::Image32 ()
{	
	m_area.set(0,0,0,0);
	m_data   = NULL;
	m_width  = 0;
	m_height = 0;
	m_pitch  = 0;
}

//=========================================================================================
Image32::Image32 (int width, int height, int pixelFormatType)
{		
	create(width, height);
}

//=========================================================================================
Image32::~Image32()
{
	release();
}

//=========================================================================================
void Image32::release()
{
	// Reseting member variables
	m_width  = 0;
	m_height = 0;
	m_pitch  = 0;
	
	if (m_data) 
	{
		free (m_data);
		m_data = NULL;
	}
}

//=========================================================================================
void Image32::create(int width, int height, int pixelFormatType)
{			
	m_width	 = width;
	m_height = height;
	m_pitch  = m_width<<2;
	m_pixelFormat.set(pixelFormatType);
	m_area.set(0,0,width,height);
	m_data	 = (uint32*) malloc(m_width * m_height * 4);		
}

//=========================================================================================

void Image32::resize(int width, int height)
{
  release();
  create(width, height);
}
