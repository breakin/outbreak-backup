/*
==============================================================================================
																	AURORA GFX LIBRARY 1.0	          												 
	_________________________________________________________________________________________	 
																																														 
			File        : core_cfg.h							            														   	
			Copyright(c): Peter Nordlander - 2000
			Author      :	Peter Nordlander	  																										 	
			Created     :	2000-12-16																															 
			Last Update :		               																							 
			Descr				: CMap - class wrapping a std::map<std::string, std::string> 
                           handling all set, get and parsing of values stored in
                           map, maily used as a configuration database for devices.

			Rev History : 2000-12-16 - Ideas printed on paper, no implementation
                    2001-01-07 - File created

==============================================================================================
*/
#ifndef __CONFIG_H__
#define __CONFIG_H__


namespace Helper{
	

//============================================================================================
// Includes
//============================================================================================
#include "helper\typedefs.h"
#include <map>


//============================================================================================
// class CMap
//============================================================================================
class Config
{
  public:

    /**
     * add methods, adds different data into CConfig
     * always set as std::string, std::string
     */
    void set(const std::string key, std::string data)
    {
      m_table[key] = data;
    }

    /**
     * Stores keydata inside bool variable referenced by <data>
     */
    void get(const std::string key,  bool &data)
		{
      if ((m_table[key] == "TRUE") || (m_table[key] == "FALSE"))
      data = (bool)(m_table[key] == "TRUE");
		}
    
    /**
     * Stores keydata inside int variable referenced by <data>
     */
		void get(const std::string key, int  &data)
		{
      data = atoi(m_table[key].c_str());
		} 
      
    /**
     * Stores keydata inside char* variable referenced by <data>
     */
		void get(const std::string key, char *data)
		{
      strcpy(data,m_table[key].c_str());
		}

    /**
     * Stores keydata inside std::string variable referenced by <data>
     */
    void get(const std::string key, std::string &data)
		{
      data = m_table[key];
		}

    /**
     * Stores keydata inside char variable referenced by <data>
     */
    void get(const std::string key, char &data)
    {
      data = (m_table[key].c_str()[0]);
    }
    
    /**
     * operator[",,,,"], CMap class can be used
     * widht operator[] like config["WITDH"] = "320" 
     */
    std::string& operator[](std::string key)
    {
      return m_table[key];
    }

  protected:
    
    /**
     * Data is stored in a STL map<std::string, std::string> container
     */
    std::map<std::string, std::string> m_table;

};
} 

#endif