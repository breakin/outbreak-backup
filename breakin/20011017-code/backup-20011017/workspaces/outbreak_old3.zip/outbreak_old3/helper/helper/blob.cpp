#include "blob.h"
#include "exception.h"
#include <memory.h>

/* Control reading; perhaps there is a memory leak or a refCount bug or whatever */

// ---------------------------------------------------------------------------

Helper::Blob::Blob() : blobRef(0) {
}

// ---------------------------------------------------------------------------

Helper::Blob::Blob(const Blob &other) : blobRef(other.blobRef) {
	if (this==&other) throw Helper::Exception("Blob::Blob(other); this==&other");
	if (blobRef) blobRef->refCount++;
}

// ---------------------------------------------------------------------------

Helper::Blob::Blob(const uint8 * const memory, const int size) : blobRef(0) {
	setMemory(memory, size);
}

// ---------------------------------------------------------------------------

Helper::Blob::Blob(const int newSize) : blobRef(0) {
	resize(newSize);
}

// ---------------------------------------------------------------------------

Helper::Blob::~Blob() {
	clear();
}

// ---------------------------------------------------------------------------

void Helper::Blob::operator=(const Blob &other) {
	if (blobRef==other.blobRef) return; // this will also reject this=&other

	clear();

	blobRef=other.blobRef;
	if (blobRef) blobRef->refCount++;	
}

// ---------------------------------------------------------------------------

void Helper::Blob::clear() {
	
	if (blobRef) {
		if (blobRef->refCount==1) {
			delete [] blobRef->mBuffer;
			delete blobRef;
		} else {
			blobRef->refCount--;
		}

		blobRef=0;
	}	
}

// ---------------------------------------------------------------------------

void Helper::Blob::makeUniqueCopy() {
	if (blobRef && blobRef->refCount!=1) {

		// We've gotta make a copy in order to get the blob unique
		
		const int size=blobRef->mSize;

		BlobRef *temp=new BlobRef;

		temp->refCount=1;
		temp->mSize=size;
		temp->mBuffer=new uint8[size];

		memcpy(temp->mBuffer, blobRef->mBuffer, size);

		blobRef->refCount--;

		blobRef=temp;
	}
}

// ---------------------------------------------------------------------------

void Helper::Blob::setMemory(const uint8 * const memory, const int size) {
	resize(size, false);                    // Resize and make a valid (unique) blobRef
	memcpy(blobRef->mBuffer, memory, size); // Copy memory
	blobRef->mSize=size;
}

// ---------------------------------------------------------------------------

void Helper::Blob::giveMemory(uint8* memory, const int size) {
	clear();                                // Clear the blobRef
	blobRef=new BlobRef;                    // Make a new blobRef (no allocation here!)
	blobRef->mBuffer=memory;
	blobRef->mSize=size;
	blobRef->refCount=1;
}

// ---------------------------------------------------------------------------

Helper::uint8* Helper::Blob::takePointer() {
	if (!blobRef) return 0;

	makeUniqueCopy();

	uint8* temp=blobRef->mBuffer;

	delete blobRef;
	blobRef=0;

	return temp;
}

// ---------------------------------------------------------------------------

void Helper::Blob::resize(const int newSize, const bool keepData) {

	if (newSize<=0) throw Helper::Exception("Blob::resize; newsize<=0");

	if (!blobRef) {
		blobRef=new BlobRef;
		blobRef->mBuffer=new uint8[newSize];
		blobRef->mSize=newSize;
		blobRef->refCount=1;
	} else {

		if(keepData) {
			if (blobRef->refCount==1) {

				uint8* temp=new uint8[newSize];

				memcpy(temp, blobRef->mBuffer, blobRef->mSize > newSize ? newSize : blobRef->mSize);

				delete [] blobRef->mBuffer;
				blobRef->mBuffer=temp;
				blobRef->mSize=newSize;
				
			} else {

				blobRef->refCount--;
				BlobRef *temp=new BlobRef;
				temp->mSize=newSize;
				temp->refCount=1;
				temp->mBuffer=new uint8[newSize];

				memcpy(temp->mBuffer, blobRef->mBuffer, 
					   blobRef->mSize > newSize ? newSize : blobRef->mSize);

				blobRef=temp; 

			}
		} else {
			if (blobRef->refCount==1) {
				delete [] blobRef->mBuffer;
				blobRef->mBuffer=new uint8[newSize];
				blobRef->mSize=newSize;
			} else {
				clear();
				BlobRef *temp=new BlobRef;
				temp->refCount=1;
				temp->mBuffer=new uint8[newSize];
				temp->mSize=newSize;
				blobRef=temp;
			}
		}
	}
    
}

// ---------------------------------------------------------------------------