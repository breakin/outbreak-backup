#ifndef HELPER_DEMO_APPLICATION_H
#define HELPER_DEMO_APPLICATION_H

/*
	An application class is inherited by class which desires to be used 
	within the console system and can whereby be stacked by console.
*/

#include <helper/typedefs.h>
#include <helper/demo/script.h>
#include <helper/demo/console/c64.h>

namespace Helper {

	struct ConsoleData {
		// Graphics, processors, music clock, script etc. EVERYTHING USED :)
		// Those not filled in use 0 (NULL) to mark that they're not included.

		Script* script;
		C64*    c64;

		ConsoleData() {
			// Set all to 0
			script=0;
			c64=0;
		}
	};

	class Application {
	private:

	protected:
		ConsoleData consoleData;

	public:
		Application(const ConsoleData& consoleData) {
			this->consoleData = consoleData;
		}

		virtual Application* update() { return 0; }
	};
}

#endif