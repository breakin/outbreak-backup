#ifndef HELPER_PROFILE_PROFILE_H
#define HELPER_PROFILE_PROFILE_H

#include <map>
#include <string>
#include "test.h"

namespace Helper {

	class Profile {
	private:

		Test etst;

		// map<Filename, Lock>
//		std::map<std::string, *ProfileLockFile>  fileLocks;
//		std::map<std::string, *ProfileLockImage> imageLocks;

	public:
	};
}

#endif