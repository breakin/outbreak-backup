#ifndef HELPER_HELPER_IMAGETOOL_IMAGECODER_JPG_H
#define HELPER_HELPER_IMAGETOOL_IMAGECODER_JPG_H

/*

    Author: Breakin
    See "imagecoder.h" for details.

    This class will encode and decode JPEG-files, supporting the jpg-extension ("jpg").
	Implemented using jpeglib.

*/

#include "imagecoder.h"

namespace Helper {

	class ImageCoder_JPG : public ImageCoder {
	public:

		ImageCoder_JPG();		
		virtual ~ImageCoder_JPG();

		virtual void encode(Blob &destinationBlob, const Image32 &sourceImage, const EncodeSettings &settings=defaultEncodeSettings) const;
		virtual void decode(Image32 &destinationImage, const Blob &sourceBlob, const DecodeSettings &settings=defaultDecodeSettings) const;

		virtual const bool isEncoder(const std::string &extension="") const;
		virtual const bool isDecoder(const std::string &extension="") const;
	};
};

#endif