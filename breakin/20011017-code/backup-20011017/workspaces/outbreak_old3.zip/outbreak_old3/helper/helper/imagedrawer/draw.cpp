//===========================================================================================
// Includes
//===========================================================================================
#include "draw.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//===========================================================================================
// use Aurora namespace
//===========================================================================================
using namespace Helper;

//===========================================================================================
// interpolate bilinear and return a filtered color
//===========================================================================================
/****
calColorBilinear
- interpolate bilinear and return the correct color to be set
**/

uint32 calc_color_bilinear(uint32 *data, float xpos, float ypos, int width)
{
	int   r,g,b;
	int   r2,g2,b2;
	int   intPart;
	float fraction;

	// add interpolated attributes
	intPart		= (int)xpos;
	fraction	= xpos - (float)intPart;
	
	// extract color attributes, from the current pixel and one to the left 
	r  = (data[0]>>16) & 0xff;
	g  = (data[0]>>8)& 0xff;
	b  =  data[0] & 0xff;
	r2 = (data[1]>>16)& 0xff;
	g2 = (data[1]>>8)& 0xff;
	b2 =  data[1]&0xff;

	// add interpolated attributes
	r = (int)(((1.0 - fraction) * (float)r) + fraction * (float)r2)&0xff;
	g = (int)(((1.0 - fraction) * (float)g) + fraction * (float)g2)&0xff;
	b = (int)(((1.0 - fraction) * (float)b) + fraction * (float)b2)&0xff;
	
	// calculate vertical interpolation
	intPart		= (int)ypos;
	fraction	= ypos - (float)intPart;
	
	// extract lower pixel's attributes
	r2 = (data[width]>>16)& 0xff;
	g2 = (data[width]>>8)  & 0xff;
	b2 =  data[width]& 0xff;
	
	// add x and y interpolated attributes
	r =(int) (((1.0 - fraction) * (float)r) + fraction * (float)r2)&0xff;
	g =(int) (((1.0 - fraction) * (float)g) + fraction * (float)g2)&0xff;
	b =(int) (((1.0 - fraction) * (float)b) + fraction * (float)b2)&0xff;

	// return color
	return ((r<<16)|(g<<8)|b);
}



//=============================================================================================================
void Drawer::clearARGB(uint32 *pixels, int width, int height, int pitch)
{
	// clear surface pixels
	for (int C=0; C < height; C++)
	{
		memset(pixels, 0 , (width<<2));
		pixels+=(pitch>>2);
	}
}

//=============================================================================================================
void Drawer::clearRGB(uint32 *pixels, int width, int height, int pitch)
{	
	for (int H=0; H < height; H++)
	{
		for (int W=0; W < width; W++) pixels[W] &= 0xff000000;
		pixels += (pitch>>2);
	}
}


//=============================================================================================================
void Drawer::copy(uint32 *srcPixels, uint32 *dstPixels, int pixelCount)
{
	// cpy, mul pixelcount by 4, we need to get amount of bytes
	memcpy(dstPixels, srcPixels, pixelCount * 4);
}


//=============================================================================================================
void Drawer::scale_bilinear(uint32 *srcPixels, const AreaInt &srcArea, int srcPitch, 
							uint32 *dstPixels, const AreaInt &dstArea, int dstPitch)
{
	// variables..
	float deltax;
	float deltay;
	int   srcOffset;
	int   dstOffset;
	int   dstWidth;
	int   srcWidth;
	float x,y;
	
	// calculate src and dst 4byte pixel width
	srcWidth = srcPitch>>2;
	dstWidth = dstPitch>>2;

	// deltas
	deltax = (float)srcArea.getWidth()  / (float)dstArea.getWidth();
	deltay = (float)srcArea.getHeight() / (float)dstArea.getHeight();
	
	// offsets, 
	srcOffset = srcArea.getLeft() + srcArea.getTop() * srcWidth;
	dstOffset = dstArea.getLeft() + dstArea.getTop() * dstWidth;
	
	srcPixels+=srcOffset;
	dstPixels+=dstOffset;

	x = (float)srcArea.getLeft();
	y = (float)srcArea.getTop();
	
	for (int Y=0; Y<dstArea.getHeight(); Y++)
	{
		for (int X=0; X<dstArea.getWidth(); X++)
		{
			dstPixels[Y*dstWidth+X] = calc_color_bilinear(&srcPixels[(int)x + (int)y * srcWidth ], x, y, srcWidth);			
			x+=deltax;
		}
		x = (float)srcArea.getLeft();
		y+=deltay;
	}
}

//=============================================================================================================
void Drawer::scale(	uint32 *srcPixels, const AreaInt &srcArea, int srcPitch, 
					uint32 *dstPixels, const AreaInt &dstArea, int dstPitch) 
{
	// TODO : IMPLEMENT!
}

//=============================================================================================================
void Drawer::blit(uint32 *srcPixels, uint32 *dstPixels, int width, int height, int srcPitch, int dstPitch)
{
	for (int Y =0; Y<height; Y++) {
		// cpy each line
		memcpy(dstPixels,srcPixels,(width<<2));
		
		//move to next
		srcPixels+=(srcPitch>>2);
		dstPixels+=(dstPitch>>2);
	}
}


//=============================================================================================================
void Drawer::blit_alpha(uint32 *src, uint32 *dst, int width, int height, int srcPitch, int dstPitch)
{
	// recalc pitch to dwords per line..
	srcPitch>>=2;
	dstPitch>>=2;
	
	for (int Y =0; Y<height; Y++)
	{
		for (int X=0; X<width; X++)
		{
			// Store source components.
			uint8 sa = src[X] >> 24;
			uint8 sr = src[X] >> 16;
			uint8 sg = src[X] >> 8;
			uint8 sb = src[X];

			// Calculate destination components.
			uint8 da = 0xff-sa;
			uint8 dr = ( ((uint8)(dst[X] >> 16) *da) + (sr*sa) )>>8;
			uint8 dg = ( ((uint8)(dst[X] >> 8 ) *da) + (sg*sa) )>>8;
			uint8 db = ( ((uint8)(dst[X]      ) *da) + (sb*sa) )>>8;

			// Assign color value from components.
			dst[X] = (dr<<16) + (dg<<8) +db;
		}
		
		// Jump to next rows.
		dst+=dstPitch;
		src+=srcPitch;
	}
}

//=============================================================================================================
void Drawer::blit_colorkey(uint32 *srcPixels, uint32 *dstPixels, int width, int height, int srcPitch, int dstPitch)
{
	// TODO : implementation
}

//=============================================================================================================
void Drawer::blit_colorkey_alpha(uint32 *srcPixels, uint32 *dstPixels, int width, int height, int srcPitch, int dstPitch)
{
	// TODO : implemetation	
}


