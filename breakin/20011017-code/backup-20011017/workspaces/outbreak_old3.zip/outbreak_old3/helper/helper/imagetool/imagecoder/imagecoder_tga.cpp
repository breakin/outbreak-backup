#include "imagecoder_tga.h"
#include "../../exception.h"

// ---------------------------------------------------------------------------

Helper::ImageCoder_TGA::ImageCoder_TGA() : ImageCoder() {
}

// ---------------------------------------------------------------------------

Helper::ImageCoder_TGA::~ImageCoder_TGA() {
}

// ---------------------------------------------------------------------------

const bool Helper::ImageCoder_TGA::isEncoder(const std::string &extension) const {
	return (extension.empty() || extension=="tga");
}

// ---------------------------------------------------------------------------

const bool Helper::ImageCoder_TGA::isDecoder(const std::string &extension) const {
	return (extension.empty() || extension=="tga");
}

// ---------------------------------------------------------------------------

Helper::Blob Helper::ImageCoder_TGA::encode(const Image32 &sourceImage, const EncodeSettings &settings) const {

	Blob returnBlob;
	
	// Shall we save with an alphachannel? (32-bit instead of 24-bit)
	const bool useAlpha=settings.saveAlphaChannel;
		
	// Calculate bitdepth
	int bitDepth;

	if (settings.saveAlphaChannelAsGreyScale) {
		bitDepth=8;
	} else {
		bitDepth=(useAlpha ? 32 : 24);
	}

	// Calculate the size of each pixel (in bytes)
	const int pixelSize=bitDepth/8;

	// Get width/height from the texture
	const int width=sourceImage.getWidth();
	const int height=sourceImage.getHeight();

	// Allocate memory for the file
	returnBlob.resize(18+pixelSize*width*height);
	
	// Clear header with zeroes. The following header is 100% correct according to specifications,
	// assuming the fields that are left out are set to zero.
	for (int C=0; C<18; C++) returnBlob.set(C, 0);

	// Save the header
	if (bitDepth==8) {
		returnBlob.set(2,3); // Version (2=uncompressed TGA, our favorite!)
	} else {
		returnBlob.set(2,2); // Version (3=uncompressed grayscale TGA)
	}

	returnBlob.set(12, width&0xff);        // Width
	returnBlob.set(13, width>>8);
	returnBlob.set(14, height&0xff);       // Height
	returnBlob.set(15, height>>8);
	returnBlob.set(16, bitDepth);          // Bitdepth
	returnBlob.set(17, bitDepth==32?8:0);  // Bits of alphachannels (8 for 32-bit, zero for 24/gray)												
	                                        // Also says; save-it-up-side-down! :)

	// Get a pointer to the image-data from the texture
	const uint8 * const imageData=sourceImage.getByte();
	
	// Source is 32-bit
	int imageOffset=(height-1)*width*4;
	uint8* returnOffset=18+returnBlob.get();

	// Save the image data
	for (int Y=0; Y<height; Y++) {
		for (int X=0; X<width; X++) {
			
			if (bitDepth==8) { 
				imageOffset+=3;
				*returnOffset++=imageData[imageOffset++];
			} else {
				*returnOffset++=imageData[imageOffset++];
				*returnOffset++=imageData[imageOffset++];
				*returnOffset++=imageData[imageOffset++];

				if (bitDepth==32) *returnOffset++=imageData[imageOffset++];
					else imageOffset++;
			}
		}

		imageOffset-=width*2*4;
	}

	return returnBlob;
}

// ---------------------------------------------------------------------------

void Helper::ImageCoder_TGA::decode(Image32 &destinationImage, const Blob &sourceBlob, const DecodeSettings &settings) const {
	
	// Calculate width, height, bitdepth and how many bytes/pixel that are involved.
	const int width      = (sourceBlob.get(13)<<8) + sourceBlob.get(12);
	const int height     = (sourceBlob.get(15)<<8) + sourceBlob.get(14);
	const int bitDepth   = sourceBlob.get(16);
	const int pixelSize  = bitDepth / 8;
	const int bufferSize = width * height * pixelSize;

	const bool toAlpha   = settings.storeInAlphaChannel;
	const bool fillAlpha = settings.modifyTheAlphaChannel;

	// Check version
	if (toAlpha) {
		// Is it an uncompressed grayscale tga?
		if (sourceBlob.get(2)!=3) throw Helper::Exception("ImageCoder_TGA::decode; Not an grayscale TGA when supposed to load to the alpha channel (wrong version, save as grayscale))");
	} else {
		// Is it a uncompressed color or grayscale tga?
		if (sourceBlob.get(2)!=2 && sourceBlob.get(2)!=3) throw Helper::Exception("ImageCoder_TGA::decode; Only uncompressed 24-bit or grayscale supported (wrong version, save as uncompressed)");

		if (bitDepth==8 && sourceBlob.get(2)==2) throw Helper::Exception("ImageCoder_TGA::decode; 8-bit only supported when grayscaled (change to 16- or 24-bit mode)");
	}

	// Resize the texture if needed
	if (destinationImage.getWidth()!=width && destinationImage.getHeight()!=height) {
		if (settings.resizeImageIfNeeded) {
			destinationImage.resize(width, height);
		} else {
			throw Helper::Exception("ImageCoder_TGA::decode; Can't resize destinationImage since we are not allowed.");
		}
	}

	// Decompress depending on bitdepth
	if (bitDepth==32) {
		if (fillAlpha==true) {
			// Decompress 32-bit picture and read the alpha channel

			const uint32 *bufferData=(uint32*)(sourceBlob.getReadOnly()+18+sourceBlob.get(0));
			uint32 *imageData=destinationImage.getDword()+(height-1)*width;

			for (int Y=0; Y<height; Y++) {
				memcpy(imageData, bufferData, width*4);
				imageData-=width;
				bufferData+=width;
			}
		} else {
			// Decompress 32-bit picture but don't read the alpha channel

			const uint8 *bufferData=sourceBlob.getReadOnly()+18+sourceBlob.get(0);
			uint8 *imageData=destinationImage.getByte()+((height-1)*width)*4;

			for (int Y=0; Y<height; Y++) {
				for (int X=0; X<width; X++) {
					*imageData++=*bufferData++;
					*imageData++=*bufferData++;
					*imageData++=*bufferData++;
					bufferData++;
					imageData++;
				}
				
				imageData-=width*2*4;
			}
		}
	} else if (bitDepth==24) {
		// Decompress 24-bit picture

		const uint8 *bufferData=sourceBlob.getReadOnly()+18+sourceBlob.get(0);
		uint8 *imageData=destinationImage.getByte()+((height-1)*width)*4;

		for (int Y=0; Y<height; Y++) {
			for (int X=0; X<width; X++) {
				*imageData++=*bufferData++;
				*imageData++=*bufferData++;
				*imageData++=*bufferData++;
				imageData++;
			}
			
			imageData-=width*2*4;
		}
	} else if (bitDepth==16) {
		// Decompress 16-bit picture (555)

		const uint8 *bufferData=sourceBlob.getReadOnly()+18+sourceBlob.get(0);
		uint8 *imageData=destinationImage.getByte()+((height-1)*width)*4;

		for (int Y=0; Y<height; Y++) {
			for (int X=0; X<width; X++) {
				unsigned short readWord=*bufferData++;
				readWord+=256*(*bufferData++);

				*imageData++=((readWord    )&31)<<3;
				*imageData++=((readWord>> 5)&31)<<3;
				*imageData++=((readWord>>10)&31)<<3;
				imageData++;
			}

			imageData-=width*2*4;
		}

	} else if (bitDepth==8) {
		const uint8 *bufferData=sourceBlob.getReadOnly()+18+sourceBlob.get(0);
		uint8 *imageData=destinationImage.getByte()+((height-1)*width)*4;

		if (toAlpha==true) {
			for (int Y=0; Y<height; Y++) {
				for (int X=0; X<width; X++) {
					imageData+=3;
					*imageData++=*bufferData++;
				}

				imageData-=width*2*4;
			}
		} else {
			for (int Y=0; Y<height; Y++) {
				for (int X=0; X<width; X++) {
					uint8 alphaValue=*bufferData++;
					*imageData++=alphaValue;
					*imageData++=alphaValue;
					*imageData++=alphaValue;
					imageData++;
				}

				imageData-=width*2*4;
			}
		}
	}

	// Set alphaChannel to 0xff (if we are allowed to touch it,
	// and we are not just reading a 8-bit to the alphaChannel
	// and the alphaChannel has not been filled already (since
	// 32-bit images store it)
	if (settings.modifyTheAlphaChannel && (bitDepth==24 || bitDepth==16)) {
		uint8 *imageData=destinationImage.getByte()+3;
		
		for (int Y=0; Y<height; Y++) {
			for (int X=0; X<width; X++) {
				*imageData=0xff;
				imageData+=4;
			}
		}
	}
}

// ---------------------------------------------------------------------------

 