#include "archivedirectory.h"
#include "../exception.h"

// ---------------------------------------------------------------------------

Helper::ArchiveDirectory::ArchiveDirectory(const std::string &directoryName) :
	mDirectoryName(directoryName), Archive() {

	// Construct file-list via recurse-file-listing
	// Create directory if it does not exist
	// OS-dependant, the method is located in another .cpp-file (archivedirectory_win32.cpp)

	initialize();
}

// ---------------------------------------------------------------------------

Helper::ArchiveDirectory::~ArchiveDirectory() {
}

// ---------------------------------------------------------------------------

/* Returns the number of files in the directory */

const int Helper::ArchiveDirectory::getFileCount() const {
	return mFileList.size();
}

// ---------------------------------------------------------------------------

/* Returns true if the file 'filename' exists, false if it does not.
   'filename' includes full path from 'mDirectoryName'. */

const bool Helper::ArchiveDirectory::isExist(const std::string &filename) const {
	if (mFileList.find(filename)==mFileList.end()) return false;
		else return true;
}

// ---------------------------------------------------------------------------

/* Returns a File& object to the file with the filename 'filename'. Throws an exception
   if the file is not found. */

const Helper::ArchiveDirectory::File& Helper::ArchiveDirectory::operator[](const std::string &filename) const {
	const std::map<std::string, ArchiveDirectory::FileDirectory>::const_iterator i=mFileList.find(filename);

	if (i==mFileList.end()) throw Exception("ArchiveDirectory::getFileInfo; File does not exist!");
		else return i->second;
}

// ---------------------------------------------------------------------------

/* Returns a File& object to the file with the index fileIndex in the fileList.
   Throws an exception if the index is out of bound. */

const Helper::ArchiveDirectory::File& Helper::ArchiveDirectory::operator[](const int fileIndex) const {

	if (fileIndex<0 || fileIndex>=mFileList.size()) {
		throw Helper::Exception("ArchiveDirectory::operator[int]; Index out of bound");
	}

	std::map<std::string, ArchiveDirectory::FileDirectory>::const_iterator i=mFileList.begin();

	for (int C=0; C<fileIndex; C++, i++);	

	return i->second;
}

// ---------------------------------------------------------------------------

/* Creates a sub-directory to the root directory. */

void Helper::ArchiveDirectory::createDirectory(const std::string &directoryName) {

	std::string temp(mDirectoryName);
	temp+=directoryName;

	createRootDirectory(temp);
}

// -[FileDirectory]-----------------------------------------------------------

/* Remove the file. Does not complain if the file did not exist. */

void Helper::ArchiveDirectory::FileDirectory::remove() {
	if (!isWriteable()) throw Helper::Exception("ArchiveDirectory::FileDirectory; Cant remove a file since not allowed to write!");

	mContext->remove(getName());
}

// ---------------------------------------------------------------------------

/* Loads the file. */

Helper::Blob Helper::ArchiveDirectory::FileDirectory::getData() const {
	if (!isReadable()) throw Helper::Exception("ArchiveDirectory::FileDirectory; Cant read a file since not allowed to read!");

	return mContext->getData(getName(), getSize());
}

// ---------------------------------------------------------------------------