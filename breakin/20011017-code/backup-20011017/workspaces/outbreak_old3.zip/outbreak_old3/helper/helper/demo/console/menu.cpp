#include "menu.h"

#include <helper/exception.h>

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Menu::Menu(const ConsoleData& consoleData) : Helper::Application(consoleData) {

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Application* Helper::Menu::update() {
	C64& c64 = *consoleData.c64;

	Msg msg;
	while(c64.winDevice.getMessage(msg, true)) {
		
	}

	for (int y=0; y<30; y++) {
		for (int x=0; x<80; x++) {
			c64.setColor(rand()%16, rand()%16);
			c64.drawLetter(c64.screen, x*8, y*8, 65+(rand()%25));
		}
	}

	c64.winDevice.update(c64.screen);

	// Continue to live.
	return this;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
