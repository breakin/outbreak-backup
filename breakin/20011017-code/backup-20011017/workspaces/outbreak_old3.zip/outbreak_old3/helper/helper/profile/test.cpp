#include "test.h"
#include "profile.h"

Helper::Test::Test(Profile &profile) {
}