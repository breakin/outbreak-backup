
#include "tga.h"

using namespace Helper;

void TGALoader::load(const char filename[], Image32 &surface)
{
	uint8 *tgaImageData;
	int    width;
	int    height;
	int    bytepp;
	int    id_len;
	uint32 *surfData;
	FILE   *fp;
	int    filesize;

	// read image file
	fp = fopen(filename,"rb");
	fseek(fp,0,SEEK_END);
	filesize = ftell(fp);
	fseek(fp,0,SEEK_SET);
	tgaImageData = new uint8[filesize];
	fread(tgaImageData,1,filesize,fp);
	fclose (fp);

	/**
	 * first check TGA version, only support ver 2
	 */
	if (tgaImageData[TGA_VERSION]!=2) return; // TODO : throw exception

	width  = (tgaImageData[TGA_WIDTH_HIGH] <<8) | tgaImageData[TGA_WIDTH_LOW];
	height = (tgaImageData[TGA_HEIGHT_HIGH]<<8) | tgaImageData[TGA_HEIGHT_LOW];
	id_len =  tgaImageData[TGA_ID_LENGTH];
	bytepp =  tgaImageData[TGA_BPP];

	/**
	 * check if we need to resize the surface, to fit image
	 */
	surface.resize(width,height);

	surfData = (uint32*) surface.getPixels();

	/**
	 * Calculate image pixel data offset
	 * bye adding the the size iof
	 */
	long skipper = 18 + id_len;

	/**
	 * first handle 24 and 32 bpp formats
	 */
	if (bytepp == 32) {
		// Spoil header.
		uint32* tgaData = (uint32*)(tgaImageData+skipper);

		// Load image data
		for (int h=0, offset=0; h<height; h++) {
			for (int w=0; w<width; w++, offset++) {
				surfData[offset] = tgaData[(height-h-1)*width + w];
			}
		}
	}

	if (bytepp == 24)
	{
		/*
		for (int h=0; h<height; h++)
			for (int w=0; w<width; w++)
			{
				*surfData = 0;
				for (loop=0; loop<(bytepp/8); loop++)
				{
					*surfData |= (uint32)((uint32)tgaImageData[skipper + loop]<<(loop<<3));
				}
				// increase offsets
				surfData++;
				tgaImageData+=(bytepp/8);        
			}
		*/
	}

	/**
	* test for 16 bpp
	*/
	if (bytepp == 16)
	{
		/*
		uint16 color;
		int r,g,b,a;

		for (int h=0; h<height; h++)
			for (int w=0; w<width; w++)
			{
				color = (tgaImageData[skipper + 1] << 8) | tgaImageData[skipper + 0]; 
				r     = ((color>>10) & 31)<<3;
				g     = ((color>>5)  & 31)<<3;
				b     = (color&31)<<3;
				a     = 0;

				*surfData = (a<<24)|(r<<16)|(g<<8)|b;

				// increase offsets       
				surfData++;
				tgaImageData+=2;        
			}
		*/
	}

	delete[] tgaImageData;
}
