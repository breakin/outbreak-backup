#ifndef HELPER_DEMO_C64_H
#define HELPER_DEMO_C64_H

#include <helper\imagedrawer\imagedrawer.h>
#include <helper\win32\win32_device2d.h>

#include <string>

namespace Helper {

	class C64 {
	private:
		// Font stuff
		int32 fontWidth, fontHeight;
		int32 color[16];
		int32 foreground, background;

		// Fontdata and colordata for the images.
		Helper::Image32 fontData[256];
		int32 fontDataColor[256];

		// Drawer used by font and various.
		Helper::ImageDrawer drawer;

		// Functions to help drawLetter to set the right colour on the fontData.
		void clearBackground(Helper::Image32& dest, const int32 x, const int32 y);
		void clearFontRGB(const uint8 sign);
		void clear(const uint32 clearColor);
	public:
		// 2d-device to be used as the c64.
		Helper::Win32Device2D winDevice;
		Helper::Image32 screen;
		Helper::Msg     msg;

		// Constructor / Destructor.
		C64(Helper::Image32& fontImage);
		~C64();

		// Font-routines.
		void setColor(const int32 foreground, const int32 background);

		void drawLetter(Helper::Image32& dest, const int32 x, const int32 y, const uint8 sign);
		void drawString(Helper::Image32& dest, const int32 x, const int32 y, const std::string input);
	};

}

#endif