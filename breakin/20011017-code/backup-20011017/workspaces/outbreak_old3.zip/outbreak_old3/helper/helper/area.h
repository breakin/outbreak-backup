#ifndef HELPER_AREA_H
#define HELPER_AREA_H

#include "point.h"
template<class T> class Point;

namespace Helper {

	template<class T>class Area {
	private:
		
		T left,top,width,height;

	public:

		Area(const T initLeft=T(), const T initTop=T(), const T initWidth=T(), const T initHeight=T()) 
			: left(initLeft), top(initTop), width(initWidth), height(initHeight) {
		}

		void setLeft(const T newLeft) { left=newLeft; }
		void setTop(const T newTop) { top=newTop; }
		void setWidth(const T newWidth) { width=newWidth; }
		void setHeight(const T newHeight) { height=newHeight; }
		void setRight(const T newRight) { width=newRight-left; }
		void setBottom(const T newBottom) { height=newBottom-top; }
		const T getLeft() const { return left; }
		const T getTop() const { return top; }
		const T getWidth() const { return width; }
		const T getHeight() const { return height; }
		const T getRight() const { return left+width; }
		const T getBottom() const { return top+height; }

		const T getSize() const { return width*height; }

		const bool isEmpty() const { return (width<=T(0))||(height<=T(0)); }

	/*	const bool isInside(const Point<T> &p) { 
			if (p.getX()>=left && p.getY()>=top && p.getX()<left+width && p.getY()<top+height) return true;
				else return false;
		}*/

		void set(const T newLeft, const T newTop) {
			left=newLeft;
			top=newTop;
		}

		void set(const T newLeft=T(), const T newTop=T(), const T newWidth=T(), const T newHeight=T()) {
			left=newLeft;
			top=newTop;
			width=newWidth;
			height=newHeight;			
		}

		// Offset by a point (move upper left)
		void operator+=(const Point<T> &p) {
			left+=p.getX();
			top+=p.getY();
		}

		Area<T> operator+(const Point<T> &p) {
			Area<T> result(*this);
			result+=p;
			return result;
		}

		// Minimum area that includes both areas
		void operator|=(const Area<T> &other) {
			if (other.getLeft()<left) left=other.getLeft();
			if (other.getTop()<top) top=other.getTop();
			
			// Feel free to optimize the following to lines (not using right/bottom) if you dare ;)
			if (other.getRight()>getRight()) setRight(other.getRight());
			if (other.getBottom()>getBottom()) setBottom(other.getBottom());
		}

		Area<T> operator|(const Area<T> &other) {
			Area<T> result(*this);
			result|=other;
			return result;
		}

		// Union area (overlap)
		void operator&=(const Area<T> &other) {
			if (other.getLeft()>left) left=other.getLeft();
			if (other.getTop()>top) top=other.getTop();
			
			// Feel free to optimize the following to lines if you dare ;)
			if (other.getRight()<getRight()) setRight(other.getRight());
			if (other.getBottom()<getBottom()) setBottom(other.getBottom());			
		}

		Area<T> operator&(const Area<T> &other) {
			Area<T> result(*this);
			result&=other;
			return result;
		}

		const bool operator==(const Area<T> &other) {
			if (width==other.getWidth() && height==other.getHeight()) return true;
			return false;
		}

		const bool operator!=(const Area<T> &other) {
			if (width!=other.getWidth() || height!=other.getHeight()) return true;
			return false;
		}
	};

	typedef Area<int> AreaInt;
	typedef Area<float32> AreaFloat32;
	typedef Area<float64> AreaFloat64;
};

#endif