#ifndef __WIN32_SURFACE__
#define __WIN32_SURFACE__

#include <windows.h>
#include <helper\typedefs.h>
#include <helper\image\image32.h>

namespace Helper {

class Win32Image:public Image32
{
	
	public:
	
		Win32Image(int width, int height);
		Win32Image();
		~Win32Image();

		/**
		 * Methods overriden from CSurface
		 */
		void   create(int width, int height, int pixelFormatType = PixelFormat::BPP_32);
		void   release();

		/**
		 * CWin32Surace specific methods,
		 * Blt draws the surface on a Window's DeviceContext
		 */
		void    blt(HWND destWindow, int xpos=0, int ypos=0);
		HBITMAP	getBitmap() const { return m_bitmapHandle; }	

	protected:

		/**
		 * CWin32Surface properties
		 */
		HBITMAP m_bitmapHandle;		// handle to hitmap containing DIB Section
		bool    m_active;					// flag set if created
};


}// end namespace Aurora


#endif
