/*
===========================================================================================
																	AURORA GFX LIBRARY 1.0	          												 
	_________________________________________________________________________________________	 
																																														 
			File        : core_bltasm.h 								            														   	
			Copyright(c): Peter Nordlander - 2000
			Author      :	Peter Nordlander	  																										 	
			Created     :	2001-01-06																															 
			Last Update :		               																							 
			Descr	  		: ASM optimized version of the blitter contains highly optimized asm routines  	 															 
										CASMBlitter ingherits CBlitter(it's ANSI C++ parent)and will fall back  	
										on the methods not available.                                            


			Rev History : 

==============================================================================================
*/
#ifndef __HELPER_ASM_DRAWER__
#define __HELPER_ASM_DRAWER__
//============================================================================================
// Includes
//============================================================================================
#include "draw.h"
#include <helper\typedefs.h>

//============================================================================================
// Namespace Aurora
//============================================================================================
namespace Helper {

//============================================================================================
// Class or method implementations
//============================================================================================
class DrawerASM : public Drawer
{
		protected:
		// internal blit methods - routed to by public blitmethods
		//virtual void internal_blit_scaleBilinear(CSurface &srcSurface, CArea &srcArea, CSurface &dstSurface, CSurface &dstArea);
		//virtual void internal_blit_alpha(byte *srcPixels,dword *dstPixels, int width, int height, int srcPitch, int dstPitch);
		//virtual void internal_blit_colorkey(byte *srcPixels, byte *dstPixels, int width, int height, int srcPitch, int dstPitch);
		//virtual void internal_blit_colorkey_alpha(byte *srcPixels, byte *dstPixels, int width, int height, int srcPitch, int dstPitch);
};
} // end namespace

#endif
