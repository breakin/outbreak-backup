#ifndef HELPER_DEMO_CONSOLE_H
#define HELPER_DEMO_CONSOLE_H

/*
	The "operating system" within the console system.

	This class simply stacks applications and runs the active one.

	The application returns their this-pointers if they want to stay 
	active, else returns NULL and the application closes.

	If you want to run another application, just create the object
	with new and return the pointer to the console and it simply runs
	next frame.
*/

#include "application.h"
#include "scripter.h"
#include "menu.h"

#include <helper/typedefs.h>
#include <stack>

namespace Helper {

	class Console {
	private:
		ConsoleData consoleData;
		std::stack<Application*> applications;
	
		Application* activeApplication;

	public:
		Console(const ConsoleData& consoleData);
		~Console();

		const bool update();
	};

}

#endif