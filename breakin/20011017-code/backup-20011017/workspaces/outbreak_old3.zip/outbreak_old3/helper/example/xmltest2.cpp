#include <helper.h>	// For the xml-parser
#include <iostream>	// For cout/cin
#include <fstream>	// For ifstream/ofstream
#include <conio.h>

void main() {
	try {

		std::cout << "Type a xml-compatible file using your keyboard." << std::endl;
		std::cout << "Feel free to betatest the tag-parser!" << std::endl << std::endl;

		// Read a xml-file from keyboard (cin)
		Helper::XmlParser x(std::cin);

		// Write a blank line
		std::cout << std::endl;

		// Write the xml to the screen
		x.writeXml(std::cout, "    ");
	}

	// Helper::Exception is derived from std::exception so this handler is redundant, included it anyway
	catch (Helper::Exception &e) {
		std::cout << "Helper::Exception; " << e.what() << std::endl;
	}

	catch (std::exception &e) {
		std::cout << "std::Exception; " << e.what() << std::endl;
	}

	getch();
}
