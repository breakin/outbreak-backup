
#include <helper.h>
#include <fstream>
#include <conio.h>
#include <windows.h>

using namespace Helper;
using namespace std;

void main(void) {

	try {

		XmlParser x(std::ifstream("test/script.xml"));

		Script script(x);

		Clock timer;

		while (script.update(timer.get())) {
			std::cout << timer.get() << "   ";

			Script::Scene& activeScene = script.getActiveScene();

			if (activeScene.name == "history") {
				cout << "s:history ";
			}

			if (activeScene.name == "flowerscene") {
				cout << "s:flowerscene ";
		
				Script::Effect& e1=activeScene.getEffect("vitsippa");
				Script::Effect& e2=activeScene.getEffect("nejlika");

				if (e1.running) {
					cout << "  [e:vitsippa]   ";
				}
				
				if (e2.running) {
					cout << "  [e:nejlika]   ";

					if (e2.getTriggerCount("nejlikasvamp")>0) {
						cout << " [t:nejlikatrigger] ";
					}
				}

				if (activeScene.getTriggerCount("lampa rod")>0) {
					cout << " [t:r�d lampa] ";
				}

				if (activeScene.getTriggerCount("lampa vit")>0) {
					cout << " [t:vit lampa] ";
				}
			}

			std::cout << std::endl;

			Sleep(100);
		}

		XmlParser o;
		script.save(o);
		o.writeXml(std::ofstream("test/script_out.xml"));
	}
	
	// Helper::Exception is derived from std::exception so this handler is redundant, included it anyway
	catch (Helper::Exception &e) {
		std::cout << "Helper::Exception; " << e.what() << std::endl;
	}

	catch (std::exception &e) {
		std::cout << "std::Exception; " << e.what() << std::endl;
	}
	
	catch (...) {
		std::cout << "Unknown exception";
	}

	std::cout << std::endl << "Press any key to continue." << std::endl;

	getch();
}