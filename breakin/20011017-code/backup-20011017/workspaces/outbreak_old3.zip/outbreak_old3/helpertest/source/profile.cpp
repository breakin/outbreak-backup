//#include <helper/profile/profile.h>
#include <helper/statistics.h>

using namespace Helper;

void main(void) {

	Statistics a;

}