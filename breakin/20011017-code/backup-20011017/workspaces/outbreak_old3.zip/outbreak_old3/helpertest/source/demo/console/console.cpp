#include "console.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Console::Console(const ConsoleData& consoleData) {
	this->consoleData = consoleData;

	Scripter* scripter = new Scripter(consoleData);
	applications.push(scripter);

	activeApplication = scripter;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Console::~Console() {
	while (applications.size()>0) {
		Application* temp = applications.top();
		applications.pop();
		delete temp;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const bool Helper::Console::update(const float64 timer) {
	// If there are no apps on the stack, tell the program to stop calling!
	// This only happens when the caller doesn't handle the return false 
	// statement, and there are some errors. I continue anyway though.
	if (activeApplication == 0) {
		return false;
	}

	// Update the active application.
	Application* result = activeApplication->update(timer);

	// Application closed.
	if (result == 0) {
		Application* temp = applications.top();
		applications.pop();
		delete temp;

		if (applications.size()>0) {
			// There were still applications on the stack,
			// set the active application to the one on top.
			activeApplication = applications.top();
			return true;
		} else {
			// No more applications, tell the program to stop calling!
			activeApplication = 0;
			return false;
		}
	}

	// New application, put it on stack and update activeApplication.
	if (result != activeApplication) {
		applications.push(result);
		activeApplication = result;
	}

	// Keep running the console.
	return true;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
