#ifndef HELPER_DEMO_C64_H
#define HELPER_DEMO_C64_H

#include <helper\imagedrawer\imagedrawer.h>

namespace Helper {

	class C64 {
	private:
		// Font stuff
		int32 fontWidth, fontHeight;
		int32 color[16];
		int32 foreground, background;

		// Fontdata and colordata for the images.
		Helper::Image32 fontData[256];
		int32 fontDataColor[256];

		// Drawer used by font and various.
		Helper::ImageDrawer drawer;

		// Functions to help drawLetter to set the right colour on the fontData.
		void clearBackground(Helper::Image32& dest, int32 x, int32 y);
		void clearFontRGB(uint8 sign);

	public:
		// Constructor / Destructor.
		C64(Helper::Image32& fontImage);
		~C64();

		// Font-routines.
		void setColor(int32 foreground, int32 background);

		void drawLetter(Helper::Image32& dest, int32 x, int32 y, uint8 sign);
	};

}

#endif