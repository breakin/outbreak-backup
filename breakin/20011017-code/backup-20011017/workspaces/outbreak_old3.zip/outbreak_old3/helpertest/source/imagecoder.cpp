#include <helper/imagetool/imagecoder/imagecoder_tga.h>
#include <helper/image.h>
#include <helper/archive/archivedirectory.h>

#include <conio.h>

using namespace Helper;

void main(void) {

	ImageCoder_TGA s;
	Image32 i;

	ArchiveDirectory a("test");

	ImageCoder::DecodeSettings dset;
	ImageCoder::EncodeSettings eset;

	Blob file;
	a["imagecoder_in.tga"].getData(file);
	s.decode(i, file, dset);
	s.encode(file, i, eset);
	a.createFile("imagecoder_out.tga", file);

	getch();
}