#include <helper/archive/archive.h>
#include <conio.h>
#include <helper/archive/archivedirectory.h>
#include <iostream>

using namespace Helper;
using namespace std;

void main(void) {
	
	ArchiveDirectory a("test/archive");
	//ArchiveRAR a("test/archive.rar");

	cout << "---" << endl;
	for (int C=0; C<a.getFileCount(); C++) cout << a[C].getName() << "=" << a[C].getSize() << endl;
	cout << "---" << endl;

	cout << "Reading a file..." << endl;
	Blob gah=a["test2.txt"].getData();
	
	cout << "Bytes: " << gah.getSize() << endl << "[";
	for (C=0; C<gah.getSize(); C++) cout << gah.get(C);
	cout << "]" << endl;

	cout << "---" << endl;

	a.createFile("created.txt", gah);

	getch();
}