#ifndef HELPER_DEMO_SCRIPT_H
#define HELPER_DEMO_SCRIPT_H

#include <helper/typedefs.h>
#include <helper/xml/xmlbase.h>
#include <vector>

namespace Helper {

	class Script {
	public:

		// Attribute
		struct Attribute {
			std::string name;
			std::string value;

			inline XmlTag getTag() const;
		};
		
		// One time execution only.
		struct Trigger {
			int         running;
			int         executedCount;

			std::string name;
			float64     start;
			int         repeat;
			float64     delay;

			inline XmlTag getTag() const;
			void setRunning(const float64 timer);
		};

		// Effect.
		class Effect {
		public:
			bool        running;
			float64		current;
			
			std::string name;
			float64     start;
			float64     end;

			std::vector<Attribute*>   attributeList;
			std::vector<Trigger*>     triggerList;

			const int getTriggerCount(const std::string& name);
			const std::string& getAttribute(const std::string name);
		};

		// Scene, demo-part.
		class Scene {
		public:
			std::string name;
			float64     current;
			float64     start;
			float64     end;

			std::vector<Attribute*>   attributeList;
			std::vector<Trigger*>     triggerList;
			std::vector<Effect*>      effectList;

			Effect& getEffect(const std::string& name);
			const int getTriggerCount(const std::string& name);
			const std::string& getAttribute(const std::string name);
		};

	private:
		// Update() control variables.
		Scene*  activeScene;

		void loadAttribute(std::vector<Attribute*> &attributeList, const XmlBase::IteratorConst& attribute);
		void loadTrigger(std::vector<Trigger*> &triggerList, const XmlBase::IteratorConst& trigger);
		void loadEffect(std::vector<Effect*> &effectList, const XmlBase::IteratorConst& effect, const float64 sceneEnd);

		void load(const XmlBase& xmlObject);

	public:
		// List of scenes.
		std::vector<Scene*> sceneList;

		// Initialize the script object 
		Script();
		Script(const XmlBase& xmlObject);
		~Script();
		
		void save(XmlBase& xmlObject);

		const bool update(const float64 timer);
		Scene& getActiveScene();
	};

}

#endif

