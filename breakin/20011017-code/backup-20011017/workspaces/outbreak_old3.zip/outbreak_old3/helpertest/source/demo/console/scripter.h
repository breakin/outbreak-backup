#ifndef HELPER_DEMO_SCRIPTER_H
#define HELPER_DEMO_SCRIPTER_H

/*
	This is the famous scripter for the script.
*/

#include "application.h"
#include "console.h"
#include <helper/demo/script.h>

#include <helper/typedefs.h>
#include <vector>

namespace Helper {

	class Scripter : public Application {

	private:
		struct TriggerGroup {
			std::string name;
			std::vector<Helper::Script::Trigger*> triggerList;
		};

		std::vector<TriggerGroup> triggerGroupList;

		const int findTriggerGroup(const std::string name);

		void loadGroups();

	public:
		Scripter(const ConsoleData& consoleData);
		Application* update(const float64 timer);
	};

}

#endif
