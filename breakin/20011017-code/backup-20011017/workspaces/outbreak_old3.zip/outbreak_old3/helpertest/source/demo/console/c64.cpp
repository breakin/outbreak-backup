#include "c64.h"

#include <helper/exception.h>

using namespace Helper;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::C64::clearBackground(Image32& dest, int32 x, int32 y) {
	int32* pixel = (int32*)dest.getPixels();

	// Clear dest with size of character, also set the right color.
	for (int yloop=y, offset=y*dest.getArea().getWidth()+x; yloop<y+fontHeight; yloop++, offset+=(dest.getArea().getWidth()-fontWidth)) {
		for (int xloop=x; xloop<x+fontWidth; xloop++, offset++) {
			pixel[offset] = color[background];
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::C64::clearFontRGB(uint8 sign) {
	// This helps us with speed issues. Font is not updated unless it's a new color.
	if (fontDataColor[sign] != foreground) {
		int32* pixel = (int32*)fontData[sign].getPixels();
		for (int32 offset=0; offset<fontWidth*fontHeight; offset++) {
			uint32 oldAlpha = pixel[offset]&0xff000000;			

			// Write the new color with empty alphachannel.
			pixel[offset] =  color[foreground];

			// Transfer alphachannel from old alpha.
			pixel[offset] |= oldAlpha;
		}

		fontDataColor[sign] = foreground;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::C64::C64(Image32& fontImage) {
	// Calculate sign width & height.
	fontWidth = fontImage.getArea().getWidth() / 16;
	fontHeight = fontImage.getArea().getHeight() / 16;

	// If the texture isn't the right size, throw an error to inform user.
	if ((fontWidth*16 != fontImage.getArea().getWidth()) ||
		(fontHeight*16 != fontImage.getArea().getHeight())) {
		
		throw Exception("Font texture not dividable in some of the dimentions using a divider of 16.");
	}

	// Loop through all the signs and copy textures.
	for (int y=0, offset=0; y<16; y++) {
		for (int x=0; x<16; x++, offset++) {
			AreaInt sourceArea;
			sourceArea.setLeft(x*fontWidth);
			sourceArea.setTop(y*fontHeight);
			sourceArea.setWidth(fontWidth);
			sourceArea.setHeight(fontHeight);

			fontData[offset].resize(fontWidth, fontHeight);
			fontDataColor[offset] = -1;

			drawer.draw(fontImage, sourceArea, fontData[offset], 0, 0, 0);
		}
	}

	// Set up c64 colors "borrowed" from VICE c64 emulator (default.vpl).
	color[0] = 0x000000;  // Black
	color[1] = 0xFDFEFC;  // White
	color[2] = 0xBE1A24;  // Red
	color[3] = 0x30E6C6;  // Cyan
	color[4] = 0xB41AE2;  // Purple
	color[5] = 0x1FD21E;  // Green
	color[6] = 0x211BAE;  // Blue
	color[7] = 0xDFF60A;  // Yellow
	color[8] = 0xB84104;  // Orange
	color[9] = 0x6A3304;  // Brown
	color[10] = 0xFE4A57; // Light red
	color[11] = 0x424540; // Dark grey
	color[12] = 0x70746F; // Medium grey
	color[13] = 0x59FE59; // Light green
	color[14] = 0x5F53FE; // Light blue
	color[15] = 0xA4A7A2; // Light grey

	foreground = 14;
	background = 6;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::C64::~C64() {
	for (int i=0; i<256; i++) {
		fontData[i].resize(0,0);
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::C64::setColor(int32 foreground, int32 background) {
	this->foreground = foreground;
	this->background = background;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::C64::drawLetter(Image32& dest, int32 x, int32 y, uint8 sign) {
	// If sign is outside the window, abort!
	if ((x+fontWidth>dest.getArea().getWidth()) || (y+fontHeight>dest.getArea().getWidth()) ||
		(x<0) || (y<0) ) return;

	// Clear background and foreground
	clearBackground(dest, x,y);
	clearFontRGB(sign);

	// Draw sign as usual.
	drawer.setAlphaMode(0);
	drawer.draw(fontData[sign], fontData[sign].getArea(), dest, x, y, 2);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
