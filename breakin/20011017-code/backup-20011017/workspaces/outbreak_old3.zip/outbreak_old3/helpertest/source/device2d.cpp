#include <math.h>
#include <windows.h>
#include <helper.h>
#include <helper\imagedrawer\imagedrawer.h>
#include <helper\demo\console\c64.h>
#include <helper\demo\console\console.h>
#include <helper\win32\win32_device2d.h>
#include <helper\tga\tga.h>

using namespace Helper;

//int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevinst, LPSTR cmdline, int showstate)
int main(void)
{
	Helper::Win32Device2D winDevice;
	Helper::Image32 image;
	Helper::Msg     msg;
	Helper::ImageDrawer drawer;
	Helper::TGALoader tgaLoader;
	
	// Configure the device
	winDevice.config("CAPTION","TRUE");
	winDevice.config("TITLE","Demo power!");
	winDevice.config("XPOS","100");
	winDevice.config("YPOS","100");
	winDevice.config("WIDTH","128");
	winDevice.config("HEIGHT","128");
	
	// Open configured device.
	winDevice.open();
		
	// Create the image
	image.create(128,128);
	
	// Load the font image.
	Helper::Image32 font;
	font.resize(128,128);
	tgaLoader.load("test\\c64.tga", font);

	uint32* pixels = (uint32*)font.getPixels();
	uint32* pixels2 = (uint32*)image.getPixels();
	for (int ix=0; ix<128*128; ix++) {
		uint8 alpha  = pixels[ix]>>24;
		pixels2[ix]  = (alpha<<16) + (alpha<<8) + alpha;
	}

	// Create the c64 "device".
	Helper::C64 c64(font);

	// Create the console and it's components.
	ConsoleData consoleData;
	consoleData.c64 = &c64;

	Console console(consoleData);

	// Fps variables.
	Helper::Clock timer;
	float64 start = timer.get();
	int32 frames  = 0;

	while (1)
	{
		// Fps stuff
		float64 fps = (float64)frames / (timer.get() - start);
		char temp[200];
		sprintf(temp, "FPS:%.3f     \0", fps);
		std::string tempString = temp;

		c64.setColor(7, 6);
		c64.drawString(image, 0,0, tempString);
		// End of fps stuff

		// Go through the messages.
		if (winDevice.getMessage(msg,true)) {
			if (msg.message == Helper::Msg::MSG_QUIT) break;
			if (msg.message == Helper::Msg::MSG_KEYCHAR) {
				// Escape
				if (msg.param==27) break;				
			}
		}
		
		winDevice.update(image);
		console.update();
		frames++;
	}
	
	return 1;
}
