#include <helper/blob.h>
#include <iostream>
#include <conio.h>

using namespace Helper;
using namespace std;

void debug(Blob &a) {

	if (!a.isEmpty()) {
		cout << &a.blobRef->mBuffer << " " << a.blobRef->mSize << " " << a.blobRef->refCount << endl;
	}else {
		cout << "(empty)" << endl;
	}
}

Blob g() {
	Blob gah(300);
	debug(gah);
	return gah;
}

Blob c() {
	return g();
}

void main(void) {

	Blob a=c();
	Blob b=c();
	debug(a);
	debug(b);
	a=b;
	debug(a);
	debug(b);

	getch();
}