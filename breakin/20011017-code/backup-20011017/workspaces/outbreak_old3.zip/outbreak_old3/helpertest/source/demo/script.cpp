
#include "script.h"
#include <helper/exception.h>
#include <algorithm>

using namespace std;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::XmlTag Helper::Script::Trigger::getTag() const {
	XmlTag t("trigger");

	t.setValue("name", name);
	t.setValue("start", start);

	if (repeat>1) {
		t.setValue("repeat", repeat);
		t.setValue("delay", delay);
	}
	
	return t;
}

void Helper::Script::Trigger::setRunning(const float64 timer) {
	if ((timer<start) || (executedCount>=repeat)) {
		running=0;
		return;
	}

	if (repeat==1) {
		running=1;
		executedCount=1;
	} else {
		int times=static_cast<int>( (timer-start)/delay );
		if (times>repeat) times=repeat;
		
		if (times > executedCount) {
			running=times-executedCount;
			executedCount+=running;
		} else {
			running=0;
		}
	}
}

Helper::XmlTag Helper::Script::Attribute::getTag() const {
	XmlTag t("attribute");

	t.setValue("name", name);
	t.setValue("value", value);

	return t;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

template<class T>const T& findName(const std::vector<T> &list, const std::string &name) {
	for (int C=0; C<list.size(); C++) {
		if (list[C].name==name) return list[C];
	}

	throw Helper::Exception("Script::findName; Name not found");
}

template<class T>const std::string& findValueByName(const std::vector<T> &list, const std::string &name) {
	for (int C=0; C<list.size(); C++) {
		if (list[C].name==name) return list[C].value;
	}

	throw Helper::Exception("Script::findValueByName; Value for name not found");
}

// [Effect stuff]- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const int Helper::Script::Effect::getTriggerCount(const std::string& name) {
	int count=0;

	for (int C=0; C<triggerList.size(); C++) {
		if (triggerList[C]->name==name) {
			count += triggerList[C]->running;
		}
	}

	return count;
}

const std::string& Helper::Script::Effect::getAttribute(const std::string name) {
	for (int C=0; C<attributeList.size(); C++) {
		if (attributeList[C]->name == name) return attributeList[C]->value;
	}

	throw Helper::Exception("Script::getAttribute; Attribute not found");
}

// [Scene stuff] - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Script::Effect& Helper::Script::Scene::getEffect(const std::string& name) {
	for (int C=0; C<effectList.size(); C++) {
		if (effectList[C]->name==name) return *effectList[C];
	}

	throw Helper::Exception("Script::getEffect; Name of effect not found");
}

const int Helper::Script::Scene::getTriggerCount(const std::string& name) {
	int count=0;

	for (int C=0; C<triggerList.size(); C++) {
		if (triggerList[C]->name==name) {
			count += triggerList[C]->running;
		}
	}

	return count;
}

const std::string& Helper::Script::Scene::getAttribute(const std::string name) {
	for (int C=0; C<attributeList.size(); C++) {
		if (attributeList[C]->name == name) return attributeList[C]->value;
	}

	throw Helper::Exception("Script::getAttribute; Attribute not found");
}

// [Private] - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::Script::loadAttribute(std::vector<Attribute*> &attributeList, const XmlBase::IteratorConst& attribute) {
	Attribute* a = new Attribute;
	
	a->name  = attribute->getValue("name");
	a->value = attribute->getValue("value");

	attributeList.push_back(a);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::Script::loadTrigger(std::vector<Trigger*> &triggerList, const XmlBase::IteratorConst& trigger) {
	Trigger* t = new Trigger;

	t->running=0;
	t->executedCount=0;

	t->name   = trigger->getValue("name");	
	t->start  = atof(trigger->getValue("start").c_str());

	const std::string &repeatString=trigger->getValue("repeat").c_str();

	if (repeatString.empty()) {
		
		t->repeat=1;
		t->delay=0;

	} else {

		t->repeat = atoi(repeatString.c_str());

		const std::string &delayString=trigger->getValue("delay");

		if (delayString.empty()) throw Helper::Exception("Script::loadTrigger; Repeat but no delay attribute found!");

		t->delay  = atof(delayString.c_str());
	}

	triggerList.push_back(t);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::Script::loadEffect(std::vector<Effect*> &effectList, const XmlBase::IteratorConst& effect, const float64 sceneEnd) {

	Effect* e = new Effect;
	e->name    = effect->getValue("name");
	e->start   = atof(effect->getValue("start").c_str());
	e->running = false;

	const std::string &endString=effect->getValue("end").c_str();

	if (endString.empty()) {
		e->end=sceneEnd;
	} else {
		e->end=atof(endString.c_str());
	}

	// Search for all attributes
	XmlBase::IteratorConst attribute=effect.createIterator("attribute");
	while (++attribute) {
		loadAttribute(e->attributeList, attribute);
	}

	// Search for all beats inside effects
	XmlBase::IteratorConst trigger=effect.createIterator("trigger");
	while (++trigger) {
		loadTrigger(e->triggerList, trigger);
	}

	effectList.push_back(e);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::Script::load(const XmlBase& xmlObject) {
	if (xmlObject.createIterator().getRoot().getName()!="script") throw Exception("Root-tag must be <script>");

	XmlBase::IteratorConst scene=xmlObject.createIterator("scene");
	while (++scene) {

		Scene* s = new Scene;
		s->name  = scene->getValue("name");
		s->start = atof(scene->getValue("start").c_str());
		s->end   = atof(scene->getValue("end").c_str());

		// Search for all attributes
		XmlBase::IteratorConst attribute=scene.createIterator("attribute");
		while (++attribute) {
			loadAttribute(s->attributeList, attribute);
		}

		// Search for all triggers
		XmlBase::IteratorConst trigger=scene.createIterator("trigger");
		while (++trigger) {
			loadTrigger(s->triggerList, trigger);
		}

		// Search for all effects
		XmlBase::IteratorConst effect=scene.createIterator("effect");
		while (++effect) {
			loadEffect(s->effectList, effect, s->end-s->start);
		}

		sceneList.push_back(s);
	}
}

// [Public]- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Script::Script() {
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Script::Script(const XmlBase& xmlObject) {
	load(xmlObject);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Script::~Script() {
	for (int S=0; S<sceneList.size(); S++) {

		for (int A=0; A<sceneList[S]->attributeList.size(); A++) {
			delete sceneList[S]->attributeList[A];
		}

		for (int T=0; T<sceneList[S]->triggerList.size(); T++) {
			delete sceneList[S]->triggerList[T];
		}

		for (int E=0; E<sceneList[S]->effectList.size(); E++) {
			for (int A=0; A<sceneList[S]->effectList[E]->attributeList.size(); A++) {
				delete sceneList[S]->effectList[E]->attributeList[A];
			}

			for (int T=0; T<sceneList[S]->effectList[E]->triggerList.size(); T++) {
				delete sceneList[S]->effectList[E]->triggerList[T];
			}
		}
	}
}
		
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::Script::save(XmlBase& xmlObject) {
	XmlBase::Iterator root=xmlObject.createIterator();

	root.getRoot().setName("script");
	
	// Save scenes
	for (int sceneIndex=0; sceneIndex < sceneList.size(); sceneIndex++) {

		const Scene &s=*sceneList[sceneIndex];

		XmlTag sceneTag("scene");
		sceneTag.setValue("name",  s.name);
		sceneTag.setValue("start", s.start);
		sceneTag.setValue("end",   s.end);

		XmlBase::Iterator scene=root.addChild(sceneTag);

		// Save scene attributes
		for (int attributeIndex=0; attributeIndex < s.attributeList.size(); attributeIndex++) {
			scene.addChild(s.attributeList[attributeIndex]->getTag());
		}

		// Save scene triggers
		for (int triggerIndex=0; triggerIndex < s.triggerList.size(); triggerIndex++) {
			scene.addChild(s.triggerList[triggerIndex]->getTag());
		}

		// Save scene effects
		for (int effectIndex=0; effectIndex < s.effectList.size(); effectIndex++) {

			const Effect& e=*s.effectList[effectIndex];

			XmlTag effectTag("effect");
			effectTag.setValue("name",  e.name);
			effectTag.setValue("start", e.start);
			effectTag.setValue("end",   e.end);

			XmlBase::Iterator effect=scene.addChild(effectTag);

			// Save effect attributes
			for (int attributeIndex=0; attributeIndex < e.attributeList.size(); attributeIndex++) {
				effect.addChild(e.attributeList[attributeIndex]->getTag());
			}

			// Save effect triggers
			for (int triggerIndex=0; triggerIndex < e.triggerList.size(); triggerIndex++) {
				effect.addChild(e.triggerList[triggerIndex]->getTag());
			}
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const bool Helper::Script::update(const float64 timer) {

	// If demo aint started, continue.
	if (timer<0) return true;

	// Find active scene.
	activeScene=0;
	for (int index=0; index<sceneList.size(); index++) {
		if ((timer>=sceneList[index]->start) && (timer<sceneList[index]->end)) {
			activeScene = sceneList[index];

			activeScene->current = (timer - activeScene->start) / (activeScene->end - activeScene->start);

			// Loop throught triggers and set running.
			for (int t=0; t<activeScene->triggerList.size(); t++) {
				activeScene->triggerList[t]->setRunning(timer-activeScene->start);
			}

			// Loop through the effects and set running to true.
			for (int e=0; e<activeScene->effectList.size(); e++) {
				Effect& currentEffect = *activeScene->effectList[e];

				// Check if it's running.
				if ((timer>=(currentEffect.start+activeScene->start)) && 
					(timer<(currentEffect.end+activeScene->start))) {
					
					currentEffect.running = true;
					currentEffect.current = (timer - (currentEffect.start+activeScene->start)) /
					                        (currentEffect.end - currentEffect.start);

					// Loop throught triggers and set running.
					for (t=0; t<currentEffect.triggerList.size(); t++) {
						currentEffect.triggerList[t]->setRunning(timer-currentEffect.start-activeScene->start);
					}
					
				} else {
					currentEffect.running=false;
				}
			}

			break;
		}
	}

	// If no scene is found (end of demo), return and finish.
	if (!activeScene) return false;

	return true;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Script::Scene& Helper::Script::getActiveScene() {
	return *activeScene;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

