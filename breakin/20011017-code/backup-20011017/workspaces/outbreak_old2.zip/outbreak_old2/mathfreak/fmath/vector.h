
#ifndef MATHFREAK_VECTOR_H
#define MATHFREAK_VECTOR_H

#include <cmath>
#include <iostream>

static const double EPSILON=1E-6;

namespace MathFreak {

	class Vector
	{
	protected:
	public:

		union { float x,r,u; };
		union { float y,g,v; };
		union { float z,b; };
		union { float w,a; };

		Vector(const double x=0, const double y=0, const double z=0);
		~Vector();

		Vector operator+(const Vector &other) const;
		Vector operator-(const Vector &other) const;
		Vector operator*(const Vector &other) const;
		Vector operator/(const Vector &other) const;
			
		// The following two operators are not for realtime use
		// They return true (or false for !=) if vectors are max 'epsilon' different
		// for all arguments
		bool operator==(const Vector &other) const;
		bool operator!=(const Vector &other) const;

		operator =(const Vector &other);

		operator+=(const Vector &other);
		operator-=(const Vector &other);
		operator*=(const Vector &other);
		operator/=(const Vector &other);
		
		operator+=(const double add);
		operator-=(const double subtract);
		operator*=(const double multiply);
		operator/=(const double divide);
		
		double sum() const;
		double length() const;
		double lengthby2() const;

		void  normalize();

		cross(const Vector &other);
		Vector crossReturn(const Vector &other) const;
		double dot(const Vector &other) const;
		Vector reflection(const Vector &normal) const;
	};

	typedef Vector Vector3;
	typedef Vector3 Vector2;
	typedef Vector Vector4;
	typedef Vector4 Color;
}

//***********************************************************

inline MathFreak::Vector::Vector(const double x, const double y, const double z) {
	this->x=static_cast<float>(x);
	this->y=static_cast<float>(y);
	this->z=static_cast<float>(z);
}

//***********************************************************

inline MathFreak::Vector::~Vector() {
}

//***********************************************************

inline MathFreak::Vector MathFreak::Vector::operator+(const Vector &other) const {
	return Vector(x+other.x, y+other.y, z+other.z);
}

//***********************************************************

inline MathFreak::Vector MathFreak::Vector::operator-(const Vector &other) const {
	return Vector(x-other.x, y-other.y, z-other.z);
}

//***********************************************************

inline MathFreak::Vector MathFreak::Vector::operator*(const Vector &other) const {
	return Vector(x*other.x, y*other.y, z*other.z);
}

//***********************************************************

inline MathFreak::Vector MathFreak::Vector::operator/(const Vector &other) const {
	return Vector(x/other.x, y/other.y, z/other.z);
}

//***********************************************************

inline MathFreak::Vector::operator=(const Vector &other) {
	x=other.x;
	y=other.y;
	z=other.z;
}

//***********************************************************

inline MathFreak::Vector::operator+=(const Vector &other) {
	x+=other.x;
	y+=other.y;
	z+=other.z;
}

//***********************************************************

inline MathFreak::Vector::operator-=(const Vector &other) {
	x-=other.x;
	y-=other.y;
	z-=other.z;
}

//***********************************************************

inline MathFreak::Vector::operator*=(const Vector &other) {
	x=x*other.x;
	y=y*other.y;
	z=z*other.z;
}

//***********************************************************

inline MathFreak::Vector::operator/=(const Vector &other) {
	x/=static_cast<float>(other.x);
	y/=static_cast<float>(other.y);
	z/=static_cast<float>(other.z);
}

//***********************************************************

inline MathFreak::Vector::operator+=(const double add) {
	x+=static_cast<float>(add);
	y+=static_cast<float>(add);
	z+=static_cast<float>(add);
}

//***********************************************************

inline MathFreak::Vector::operator-=(const double subtract) {
	x-=static_cast<float>(subtract);
	y-=static_cast<float>(subtract);
	z-=static_cast<float>(subtract);
}

//***********************************************************

inline MathFreak::Vector::operator*=(const double multiply) {
	x=static_cast<float>(x*multiply);
	y=static_cast<float>(y*multiply);
	z=static_cast<float>(z*multiply);
}

//***********************************************************

inline MathFreak::Vector::operator/=(const double divide) {
	*this*=1.0/divide;
}

//***********************************************************

inline double MathFreak::Vector::sum() const {
	return x+y+z;
}

//***********************************************************

inline double MathFreak::Vector::length() const {
	return sqrt(x*x+y*y+z*z);
}

//***********************************************************

inline double MathFreak::Vector::lengthby2() const {
	return x*x+y*y+z*z;
}

//***********************************************************
	
inline void MathFreak::Vector::normalize() {
	double tempLength=1.0/length();

	x*=static_cast<float>(tempLength);
	y*=static_cast<float>(tempLength);
	z*=static_cast<float>(tempLength);
}

//***********************************************************

inline MathFreak::Vector MathFreak::Vector::reflection(const Vector &normal) const {
	return (normal*((normal.crossReturn(*this)-*this)*2.0));
}

//***********************************************************

inline bool MathFreak::Vector::operator==(const Vector &other) const {
	if (((other.x-x)<EPSILON) && ((other.y-y)<EPSILON) && ((other.z-z)<EPSILON))
		return true;
	
	return false;
}

//***********************************************************

inline bool MathFreak::Vector::operator!=(const Vector &other) const {
	return !(*this==other);
}

//*[CROSS PRODUCT]******************************************* 

inline MathFreak::Vector MathFreak::Vector::crossReturn(const Vector &other) const {
	Vector result;

	result.x=y*other.z-z*other.y;
	result.y=z*other.x-x*other.z;
	result.z=x*other.y-y*other.x;

	return result;
}

inline MathFreak::Vector::cross(const Vector &other) {
	Vector result;

	result.x=y*other.z-z*other.y;
	result.y=z*other.x-x*other.z;
	result.z=x*other.y-y*other.x;

	*this=result;
}

//*[DOT PRODUCT]*********************************************

inline double MathFreak::Vector::dot(const Vector &other) const {
	return x*other.x+y*other.y+z*other.z;
}

//***********************************************************

inline std::ostream &operator<<(std::ostream &s, const MathFreak::Vector &v) {
	s << "(" << v.x << ", " << v.y << ", " << v.z << ")";
	return s;
}

#endif