#ifndef MATHFREAK_FRUSTUM_H
#define MATHFREAK_FRUSTUM_H

#include "plane.h"
#include <vector>

namespace MathFreak {

	class Frustum {
	private:

		std::vector<Plane> planes;

	public:

		const int test(const BSphere &bSphere) const { return 0; }

		void clearPlanes() { planes.clear(); }
		void addPlane(const Plane &other) { planes.push_back(other); }
	};
};

#endif