
#ifndef MATHFREAK_QUAT_H
#define MATHFREAK_QUAT_H

namespace MathFreak {

	class Quat {
	};
}

#endif