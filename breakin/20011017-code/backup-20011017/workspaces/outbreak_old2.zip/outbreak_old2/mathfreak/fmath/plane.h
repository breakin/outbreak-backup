#ifndef MATHFREAK_PLANE_H
#define MATHFREAK_PLANE_H

/* Plane is a class for handling planes (ax+by+cz+d) where the public member 'normal' defines x,y,z,d,
   being acess using normal.x, .y, .z and .w.
   */

#include "vector.h"

namespace MathFreak {

	class Plane
	{
	private:
		mutable Vector temp;

		Vector normal;

	public:

		Plane(Vector &newNormal) {
		}

		// Calculates intersection point between a ray (normalized) and the plane, returning the point of intersection	
		Vector intersection(const Vector &position, const Vector &direction) const {
			// TODO: Calculate and place result in temp

			return temp;
		}
	};
}

#endif