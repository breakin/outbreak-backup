#include "d3d.h"
#include "../../common/exception.h"

Plural::Device3dD3D::Device3dD3D() : Device3d(), running(false) {
	enumerate();
	reset();
}

Plural::Device3dD3D::~Device3dD3D() {
	if (running) close();
}

void Plural::Device3dD3D::reset() {
	if (running) close();

	// Set up defaults

	// Is a compatible version installed on the system?
	configData["available"].value="true";
	configData["available"].type="system";

	// Shall we run in fullsceren?
	configData["fullscreen"].value="true";
	configData["fullscreen"].type="checkbox";
}

void Plural::Device3dD3D::init() {
	if (running) throw Exception("Plural::Device3dD3D::close; Already running!");

	running=true;
}

void Plural::Device3dD3D::close() {
	if (!running) throw Exception("Plural::Device3dD3D::close; Not running!");

	running=false;
	reset();
}

void Plural::Device3dD3D::update() {
	if (!running) throw Exception("Plural::Device3dD3D::update; Not running!");
}

void Plural::Device3dD3D::config(const std::string &field, const std::string &value) {
	configData[field].value=value;
}