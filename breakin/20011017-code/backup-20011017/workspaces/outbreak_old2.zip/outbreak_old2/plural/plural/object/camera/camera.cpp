#include "camera.h"
#include <helper/debug.h>

Plural::Camera::Camera(const std::string &newName) 
	: Object(newName), trackPosition(0), trackTarget(0), trackRoll(0), trackFov(0) {

	#ifdef LOGGER
		Helper::Debug log("Plural::Camera::Camera");
		log << "Name     [" << getName() << "]" << std::endl;
	#endif
}

Plural::Camera::~Camera() {
	#ifdef LOGGER
		Helper::Debug log("Plural::Camera::~Camera");
		log << "Name     [" << getName() << "]" << std::endl;
	#endif
	
	delete trackPosition;
	delete trackTarget;
	delete trackRoll;
	delete trackFov;
}

void Plural::Camera::calculateTransformObjectSpace() {
}

void Plural::Camera::keyframe(const double time, const MathFreak::Matrix &parent, const int renderMode) {
	bool update=false;

	if (trackRoll!=0)     { update=true; roll=trackRoll->update(time); }
	if (trackFov!=0)      { update=true; fov=trackFov->update(time); }
	if (trackPosition!=0) { update=true; position=trackPosition->update(time); }
	if (trackTarget!=0)   { update=true; target=trackTarget->update(time); }

	if (update) calculateTransformObjectSpace();

	Object::keyframe(time, parent, renderMode);
}

void Plural::Camera::keyframe(const double time, const int renderMode) {
	bool update=false;

	if (trackRoll!=0)     { update=true; roll=trackRoll->update(time); }
	if (trackFov!=0)      { update=true; fov=trackFov->update(time); }
	if (trackPosition!=0) { update=true; position=trackPosition->update(time); }
	if (trackTarget!=0)   { update=true; target=trackTarget->update(time); }

	if (update) calculateTransformObjectSpace();

	Object::keyframe(time, renderMode);
}