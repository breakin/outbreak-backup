#ifndef PLURAL_KEYFRAME_TRACKFLOAT_H
#define PLURAL_KEYFRAME_TRACKFLOAT_H

#include <helper/typedefs.h>

namespace Plural {

	class TrackFloat {
	private:

		Helper::float64 currentValue;

	public:

		virtual ~TrackFloat() {}

		const Helper::float64 &getValue() const { return currentValue; }
		void setValue(const Helper::float64 newValue) { currentValue=newValue; }

		virtual const Helper::float64 &update(const Helper::float64 time, const Helper::float64 frameStep);
	};
};

#endif