#include "scene.h"
#include <helper/debug.h>

Plural::Scene::Scene(const std::string &newName) : Object(newName) {
	#ifdef LOGGER
		Helper::Debug log("Plural::Scene::Scene");
		log << "Name     [" << getName() << "]" << std::endl;
	#endif
}

Plural::Scene::~Scene() {
	#ifdef LOGGER
		Helper::Debug log("Plural::Scene::~Scene");
		log << "Name     [" << getName() << "]" << std::endl;
	#endif
}

void Plural::Scene::render(Device3d &device3d, const int renderMode) {
	Object::render(device3d, renderMode);
}

void Plural::Scene::keyframe(const double time, const MathFreak::Matrix &parent, const int renderMode) {
	Object::keyframe(time, parent, renderMode);
}

void Plural::Scene::keyframe(const double time, const int renderMode) {
	Object::keyframe(time, renderMode);
}

void Plural::Scene::lighten(const LightOmni &lightOmni, const int renderMode) {
}
