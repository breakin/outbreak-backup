#include "light.h"
#include <helper/debug.h>

Plural::Light::Light(const std::string &newName) : Object(newName) { 
	#ifdef LOGGER
		Helper::Debug log("Plural::Light::Light");
		log << "Name     [" << getName() << "]" << std::endl;
	#endif
}

Plural::Light::Light(const std::string &newName, const MathFreak::Vector &newPosition, const MathFreak::Color &newColor, const double newStrength)
	: Object(newName), position(newPosition), color(newColor), strength(newStrength) {

	#ifdef LOGGER
		Helper::Debug log("Plural::Light::Light");
		log << "Name     [" << getName() << "]" << std::endl;
		log << "Position [" << newPosition << "]" << std::endl;
		log << "Color    [" << newColor << "]" << std::endl;
		log << "Strength [" << newStrength << "]" << std::endl;
	#endif
}

Plural::Light::~Light() {
	#ifdef LOGGER
		Helper::Debug log("Plural::Light::~Light");
		log << "Name     [" << getName() << "]" << std::endl;
	#endif
}