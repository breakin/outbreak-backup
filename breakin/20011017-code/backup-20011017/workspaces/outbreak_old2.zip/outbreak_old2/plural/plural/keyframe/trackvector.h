#ifndef PLURAL_KEYFRAME_TRACKVECTOR_H
#define PLURAL_KEYFRAME_TRACKVECTOR_H

#include <helper/typedefs.h>
#include <fmath/vector.h>

namespace Plural {

	class TrackVector {
	private:

		MathFreak::Vector currentValue;

	public:

		virtual ~TrackVector() {}

		const MathFreak::Vector &getValue() const { return currentValue; }
		void setValue(const MathFreak::Vector &newValue) { currentValue=newValue; }

		virtual const MathFreak::Vector &update(const Helper::float64 time, const Helper::float64 frameStep) = 0;
	};
};

#endif