#ifndef PLURAL_DEVICE3D_D3D_H
#define PLURAL_DEVICE3D_D3D_H

#include "../device3d.h"
#include <d3d.h>
#include <sstream> // for istringstream

// TODO: Mayb redo using iterators, will work even if I change containers
// TODO: Move all class-methods to .cpp-files, even the nested stuff. Easier to read;
//       Preferably only forward declarations for the classes.
// TODO: Fix formatiing of type, very wrong at the moment

namespace Plural {

	BOOL WINAPI DriverEnumCallback( GUID* guid, char* strDesc,char* strName, VOID* parent, HMONITOR );
	HRESULT WINAPI ModeEnumCallback( DDSURFACEDESC2* pddsd,VOID* parent );
	HRESULT WINAPI DeviceEnumCallback( char* strDesc, char* strName, D3DDEVICEDESC7* pDesc,VOID* parent);
	HRESULT WINAPI EnumZBufferFormatsCallback( DDPIXELFORMAT* pddpf, VOID* parent );

	class Device3dD3D : public Device3d {
	private:

		//-----------------------------------------------------------

		class Driver {
		public:

			//-----------------------------------------------------------

			class Mode {
			private:

				DDSURFACEDESC2	surfaceDescription;

			public:

				Mode(const DDSURFACEDESC2 *newSurfaceDescription) {
					surfaceDescription=*newSurfaceDescription;
				}

				const DDSURFACEDESC2 &getSurf() const { return surfaceDescription; }
			};

			//-----------------------------------------------------------

			class Device3d {
			public:

				//-----------------------------------------------------------
			
				class ZBuffer {
				private:
					DDPIXELFORMAT	pixelFormat;
				public:
					ZBuffer(const DDPIXELFORMAT *pddpf) { 
						pixelFormat=*pddpf; 
					}

					const DDPIXELFORMAT &getPixelFormat() const { return pixelFormat; }
				};

				//-----------------------------------------------------------

			private:

				std::string				name;
				std::string				description;

				D3DDEVICEDESC7			deviceDesc;	// Here's the guid under ->deviceGUID

				std::vector<ZBuffer>	zBufferList;

			public:

				Device3d(const D3DDEVICEDESC7* newDeviceDesc, const char *newName, const char *newDescription) {
					deviceDesc=*newDeviceDesc;
					name=newName;
					description=newDescription;
				}

				void addZBuffer(const DDPIXELFORMAT *pddpf) {
					zBufferList.push_back(ZBuffer(pddpf));
				}


				void createSetupInfo(std::string &type, const std::vector<Mode> &modeList) const {
					type+="<";

					bool first=false;

					type+=name;
					if (!description.empty()) type+="{{"+description+"}}";

					for (int C=0; C<modeList.size(); C++) {
						for (int D=0; D<zBufferList.size(); D++) {

							const DWORD dwBitDepth=modeList[C].getSurf().ddpfPixelFormat.dwRGBBitCount;
							const DWORD dwBitZDepth=zBufferList[D].getPixelFormat().dwZBufferBitDepth;
							
							// Ignore mode if device is not capable of bitdepth
							if (dwBitDepth==8  && ((deviceDesc.dwDeviceRenderBitDepth & DDBD_8 )==0)) continue;
							if (dwBitDepth==16 && ((deviceDesc.dwDeviceRenderBitDepth & DDBD_16)==0)) continue;
							if (dwBitDepth==24 && ((deviceDesc.dwDeviceRenderBitDepth & DDBD_24)==0)) continue;
							if (dwBitDepth==32 && ((deviceDesc.dwDeviceRenderBitDepth & DDBD_32)==0)) continue;

							// Ignore mode if device is not capable of z-buffer bitdepth
							if (dwBitZDepth==8  && ((deviceDesc.dwDeviceZBufferBitDepth & DDBD_8 )==0)) continue;
							if (dwBitZDepth==16 && ((deviceDesc.dwDeviceZBufferBitDepth & DDBD_16)==0)) continue;
							if (dwBitZDepth==24 && ((deviceDesc.dwDeviceZBufferBitDepth & DDBD_24)==0)) continue;
							if (dwBitZDepth==32 && ((deviceDesc.dwDeviceZBufferBitDepth & DDBD_32)==0)) continue;

							if (!first) {
								first=true;
							} else {
								type+="|";
							}

							std::ostringstream width, height, bpp, zbuf, refresh;

							width << modeList[C].getSurf().dwWidth;
							type+=width.str()+",";

							height << modeList[C].getSurf().dwHeight;
							type+=height.str()+",";

							bpp << dwBitDepth;
							type+=bpp.str()+",";

							zbuf << dwBitZDepth;
							type+=zbuf.str()+",";								

							refresh << modeList[C].getSurf().dwRefreshRate;
							type+=refresh.str();
						}
					}

					type+=">";
				}
			};

			//-----------------------------------------------------------

		private:

			std::string				name;
			std::string				description;
			GUID					guid;
			bool					guidNull;

			LPDIRECT3D7				D3D7;

			DDCAPS					caps, helCaps;

			// TODO: zbufferList, or hm... yes :)
			std::vector<Device3d>	device3dList;
			std::vector<Mode>		modeList;

		public:

			Driver(const GUID *newGuid, const char *newName, const char *newDescription, const DDCAPS &newCaps, const DDCAPS &newHelCaps) {
				
				if (newGuid!=NULL) {
					memcpy(&guid, newGuid, sizeof(GUID));
					guidNull=false;
				} else {
					guidNull=true;
				}

				caps=newCaps;
				helCaps=newHelCaps;
				name=newName;
				description=newDescription;
			}

			LPDIRECT3D7		getLPDIRECT3D7() { return D3D7; }
			void			setLPDIRECT3D7(LPDIRECT3D7 newD3D7) { D3D7=newD3D7; }

			void addMode(const DDSURFACEDESC2 *newSurfaceDescription) {
				modeList.push_back(Mode(newSurfaceDescription));
			}

			void addDevice3d(const D3DDEVICEDESC7* newDeviceDesc, const char *newName, const char *newDescription, Device3d *&device) {
				device3dList.push_back(Device3d(newDeviceDesc, newName, newDescription));
				device=&device3dList.back();
			}

			void createSetupInfo(std::string &type) const {
				type+=name;
				if (!description.empty()) type+="{{"+description+"}}";

				type+="<";

				for (int C=0; C<device3dList.size(); C++) {
					if (C!=0) type+="|";
					device3dList[C].createSetupInfo(type, modeList);
				}

				type+=">";
			}
		};

		//-----------------------------------------------------------

		friend HRESULT WINAPI EnumZBufferFormatsCallback( DDPIXELFORMAT* pddpf, VOID* parent);
		friend HRESULT WINAPI ModeEnumCallback( DDSURFACEDESC2* pddsd,VOID* parent );
		friend BOOL WINAPI Plural::DriverEnumCallback( GUID* guid, char* strDesc,char* strName, VOID* parent, HMONITOR );
		friend HRESULT WINAPI DeviceEnumCallback( char* strDesc, char* strName, D3DDEVICEDESC7* pDesc,VOID* parent);

		void enumerate();
		std::vector<Driver> driverList;

		bool running;

		void addDriver(const GUID *newGuid, const char *newName, const char *newDescription, const DDCAPS &newCaps, const DDCAPS &newHelCaps, Driver *&driver) {
			driverList.push_back(Driver(newGuid, newName, newDescription, newCaps, newHelCaps));
			driver=&driverList.back();
		}


	public:

		Device3dD3D();
		virtual ~Device3dD3D();

		void init();
		void close();
		void reset();
		void update();
		void config(const std::string &field, const std::string &value);		
	};
}

#endif