#ifndef PLURAL_SCENE_H
#define PLURAL_SCENE_H

#include "../object.h"

/* Currently the only different between a scene and an object is that a scene does not multiply
   by it's matrix when keyframing and has no keyframing in itself.
   Later a scene must hold information about it's cameras and lights. */

namespace Plural {

	class Scene : public Object {
	public:

		Scene(const std::string &newName="unknown");
		virtual ~Scene();

		// Render
		virtual void render(Device3d &device3d, const int renderMode=OBJECT|CHILDREN);
		virtual void keyframe(const double time, const MathFreak::Matrix &parent, const int renderMode=OBJECT|CHILDREN);
		virtual void keyframe(const double time, const int renderMode=OBJECT|CHILDREN);
		virtual void lighten(const LightOmni &lightOmni, const int renderMode=OBJECT|CHILDREN);
	};
}

#endif