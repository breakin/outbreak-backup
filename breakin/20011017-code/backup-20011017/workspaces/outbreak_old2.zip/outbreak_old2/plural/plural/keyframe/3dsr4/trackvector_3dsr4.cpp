#include "trackvector_3dsr4.h"

const MathFreak::Vector &Plural::TrackVector_3DSR4::update(const Helper::float64 time, const Helper::float64 frameStep) {
	// TODO
	return currentValue;
}

void Plural::TrackVector_3DSR4::addKey(const Helper::float64 time, const MathFreak::Vector &value, const Helper::float64 t, const Helper::float64 c, const Helper::float64 b, const Helper::float64 easeFrom, const Helper::float64 easeTo) {
	Key k;

	k.time=time;
	k.value=value;
	k.t=t;
	k.c=c;
	k.b=b;
	k.easeFrom=easeFrom;
	k.easeTo=easeTo;

	// TODO: Insert at right time
	keys.push_back(k);
}
