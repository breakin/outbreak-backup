#ifndef PLURAL_DEVICE3D_H
#define PLURAL_DEVICE3D_H

#ifdef WIN32
#pragma warning(disable:4786)
#endif

#include <fmath.h>
#include <string>
#include <map>
#include <helper/message.h>

namespace Plural {

	struct SetupItem { // TODO: Move to setup
		std::string	value;
		std::string type;
	};

	class Device3d : public Helper::MessageQueue {
	private:
		
	protected:

		std::map<std::string, SetupItem> configData;

	public:

		Device3d() {};
		virtual ~Device3d() { reset(); }

		// Init screen according to config
		virtual void init() = 0;

		// Close screen, might be re-inited afterwards
		virtual void close() = 0;
		
		// Update the current frame (might generate messages for next frame)
		virtual void update() = 0;
		
		// Config (or re-config after init)
		// Might call close, change config and then run init if it's impossible
		// to change the config without doing so
		virtual void config(const std::string &field, const std::string &value) = 0;

		// Reset all configurations (default). Calls close if running
		// Will be called from destructor
		virtual void reset() = 0;
	};
}

#endif