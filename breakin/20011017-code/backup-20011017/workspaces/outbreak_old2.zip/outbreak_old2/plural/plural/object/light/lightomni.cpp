#include "lightomni.h"
#include <helper/debug.h>

Plural::LightOmni::LightOmni(const std::string &newName) : Light(newName) {
	#ifdef LOGGER
		Helper::Debug log("Plural::LightOmni::LightOmni", true);
		log << "Name     [" << getName() << "]" << std::endl;
	#endif
}

Plural::LightOmni::LightOmni(const std::string &name, const MathFreak::Vector &newPosition, const MathFreak::Vector &newColor, const double newStrength, const double newFallOff) 
	: Light(name, newPosition, newColor, newStrength), fallOff(newFallOff) {

	#ifdef LOGGER
		Helper::Debug log("Plural::LightOmni::LightOmni", true);
		log << "Name     [" << getName() << "]" << std::endl;
		log << "Falloff  [" << newFallOff << "]" << std::endl;
	#endif
}

Plural::LightOmni::~LightOmni() {
	#ifdef LOGGER
		Helper::Debug log("Plural::LightOmni::~LightOmni", true);
		log << "Name     [" << getName() << "]" << std::endl;
	#endif
}