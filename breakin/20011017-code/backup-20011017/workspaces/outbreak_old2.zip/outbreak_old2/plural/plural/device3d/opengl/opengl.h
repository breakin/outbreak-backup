#ifndef PLURAL_DEVICE3D_OPENGL_H
#define PLURAL_DEVICE3D_OPENGL_H

#include "../device3d.h"

namespace Plural {

	class Device3dOpenGL : public Device3d {
	private:

		bool running;

	public:

		Device3dOpenGL();
		virtual ~Device3dOpenGL();

		void init();
		void close();
		void reset();
		void update();
		void config(const std::string &field, const std::string &value);		
	};
}

#endif