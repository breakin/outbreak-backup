#ifndef PLURAL_CAMERA_H
#define PLURAL_CAMERA_H

#include "../object.h"
#include "../../keyframe/trackvector.h"
#include "../../keyframe/trackfloat.h"
#include <helper/typedefs.h>

namespace Plural {

	class Camera : public Object {
	private:

		TrackVector *trackPosition, *trackTarget;
		TrackFloat	*trackRoll, *trackFov;

		MathFreak::Vector	position,target;
		Helper::float64		roll,fov;

		void calculateTransformObjectSpace();

	public:

		Camera(const std::string &newName="unknown");
		virtual ~Camera();

		void setPositionTrack	(TrackVector	*newPositionTrack);
		void setTargetTrack		(TrackVector	*newPositionTrack);
		void setRollTrack		(TrackFloat		*newFloatTrack);
		void setFovTrack		(TrackFloat		*newFloatTrack);

		// Render
		virtual void keyframe(const double time, const MathFreak::Matrix &parent, const int renderMode=OBJECT|CHILDREN);
		virtual void keyframe(const double time, const int renderMode=OBJECT|CHILDREN);
	};
}

#endif