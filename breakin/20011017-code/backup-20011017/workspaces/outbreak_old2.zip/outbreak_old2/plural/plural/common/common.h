#ifndef PLURAL_COMMON_COMMON_H
#define PLURAL_COMMON_COMMON_H

#ifdef WIN32
#pragma warning(disable:4786)
#endif

#include <vector>
#include <fmath.h>
#include <exception>

namespace Plural {

	
}

#endif