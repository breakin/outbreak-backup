#ifndef PLURAL_KEYFRAME_TRACKFLOAT_3DSR4_H
#define PLURAL_KEYFRAME_TRACKFLOAT_3DSR4_H

#include "../trackfloat.h"
#include <vector>

/* Check so that tcb/ease are 'neutral' as default values */

namespace Plural {

	class TrackFloat_3DSR4 : public TrackFloat {
	private:

		struct Key {
			Helper::float64 time;
			Helper::float64 value;
			Helper::float64 t,c,b,easeFrom,easeTo;
		};

		int currentKey;

		Helper::float64 currentValue;

		std::vector<Key> keys;

	public:

		virtual const Helper::float64 &update(const Helper::float64 time, const Helper::float64 frameStep);

		void addKey(const Helper::float64 time, const Helper::float64 value, 
					const Helper::float64 t=1.0, const Helper::float64 c=1.0, const Helper::float64 b=1.0,
					const Helper::float64 easeFrom=1.0, const Helper::float64 easeTo=1.0);
	};
};

#endif