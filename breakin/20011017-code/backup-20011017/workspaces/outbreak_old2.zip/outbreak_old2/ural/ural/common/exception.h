
#ifndef URAL_COMMON_EXCEPTION_H
#define URAL_COMMON_EXCEPTION_H

#include <exception>

namespace Ural {

	class Exception : public exception {
	public:
		Exception(const char *message) : exception(message) {};
	};
}

#endif