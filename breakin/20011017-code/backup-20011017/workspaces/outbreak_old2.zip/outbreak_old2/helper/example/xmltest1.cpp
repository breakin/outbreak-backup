#include <helper.h>	// For the xml-parser
#include <iostream>	// For cout/cin
#include <fstream>	// For ifstream/ofstream

void main() {
	try {

		// Read a xml-file from xmltest.xml
		Helper::XmlParser x(std::ifstream("xmltest.xml"));

		// Write the xmlBase to xmltest1_out.xml, using four spaces as intend per level (default is a tab)
		x.writeXml(std::ofstream("xmltest1_out.xml"), "    ");
	}

	// Helper::Exception is derived from std::exception so this handler is redundant, included it anyway
	catch (Helper::Exception &e) {
		std::cout << "Helper::Exception; " << e.what() << std::endl;
	}

	catch (std::exception &e) {
		std::cout << "std::Exception; " << e.what() << std::endl;
	}

}
