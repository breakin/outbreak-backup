#include <helper.h>	// For the xml-parser
#include <iostream>	// For cout/cin
#include <fstream>	// For ifstream/ofstream
#include <conio.h>

// By not including a search criteria for a createIterator all tags in that node will be listed
// tagName can be found by using i->getName()

// If you want to find the parent tag you can take i.getRoot() (returns Tag-object)

// i-> actually refers to a Tag-object so check helper/source/tag.h for interface

void main() {
	try {

		// Read a xml-file from xmltest.xml
		Helper::XmlParser x(std::ifstream("xmltest.xml"));

		if (x.createIterator().getRoot().getName()!="demo") throw exception("Root-tag must be <demo>");

		// Browse for all setup-blocks in root
		Helper::XmlBase::IteratorConst s=x.createIterator("setup");

		std::cout << "Setup:" << std::endl;

		while (++s) {
			std::cout << "  " << s->getValue("name") << std::endl;

			Helper::XmlBase::IteratorConst attribute=s.createIterator("attribute");

			while (++attribute) {
				std::cout << "    " << attribute->getValue("name") << "=" << attribute->getValue("value") << std::endl;
			}
		}

		// Search for all synch-blocks in root
		std::cout << "Synch:" << std::endl;
		Helper::XmlBase::IteratorConst synch=x.createIterator("synch");
		while (++synch) {

			// Search for all beats
			std::cout << "  Beat:" << std::endl;

			Helper::XmlBase::IteratorConst beat=synch.createIterator("beat");

			while (++beat) {
				std::cout << "    Beat" << std::endl;
			}

			// Search for all effects
			std::cout << "  Effect:" << std::endl;

			Helper::XmlBase::IteratorConst effect=synch.createIterator("effect");

			while (++effect) {
				std::cout << "    Effect!" << std::endl;

				// Search for all beats inside effects
				Helper::XmlBase::IteratorConst beat=effect.createIterator("beat");
				while (++beat) {
					std::cout << "      Beat!" << std::endl;
				}
			}
		}
	}

	// Helper::Exception is derived from std::exception so this handler is redundant, included it anyway
	catch (Helper::Exception &e) {
		std::cout << "Helper::Exception; " << e.what() << std::endl;
	}

	catch (std::exception &e) {
		std::cout << "std::Exception; " << e.what() << std::endl;
	}
	
	getch();

}
