#include <helper.h>	// For the xml-parser
#include <iostream>	// For cout/cin
#include <fstream>	// For ifstream/ofstream
#include <conio.h>

// By not including a search criteria for a createIterator all tags in that node will be listed
// tagName can be found by using i->getName()

// If you want to find the parent tag you can take i.getRoot() (returns Tag-object)

// i-> actually refers to a Tag-object so check helper/source/tag.h for interface

void main() {
	try {

		// Read a xml-file from xmltest.xml
		Helper::XmlParser x(std::ifstream("xmltest.xml"));

		if (x.createIterator().getRoot().getName()!="demo") throw exception("Root-tag must be <demo>");

		// Search for all synch-blocks in root
		Helper::XmlBase::Iterator synch=x.createIterator("synch");
		while (++synch) {

			// Search for all beats
			Helper::XmlBase::Iterator beat=synch.createIterator("beat");

			while (++beat) {
				// Add the tag <afterbeat> after each beat-tag
				// and add the tag <underbeat> into the afterbeat-tag.

				// Notice that the constructor for Tag taking a name
				// by default closes the tag, but it is reopened when a child
				// is added to it (ie. in c.addChild())

				Helper::Tag a("afterbeat");
				a.setValue("test", "mest");
				Helper::XmlBase::Iterator c=beat.addChild(a);	// It's ok to ignore return-iterator!

				Helper::Tag b("underbeat");
				b.setValue("wow", "pow!");
				c.addChild(b);
			}
		}

		x.writeXml(std::ofstream("xmltest4_out.xml"));
	}

	// Helper::Exception is derived from std::exception so this handler is redundant, included it anyway
	catch (Helper::Exception &e) {
		std::cout << "Helper::Exception; " << e.what() << std::endl;
	}

	catch (std::exception &e) {
		std::cout << "std::Exception; " << e.what() << std::endl;
	}
}
