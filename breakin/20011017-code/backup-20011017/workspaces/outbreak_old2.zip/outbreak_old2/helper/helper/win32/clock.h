#ifndef HELPER_WIN32_CLOCK_H
#define HELPER_WIN32_CLOCK_H

namespace Helper {

	class Clock {
	private:

		double startTime;

		static bool initialized;
		inline static const double getTime();
		inline static void initTime();

	public:

		Clock() {
			if (!initialized) {
				initTime();

				// Initialize hardware timer.
				// Made once for all instances of this class.				
				
				initialized=true;
			}

			startTime=getTime();
		}

		~Clock() {
		}

		inline const double get() const { return getTime()-startTime; }
	};
};

#endif
