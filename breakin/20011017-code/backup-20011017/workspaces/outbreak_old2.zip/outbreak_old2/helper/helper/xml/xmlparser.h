#ifndef HELPER_XMLPARSER_H
#define HELPER_XMLPARSER_H

#include <iostream>
#include "xmlbase.h"

/* Restrictions on xml-files parsed:

	Does not allow tag-attributes without an value, like
		<tagname name>

	Does not allow text out of tags, such as:
		<tagname>Text</tagname>

	Due to this this is not a complete xml-parser, but it do fit our needs.

  Notes:

	All tagnames are converted to lowercase

*/

namespace Helper {

	class XmlParser : public XmlBase {
	private:

		void parseXml(std::istream &inputStream, Iterator &parent);
		void writeXml(std::ostream &outputStream, IteratorConst &parent, const std::string &intend, const int depth) const;
		bool parsed;

	public:

		XmlParser();
		XmlParser(std::istream &inputStream);
		~XmlParser();

		void writeXml(std::ostream &outputStream, const std::string &intend="\t") const;

		void parseXml(std::istream &inputStream);
		void clear();
	};
};

#endif