#ifndef HELPER_DEBUG_H
#define HELPER_DEBUG_H

/* TODO: Total rewrite of Tooon */

#ifdef WIN32
#ifdef _DEBUG
	#define LOGGER
#endif
#endif

#ifdef LOGGER

#include <ostream>
#include <string>

/* Denna klassen kanske ser ut som en idyll, men det var ett helvete att f� r�tt p� tramset
   Tyv�rr kan vi inte streama in i konstruktorn som vi hade kunnat g�ra med printf, men det f�r vi leva med.
   En ok syntax �r f�ljande:

	#ifdef LOGGER
		Debug log("Image::Image", false); // true=superdebug, false(default)=normal debug
		log << "Creating image" << 32 << 4.5 << std::endl;
	#endif

	#ifdef LOGGER
		log << "Major problem, shutting down!" << std::endl;
	#endif
*/

namespace Helper {

	class Debug : public std::basic_ostream<char> {
	public:

		Debug(const std::string &methodName, const bool extra=false);
		~Debug();
	};
};

#endif
#endif