#include "xmlbase.h"
#include "../exception.h"

// Ideas: Might implement an operator[] for Iterator[Const]
// MIght rename getRoot to something good <g>

// Fix operator-- for Iterator[Const]

//--------------------------------------------------------------------------//

Helper::XmlBase::XmlBase() {
}

Helper::XmlBase::~XmlBase() {
}

Helper::XmlBase::Iterator Helper::XmlBase::createIterator(const std::string &searchCriteria) {
	return root.createIterator(searchCriteria);
}

Helper::XmlBase::IteratorConst Helper::XmlBase::createIterator(const std::string &searchCriteria) const {
	return root.createIterator(searchCriteria);
}

void Helper::XmlBase::clear() {
	root.clear();
}

//--------------------------------------------------------------------------//

Helper::XmlBase::Node::Node() {
}

Helper::XmlBase::Node::Node(const XmlTag &initTag) : tag(initTag) {
}

Helper::XmlBase::Node::~Node() {
	clear();
}

void Helper::XmlBase::Node::setTag(const XmlTag &newTag) {
	tag=newTag;
}

void Helper::XmlBase::Node::clear() {
	setTag(XmlTag());
	
	for (int C=0; C<children.size(); C++) {
		delete children[C];
	}

	children.clear();
}

Helper::XmlBase::Iterator Helper::XmlBase::Node::createIterator(const std::string &searchCriteria) {
	return Iterator(this, searchCriteria);
}

Helper::XmlBase::IteratorConst Helper::XmlBase::Node::createIterator(const std::string &searchCriteria) const {
	return IteratorConst(this, searchCriteria);
}

const Helper::XmlTag& Helper::XmlBase::Node::getTag() const {
	return tag;
}

Helper::XmlTag& Helper::XmlBase::Node::getTag() {
	return tag;
}

const int Helper::XmlBase::Node::getChildrens() const {
	return children.size();
}

const Helper::XmlBase::Node& Helper::XmlBase::Node::getChildren(const int index) const {
	return *children[index];
}

Helper::XmlBase::Node& Helper::XmlBase::Node::getChildren(const int index) {
	return *children[index];
}

Helper::XmlBase::Iterator Helper::XmlBase::Node::addChild(const int index, const XmlTag &childTag) {
	// Force parent tag to be opened (can't have children otherwise, can em?)
	tag.setClosed(false);

	if (index==children.size()) {
		children.push_back(new Node(childTag));
		return children.back()->createIterator();
	} else {

		// This might not be fully portable (using &element as a iterator), fix! (todo)
		children.insert(&children[index], new Node(childTag));
		return children[index]->createIterator();
	}
}

//--------------------------------------------------------------------------//

Helper::XmlBase::Iterator::Iterator(Node *newContext, const std::string &newSearchCriteria) :	
		context(newContext), 
		searchCriteria(newSearchCriteria),
		atBegin(true),
		atEnd(false),
		currentChild(-1) {
}

Helper::XmlBase::Iterator::~Iterator() {
}

const bool Helper::XmlBase::Iterator::isAtBegin() const {
	return atBegin;
}

const bool Helper::XmlBase::Iterator::isAtEnd() const {
	return atEnd;
}

Helper::XmlTag* Helper::XmlBase::Iterator::operator->() {
	if (atBegin) throw Exception("XmlBase::Iterator::operator->; Can't access before first element, try operator++ first!");
	if (atEnd) throw Exception("XmlBase::Iterator::operator->; Can't access after last element, no Tags matching searchCriteria?");
	return &context->getChildren(currentChild).getTag();
}

const Helper::XmlTag* Helper::XmlBase::Iterator::operator->() const {
	if (atBegin) throw Exception("XmlBase::Iterator::operator->; Can't access before first element!");
	if (atEnd) throw Exception("XmlBase::Iterator::operator->; Can't access after last element!");
	return &context->getChildren(currentChild).getTag();
}

const bool Helper::XmlBase::Iterator::operator++() {
	if (atEnd) throw Exception("XmlBase::Iterator::operator++; Called after last tag!");

	atBegin=false;

	if (currentChild+1>=context->getChildrens()) {
		currentChild=context->getChildrens();
		atEnd=true;
		return false;
	}

	if (searchCriteria.empty()) { 
		currentChild++;
		return true;
	}

	for (int C=currentChild+1; C<context->getChildrens(); C++) {
		if (context->getChildren(C).getTag().getName()==searchCriteria) {
			currentChild=C;
			return true;
		}
	}

	atEnd=true;
	return false;
}

const Helper::XmlTag& Helper::XmlBase::Iterator::getRoot() const {
	return context->getTag();
}

Helper::XmlTag& Helper::XmlBase::Iterator::getRoot() {
	return context->getTag();
}

Helper::XmlBase::Iterator Helper::XmlBase::Iterator::createIterator(const std::string &searchCriteria) const {
	return context->getChildren(currentChild).createIterator(searchCriteria);
}

Helper::XmlBase::Iterator Helper::XmlBase::Iterator::addChild(const XmlTag &childTag) {
	atEnd=false;
	atBegin=false;
	currentChild++;
	return context->addChild(currentChild, childTag);
}

void Helper::XmlBase::Iterator::setRoot(const XmlTag &t) {
	context->getTag()=t;
}

//--------------------------------------------------------------------------//

Helper::XmlBase::IteratorConst::IteratorConst(const Node * const newContext, const std::string &newSearchCriteria) :	
		context(newContext), 
		searchCriteria(newSearchCriteria),
		atBegin(true),
		atEnd(false),
		currentChild(-1) {
}

Helper::XmlBase::IteratorConst::IteratorConst(const Iterator &i) {
	*this=i;
}

Helper::XmlBase::IteratorConst::~IteratorConst() {
}

void Helper::XmlBase::IteratorConst::operator=(const Iterator &i) {
	atBegin=i.isAtBegin();
	atEnd=i.isAtEnd();
	context=i.getContext();
	searchCriteria=i.getSearchCriteria();
	currentChild=i.getCurrentChild();
}

const bool Helper::XmlBase::IteratorConst::isAtBegin() const {
	return atBegin;
}

const bool Helper::XmlBase::IteratorConst::isAtEnd() const {
	return atEnd;
}

const Helper::XmlTag* Helper::XmlBase::IteratorConst::operator->() const {
	if (atBegin) throw Exception("XmlBase::IteratorConst::operator->; Can't access before first element!");
	if (atEnd) throw Exception("XmlBase::IteratorConst::operator->; Can't access after last element!");
	return &context->getChildren(currentChild).getTag();
}

const bool Helper::XmlBase::IteratorConst::operator++() {
	if (atEnd) throw Exception("XmlBase::IteratorConst::operator++; Called after last tag!");

	atBegin=false;

	if (currentChild+1>=context->getChildrens()) {
		currentChild=context->getChildrens();
		atEnd=true;
		return false;
	}

	if (searchCriteria.empty()) { 
		currentChild++;
		return true;
	}

	for (int C=currentChild+1; C<context->getChildrens(); C++) {
		if (context->getChildren(C).getTag().getName()==searchCriteria) {
			currentChild=C;
			return true;
		}
	}

	atEnd=true;
	return false;
}

const Helper::XmlTag& Helper::XmlBase::IteratorConst::getRoot() const {
	return context->getTag();
}

Helper::XmlBase::IteratorConst Helper::XmlBase::IteratorConst::createIterator(const std::string &searchCriteria) const {
	return context->getChildren(currentChild).createIterator(searchCriteria);
}