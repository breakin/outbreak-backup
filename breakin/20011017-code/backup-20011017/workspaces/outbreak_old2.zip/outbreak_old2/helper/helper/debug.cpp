#include "debug.h"

#ifdef LOGGER

#include "exception.h"
#include <string>
#include <streambuf>
#include <fstream>

// CONFIG ----------------------------------------------------------------------------

static const char*	debugFileName="secret.log";
static const char*	debugIntendString="    ";
static const int	debugMaxDepth=8;
static const bool	debugExtra=true;

//----------------------------------------------------------------------------

class Tjosan : public std::basic_streambuf<char> {
private:

	static bool newLine;
	static std::ofstream *outputFile;
	static int intend;
	static int lowestPause;

protected:

	void outputIntend() {
		for (int C=0; C<intend; C++) *outputFile << debugIntendString;
	}

	virtual int_type overflow(int_type _C = std::char_traits<char>::eof()) {
		if (intend<lowestPause) {
			if (newLine) { outputIntend(); newLine=false; }
			*outputFile << char(_C);
			if (_C=='\n') newLine=true;
			if (!outputFile) return std::char_traits<char>::eof();
		}
	
		return _C;
	}

public:

	void open() {
		if (outputFile==0) {
			outputFile=new std::ofstream(debugFileName);

			*outputFile << "----------------------" << std::endl;
			*outputFile << "Mega-cool ascii header" << std::endl;
			*outputFile << "----------------------" << std::endl;
			*outputFile << "depth:      " << debugMaxDepth << std::endl;
			*outputFile << "superdebug: " << (debugExtra==true?"on":"off") << std::endl;
			*outputFile << "----------------------" << std::endl;
		}
	}

	void pause() {
		if (intend<lowestPause) lowestPause=intend;
	}

	void close() {
		if (intend<=0) delete [] outputFile;
	}

	void operator++() {
		if (intend==0) open();
		intend++; 
	}

	void operator--() { 
		intend--; 
		if (intend<lowestPause) lowestPause=debugMaxDepth; 
	}

} myDebugger;

bool Tjosan::newLine=true;
std::ofstream *Tjosan::outputFile=0;
int Tjosan::intend=0;
int Tjosan::lowestPause=debugMaxDepth;

//----------------------------------------------------------------------------

Helper::Debug::Debug(const std::string &methodName, const bool extra) : std::basic_ostream<char>(&myDebugger) {
	if (extra && !debugExtra) myDebugger.pause();

	myDebugger.open();
	*this << std::endl << methodName << " {" << std::endl;
	++myDebugger;
}

//----------------------------------------------------------------------------

Helper::Debug::~Debug() {

	--myDebugger;
	*this << "}" << std::endl;
	myDebugger.close();	
}

//----------------------------------------------------------------------------

#endif