#ifndef HELPER_PROFILE_PROFILE_H
#define HELPER_PROFILE_PROFILE_H

// Archive manager with built in caching of files

/* Ideas:

If a new[] fails things non-cached files should be flushed 

ProfileLock(Profile, "hejsan.xml");
ProfileLockImage(Profile, "hejsan.tga");
ProfileLockImage(Profile, "hejsan.tga", Profile::SAVEACCESS|Profile::WRITEACCESS|Profile::READACCESS);

vid ~ProfileLock s� kallas Profile->unlock

*/

#include <map>
#include <string>

#include "../image.h"
#include "../typedefs.h"

#include "profilestatistics.h"

namespace Helper {

	class Profile {
	public:

		enum { READACCESS, WRITEACCESS, SAVEACCESS };

		/* For an archive readAccess means that it's readable, writeaccess that
		   one might save files to it and saveAccess that automated saveing will be perfomed */

		/* For a file readaccess means you can read, write that you have a unique copy of the file
		   and saveaccess that your unique copy will be saved somehow */

	private:

		int archiveAccessMode;

		struct FileEntry {

			bool markedForSave;
			bool markedForDelete;

			bool references;
			int referenceCount;
			
			int fileSize;
			uint8* cachedData;
		};

		struct ImageEntry {

			bool markedForEncode;
			
			int referenceCount;
			bool unique;

			FileEntry *fileEntry;

			int imageSize;

			Image32 *image;
		};

		std::multimap<std::string, FileEntry*> fileList;

		// Optimization for unlock
		std::map<uint8*, FileEntry> fileLockedList;
		std::map<Image32*, ImageEntry> imageLockedList;

		bool deleteStatisticsOnDestruct;
		ProfileStatistics *statistics;

	protected:

		const int getArchiveAccessMode() const;

		uint8 *lock(const std::string &filenameWithPath, const int acess=READACCESS);
		Image32* lockImage(const std::string &filenameWithPath, const int acess=READACCESS);

		void unlock(uint8 *fileData);
		void unlockImage(Image32 *imageData);

		// Used for parsing the archive
		virtual void loadFileList(std::multimap<std::string, FileEntry*> &destination) = 0;
		virtual void saveFileList(const std::multimap<std::string, FileEntry*> &source) = 0;

	public:

		Profile(const int access=READACCESS, ProfileStatistics *stats=0) {
			if (stats==0) {
				deleteStatisticsOnDestruct=true;
				statistics=new ProfileStatistics(*this);
			} else {
				deleteStatisticsOnDestruct=false;
			}

		}
		virtual ~Profile();

		// Following might be called by statistics and
		// when called they will call statistics for an update
		void flushCache();
		void flushFileCache();
		void flushImageCache();		

		void copy(Profile *destinationProfile, const bool keepNotReferencedFiles=true);
	};
}

#endif