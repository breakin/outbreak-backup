#ifndef HELPER_IMAGE_IMAGEDRAWER_H
#define HELPER_IMAGE_IMAGEDRAWER_H

#include "image.h"

// Imagedrawer might be implemented using a internal object that is access via a pointer and
// set up using System, or by method-pointers.
// I will do a clipper that calls four internal methods depending on values
// and those might be mmxed, asmed and so on.

namespace Helper {

	class ImageDrawer {
	private:
	public:

		// Copy (dest=source)		
		// Will zoom if destArea is different from sourceArea
		void draw(Image32 &dest, const Image32 &source, const Area<int> &destArea, const Area<int> &sourceArea);

		// Copy but blend using source-alpha (dest=dest*(1.0-sourceAlpha)+source*sourceAlpha)
		// Will zoom if destArea is different from sourceArea
		void drawAlpha(Image32 &dest, const Image32 &source, const Area<int> &destArea, const Area<int> &sourceArea);
	};
};

#endif