#ifndef HELPER_MESSAGEQUEUE_H
#define HELPER_MESSAGEQUEUE_H

#include <queue>
#include "point.h"

/* This is class should be derived into all devices that want to have a message queue of keys/mouse/... */

namespace Helper {

	class Message {
	private:
	public:
	};

	class MessageQueue {
	private:
		
		std::queue<Message> q;
		Point<int> mousePosition;
		
	protected:

		void messageKeyDown();
		void messageKeyUp();
		void messageChar(char character);
		void messageMouseMove(const Point<int> &position) { mousePosition=position; }
		void messageMouseLeftDown();
		void messageMouseLeftUp();
		void messageMouseRightDown();
		void messageMouseRightUp();
		void messageMouseLeftDoubleClick();
		void messageMouseRightDoubleClick();

	public:

		std::queue<Message> &getMessageQueue() { return q; }
		const std::queue<Message> &getMessageQueue() const { return q; }
	};
};

#endif