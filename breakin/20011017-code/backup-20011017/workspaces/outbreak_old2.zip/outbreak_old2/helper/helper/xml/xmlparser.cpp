#include "xmlparser.h"
#include "../exception.h"
#include "xmltag.h"

Helper::XmlParser::XmlParser() {
	parsed=false;
}

Helper::XmlParser::XmlParser(std::istream &inputStream) {
	parsed=false;
	parseXml(inputStream);
}

Helper::XmlParser::~XmlParser() {
	clear();
}

void Helper::XmlParser::clear() {
	XmlBase::clear();
	parsed=false;
}

void Helper::XmlParser::parseXml(std::istream &inputStream) {
	if (parsed==true) throw Exception("XmlParser::parseXml; Parser has already parsed a xml-file, use erase() first!");

	try {
		XmlTag startTag;
		inputStream >> startTag;

		if (startTag.getClosed()) throw Exception("XmlParser::parseXml; Root tag is closed!");

		Iterator i=createIterator();
		i.getRoot().setTag(startTag);

		parseXml(inputStream, i);
	}

	catch(...) {
		throw Exception("Helper::XmlParser::parseXml; Error when parsing xml-file!");
	}
}

void Helper::XmlParser::parseXml(std::istream &inputStream, Iterator &parent) {
	while (true) {

		XmlTag t;
		inputStream >> t;

		// Jump out a branch if found end of current depth block
		if (t.getClosed() && t.getName()==parent.getRoot().getName()) return;

		Iterator i2=parent.addChild(t);

		if (t.getClosed()==false) parseXml(inputStream, i2);				
	}
}

void Helper::XmlParser::writeXml(std::ostream &outputStream, const std::string &intend) const {
	writeXml(outputStream, createIterator(), intend, 1);
}

void Helper::XmlParser::writeXml(std::ostream &outputStream, IteratorConst &parent, const std::string &intend, const int depth) const {
	for (int C=0; C<depth-1; C++) outputStream << intend;
	outputStream << "<" << parent.getRoot().getName() << ">" << std::endl;

	while (++parent) {
		for (int C=0; C<depth; C++) outputStream << intend;
		outputStream << *parent.operator->() << std::endl;
		if (!parent->getClosed()) writeXml(outputStream, parent.createIterator(), intend, depth+1);
	}

	for (C=0; C<depth-1; C++) outputStream << intend;
	outputStream << "</" << parent.getRoot().getName() << ">" << std::endl;
}