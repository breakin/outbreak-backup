#ifndef HELPER_PROFILE_PROFILESTATISTICS_H
#define HELPER_PROFILE_PROFILESTATISTICS_H

#include <vector>

namespace Helper {

	class Profile;
	
	class ProfileStatistics {
	private:

		int currentFileCache;	// Indicates if a load requires getting rid of old data
		int currentImageCache;

		int totalImageCache;	// Bytes totally cached (delete[] does not subtract)
		int totalFileCache;		// Av value larger than peek*Cache indicate swapping

		int peekImageCache;		// The maximum of bytes totally cached at the same time
		int peekFileCache;

		int peekCache;
		
		std::vector<Profile*> profiles;
		
	protected:		
		
		void allocateImage(const int bytes) {
			currentImageCache+=bytes;
			totalImageCache+=bytes;
			if (currentImageCache>peekImageCache) peekImageCache=currentImageCache;
			if (currentImageCache+currentFileCache>peekCache) peekCache=currentImageCache+currentFileCache;
		}

		void allocateFile(const int bytes) {
			currentFileCache+=bytes;
			totalFileCache+=bytes;
			if (currentFileCache>peekFileCache) peekFileCache=currentFileCache;
			if (currentImageCache+currentFileCache>peekCache) peekCache=currentImageCache+currentFileCache;
		}
	
		void deallocateFile(const int bytes) {
			currentFileCache-=bytes;
		}

		void deallocateImage(const int bytes) {
			currentImageCache-=bytes;
		}

		void addProfile(Profile* profile) {
			profiles.push_back(profile);
		}

	public:

		virtual void flush() { for (int C=0; C<profiles.size(); C++) profiles[C]->flush(); }
		virtual void flushFiles() { for (int C=0; C<profiles.size(); C++) profiles[C]->flushFiles(); }
		virtual void flushImages() { for (int C=0; C<profiles.size(); C++) profiles[C]->flushImags(); }
	};
}

#endif