#ifndef HELPER_TAG_H
#define HELPER_TAG_H

/* Parsing broken atm */

#ifdef WIN32
#pragma warning(disable:4786)
#endif

#include <string>
#include <vector>
#include <iostream>

namespace Helper {

	class XmlTag {
	public:

		class Argument {
		private:

			std::string name;
			std::string value;

		public:

			Argument(const std::string &newName, const std::string &newValue) : name(newName), value(newValue){
			}

			const std::string &getName() const { return name; }
			const std::string &getValue() const { return value; }
			void setName(const std::string &newName) { name=newName; }
			void setValue(const std::string &newValue) { value=newValue; }
		};

	private:

		bool closed;
		std::string name;
		std::vector<Argument> arg;
		
	public:

		XmlTag();
		XmlTag(const std::string &newName);
		~XmlTag();

		void setTag(const XmlTag &tag);
		
		// Returns the name of the tag
		const std::string &getName() const;

		// Returns the value of a given attribute
		const std::string &getValue(const std::string &name) const;

		// Returns if the tag is closed, ie. has a /-marker
		const bool getClosed() const;

		// Set the state of the tag
		void setClosed(const bool newClosed=true);
		void setName  (const std::string &newName);
		void setValue (const std::string &name, const std::string &value);

		// Empties all data for the tag, (clearing the attributelist)
		void erase();

		// Methods used for iterating through all attributes
		const std::vector<Argument> &getArg() const;
		      std::vector<Argument> &getArg();		
	};
}

// Output a Tag on a output-stream
extern std::ostream &operator<<(std::ostream &s, const Helper::XmlTag &t);
extern std::istream &operator>>(std::istream &s, Helper::XmlTag &t);

#endif
