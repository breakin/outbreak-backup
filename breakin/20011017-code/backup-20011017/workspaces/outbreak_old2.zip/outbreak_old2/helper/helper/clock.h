#ifndef HELPER_CLOCK_H
#define HELPER_CLOCK_H

// TODO: Add linux compatible clock here

#ifdef WIN32
	#include "win32/clock.h"
#endif

#endif