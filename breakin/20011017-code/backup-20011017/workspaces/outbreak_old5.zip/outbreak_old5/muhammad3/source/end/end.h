#ifndef MUHAMMED_EFFECT_END_H
#define MUHAMMED_EFFECT_END_H

/*
	Owner   : Peter Nordlander (Tooon^outbreak)
	Purpose : Demo

	Todo    : The whole thing :)
*/

#include <helper/core/imagedrawer/imagedrawer.h>

#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectEnd : public Effect {
private:
	
	MuhamadGlobals *globals;

public:
	
	EffectEnd(MuhamadGlobals *globals);

	void update(const float64 delta, const float64 percent);
};

#endif