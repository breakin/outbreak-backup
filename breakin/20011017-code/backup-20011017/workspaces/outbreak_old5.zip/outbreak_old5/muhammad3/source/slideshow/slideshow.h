#ifndef MUHAMMED_EFFECT_SLIDESHOW_H
#define MUHAMMED_EFFECT_SLIDESHOW_H

/*
	Owner   : Anders Nilsson (Breakin^outbreak)
	Purpose : Demo

	Todo    : The whole thing :)
*/

#include <helper/core/imagedrawer/imagedrawer.h>

#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectSlideshow : public Effect {
private:
	
	MuhamadGlobals *globals;

public:
	EffectSlideshow(MuhamadGlobals *globals);

	void update(const float64 delta, const float64 percent);
};

#endif