#ifndef MUHAMAD_GLOBALS_H
#define MUHAMAD_GLOBALS_H

#include <helper/helper.h>

// ---------------------------------------------------------------------------

namespace Helper {
	struct MuhamadGlobals {
		Archive*		archive;
		Image32*		screen;	
		ImageTool*		imageTool;
		ImageDrawer*	imageDrawer;
		XmlBase*		setup;
		Device2D*		device2D;
	};
}

// ---------------------------------------------------------------------------

#endif