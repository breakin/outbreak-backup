#include "slideshow.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectSlideshow::EffectSlideshow(MuhamadGlobals *initGlobals) : globals(initGlobals) {
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectSlideshow::update(const float64 delta, const float64 percent) {
	//uint32* pixel = (uint32*)screen->getPixels();
	//pixel[(rand()%screen->getHeight())*screen->getWidth() + (rand()%screen->getWidth())] = 0xff0000;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
