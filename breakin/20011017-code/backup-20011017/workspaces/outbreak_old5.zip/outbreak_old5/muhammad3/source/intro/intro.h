#ifndef MUHAMMED_EFFECT_INTRO_H
#define MUHAMMED_EFFECT_INTRO_H

/*
	Owner   : Albert Sandberg (thec^outbreak)
	Purpose : Demo

	Todo    : The whole thing :)
*/

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectIntro : public Effect {
private:
	
	// Effect specific data.
	Image32 iOutbreakLogo;
	Image32 iBall;

	bool    showLogo;

	// Demo backbuffer image.
	MuhamadGlobals* globals;

public:
	
	EffectIntro(MuhamadGlobals *globals);

	void executeTrigger(const std::string& name, const std::string& value);

	void update(const float64 delta, const float64 percent);
};

#endif