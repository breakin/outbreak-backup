#include "end.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectEnd::EffectEnd(MuhamadGlobals *initGlobals) : globals(initGlobals) {
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectEnd::update(const float64 delta, const float64 percent) {
	//uint32* pixel = (uint32*)screen->getPixels();
	//pixel[(rand()%screen->getHeight())*screen->getWidth() + (rand()%screen->getWidth())] = 0x0000ff;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
