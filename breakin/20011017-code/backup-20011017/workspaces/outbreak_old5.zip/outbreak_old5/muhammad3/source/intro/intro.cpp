#include "intro.h"
#include <math.h>

using namespace Helper;
using namespace std;

static const int CIRCLES=150;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectIntro::EffectIntro(MuhamadGlobals *initGlobals) : globals(initGlobals) {

	showLogo = false;

	iOutbreakLogo=globals->imageTool->decode(globals->archive->getFile("intro/outbreaklogo.tga").get(), "tga");
	iBall        =globals->imageTool->decode(globals->archive->getFile("intro/ball.tga").get(), "tga");
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectIntro::executeTrigger(const std::string& name, const std::string& value) {
	if (name == "showLogo") {
		showLogo = !showLogo;    // ie. can be used to blink the logo!
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectIntro::update(const float64 delta, const float64 percent) {
	// New color value without the alpha included.
	uint32 color = ((uint8(percent*85)<<8) + uint8(percent*232));

	// Include the alpha and copy to sprite.
	uint32* pixel  = (uint32*)iBall.get();
	for (int i=0; i<iBall.getWidth()*iBall.getHeight(); i++) {
		pixel[i] = (pixel[i]&0xff000000) | color;
	}

	globals->imageDrawer->clear(*globals->screen, globals->screen->getArea());

	// Increase angle after each frame.
	const double angle=10.0*percent;

	// Draw evil circles, 3/4 of a whole round each frame.
	for (int a=0; a<CIRCLES; a++) {
		globals->imageDrawer->draw(iBall, iBall.getArea(), *globals->screen, 
						 (globals->screen->getArea().getWidth()>>1) -22 + sin(angle + 6.28*(float(a)/CIRCLES))*(iOutbreakLogo.getArea().getWidth()>>1),
						 (globals->screen->getArea().getHeight()>>1) -50 + cos(-angle + 12.56*(float(a)/CIRCLES))*(iOutbreakLogo.getArea().getHeight()>>1),
						 ImageDrawer::BLIT_ALPHABLEND);
	}

	// Draw logo
	if (showLogo) {
		globals->imageDrawer->draw(iOutbreakLogo, iOutbreakLogo.getArea(), *globals->screen, 
						 (globals->screen->getArea().getWidth()>>1) - (iOutbreakLogo.getArea().getWidth()>>1),
						 (globals->screen->getArea().getHeight()>>1) - (iOutbreakLogo.getArea().getHeight()>>1),
						 ImageDrawer::BLIT_ALPHABLEND);
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
