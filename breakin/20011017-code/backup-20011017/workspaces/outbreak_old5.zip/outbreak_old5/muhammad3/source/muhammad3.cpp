/*
	Owner   : Albert Sandberg (thec^outbreak)
	Purpose : Demo

	Todo    : Music implementation, screenshot's (screenshot/screenshot<sec>.tga), pause demo.
*/

// Helper includes
#include <helper/helper.h>
#include <helper/win32/win32_device2d.h>
#include <helper/directx/dx_device2d.h>
#include "globals.h"

// Standard includes
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <math.h>

// Effect includes
#include "intro/intro.h"
#include "slideshow/slideshow.h"
#include "end/end.h"

// Namespaces
using namespace Helper;
using namespace std;

// ---------------------------------------------------------------------------

namespace Helper {

	class MuhamadGlobals_Impementation : public MuhamadGlobals {
	public:

		MuhamadGlobals_Impementation() {
			archive=new ArchiveDirectory(".");
			setup=new XmlParser(archive->getFile("setup.xml").get());

			device2D=new DirectDrawDevice2D;

			Setup general(setup, "general");
			device2D->config("width",      general.getAttribute("width"));
			device2D->config("height",     general.getAttribute("height"));
			device2D->config("caption",    general.getAttribute("caption"));
			device2D->config("fullscreen", general.getAttribute("fullscreen"));
			device2D->config("title",      general.getAttribute("title"));
			device2D->config("bpp",        "32");
			
			imageTool=new ImageTool;
			imageDrawer=new ImageDrawer;

			device2D->open();

			screen=new Image32(device2D->getWidth(), device2D->getHeight());
		}

		~MuhamadGlobals_Impementation() {
			delete device2D;
			delete imageDrawer;
			delete imageTool;
			delete screen;
			delete setup;
			delete archive;		
		}
	};
}

// ---------------------------------------------------------------------------

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevinst, LPSTR cmdline, int showstate) {
	try {
		Debug::log("Main()", "Demo started...");

		MuhamadGlobals_Impementation globals;
		
		// Load the console (only if debug).

#ifdef HELPER_DEBUG

		// Create the c64 "device".
		C64 c64(globals.imageTool->decode(globals.archive->getFile("console/c64.tga").get(), "tga"));

		// Create the console and it's components.
		ConsoleData consoleData;
		consoleData.c64 = &c64;

		Console console(consoleData);
#endif

		// - - - - - - - -
		// Create effects.
		// - - - - - - - - - -
		EffectIntro     effectIntro(&globals);
		EffectSlideshow effectSlideshow(&globals);
		EffectEnd       effectEnd(&globals);

		// - - - - - - - -
		// Initialize script, the effects are drawn in the order they are entered!
		// (In-script order is primary, this order is secondary, if effects not found in script,
		// with other words, don't trust this order, trust the script!)
		// - - - - - - - - - -
		Script script(XmlParser(globals.archive->getFile("script.xml").get()));

		script.addCallback("intro"     , "intro"    , &effectIntro);
		script.addCallback("slideshow" , "slideshow", &effectSlideshow);
		script.addCallback("end"       , "end"      , &effectEnd);

		// Create timer, replace with music's timer later!
		Clock timer;
		bool  exit = false;

		while (1) {
			if (!script.update(timer.get())) break;

			// Update console (only if debug).
#ifdef HELPER_DEBUG
			if (!console.update()) break;
#endif

			globals.device2D->update(*globals.screen, true);

			Msg msg;
			if (globals.device2D->getMessage(msg)) {
				if (msg.message == Helper::Msg::MSG_QUIT) break;

				if (msg.message == Helper::Msg::MSG_KEYDOWN) {

					Debug::log("WinMain()", "Key param:%d, extra:%d", msg.param, msg.extra);
					
					if (msg.param == 27) break;     // Escape, abort demo!

					if ((msg.param == 'p') || (msg.param == 'P')) {         // Pause demo
						// *will* pause the demo ;)
						Debug::log("WinMain()", "Pause requested!");
					}
				}
			}
		}

		// Don't save _out-xml-file when in release mode!
#ifdef HELPER_DEBUG
		XmlParser out;
		script.save(out);
		out.writeXml(std::ofstream("muhammad3_out.xml"));
#endif
	}
	
	// Catch exceptions.
	catch (Helper::Exception &e) {
		MessageBox(NULL, e.what(), "Helper::Exception", MB_OK);
	}

	// Catch unknown exceptions.
	catch (...) {
		MessageBox(NULL, "Unknown exception", "(...)::Exception", MB_OK);
	}

	// Return the answer :-D
	return 42;
}