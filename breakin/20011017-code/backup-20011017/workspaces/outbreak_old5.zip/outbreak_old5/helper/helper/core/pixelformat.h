#ifndef __HELPER_PIXELFORMAT_INCLUDED__
#define __HELPER_PIXELFORMAT_INCLUDED__

#include "typedefs.h"

namespace Helper {

struct PixelFormat
{
		
		/**
		 * Enumerated predefined pixelformats
		 * Used as type, and send to set to correctly create the wished 
		 * pixelformat
		 */
		enum
		{
			BPP_UNSPEC  = 0,
			BPP_16_565  = 2,
			BPP_16_1555 = 3,
			BPP_24      = 4,
			BPP_32      = 5,
		};
		
		/**
		 * Constructor, destructor
		 */
		PixelFormat() {}
		PixelFormat(int pixelFormatType);
		
		/**
		 * set - sets a predefined pixelformat, 
		 * set know how to properly setup 32bpp,24bpp, 16bpp and 15bpp formats
		 */
		void set(int pf_type);

		/**
		 * operator overloads, only needs to compare the
		 * two pixleformat's m_formatType properties
		 */
		bool operator == (PixelFormat &other) { return (m_formatType == other.m_formatType); }
		bool operator != (PixelFormat &other) { return (m_formatType != other.m_formatType); }

		/**
		 * R,G,B and Alpha max values (255,63,31 and so on)
		 */
		uint16 m_valueRed;
		uint16 m_valueGreen;
		uint16 m_valueBlue;
		uint16 m_valueAlpha; // 0 for 24 and 16 bit formats

		/**
		 * Bitmasks for each attribute
		 */
		uint32 m_bitMaskRed;
		uint32 m_bitMaskGreen;
		uint32 m_bitMaskBlue;
		uint32 m_bitMaskAlpha;// 0 for 24 and 16 bit formats

		/**
		 * amounts of shifts needed to get each 
		 * attribute on it's occupied bits
		 */
		uint8 m_shiftAlpha;
		uint8 m_shiftRed;
		uint8 m_shiftGreen;
		uint8 m_shiftBlue;

		/**
		 * Bits per pixel, should not be used,
		 * some classes uses it and it's therefor still here
		 * Use of m_formatType is better
		 */
		uint8 m_bpp;		

		/**
		 * enumerated pixelformat type
		 */
		int   m_formatType;
	};

} // end namespace Aurora

#endif
