#ifndef HELPER_HELPER_IMAGETOOL_H
#define HELPER_HELPER_IMAGETOOL_H

/* 

  Author: Breakin
  
  ImageTool keeps a list of ImageCoder:ers and let you forget about what formats
  you are dealing with. Merely an interface to several ImageCoder:ers.

  All ImageCoders from Helper will be added automatically
 
 */

#include "../typedefs.h"
#include "../file.h"

#include "imagecoder/imagecoder.h"

#include <vector>
#include <string>

namespace Helper {

	class ImageTool {
	private:

		std::vector<ImageCoder*> mCoders;

		inline ImageCoder* getDecoder(const std::string &extension) const;
		inline ImageCoder* getEncoder(const std::string &extension) const;

	public:

		ImageTool();
		~ImageTool();

		Blob    encode(const Image32 &sourceImage, const std::string &destinationExtension, const ImageCoder::EncodeSettings &encodeSettings=ImageCoder::defaultEncodeSettings) const;
		Image32 decode(const Blob &sourceBlob, const std::string &sourceExtension, const ImageCoder::DecodeSettings &decodeSettings=ImageCoder::defaultDecodeSettings) const;
		Image32 decode(const File &sourceFile, const ImageCoder::DecodeSettings &decodeSettings=ImageCoder::defaultDecodeSettings) const;

		// NOTICE! The ImageCoder will be deleted by ImageTool
		inline void addImageCoder(ImageCoder* imageCoder);

		inline const bool isEncoder(const std::string &extension) const;
		inline const bool isDecoder(const std::string &extension) const;
	};
};

#endif