
#include "archivedirectory.h"
#include "../exception.h"

#include <direct.h>
#include <windows.h>

/* 
  TODO: Currently insertations probably are linear casuing a degenerated tree. Fix! 
  TODO: Win32 has built in file services that probably are faster than stdio. Use them!
  TODO: Implement remove()
  TODO: createFile could try to create the directory if it fails...
  TODO: Make ansi c++ (ifdef for win32 specific).
        MOVE into archivedirectory.cpp
*/

// ---------------------------------------------------------------------------

static void initializeInnerMethod(const std::string &searchRoot, const std::string &root, std::map<std::string, Helper::ArchiveDirectory::FileDirectory> &target, Helper::ArchiveDirectory *context) {
	
	std::string directory(searchRoot);
	directory+=root;
	directory+="*.*";

	WIN32_FIND_DATA findFileData;
	HANDLE hFindFile=FindFirstFile(directory.c_str(), &findFileData);

	// No files applied to the search critieria
	if (hFindFile==INVALID_HANDLE_VALUE) {
		return;
	}

	do {

		// Ignore hidden and offline files
		if ((findFileData.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN)  !=0 ||
			(findFileData.dwFileAttributes & FILE_ATTRIBUTE_OFFLINE) !=0) {

			continue;
		}

		// Recurse if another directory
		if ((findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) !=0) {

			const std::string directoryName=findFileData.cFileName;

			if (directoryName!="." && directoryName!="..") {

				std::string newDirectory(root);
				newDirectory+=directoryName;
				newDirectory+="/";

				initializeInnerMethod(searchRoot, newDirectory, target, context);
			}

		} else {

			// Add the file to the fileList

			// Create the full fileName
			std::string result(root);
			result+=findFileData.cFileName;

			// Create the temporary file object
			Helper::ArchiveDirectory::FileDirectory temp;

			temp.setName(result);
			temp.setContext(context);
			temp.setSize(findFileData.nFileSizeLow);
			temp.setReadable(true);
			temp.setWriteable((findFileData.dwFileAttributes & FILE_ATTRIBUTE_READONLY)==0);

			target[result]=temp;
		}

	} while (FindNextFile(hFindFile, &findFileData)!=0);

	FindClose(hFindFile);
}

// ---------------------------------------------------------------------------

/* Correct all slashes
   Appends trailing '/' if needed.
   Changes all '\' into '/'

   Removes start '/' if found
*/

inline static void fixDirectory(std::string &directoryToFix) {

	if (!directoryToFix.empty()) {

		// Change all '\' into '/'
		for (int C=0; C<directoryToFix.length(); C++) {
			if (directoryToFix[C]=='\\') directoryToFix[C]='/';
		}

		// Append trailer
		if (directoryToFix[directoryToFix.length()-1]!='/') {
			directoryToFix+="/";
		}

		if (directoryToFix[0]=='/') {
			directoryToFix.erase(0, 1);
		}
	}
}

// ---------------------------------------------------------------------------

void Helper::ArchiveDirectory::initialize() {

	fixDirectory(mDirectoryName);

	// Save current working directory
	char currentDirectory[_MAX_PATH+1];
	getcwd(currentDirectory, _MAX_PATH);

	// Check if the directory exists
	if (chdir(mDirectoryName.c_str())==0) {

		// Ok it existed, let's change back!
		chdir(currentDirectory);

		// Directory existed, build fileList
		initializeInnerMethod(mDirectoryName, "", mFileList, this);

	} else {

		// Directory did not exist, create!
		createRootDirectory(mDirectoryName);

	}
}

// ---------------------------------------------------------------------------

/* This methods require a trailing /-slash and that only '/'-are used (not '\').
   That should be true after a call to fixDirectory. */

void Helper::ArchiveDirectory::createRootDirectory(const std::string &directoryName) {

	if (directoryName.empty()) return;
	
	std::string directoriesLeft=directoryName;
	fixDirectory(directoriesLeft);

	std::string::size_type position=0;

	while (position < directoriesLeft.length()) {

		// Find the next '/' and then increase position with one
		// so that it is _after_ the '/' (oterwise it will be found the next time too)
		position=directoriesLeft.find("/", position);
		position++;

		mkdir(directoriesLeft.substr(0, position).c_str());
	}
}

// ---------------------------------------------------------------------------

void Helper::ArchiveDirectory::remove(const std::string &fileName) {

	std::string realName(mDirectoryName);
	realName+=fileName;
	
	// Not implemented yet!

	__asm{
		int 3;
	}
}

// ---------------------------------------------------------------------------

Helper::Blob Helper::ArchiveDirectory::getData(const std::string &fileName, const int bytesToRead) const {

	std::string realName(mDirectoryName);
	realName+=fileName;
	
	FILE *f=fopen(realName.c_str(), "rb");

	if (!f) throw Helper::FileException("ArchiveDirectory::getData; Could not open '%s' (%d bytes)", fileName.c_str(), bytesToRead);

	Blob returnBlob(bytesToRead);
	fread(returnBlob.get(), bytesToRead, 1, f);

	fclose(f);

	return returnBlob;
}

// ---------------------------------------------------------------------------

void Helper::ArchiveDirectory::createFile(const std::string &fileName, const Blob &source) {

	std::string realName(mDirectoryName);
	realName+=fileName;

	FILE *f=fopen(realName.c_str(), "wb+");
	if (!f) throw Helper::FileException("ArchiveDirectory::createFile; Could not create '%s'", fileName.c_str());

	fwrite(source.getReadOnly(), source.getSize(), 1, f);

	fclose(f);

	FileDirectory temp;

	temp.setName(fileName);
	temp.setContext(this);
	temp.setSize(source.getSize());
	temp.setReadable(true);
	temp.setWriteable(true);

	mFileList[fileName]=temp;
}

// ---------------------------------------------------------------------------