/*
��������������������������������������������������������������������������������
�	Win32Window.H																							
�	CPP file - Window Manager method implementations...
�	
�	Copyright (c) 2000 Peter Nordlander																												
�	Created  : 2000-03-29																						
� Last Upd : 2000-03-30																																							�
�
���������������������������������������������������������������������������������
*/
#include "win32_cursor.h"
#include "win32_window.h"
#include "..\core\area.h"
#include <stdio.h>
#include <stdlib.h>


using namespace Helper;


int        Win32Window::m_referenceCount = 0;
char*      Win32Window::m_windowClassName = "tooonwndclass";
WNDCLASSEX Win32Window::m_windowClass;
bool       Win32Window::m_windowRegistered = false;



//===============================================================================
/**
 * Static window mehods, register and
 * unregister a common, shared windowclasss
 */

void Win32Window::registerClass()
{
	HINSTANCE progInstance;		// prog address space start
		
	// get program instance
	progInstance = GetModuleHandle(NULL); 

	// Initialize window class structure
	m_windowClass.style					= CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
	m_windowClass.cbClsExtra    = 0;
	m_windowClass.cbWndExtra    =	4; // declare 4 extra byte to hold 32bit "this"-object address
	m_windowClass.lpfnWndProc	= win32WindowProcMsg;
	m_windowClass.hInstance		= progInstance;
	m_windowClass.lpszMenuName  = NULL;
	m_windowClass.lpszClassName = m_windowClassName;
	m_windowClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	m_windowClass.hCursor		= LoadCursor(NULL,IDC_ARROW);
	m_windowClass.hIcon			= LoadIcon(NULL,IDI_APPLICATION);
	m_windowClass.hIconSm		= LoadIcon(NULL,IDI_APPLICATION);
	m_windowClass.cbSize        = sizeof(WNDCLASSEX);

	// Register out created windowclass...
	RegisterClassEx (&m_windowClass);

    // set register flag to true
    m_windowRegistered = true;
}

//===============================================================================
void Win32Window::unregisterClass()
{
	if (m_windowRegistered)	
	{
		UnregisterClass(m_windowClassName,GetModuleHandle(NULL));
		m_windowRegistered = false;
	}
}

//===============================================================================

Win32Window::Win32Window()
{
	// set defaultvalues when window is created
	m_clientArea.set(0,0,640,480);
	m_caption			 = true;
	m_visible			 = true;
	m_opened			 = false;
	m_windowHandle = NULL;
	m_windowHDC    = NULL;
}


//===============================================================================
Win32Window::~Win32Window()
{
	close();
}

//===============================================================================
void Win32Window::close()
{
	if (m_opened)	  DestroyWindow(m_windowHandle);

	m_opened	   = false;
	m_referenceCount--;

	/**
	* Check if no references are left, and if class is 
	* registered with Windows and unregister it.
	*/
	if (m_referenceCount==0)
	{
		if (m_windowRegistered) unregisterClass();
	}
}

//===============================================================================
void Win32Window::open(const char title[], const AreaInt &clientArea, bool caption, bool visible)
{
	/**
	 * predefine window's properties by
	 * parameter values
	 */
	m_windowTitle = title;
	m_clientArea  = clientArea;
	m_width       = clientArea.getWidth();
	m_height      = clientArea.getHeight();
	m_caption     = caption;
	m_visible     = visible;

	/**
	 * Check if we need to register a windowclass
	 */
	if (!m_windowRegistered) registerClass();

	/**
	 * Create the window and show cursor
	 */
	createWindow();
	showCursor(true);

	/**
	 * Update static member to hold information about amount of windows created...
	 */
	m_referenceCount++;

}

//===============================================================================
void Win32Window::createWindow()
{
	RECT	rect;
	DWORD WINDOW_STYLE = 0;

	/**
	 * Check so that it is not open and unregistered,
	 * If not, create the window...
	 */
	if (m_windowRegistered && (!m_opened))
	{

	/**
	 * set style build on set choices
	 */
	WINDOW_STYLE = WS_POPUPWINDOW;
	if (m_caption)	WINDOW_STYLE|=WS_CAPTION;
	if (m_visible)  WINDOW_STYLE|=WS_VISIBLE;

	/**
 	 * prevent caption from beeing hidden (if 0, add 64 to move it 
	 * 64 pixels towards center at each axis
	 */
	if (m_clientArea.getLeft()<64) m_clientArea.setLeft(64);
	if (m_clientArea.getTop()<64) m_clientArea.setLeft(64);

	/** 
     * first adjust windowrect, to make the "client area"
     * exactly the size asked for, excluding the menu and borders
     */
	rect.top    = m_clientArea.getTop(); 
	rect.left   = m_clientArea.getLeft();
	rect.bottom = m_clientArea.getHeight()+rect.top;
	rect.right  = m_clientArea.getWidth()+rect.left;
	AdjustWindowRectEx(&rect,WINDOW_STYLE,FALSE,0);
		
    /**
     * Create the window and save handle
     */
    m_windowHandle=CreateWindowEx(0,
								m_windowClassName,
								m_windowTitle.c_str(),
								WINDOW_STYLE,
								rect.left,rect.top,
								(rect.right-rect.left),
								(rect.bottom-rect.top),
								NULL,NULL,
								GetModuleHandle(NULL) ,NULL);

	/**
	 * The static class winProc, need to be able to extract
	 * which object that is called, that is done by storing the
	 * this pointer in windows extra allocated memoryspace
	 */
    SetWindowLong(m_windowHandle, 0,(LONG)this);
		m_opened = true;
	}
}

//===============================================================================
void Win32Window::destroyWindow()
{
	if (IsWindow(m_windowHandle)) DestroyWindow(m_windowHandle);
	m_opened = false;
}

//===============================================================================
void Win32Window::setMsgQueue(MsgQueue &msgQueue)
{
	m_msgQueue = &msgQueue;
}

//===============================================================================
void Win32Window::showCursor(bool show) const
{
	if (show) Win32Cursor::show();
	else      Win32Cursor::hide();
}

//===============================================================================
void Win32Window::showCaption(bool captionShow)
{
	RECT	wndPosRect;
	DWORD style = WS_POPUPWINDOW|WS_VISIBLE;

	if (m_caption != captionShow)
	{
		// get current window position
		GetWindowRect(m_windowHandle,&wndPosRect);
		// check if caption is to be showed or removed
		if (captionShow) style|=WS_CAPTION;
		// update window's properties
		m_caption = captionShow;
		// set new windowstyle
  		SetWindowLong(m_windowHandle,GWL_STYLE,style);
		// resize width same resolution to force Windows to repaint our window.
		resize(AreaInt(wndPosRect.left,wndPosRect.top,m_width, m_height),true);
	}
}

//===============================================================================
void Win32Window::update()
{
	MSG msg;

	if (PeekMessage(&msg,m_windowHandle,0,NULL,PM_REMOVE))
	{
		if (msg.message == WM_QUIT) m_msgQueue->addMessage(Msg::MSG_QUIT,0,0,0,0);
		TranslateMessage(&msg);
		DispatchMessage (&msg);
	}
}

//===============================================================================
HWND Win32Window::getHandle() const
{
	return m_windowHandle;
}

//===============================================================================
HDC Win32Window::getDC()
{
	if (m_windowHDC==NULL) m_windowHDC = GetDC(m_windowHandle);
	return m_windowHDC;
}

//===============================================================================
void Win32Window::releaseDC()
{
	if (m_windowHDC!=NULL) ReleaseDC(m_windowHandle,m_windowHDC);
}

//===============================================================================
void Win32Window::getClientArea(AreaInt &area) const
{
	RECT rect;
	GetClientRect(m_windowHandle,&rect);
	area.set(rect.left,rect.top,(rect.right-rect.left),(rect.bottom-rect.top));
}

//===============================================================================
void Win32Window::show()
{
	if (!m_visible)
	ShowWindow(m_windowHandle,SW_SHOW);
	m_visible = true;
}

//===============================================================================
void Win32Window::hide()
{
	if (m_visible)
	ShowWindow(m_windowHandle,SW_HIDE);
	m_visible = false;
}

//===============================================================================
void Win32Window::resize(AreaInt &newClientArea, bool keepPosition)
{
	RECT  clientRect;
	DWORD style = WS_POPUPWINDOW;
	
	// set style, so we know how to resize clientarea
	if (m_caption) style|=WS_CAPTION; 	
	
	// check so window is not positioned 
	// outside screen
	if (newClientArea.getLeft()<64) newClientArea.setLeft(64);
	if (newClientArea.getTop()<64) newClientArea.setTop(64);

	// update window's properties
	m_width  = newClientArea.getWidth();
	m_height = newClientArea.getHeight();
	m_clientArea = newClientArea;
	
	clientRect.top   = newClientArea.getTop();
	clientRect.left  = newClientArea.getLeft();
	clientRect.right = newClientArea.getLeft() + newClientArea.getWidth();
	clientRect.bottom= newClientArea.getTop() + newClientArea.getHeight();
	// adjust window clientrect to be exacly
	// the wished size
	AdjustWindowRectEx(&clientRect,style,FALSE,0);
	MoveWindow(m_windowHandle,clientRect.left,clientRect.top,
														clientRect.right - clientRect.left,
														clientRect.bottom- clientRect.top,
														TRUE);
}

//===============================================================================
void Win32Window::center()
{
	int mid_x = GetSystemMetrics(SM_CXSCREEN)/2 - m_width/2;
	int mid_y = GetSystemMetrics(SM_CYSCREEN)/2 - m_height/2;
	AreaInt area(mid_x,mid_y,m_width, m_height);
	resize(area,false);
}

//===============================================================================
// Own defined window procedure...
//===============================================================================
LRESULT CALLBACK Win32Window::win32WindowProcMsg(HWND hwnd,UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT		mousePos;
	Win32Window *wndOwner = (Win32Window*)GetWindowLong(hwnd,0);

	/**
	 * Get windows current mousePosition
	 */
	GetCursorPos(&mousePos);
	ScreenToClient(hwnd,&mousePos);

	switch (message)
	{
		case WM_CREATE:

		return 0;
		break;

		case WM_DESTROY:
		//PostQuitMessage(0);
		return 0;
		break;

		case WM_CLOSE:
		//PostQuitMessage(0);
		wndOwner->m_msgQueue->addMessage(Helper::Msg::MSG_CLOSE,wParam,0,mousePos.x,mousePos.y);		
		break;

		case WM_PAINT:
		//wndOwner->m_msgQueue->addMessage(Helper::Msg::MSG_PAINT,0,0,mousePos.x,mousePos.y);
		break;

		case WM_SYSCOMMAND:
		switch (wParam)
		{
			case SC_SCREENSAVE:
			case SC_MONITORPOWER:
			return 0;
		}	
		break;

		case WM_CHAR:
		wndOwner->m_msgQueue->addMessage(Helper::Msg::MSG_KEYCHAR,wParam,lParam,mousePos.x,mousePos.y);    
		break;

		case WM_KEYDOWN:
		wndOwner->m_msgQueue->addMessage(Helper::Msg::MSG_KEYDOWN,wParam,0,mousePos.x,mousePos.y);
		return 0;
		break;

		case WM_KEYUP:
		wndOwner->m_msgQueue->addMessage(Helper::Msg::MSG_KEYUP,wParam,0,mousePos.x,mousePos.y);
		return 0;
		break;

		case WM_LBUTTONDOWN:
		wndOwner->m_msgQueue->addMessage(Helper::Msg::MSG_LMOUSEDOWN,0,0,mousePos.x,mousePos.y);		
		return 0;
		break;

		case WM_LBUTTONUP:
		wndOwner->m_msgQueue->addMessage(Helper::Msg::MSG_LMOUSEUP,0,0,mousePos.x,mousePos.y);			
		break;

		return 0;

	}

	return DefWindowProc(hwnd,message,wParam,lParam);
}
//==============================================================================

LRESULT CALLBACK Win32Window::win32WindowProcEvent(HWND hwnd,UINT message, WPARAM wParam, LPARAM lParam)
{
	
	Win32Window *wndOwner = (Win32Window*)GetWindowLong(hwnd,0);
	
	switch (message)
	{
		case WM_CREATE:
		
		return 0;
		break;
	
		case WM_DESTROY:
		//PostQuitMessage(0);
		return 0;
		break;

		case WM_CLOSE:
		//PostQuitMessage(0);
		
		return 0;
		break;
		
		case WM_SYSCOMMAND:
		switch (wParam)
		{
			case SC_SCREENSAVE:
			case SC_MONITORPOWER:
			return 0;
		}	
		break;

		case WM_KEYDOWN:
		/* EXAMPLE */
		//wndOwner->m_events[KEY_DOWN](0,0,0,0);
		return 0;
		break;
		
		case WM_KEYUP:
		return 0;
		break;

		case WM_LBUTTONDOWN:
		return 0;
		break;

		case WM_LBUTTONUP:
		break;
		
		return 0;

	}

	return DefWindowProc(hwnd,message,wParam,lParam);
}