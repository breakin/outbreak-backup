#include "music.h"
#include "../exception.h"


Helper::Music::Music() {
}

Helper::Music::Music(const std::string &filename) {
	load(filename);
}

Helper::Music::~Music() {
	unload();
}

void Helper::Music::load(const std::string &filename) {
	// Best�m typen av extension (.mp3/.xm) osv...
	// R�cker med mp3-st�d nu, men detecta det

	FSOUND_Init(44100, 1, 0);
	mStream = FSOUND_Stream_OpenFile(filename.data(), 0, 0);
	if (mStream == NULL){
		throw Exception("Could not load the song");
	}

	mPaused = false;
}

void Helper::Music::unload() {
	FSOUND_Stream_Close(mStream);
	FSOUND_Close();
}

void Helper::Music::play() {

	if (mPaused == true){
		FSOUND_Stream_SetPaused(mStream, 0);
	}else{
		FSOUND_Stream_Play(0, mStream);
	}
}

void Helper::Music::pause() {
	FSOUND_Stream_SetPaused(mStream, 1);
	mPaused = true;
}

void Helper::Music::setTimer(const float64 timer) {
	FSOUND_Stream_SetTime(mStream, (int)(timer*1000));
}

const Helper::float64 Helper::Music::getTimer() const {

	if (mStream == NULL){
		throw Exception("No song loaded");
	}

	int millis = FSOUND_Stream_GetTime(mStream);
	return (millis/1000.0);
}