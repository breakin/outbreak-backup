#ifndef HELPER_DEMO_SETUP_H
#define HELPER_DEMO_SETUP_H

#include "../../xml/xmlbase.h"
#include <string>

namespace Helper {

	class Setup {
	private:

		XmlBase::IteratorConst i;

	public:
		
		Setup(const XmlBase* const xmlBase, const std::string &setupName);
		const std::string &getAttribute(const std::string &attributeName) const;
	};
}

#endif
