#ifndef __HELPER_DEBUG_H__
#define __HELPER_DEBUG_H__

#include <stdarg.h>
#include <stdio.h>
#include <vector>

#include "..\clock.h"
#include "filemonitor.h"

#ifdef	_DEBUG
#define HELPER_DEBUG
#endif

#ifdef	WIN32 
#define INLINE_API //__forceinline
#else
#define INLINE_API //inline
#endif


namespace Helper {

class Debug {
		
	public:
		
		enum {
	
			APPL		= 0x01,
			SYSTEM 		= 0x02,
			EXCEPTION	= 0x04,
			ALL			= 0xff,
		};

		// logs a message to registerd debug monitors
		static INLINE_API void logException(const char method[], const char message[],...);
		static INLINE_API void logSystem   (const char method[], const char message[],...);
		static INLINE_API void log		   (const char method[], const char message[],...);

		// sets and gets the current priority filter of the default file monitor
		static INLINE_API int  getFilter();
		static INLINE_API void setFilter(int filter);
		
		// addMonitor		- register a monitor with Debug 
		// releaseMonitor	- removes the monitor from Debug's callback list		 
		static INLINE_API void addMonitor(DebugMonitor *monitor);
		static INLINE_API void releaseMonitor(DebugMonitor *monitorID);
		
		// Enables/Disables logging
		static INLINE_API void enable();
		static INLINE_API void disable();

		
	private:

		// initializes debug and set default monitor
		static INLINE_API void initialize();

		// update all registered monitors with message
		static void updateMonitors(int msgType, const char message[]);

		// Log's properties
		static std::vector<DebugMonitor*> m_monitors;
		static DebugMonitorFile m_defaultMonitor;		
		static int		m_filter;
		static bool		m_enabled;
		static bool		m_initialized;
		static Clock	m_clock;
		static char		m_message[128];
	
};

}// end namespace Helper


#endif
