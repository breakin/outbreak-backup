#ifndef HELPER_HELPER_IMAGECODER_H
#define HELPER_HELPER_IMAGECODER_H

/* 

  Author: Breakin
  
  ImageCoder is the baseClass for all image-encoders/decoders.
  It will decode a Blob into an Image, or encode a Image into a Blob.

  isDecoder/isEncoder takes an fileName (or just .ext) and returns if the ImageCoder
  thinks it can decode/encode the file. Any case is supported, but the dot must be
  included when writing just the extension.    

 */

#include "../../typedefs.h"
#include "../../blob.h"
#include "../../image32.h"
#include <string>

namespace Helper {

	class ImageCoder {
	protected:

		const bool isExtension(const std::string &fileName, const std::string &extension) const;

	public:

		// -------------------------------
		struct EncodeSettings {

			float64 colorQuality;
			float64 alphaQuality;

			std::string colorFormat;
			std::string alphaFormat;

			bool saveAlphaChannel;            // 32 (true) or 24-bit (false)?
			bool saveAlphaChannelAsGreyScale; // Ignors color channels and save greyscale targa of the alpha channel

			EncodeSettings() : colorQuality(1.0), alphaQuality(1.0),
				saveAlphaChannel(true), saveAlphaChannelAsGreyScale(false) {}
		};
		// -------------------------------
		struct DecodeSettings {
			
			bool storeInAlphaChannel;         // Shall we store the image in the alphaChannel (if grayscale)

			DecodeSettings() : storeInAlphaChannel(false) {}
		};
		// -------------------------------
	
		static const DecodeSettings defaultDecodeSettings;
		static const EncodeSettings defaultEncodeSettings;

		virtual ~ImageCoder() {}

		virtual Blob    encode(const Image32 &sourceImage, const EncodeSettings &settings=defaultEncodeSettings) const = 0;
		virtual Image32 decode(const Blob &sourceBlob,     const DecodeSettings &settings=defaultDecodeSettings) const = 0;

		// Can this ImageCoder encode/decode a file with the extension 'extension'?
		// If extension is empty it will be taken as; can you decode/encode anything?
		virtual const bool isEncoder(const std::string &fileName="") const = 0;
		virtual const bool isDecoder(const std::string &fileName="") const = 0;
	};
}

#endif