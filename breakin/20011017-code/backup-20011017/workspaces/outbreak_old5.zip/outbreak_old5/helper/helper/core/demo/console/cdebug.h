#ifndef HELPER_DEMO_DEBUG_H
#define HELPER_DEMO_DEBUG_H

#include <helper/core/debug/monitor.h>
#include <helper/core/demo/console/application.h>

/*
	Owner   : Albert Sandberg (thec^outbreak).
	Purpose : This Debugclass inheritences from DebugMonitor and stores callbacks from the logger.

	Todo    :
*/

namespace Helper {

	class ConsoleDebug : public Application, DebugMonitor {

	private:
		bool needUpdate;
		std::vector<std::string> debugMessageList;

	public:
		ConsoleDebug(const ConsoleData& consoleData);
		~ConsoleDebug();

		void refresh();
		Application* update();

		// DebugMonitor stuff
		void onDebugMessage(int msgType, const char message[]);
	};

}

#endif
