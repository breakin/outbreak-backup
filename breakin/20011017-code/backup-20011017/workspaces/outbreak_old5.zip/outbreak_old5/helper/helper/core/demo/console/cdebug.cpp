#include "cdebug.h"

#include <helper/core/debug/debug.h>

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::ConsoleDebug::ConsoleDebug(const ConsoleData& consoleData) : Helper::Application(consoleData) {
	Debug::addMonitor(this);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::ConsoleDebug::~ConsoleDebug() {

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::ConsoleDebug::refresh() {
	C64& c64 = *consoleData.c64; // Just for easier typing

	// Draw debug window
	c64.setColor(C64::COLOR_FRAME, C64::COLOR_FRAMEBACKGROUND);
	c64.drawWindow(0,0,79,29, "DEBUG");

	// Draw seperator.
	c64.setColor(C64::COLOR_TEXT, C64::COLOR_FRAMEBACKGROUND);
	for (int x=1; x<79; x++) c64.drawLetter(c64.screen, x, 27, 148);

	// Draw debug messages.
	for (int m=0; m<debugMessageList.size(); m++) {
		c64.drawString(c64.screen, 2, 2+m, debugMessageList[m]);
	}

	// Draw actions.
	c64.setColor(C64::COLOR_SELECTED, C64::COLOR_SELECTEDBACKGROUND);
	c64.drawString(c64.screen, 2, 28, " EXIT ");

	// Update console device.
	c64.winDevice.update(c64.screen);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Application* Helper::ConsoleDebug::update() {
	C64& c64 = *consoleData.c64; // Just for easier typing.

	// Refresh if needed.
	if (needUpdate) {
		refresh();
		needUpdate = false;
	}

	// Update device BUT don't flush backbuffer if not needed!
	c64.winDevice.update(c64.screen, false);

	Msg msg;
	while(c64.winDevice.getMessage(msg, true)) {
		if (msg.message == Helper::Msg::MSG_KEYDOWN) {

			// Escape or return
			if ((msg.param == 27) || (msg.param == 13)) {
				// Will close app.
				return 0;
			}
		}
	}

	// Keep active
	return this;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::ConsoleDebug::onDebugMessage(int msgType, const char message[]) {
	std::string temp = message;
	debugMessageList.push_back(temp);

	while (debugMessageList.size() > 24) {
		debugMessageList.erase(debugMessageList.begin());
	}

	needUpdate=true;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


