#ifndef HELPER_POINT_H
#define HELPER_POINT_H

template<class T> class Area;
#include "typedefs.h"

namespace Helper {

	template<class T>class Point {
	private:
		
		T x,y;

	public:

		Point(const T initX=T(), const T initY=T()) : x(initX), y(initY) {
		}

		void setX(const T newX) { x=newX; }
		void setY(const T newY) { y=newY; }
		const T getX() const { return x; }
		const T getY() const { return y; }

		void set(const T newX, const T newY) {
			x=newX;
			y=newY;
		}

		void operator+=(const Point<T> &p) {
			x+=p.getX();
			y+=p.getY();
		}

		T getX() { 
			return x;
		}

		T getY() { 
			return y;
		}

		Point<T> operator+(const Point<T> &p) {
			return Point<T>(x+p.getX(),y+getY());
		}

		void operator-=(const Point<T> &p) {
			x-=p.getX();
			y-=p.getY();
		}

		Point<T> operator-(const Point<T> &p) {
			return Point<T>(x-p.getX(),y-getY());
		}

		const bool operator==(const Point<T> &p) {
			if (x==p.getX() && x==p.getY()) return true;
				else return false;
		}

		const bool operator!=(const Point<T> &p) {
			if (x==p.getX() && x==p.getY()) return false;
				else return true;
		}
	};

	typedef Point<int> PointInt;
	typedef Point<float32> PointFloat32;
	typedef Point<float64> PointFloat64;
};

#endif