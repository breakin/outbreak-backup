#ifndef HELPER_DEMO_MENU_H
#define HELPER_DEMO_MENU_H

/*
	This is the menu for the console.
*/

#include "application.h"
#include "console.h"

#include <helper/core/typedefs.h>

namespace Helper {

	class ConsoleMenu : public Application {

	private:
		int  carret;
		bool needUpdate;

		int8 left;
		int8 right;
		int8 middle;
		int8 top;
		int8 bottom;
		std::vector<std::string> name;

	public:
		ConsoleMenu(const ConsoleData& consoleData);
		~ConsoleMenu();

		void refresh();
		Application* update();
	};

}

#endif
