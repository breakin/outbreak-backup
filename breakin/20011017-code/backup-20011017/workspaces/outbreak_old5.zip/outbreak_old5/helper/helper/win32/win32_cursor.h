
#ifndef __WIN32_CURSOR_H__
#define __WIN32_CURSOR_H__

#include <windows.h>

//================================================================================
// Cursor class
//================================================================================
class Win32Cursor
{
	
	public:
			
		static void show()
		{
			if (!m_visible)
			ShowCursor(true);
		}

		static void hide()
		{
			if (m_visible)
			ShowCursor(false);
		}


	protected:
		
		static bool m_visible;
};


// declare static member, set to visible as default
bool Win32Cursor::m_visible = true;


#endif
