#include "imagetool.h"
#include "imagecoder/imagecoder_tga.h"
#include "imagecoder/imagecoder_jpg.h"
#include "../exception.h"

// - [PRIVATE] ---------------------------------------------------------------

Helper::ImageCoder* Helper::ImageTool::getDecoder(const std::string &extension) const {
	
	for (int C=0; C<mCoders.size(); C++) {
		if (mCoders[C]->isDecoder(extension)) return mCoders[C];
	}

	return 0;
}

// ---------------------------------------------------------------------------

Helper::ImageCoder* Helper::ImageTool::getEncoder(const std::string &extension) const {
	
	for (int C=0; C<mCoders.size(); C++) {
		if (mCoders[C]->isEncoder(extension)) return mCoders[C];
	}

	return 0;
}

// - [PUBLIC] ----------------------------------------------------------------

Helper::ImageTool::ImageTool() {
	addImageCoder(new ImageCoder_TGA);
	addImageCoder(new ImageCoder_JPG);
}

Helper::ImageTool::~ImageTool() {
	for (int C=0; C<mCoders.size(); C++) {
		delete mCoders[C];
	}

	mCoders.clear();
}

// ---------------------------------------------------------------------------

void Helper::ImageTool::addImageCoder(ImageCoder *imageCoder) {
	mCoders.push_back(imageCoder);
}

// ---------------------------------------------------------------------------

const bool Helper::ImageTool::isDecoder(const std::string &extension) const {
	if (extension.empty()) return false;
	return getDecoder(extension)!=0;
}

// ---------------------------------------------------------------------------

const bool Helper::ImageTool::isEncoder(const std::string &extension) const {
	if (extension.empty()) return false;
	return getEncoder(extension)!=0;
}

// ---------------------------------------------------------------------------

Helper::Blob Helper::ImageTool::encode(const Image32 &sourceImage, const std::string &destinationExtension, const ImageCoder::EncodeSettings &encodeSettings) const {
	const ImageCoder* const encoder=getEncoder(destinationExtension);
	
	if (!encoder) throw Helper::Exception("ImageTool::encode; Could not find a encoder for '%s'", destinationExtension.c_str());

	return encoder->encode(sourceImage, encodeSettings);
}

// ---------------------------------------------------------------------------

Helper::Image32 Helper::ImageTool::decode(const Blob &sourceBlob, const std::string &sourceExtension, const ImageCoder::DecodeSettings &decodeSettings) const {
	const ImageCoder* const decoder=getDecoder(sourceExtension);
	
	if (!decoder) throw Helper::Exception("ImageTool::decode(Blob); Could not find a decoder for '%s'", sourceExtension.c_str());

	return decoder->decode(sourceBlob, decodeSettings);
}

// ---------------------------------------------------------------------------

Helper::Image32 Helper::ImageTool::decode(const File &sourceFile, const ImageCoder::DecodeSettings &decodeSettings) const {

	try {
		return decode(sourceFile.get(), sourceFile.getName(), decodeSettings);
	}

	catch (...) {
		throw Helper::Exception("ImageTool::decode(File); Could not decode '%s' (%d bytes, read=%s, write=%s)", sourceFile.getName().c_str(), sourceFile.getSize(), sourceFile.isReadable()?"true":"false", sourceFile.isWriteable()?"true":"false");
	}
}

// ---------------------------------------------------------------------------