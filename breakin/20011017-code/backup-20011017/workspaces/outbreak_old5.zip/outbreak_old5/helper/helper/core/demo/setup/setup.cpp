#include "setup.h"
#include "../../exception.h"
#include <windows.h> // TODO: Remove

// ---------------------------------------------------------------------------

Helper::Setup::Setup(const XmlBase* const xmlBase, const std::string &setupName) : i(xmlBase->createIterator("setup")) {

	if (i.getRoot().getName()!="demo") throw Exception("Setup::Setup; Root tag must be <demo> (%s)", i.getRoot().getName());

	while (++i) if (i->getValue("name")==setupName) return;

	throw Exception("Setup::Setup; Could not find '%s' in setup.xml", setupName.c_str());
}

// ---------------------------------------------------------------------------

const std::string &Helper::Setup::getAttribute(const std::string &attributeName) const {

	XmlBase::IteratorConst attribute=i.createIterator("attribute");

	while (++attribute) {
		if (attribute->getValue("name")==attributeName) return attribute->getValue("value");
	}

	throw Exception("Setup::getAttribute; An attribute where name='%s' in '%s' was not found", attributeName.c_str(), i->getName().c_str());
}

// ---------------------------------------------------------------------------
