#ifndef __AURORA_DIRECTX_DEVICE2D__
#define __AURORA_DIRECTX_DEVICE2D__

#include "..\core\device2d.h"
#include "..\core\imagedrawer\imagedrawer.h"
#include "..\win32\win32_window.h"
#include "dx_surface.h"
#include "dx_ddraw.h"

namespace Helper {


class DirectDrawDevice2D : public Device2D
{
	public:
		
		DirectDrawDevice2D();
		virtual ~DirectDrawDevice2D();

		/**
		 * Open/Close device
		 */
		void open();
		void close();

		/**
		 * Update message loop and display(if displayUpdate is set)
		 */
		void update(Image32 &surface, bool displayUpdate = true);
		
		/**
		 * Get device Properties
		 */
		int  getWidth() const { return m_width; }
		int  getHeight()const { return m_height;}
		int  getPitch() const { return m_pitch;	}
		void getPixelFormat(PixelFormat &pixelFormat) const {pixelFormat = m_pixelFormat; }
		
	protected:
		
		// resets all properties to default
		void reset();
		
		/**
		 * CDirectDrawDevice2D properties
		 */
		int					m_width;
		int					m_height;
		int					m_pitch;
		bool				m_caption;
		bool				m_opened;
		bool				m_fullscreen;
		std::string			m_title;
		PixelFormat			m_pixelFormat;
		ImageDrawer			m_blitter;
		Win32Window			m_window;
		DirectDrawImage 	m_backBuffer;
		DirectDraw			m_directDraw;

		static int			m_openDeviceRef;
};

}

#endif