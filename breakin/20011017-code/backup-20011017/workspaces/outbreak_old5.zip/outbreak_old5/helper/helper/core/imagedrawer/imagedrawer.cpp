
#include "imagedrawer.h"
#include "..\debug\debug.h"

using namespace Helper;


//=============================================================================================================

void ImageDrawer::copy(BaseImage32 &srcSurface, BaseImage32 &dstSurface)
{
	if ((srcSurface.getWidth() == dstSurface.getWidth()) && (srcSurface.getHeight() == dstSurface.getHeight())) {

		int width   = srcSurface.getWidth();
		int height  = srcSurface.getHeight();
		int spitch  = srcSurface.getPitch();
		int dpitch  = dstSurface.getPitch();

		m_drawer->copy(	(uint8*)srcSurface.getReadOnly(),
						(uint8*)dstSurface.get(), 
						width, height,
						spitch, dpitch);
	}
}

//=============================================================================================================

void ImageDrawer::clear(BaseImage32 &dstSurface,const AreaInt &dstArea, int clearCaps)
{
	uint8 *pixelOffset;
	
	// calculate offset
	pixelOffset =  (uint8*)dstSurface.get();
	pixelOffset += (dstArea.getLeft() * 4 ) + dstArea.getTop() * dstSurface.getPitch();

	// check if we should keep alpha
	if (clearCaps == CLEAR_ARGB)
	{
		m_drawer->clear_argb(pixelOffset,
							dstArea.getWidth(), dstArea.getHeight(),
							dstSurface.getPitch());
	}	
	else
	{
		m_drawer->clear_rgb (pixelOffset,
							dstArea.getWidth(), dstArea.getHeight(),
							dstSurface.getPitch());
	}
}


//=============================================================================================================

void ImageDrawer::draw(BaseImage32 &srcSurface, const AreaInt &srcArea, BaseImage32 &dstSurface, const AreaInt &dstArea, int blitFlags)
{
	uint8  *src_data, *dst_data;
	int     src_pitch, dst_pitch;
	int     dst_width, dst_height;
	Image32 zoomSurface;

	// check if we need to zoom srcSurface
	if ((dstArea.getWidth () != srcArea.getWidth()) || (dstArea.getHeight() != srcArea.getHeight()))
	{
		// create new surface and area - rearanged to new zoomed surface
		zoomSurface.resize(dstArea.getWidth(), dstArea.getHeight());
		
		// zoom srcsurface to fit in the dstArea
		m_drawer->scale_bilinear((uint32*)srcSurface.getReadOnly() , srcArea, srcSurface.getPitch(),
								 (uint32*)zoomSurface.get(), dstArea, zoomSurface.getPitch());				

		// calc pixel's address and pitch
		src_pitch = zoomSurface.getPitch();
		src_data  = (uint8*)zoomSurface.getReadOnly();
	}
	else
	{
		// get address and pitch from original source surface
		src_pitch = srcSurface.getPitch();
		src_data  = (uint8*)srcSurface.getReadOnly();
		src_data += (srcArea.getLeft() * 4) + srcArea.getTop() * src_pitch;			
	}

		
	/* calc first pixels address in dest data.
	   and set pitch and dimensions of dest surface */
	dst_pitch = dstSurface.getPitch();
	dst_width = dstArea.getWidth();
	dst_height= dstArea.getHeight();
	dst_data  = (uint8*)dstSurface.get();
	dst_data += (dstArea.getLeft() * 4) + dstArea.getTop() * dst_pitch;

		
	// check bitflags, and route to proper internal blit method
	switch (blitFlags)
	{
		case BLIT_NORMAL:
		m_drawer->copy(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;
		
		case BLIT_SATURATION:
		m_drawer->blit_saturation(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;

		case BLIT_ALPHABLEND:
		if (m_alphaMode == ALPHA_CONSTANT)
			m_drawer->blit_alpha_const(src_data,dst_data, m_alphaChannel, dst_width, dst_height, src_pitch, dst_pitch);
		else
			m_drawer->blit_alpha (src_data,dst_data, dst_width, dst_height, src_pitch, dst_pitch);
			
		break;

		case BLIT_COLORKEY:
		m_drawer->blit_colorkey(src_data,dst_data, 0, dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_SATURATION|BLIT_COLORKEY:
		m_drawer->blit_colorkey_saturation (src_data,dst_data, 0, dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_COLORKEY|BLIT_ALPHABLEND:
		
		if (m_alphaMode == ALPHA_CONSTANT)
			m_drawer->blit_alpha_const_colorkey(src_data ,dst_data, m_alphaChannel,0,dst_width, dst_height, src_pitch, dst_pitch);
		else
			m_drawer->blit_alpha_colorkey(src_data ,dst_data,0,dst_width, dst_height, src_pitch, dst_pitch);
		
		break;

		case BLIT_SATURATION|BLIT_ALPHABLEND:

		if (m_alphaMode == ALPHA_CONSTANT)
			m_drawer->blit_alpha_const_saturation(src_data ,dst_data, m_alphaChannel,dst_width, dst_height, src_pitch, dst_pitch);
		else
			m_drawer->blit_alpha_saturation(src_data ,dst_data,dst_width, dst_height, src_pitch, dst_pitch);
		
		default:
		// TODO : throw exception
		break;
	}
}


//=============================================================================================================
void ImageDrawer::draw(BaseImage32 &srcSurface, const AreaInt &srcArea, BaseImage32 &dstSurface, int x, int y, int blitFlags)
{
	uint8 *src_data,*dst_data;
	int  src_pitch,dst_pitch;
	int  dst_width,dst_height;
	
	/* get address and pitch from source surface
		 and set correct offsets */
	src_pitch = srcSurface.getPitch();
	src_data  = (uint8*)srcSurface.getReadOnly();
	src_data += (srcArea.getLeft() * 4) + srcArea.getTop() * src_pitch;			

	/* calc first pixels address in dest data.
	   and set pitch and dimensions of dest surface */
	dst_pitch = dstSurface.getPitch();
	dst_width = srcArea.getWidth();
	dst_height= srcArea.getHeight();
	dst_data  = (uint8*)dstSurface.get();
	dst_data += ( x * 4) + y * dst_pitch;
	
	// route to proper internal blit routine...
	switch (blitFlags)
	{
		case BLIT_NORMAL:
		m_drawer->copy(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;
		
		case BLIT_SATURATION:
		m_drawer->blit_saturation(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;

		case BLIT_ALPHABLEND:
		if (m_alphaMode == ALPHA_CONSTANT)
			m_drawer->blit_alpha_const(src_data,dst_data, m_alphaChannel, dst_width, dst_height, src_pitch, dst_pitch);
		else
			m_drawer->blit_alpha (src_data,dst_data, dst_width, dst_height, src_pitch, dst_pitch);
			
		break;

		case BLIT_COLORKEY:
		m_drawer->blit_colorkey(src_data,dst_data, 0, dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_SATURATION|BLIT_COLORKEY:
		m_drawer->blit_colorkey_saturation (src_data,dst_data, 0, dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_COLORKEY|BLIT_ALPHABLEND:
		
		if (m_alphaMode == ALPHA_CONSTANT)
			m_drawer->blit_alpha_const_colorkey(src_data ,dst_data, m_alphaChannel,0,dst_width, dst_height, src_pitch, dst_pitch);
		else
			m_drawer->blit_alpha_colorkey(src_data ,dst_data,0,dst_width, dst_height, src_pitch, dst_pitch);
		
		break;

		case BLIT_SATURATION|BLIT_ALPHABLEND:

		if (m_alphaMode == ALPHA_CONSTANT)
			m_drawer->blit_alpha_const_saturation(src_data ,dst_data, m_alphaChannel,dst_width, dst_height, src_pitch, dst_pitch);
		else
			m_drawer->blit_alpha_saturation(src_data ,dst_data,dst_width, dst_height, src_pitch, dst_pitch);
		
		default:
		// TODO : throw exception
		break;
	}

}

//=============================================================================================================
void ImageDrawer::setAlphaMode(int alphaMode, int alphaChannel)
{
	m_alphaMode = alphaMode;
	m_alphaChannel = alphaChannel;
}

//=============================================================================================================
void ImageDrawer::setAlphaChannel(uint8 alphaVal)
{
	m_alphaChannel = alphaVal;
}

//=============================================================================================================
void ImageDrawer::setScaleMode( int scaleMode)
{
	// sanity check
	if ((scaleMode == SCALE_BILINEAR) || (scaleMode == SCALE_LINEAR))
	m_scaleMode = scaleMode;
}