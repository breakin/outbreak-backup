#include "dx_ddraw.h"
#include "..\core\exception.h"
#include <windows.h>

using namespace Helper;

HMODULE DirectDraw::m_dllHandle = NULL;
bool	DirectDraw::m_dllLoaded = false;
int		DirectDraw::m_dllRef	 = 0;	

typedef HRESULT (WINAPI *DDCREATEFUNC) (GUID FAR*, LPDIRECTDRAW FAR*, IUnknown FAR*);

//=========================================================================================================

DirectDraw::~DirectDraw()
{

	Debug::logSystem("DirectDraw::~DirectDraw()","Destructing instance[%d]...",m_dllRef);
	
	m_dllRef--;

	if ((m_dllRef == 0) && (m_dllLoaded))
		unload();
}


//=========================================================================================================


void DirectDraw::load()
{
	if (!m_dllLoaded)
	{
		Debug::logSystem("DirectDraw::load()", "Loading ddraw.dll");
		m_dllHandle = (HMODULE) LoadLibrary("ddraw.dll");
		
		if (m_dllHandle == NULL) 
			throw DeviceException("Could not load ddraw.dll!");
		
		m_dllLoaded = true;
	}
}

//=========================================================================================================

void DirectDraw::unload()
{
	if (m_dllLoaded)
	{	
		Debug::logSystem("DirectDraw::unload()", "Unloading ddraw.dll");
		FreeLibrary(m_dllHandle);
		m_dllHandle = NULL;
		m_dllLoaded = false;
	}
}

//=========================================================================================================

void DirectDraw::create()
{
	// check if dll is loaded, otherwise - load!
	if (!m_dllLoaded) load();

	if (!m_active)
	{
		// create a function pointer and an IID
		DDCREATEFUNC directDrawCreate;
		GUID dd7IID;

		Debug::logSystem("DirectDraw::create()", "Getting <DirectDrawCreate()> from ddraw.dll");
		
		// import DirectDrawCreate from dll
		directDrawCreate = (DDCREATEFUNC)GetProcAddress(m_dllHandle,"DirectDrawCreate");

		// check if it went ok
		if (directDrawCreate == NULL) 
			throw DeviceException("Could not import <DirectDrawCreate()> from ddraw.dll");

		// create a directdraw interface
		Debug::logSystem("DirectDraw::create()","Creating a IDirectDraw1 interface");
		
		if (directDrawCreate(NULL,&m_directDraw,NULL)!=DD_OK)
			throw DeviceException("Could not create IDirectDraw");
		
		// setup DD7 IID
		dd7IID.Data1    = 0x15e65ec0; 
		dd7IID.Data2    = 0x3b9c;
		dd7IID.Data3    = 0x11d2;
		dd7IID.Data4[0] = 0xb9;
		dd7IID.Data4[1] = 0x2f;
		dd7IID.Data4[2] = 0x00;
		dd7IID.Data4[3] = 0x60;
		dd7IID.Data4[4] = 0x97;
		dd7IID.Data4[5] = 0x97;
		dd7IID.Data4[6] = 0xea;
		dd7IID.Data4[7] = 0x5b;

		// query for IID_IDirectDraw7 interface
		Debug::logSystem("DirectDraw::create()","Query for IDirectDraw7 interface");
		if (m_directDraw->QueryInterface(dd7IID, (void**)&m_directDraw7)!=S_OK)
			throw DeviceException("Could not query for IDirectDraw7 interface");
		
		m_active = true;
	}
}

//=========================================================================================================

void DirectDraw::release()
{
	if (m_active)
	{
		if (m_exclusive)
		{
			// restore displaymode and set cooperativelevel 
			// back to normal
			m_directDraw7->RestoreDisplayMode();
			setCooperativeLevel(false, m_hwnd);
		}

		m_directDraw7->Release();
		m_directDraw->Release();
		m_active = false;
	}
}

//=========================================================================================================

void DirectDraw::setCooperativeLevel(bool exclusive, HWND hwnd)
{
	Debug::logSystem("DirectDraw::setCoopertiveLevel()","Exclusive access = %d",exclusive);

	if (exclusive)
		m_directDraw7->SetCooperativeLevel(hwnd, DDSCL_FULLSCREEN|DDSCL_EXCLUSIVE|DDSCL_ALLOWREBOOT|DDSCL_ALLOWMODEX);
	else
		m_directDraw7->SetCooperativeLevel(hwnd, DDSCL_NORMAL);

	m_exclusive = exclusive;
	m_hwnd = hwnd;
}

//=========================================================================================================

void DirectDraw::setDisplayMode(int width, int height, int bpp)
{
	if (m_exclusive)
	{
		Debug::logSystem("DirectDraw::setDisplayMode()","width = %d, height =%d, bpp = %d",width,height,bpp);
		
		if (m_directDraw7->SetDisplayMode(width, height, bpp, 0, 0)!=DD_OK)
			throw DeviceException("Unsupported displaymode(%d,%d,%d)!",width, height, bpp);
	}
}




