
#include "clock.h"

/* TODO: Perhaps link winmm.dll explicity and fall back on standard timer if it's not present...? */
/* TODO: Implement ansi-c version */

// ---------------------------------------------------------------------------

#ifdef WIN32
	
	#define WIN32_LEAN_AND_MEAN
	#include <windows.h>
	#include <mmsystem.h>
	#undef WIN32_LEAN_AND_MEAN

	namespace Helper {
		static bool usingPerformanceTimer;
		static float64 performanceTimerScale;
	}

#else

	TODO; Include standard clock headers here

#endif

namespace Helper {
	static bool initialized=false;
}

// ---------------------------------------------------------------------------

Helper::Clock::Clock() {
	if (!initialized) initTime();
	startTime=getTime();
}

void Helper::Clock::initTime() {

	#ifdef WIN32

		LONGLONG performanceFreq;
		
		if (QueryPerformanceFrequency((LARGE_INTEGER*)&performanceFreq)) {

			performanceTimerScale=1.0/static_cast<float64>(performanceFreq);
			usingPerformanceTimer = true;

		} else {

			usingPerformanceTimer = false;
		}

	#else

		TODO; Initialize standard clock

	#endif

	initialized=true;
}

// ---------------------------------------------------------------------------

const Helper::float64 Helper::Clock::getTime() {
	
	#ifdef WIN32
		if (usingPerformanceTimer) {

			LONGLONG currentTime;
			QueryPerformanceCounter((LARGE_INTEGER *)&currentTime);

			return static_cast<float64>(currentTime)*performanceTimerScale;

		} else {
			
			// Windows multimedia timer (winmm.lib->winmm.dll)
			return static_cast<float64>(timeGetTime())/1000.0;
		}
	#else

		TODO; Read the Standard clock

	#endif
}

// ---------------------------------------------------------------------------