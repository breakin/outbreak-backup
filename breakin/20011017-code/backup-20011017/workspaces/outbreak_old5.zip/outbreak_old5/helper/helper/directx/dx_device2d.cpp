#include "dx_device2d.h"

using namespace Helper;

#define DX_DEVICE2D_DEFAULT_WIDTH		"640"
#define DX_DEVICE2D_DEFAULT_HEIGHT		"480"
#define DX_DEVICE2D_DEFAULT_TITLE 		"DirectDraw Device2D"
#define DX_DEVICE2D_DEFAULT_FULLSCREEN	"false"
#define DX_DEVICE2D_DEFAULT_CAPTION		"true"
#define DX_DEVICE2D_DEFAULT_BPP		    "32"

//==============================================================================================

int DirectDrawDevice2D::m_openDeviceRef = 0;

//==============================================================================================

DirectDrawDevice2D::DirectDrawDevice2D()
{
	Debug::logSystem("DirectDrawDevice2D::DirectDrawDevice2D()","Construting...");
	reset();
	
	Debug::logSystem("DirectDrawDevice2D::DirectDrawDevice2D()","Registering self as MsgQueue");
	m_window.setMsgQueue(*this);
	m_opened = false;
}

//==============================================================================================

DirectDrawDevice2D::~DirectDrawDevice2D()
{
	Debug::logSystem("DirectDrawDevice2D::DirectDrawDevice2D()","Destructing...");
	
	if (m_opened)
		close();
}

//==============================================================================================

void DirectDrawDevice2D::reset()
{
	Debug::logSystem("DirectDrawDevice2D::reset()","Set default configuration");
	m_config.set("width"  ,	DX_DEVICE2D_DEFAULT_WIDTH);
	m_config.set("height" ,	DX_DEVICE2D_DEFAULT_HEIGHT);
	m_config.set("title"  ,	DX_DEVICE2D_DEFAULT_TITLE);
	m_config.set("caption",	DX_DEVICE2D_DEFAULT_CAPTION);
	m_config.set("fullscreen",DX_DEVICE2D_DEFAULT_FULLSCREEN);
	m_config.set("bpp",		DX_DEVICE2D_DEFAULT_BPP);
}

//==============================================================================================

void DirectDrawDevice2D::open()
{
	Debug::logSystem("DirectDrawDevice2D::open()","Open device");

	if (!m_opened)
	{
		int temp_bpp;

		m_config.get("width"    , m_width);
		m_config.get("height"   , m_height);
		m_config.get("title"    , m_title);
		m_config.get("caption"  , m_caption);
		m_config.get("fullscreen",m_fullscreen);	
		m_config.get("bpp"	    , temp_bpp);
		
		Debug::logSystem("DirectDrawDevice2D::open()","Requested device configuration :");
		Debug::logSystem("DirectDrawDevice2D::open()","width       = %d", m_width);
		Debug::logSystem("DirectDrawDevice2D::open()","height      = %d", m_height);
		Debug::logSystem("DirectDrawDevice2D::open()","bpp         = %d", temp_bpp);
		Debug::logSystem("DirectDrawDevice2D::open()","title       = %s", m_title.c_str());
		//Debug::logSystem("DirectDrawDevice2D::open()","caption     = %d", m_caption);
		//Debug::logSystem("DirectDrawDevice2D::open()","fullscreen  = %d", m_fullscreen);

		m_window.open(m_title.c_str(), AreaInt(40, 40, m_width, m_height), m_caption, true);
		m_directDraw.create();
		m_directDraw.setCooperativeLevel(m_fullscreen, m_window.getHandle());

		if (m_fullscreen)
		{
			m_window.showCursor(false);
			//m_window.hide();
			m_directDraw.setDisplayMode(m_width, m_height, temp_bpp);
		}

		m_backBuffer.initialize(m_directDraw.getDirectDraw7(), m_window.getHandle());
		m_backBuffer.fullscreen(m_fullscreen);
		m_backBuffer.resize(m_width, m_height);

		m_openDeviceRef++;
		Debug::logSystem("DirectDrawDevice2D::open()","Currently opened devices = [%d]",m_openDeviceRef);
		
		m_opened = true;
	}	
}

//==============================================================================================

void DirectDrawDevice2D::close()
{
	if (m_opened)
	{
		m_backBuffer.clear();
		m_directDraw.release();
		m_window.close();
		m_opened = false;
		m_openDeviceRef--;
	}
}

//==============================================================================================

void DirectDrawDevice2D::update(Image32 &image, bool displayUpdate)
{
	if (displayUpdate)
	{	
		// lock backbuffer
		m_backBuffer.lock();
		
		// copy pixels from src to backbuffer
		m_blitter.copy(image, m_backBuffer);
		
		// unlock backbuffer
		m_backBuffer.unlock();
		
		// flip surface chain
		m_backBuffer.flip();
	}

	m_window.update();
}

//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
