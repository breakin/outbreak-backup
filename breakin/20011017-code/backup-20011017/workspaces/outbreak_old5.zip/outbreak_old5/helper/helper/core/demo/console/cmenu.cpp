#include "cmenu.h"

#include <helper/core/exception.h>

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::ConsoleMenu::ConsoleMenu(const ConsoleData& consoleData) : Helper::Application(consoleData) {
	carret  = 0;

	std::string temp = "DEBUG MONITOR";
	name.push_back(temp);
	temp = "DEMO SCRIPTER";
	name.push_back(temp);
	temp = "ABOUT";
	name.push_back(temp);
	temp = "EXIT!";
	name.push_back(temp);


	left   = 25;
	right  = 54;
	middle = 14;
	top    = middle - (name.size()>>1)-2;
	bottom = top + name.size()+3;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::ConsoleMenu::~ConsoleMenu() {

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Helper::ConsoleMenu::refresh() {
	C64& c64 = *consoleData.c64;

	uint32* pixel = c64.screen.get();
	for (int sy=0, offset=0; sy<c64.screen.getHeight(); sy++) {
		for (int sx=0; sx<c64.screen.getWidth(); sx++, offset++) {
			pixel[offset] = c64.getRGBColor(((sx^sy)^16)%7);
		}
	}

	c64.setColor(C64::COLOR_FRAME, C64::COLOR_FRAMEBACKGROUND);

	c64.drawWindow(left, top, right, bottom, "MENU");

	// Draw names (actions)
	for (int index=0; index<name.size(); index++) {
		// Set color
		if (index==carret) {
			c64.setColor(C64::COLOR_SELECTED, C64::COLOR_SELECTEDBACKGROUND);
		} else {
			c64.setColor(C64::COLOR_ACTION, C64::COLOR_FRAMEBACKGROUND);
		}

		// Clear behind the text
		for (int x=left+2; x<right-1; x++) {
			c64.drawLetter(c64.screen, x, top+2+index, 32);
		}

		// Write the text
		c64.drawString(c64.screen, 40-(name[index].length()>>1), top+2+index, name[index]);
	}

	needUpdate = true;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Application* Helper::ConsoleMenu::update() {
	C64& c64 = *consoleData.c64;

	c64.winDevice.update(c64.screen, needUpdate);
	needUpdate = false;

	Msg msg;
	while(c64.winDevice.getMessage(msg, false)) {
		if (msg.message == Helper::Msg::MSG_KEYDOWN) {
			
			// Up
			if (msg.param == 38) {
				carret = (carret+name.size()-1)%name.size();
				refresh();
			}

			// Down
			if (msg.param == 40) {
				carret = (carret+1)%name.size();
				refresh();
			}

			// Return, action!
			if (msg.param == 13) {
				if (name[carret] == "DEBUG MONITOR") {
					Application* temp = new ConsoleDebug(consoleData);
					return temp;
				}

				if (name[carret] == "ABOUT") {
					Application* temp = new ConsoleAbout(consoleData);
					return temp;
				}

				if (name[carret] == "EXIT!") {
					return 0;
				}
			}

		}
	}

	// Continue to live.
	return this;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
