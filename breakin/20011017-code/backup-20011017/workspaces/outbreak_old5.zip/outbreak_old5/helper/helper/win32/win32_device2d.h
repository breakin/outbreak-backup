#ifndef __HELPER_WIN32_DEVICE2D_H__
#define __HELPER_WIN32_DEVICE2D_H__

#include "..\core\device2d.h"
#include "..\core\pixelformat.h"
#include "..\core\imagedrawer\imagedrawer.h"
#include "win32_image.h"
#include "win32_window.h"

#define WIN32_DEVICE2D_DEFAULT_ALIGN   "CENTER"
#define WIN32_DEVICE2D_DEFAULT_WIDTH   "640"
#define WIN32_DEVICE2D_DEFAULT_HEIGHT  "480"
#define WIN32_DEVICE2D_DEFAULT_TITLE   "Win32 Device Application"
#define WIN32_DEVICE2D_DEFAULT_CAPTION "TRUE"
#define WIN32_DEVICE2D_DEFAULT_XPOS    "320"
#define WIN32_DEVICE2D_DEFAULT_YPOS    "200"


namespace Helper {


class Win32Device2D : public Device2D
{
	
	public:
	   /**
		* Constructor, Destructor
		*/
		Win32Device2D::Win32Device2D();
		virtual ~Win32Device2D();

	   /**
		* open, close...
		*/
		void open();
		void close();

		/**
		 * update() updates screen with <surface>,
		 * and check window's message queue for qued messages,
		 */
		void update(Image32 &image,bool needScreenUpdate=true);
		
		/**
		 * Methods for retrieving a device's properties
		 */
		int	 getWidth () const { return m_width; }
		int	 getHeight() const { return m_height;}
		int	 getPitch () const { return m_pitch; }
		void getPixelFormat(PixelFormat &pixelformat) const {pixelformat = m_pixelFormat; }	
	
	protected:
		/**
		 * checkReconfig() - when opening an already opened device
		 * this method is called to see if any configuration has
		 * occured, and does then takes appropriate actions
		 * returns false and closes the device if needed,
		 * otherwise makes the changes runtime and return true - 
		 * indicating to the device that it do not need to be reopened
		 */
	    bool checkReconfig();

		/**
		 * reset all properties to default
		 */
		void reset();

		/**
		 * Win32Device2D properties
		 */
		bool					m_opened;		// device open state
		bool					m_caption;		// window has caption (true or false)
		int						m_xpos;         // window's x position
	    int						m_ypos;			// window's y position
		int						m_width;		// width of window
		int						m_height;		// height of window
		int						m_pitch;		// bytes per pixel
		PixelFormat				m_pixelFormat;	// device's pixelformat.
		Win32Window				m_window;		// device output window
		Win32Image				m_backBuffer;	// device backbuffer
		ImageDrawer				m_blitter;		// device blitter
		std::string				m_title;		// window's title
		static int				m_refCount;     // reference counter, keeps track of amout of allocated devices
	};

} // end namespace Aurora

#endif