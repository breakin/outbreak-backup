#include "drawmmx.h"

using namespace Helper;


//=====================================================================================================

void Drawer_MMX::blit_alpha_saturation(uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch)
{
	int srcpadd = srcPitch - (width * 4);
	int dstpadd = dstPitch - (width * 4);

	_asm
	{
		mov edi, dst
		mov esi, src

		mov ebx, height

		HL:
			mov ecx, width
			
			WL:
				mov			eax, [esi]
				shr			eax, 24			// get alpha in al

				movd		mm0, eax		// mm0 = 0000 0000 0000 00aa
				punpcklwd	mm0, mm0		// mm0 = 0000 0000 00aa 00aa
				punpckldq	mm0, mm0		// mm0 = 00aa 00aa 00aa 00aa
						
				pxor		mm5,mm5
						
				mov			eax,[esi]		
				movd		mm3, eax		// mm3 = 0000 0000 00rr ggbb
				punpcklbw	mm3,mm5			// mm3 = 0000 00rr 00gg 00bb
				
				pmullw		mm3, mm0		// mm3 = 0000 rara gaga baba  
			
				psrlw		mm3,8			// mm3 = 0000 00ra 00ga 00ba 

				packuswb	mm3,mm3			// mm3 = 0000 0000 00ra gaba
				
				movd        mm2,[edi]		// get destination pixel

				paddusb		mm2,mm3			// add them with saturation
											
				movd		[edi],mm2		

				add edi,4
				add esi,4

				dec ecx

				jnz WL
			
			add edi, dstpadd
			add esi, srcpadd
			dec ebx
			jnz HL	

		emms
	}		
}

//=====================================================================================================

void Drawer_MMX::blit_alpha_const_saturation(uint8 *src, uint8 *dst, int alpha, int width, int height, int srcPitch, int dstPitch)
{
	
	int srcpadd = srcPitch - (width * 4);
	int dstpadd = dstPitch - (width * 4);

	_asm
	{
		mov edi, dst
		mov esi, src

		mov ebx, height

		HL:
			mov ecx, width
			
			WL:
				movd		mm0, alpha		// mm0 = 0000 0000 0000 00aa
				punpcklwd	mm0, mm0		// mm0 = 0000 0000 00aa 00aa
				punpckldq	mm0, mm0		// mm0 = 00aa 00aa 00aa 00aa
						
				pxor		mm5,mm5
						
				mov			eax,[esi]		
				movd		mm3, eax		// mm3 = 0000 0000 00rr ggbb
				punpcklbw	mm3,mm5			// mm3 = 0000 00rr 00gg 00bb
				
				pmullw		mm3, mm0		// mm3 = 0000 rara gaga baba  
			
				psrlw		mm3,8			// mm3 = 0000 00ra 00ga 00ba 

				packuswb	mm3,mm3			// mm3 = 0000 0000 00ra gaba
				
				movd        mm2,[edi]		// get destination pixel

				paddusb		mm2,mm3			// add them with saturation
											
				movd		[edi],mm2		

				add edi,4
				add esi,4

				dec ecx

				jnz WL
			
			add edi, dstpadd
			add esi, srcpadd
			dec ebx
			jnz HL	

		emms
	}		
}


//=====================================================================================================


void Drawer_MMX::blit_alpha	(uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch)
{
	int srcpadd = srcPitch - (width * 4);
	int dstpadd = dstPitch - (width * 4);

	_asm
	{
		mov edi, dst
		mov esi, src

		mov ebx, height

		HL:
			mov ecx, width
			
			WL:
				mov			eax, [esi]
				shr			eax, 24			// get alpha in al
				// mov			eax, 0xff
				movd		mm0, eax		// mm0 = 0000 0000 0000 00aa
				punpcklwd	mm0, mm0		// mm0 = 0000 0000 00aa 00aa
				punpckldq	mm0, mm0		// mm0 = 00aa 00aa 00aa 00aa
				
				mov 		eax, 0x00ff00ff	
				movd		mm1, eax		// mm1 = 0000 0000 00ff 00ff
				punpckldq	mm1,mm1			// mm1 = 00ff 00ff 00ff 00ff

				psubusb		mm1, mm0		//			00ff 00ff 00ff 00ff
											// mm1 =  - 00aa 00aa 00aa 00aa
				
				pxor		mm5,mm5
				
				mov			eax,[edi]
				movd		mm2, eax		// mm2 = 0000 0000 00rr ggbb
				punpcklbw	mm2,mm5			// mm2 = 00aa 00rr 00gg 00bb
				
				mov			eax,[esi]		
				movd		mm3, eax		// mm3 = 0000 0000 00rr ggbb
				punpcklbw	mm3,mm5			// mm3 = 0000 00rr 00gg 00bb
				
				pmullw		mm3, mm0		// mm3 = 0000 rara gaga baba  
				pmullw		mm2, mm1		// mm2 = 0000 rara gaga baba
				
				psrlw		mm3,8			// mm3 = 0000 00ra 00ga 00ba 
				psrlw		mm2,8			// mm2 = 0000 00ra 00ga 00ba 

				packuswb	mm2,mm2			// mm2 = 0000 0000 00ra gaba
				packuswb	mm3,mm3			// mm3 = 0000 0000 00ra gaba
				
				paddusb		mm2,mm3			//		  0000 0000 00ra gaba
											// mm2 = +0000 0000 00ra gaba
				movd		[edi],mm2		

				add edi,4
				add esi,4

				dec ecx

				jnz WL
			
			add edi, dstpadd
			add esi, srcpadd
			dec ebx
			jnz HL	

		emms
	}		
}

//=====================================================================================================

void Drawer_MMX::blit_alpha_const	(uint8 *src, uint8 *dst, int alpha, int width, int height, int srcPitch, int dstPitch)
{
	int srcpadd = srcPitch - (width * 4);
	int dstpadd = dstPitch - (width * 4);

	_asm
	{
		mov edi, dst
		mov esi, src

		mov ebx, height

		HL:
			mov ecx, width
			
			WL:
				mov			eax, alpha
				movd		mm0, eax		// mm0 = 0000 0000 0000 00aa
				punpcklwd	mm0, mm0		// mm0 = 0000 0000 00aa 00aa
				punpckldq	mm0, mm0		// mm0 = 00aa 00aa 00aa 00aa
				
				mov 		eax, 0x00ff00ff	
				movd		mm1, eax		// mm1 = 0000 0000 00ff 00ff
				punpckldq	mm1,mm1			// mm1 = 00ff 00ff 00ff 00ff

				psubusb		mm1, mm0		//			00ff 00ff 00ff 00ff
											// mm1 =  - 00aa 00aa 00aa 00aa
				
				pxor		mm5,mm5
				
				mov			eax,[edi]
				movd		mm2, eax		// mm2 = 0000 0000 00rr ggbb
				punpcklbw	mm2,mm5			// mm2 = 00aa 00rr 00gg 00bb
				
				mov			eax,[esi]		
				movd		mm3, eax		// mm3 = 0000 0000 00rr ggbb
				punpcklbw	mm3,mm5			// mm3 = 0000 00rr 00gg 00bb
				
				pmullw		mm3, mm0		// mm3 = 0000 rara gaga baba  
				pmullw		mm2, mm1		// mm2 = 0000 rara gaga baba
				
				psrlw		mm3,8			// mm3 = 0000 00ra 00ga 00ba 
				psrlw		mm2,8			// mm2 = 0000 00ra 00ga 00ba 

				packuswb	mm2,mm2			// mm2 = 0000 0000 00ra gaba
				packuswb	mm3,mm3			// mm3 = 0000 0000 00ra gaba
				
				paddusb		mm2,mm3			//		  0000 0000 00ra gaba
											// mm2 = +0000 0000 00ra gaba
				movd		[edi],mm2		

				add edi,4
				add esi,4

				dec ecx

				jnz WL
			
			add edi, dstpadd
			add esi, srcpadd
			dec ebx
			jnz HL	

		emms
	}		
}


//=====================================================================================================


void Drawer_MMX::blit_saturation (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch)
{
	int srcpadd = srcPitch - (width * 4);
	int dstpadd = dstPitch - (width * 4);

	_asm
	{
		mov edi, dst
		mov esi, src

		mov ebx, height

		HL:
			mov ecx, width
			shr ecx, 1
			
			// check carry for odd width, not even dividable by 2 
			jnc WL

			movd mm0, [esi]
			movd mm1, [edi]
			paddusb mm0, mm1
			movd [edi], mm0

			add edi, 4
			add esi, 4
			
			WL:
				movq mm0, [esi]
				movq mm1, [edi]
				paddusb mm0, mm1
				movq [edi], mm0

				add edi, 8
				add esi, 8
				dec ecx
				jnz WL

			add edi, dstpadd
			add esi, srcpadd
			dec ebx
			jnz HL

		emms			
	}
}

//=====================================================================================================

void Drawer_MMX::copy (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch)
{
	int dstpadd = dstPitch - (width * 4);
	int srcpadd = srcPitch - (width * 4);

	_asm
	{
		mov edi, dst
		mov esi, src

		mov ebx, height
		
		HL:
			mov ecx, width
			shr ecx, 1
			jnc WL
				
			movd mm0, [esi]
			movd [edi], mm0
			add edi, 4
			add esi, 4

			WL:
				movq mm0,[esi]
				movq [edi],mm0
				add  edi, 8
				add  esi, 8
				dec  ecx
				jnz  WL
			
			add edi, dstpadd
			add esi, srcpadd
			dec ebx
			jnz HL
	
		emms
	}
}

//=====================================================================================================

void Drawer_MMX::clear_rgb	(uint8 *dst, int width, int height, int dstPitch)
{
	int dstpadd = dstPitch - (4 * width);
	
	_asm
	{
		mov  edi, dst
		mov  eax, 0xff000000

		movd  mm0, eax
		psllq mm0, 32
		movd  mm0, eax

		mov ebx, height

		HL:
			mov ecx, width
			shr ecx, 1
			jnc WL

			and [edi], 0xff000000
			add edi, 4

			WL:
				movq mm1, [edi]
				pand mm1, mm0
				movq [edi], mm1
				add edi,8
				dec ecx
				jnz WL

			add edi, dstpadd
			dec ebx
			jnz HL

		emms
	}

}

//=====================================================================================================

void Drawer_MMX::clear_argb	(uint8 *dst, int width, int height, int dstPitch)
{
	int dstpadd = dstPitch - (4 * width);
	
	_asm
	{
		mov edi, dst
		mov ebx, height
		
		pxor mm1,mm1

		HL:
			mov ecx, width
			shr ecx, 1
			jnc WL

			movd [edi],mm1
			add  edi, 4

			WL:
				movq [edi], mm1
				add edi,8
				dec ecx
				jnz WL

			add edi, dstpadd
			dec ebx
			jnz HL

		emms
	}


}

//=====================================================================================================

void Drawer_MMX::blit (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch)
{
	int dstpadd = dstPitch - (width * 4);
	int srcpadd = srcPitch - (width * 4);

	_asm
	{
		mov edi, dst
		mov esi, src

		mov ebx, height
		
		HL:
			mov ecx, width
			shr ecx, 1
			jnc WL
				
			movd mm0, [esi]
			movd [edi], mm0
			add edi, 4
			add esi, 4

			WL:
				movq mm0,[esi]
				movq [edi],mm0
				add  edi, 8
				add  esi, 8
				dec  ecx
				jnz  WL
			
			add edi, dstpadd
			add esi, srcpadd
			dec ebx
			jnz HL
	
		emms
	}
}

