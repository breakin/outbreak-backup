#include "console.h"

#include <helper/core/exception.h>

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Console::Console(const ConsoleData& consoleData) {
	this->consoleData = consoleData;

	if (this->consoleData.c64 == 0) {
		throw Helper::Exception("Console::Console(); Cannot initialize console without c64-object");
	}

	ConsoleMenu* menu = new ConsoleMenu(consoleData);
	applications.push(menu);

	activeApplication = menu;
	activeApplication->refresh();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Helper::Console::~Console() {
	while (applications.size()>0) {
		Application* temp = applications.top();
		applications.pop();
		delete temp;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const bool Helper::Console::update() {
	// If there are no apps on the stack, tell the program to stop calling!
	// This only happens when the caller doesn't handle the return false 
	// statement, and there are some errors. I continue anyway though.
	if (activeApplication == 0) {
		// Empty messages.
		Msg msg;
		while (consoleData.c64->winDevice.getMessage(msg,true));
		return false;
	}

	// Update the active application.
	Application* result = activeApplication->update();

	// Application closed.
	if (result == 0) {
		Application* temp = applications.top();
		applications.pop();
		delete temp;

		if (applications.size()>0) {
			// There were still applications on the stack,
			// set the active application to the one on top.
			activeApplication = applications.top();

			activeApplication->refresh();

			return true;
		} else {
			// No more applications, tell the program to stop calling!
			activeApplication = 0;
			return false;
		}
	}

	// New application, put it on stack and update activeApplication.
	if (result != activeApplication) {
		applications.push(result);
		activeApplication = result;

		activeApplication->refresh();
	}

	// Keep running the console.
	return true;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
