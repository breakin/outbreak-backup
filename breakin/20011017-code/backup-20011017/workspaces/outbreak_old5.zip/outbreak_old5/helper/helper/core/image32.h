#ifndef HELPER_IMAGE32_H
#define HELPER_IMAGE32_H

#include "typedefs.h"
#include "area.h"
#include "baseimage32.h"

/* Author: Breakin
   Remark: (see blob.h for design pattern)
*/

namespace Helper {
	
	class Image32 : public BaseImage32 {
	private:

		class Image32Ref {
		public:

			uint32 *mBuffer;
			int     mWidth;
			int     mHeight;
			AreaInt mArea;

			int     refCount;
		};

		Image32Ref *image32Ref;

		void makeUniqueCopy();

	public:

		Image32();
		Image32(const Image32 &other);
		Image32(const int width, const int height);
		virtual ~Image32();

		void operator=(const Image32 &other);

		// This method will resize the Image32
		void resize(const int width, const int height);

		// This will clear the Image32, making it a null-Image32
		// Note! This will resize(0,0) not just making the image black!
		void clear();

		bool isEmpty()     const { return (image32Ref==0 || image32Ref->mBuffer==0); }
		int  getWidth()    const { return image32Ref->mWidth; }
		int  getHeight()   const { return image32Ref->mHeight; }
		const AreaInt& getArea() const { return image32Ref->mArea; }
		int  getPitch()    const { return getWidth()<<2; }		
		
		// get is not allowed on null-Image32s!
		const uint32 * const getReadOnly() const { return image32Ref->mBuffer; }

		uint32 * get() {
			makeUniqueCopy();
			return image32Ref->mBuffer;
		}

		inline const uint32 get(const int index) const { return image32Ref->mBuffer[index]; }

		inline void set(const int index, const uint32 value) {
			makeUniqueCopy();
			image32Ref->mBuffer[index]=value;
		}
	};
}

#endif