#ifndef HELPER_HELPER_IMAGETOOL_IMAGECODER_TGA_H
#define HELPER_HELPER_IMAGETOOL_IMAGECODER_TGA_H

/*

    Author: Breakin
    See "imagecoder.h" for details.

    This class will encode and decode TARGA-files, supporting the tga-extension (".tga")

*/

#include "imagecoder.h"

namespace Helper {

	class ImageCoder_TGA : public ImageCoder {
	public:

		ImageCoder_TGA();		
		virtual ~ImageCoder_TGA();

		virtual Blob    encode(const Image32 &sourceImage, const EncodeSettings &settings=defaultEncodeSettings) const;
		virtual Image32 decode(const Blob &sourceBlob, const DecodeSettings &settings=defaultDecodeSettings) const;

		virtual const bool isEncoder(const std::string &fileName="") const;
		virtual const bool isDecoder(const std::string &fileName="") const;
	};
};

#endif