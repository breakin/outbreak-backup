#ifndef __HELPER_BASEIMAGE32_H__
#define __HELPER_BASEIMAGE32_H__

/*=======================================================================

 File	:	baseimage32.h
 Author	:	Peter Nordlander
 Decr.	:	BaseImage32 class/interfacs - all Image32 classes,
			API as general, derives from BaseImage32

=======================================================================*/

#include "typedefs.h"
#include "area.h"

namespace Helper {

	struct BaseImage32 {
	
		//virtual destructor
		virtual ~BaseImage32() {}

		// resize - creates and resize an image
		virtual void resize(const int width, const int height) = 0;

		// destroys and deallocates image mem
		virtual void clear() = 0;
				
		// methods for getting pixel data
		virtual uint32* get() = 0;
		virtual const uint32 * const getReadOnly() const = 0;

		// methods for getting image properties
		virtual const AreaInt& getArea() const = 0;
		virtual int  getWidth()  const = 0;
		virtual int  getHeight() const = 0;
		virtual int  getPitch()  const = 0;	
	};
}

#endif
