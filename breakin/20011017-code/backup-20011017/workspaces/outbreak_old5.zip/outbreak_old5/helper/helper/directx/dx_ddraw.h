#ifndef __AURORA_DIRECTDRAW_H__
#define __AURORA_DIRECTDRAW_H__

#include <ddraw.h>
#include "..\core\debug\debug.h"

namespace Helper {


class DirectDraw 
{
	public:

		DirectDraw() : m_active(false), m_exclusive(false), m_directDraw7(NULL), m_directDraw(NULL) 
		{
			m_dllRef++;
			Debug::logSystem("DirectDraw::DirectDraw()","Construcing instance[%d]...",m_dllRef); 
		};

		~DirectDraw();
	
		
		// Exports and create DDraw Interfaces
		void create();
		void release();
		
		// DDraw methods called through ddraw interfaces
		void setDisplayMode(int width, int height, int bpp);
		void setCooperativeLevel(bool exclusive, HWND hwnd);

		// get direct draw
		LPDIRECTDRAW7 getDirectDraw7() const { return m_directDraw7;}

		// access and initalization checks 
		bool isExclusive() const { return m_exclusive; }
		bool isLoaded() const { return m_dllLoaded; }
	
	private:

		// Loads and unloads DLL 
		void load();
		void unload();

		// only 1 dll mapped into address space
		static	bool			m_dllLoaded;		// true if dll is loaded into address space
		static  HMODULE			m_dllHandle;		// handle to ddraw.dll
		static  int				m_dllRef;			// lib reference counter;
		
				bool			m_active;			// true if interfaces has been created
				bool			m_exclusive;		// exclusive Windows access
				LPDIRECTDRAW7	m_directDraw7;		// direct draw interfaces
				LPDIRECTDRAW	m_directDraw;
				HWND			m_hwnd;
				
};


}


#endif
