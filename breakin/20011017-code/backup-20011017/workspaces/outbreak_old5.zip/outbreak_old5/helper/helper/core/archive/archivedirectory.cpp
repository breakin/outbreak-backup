#include "archivedirectory.h"
#include "../exception.h"

// ---------------------------------------------------------------------------

Helper::ArchiveDirectory::ArchiveDirectory(const std::string &directoryName) :
	mDirectoryName(directoryName), Archive() {

	// Construct file-list via recurse-file-listing
	// Create directory if it does not exist
	// OS-dependant, the method is located in another .cpp-file (archivedirectory_win32.cpp)

	initialize();
}

// ---------------------------------------------------------------------------

Helper::ArchiveDirectory::~ArchiveDirectory() {
}

// ---------------------------------------------------------------------------

/* Returns the number of files in the directory */

const int Helper::ArchiveDirectory::getFileCount() const {
	return mFileList.size();
}

// ---------------------------------------------------------------------------

/* Returns true if the file 'filename' exists, false if it does not.
   'filename' includes full path from 'mDirectoryName'. */

const bool Helper::ArchiveDirectory::isExist(const std::string &filename) const {
	if (mFileList.find(filename)==mFileList.end()) return false;
		else return true;
}

// ---------------------------------------------------------------------------

/* Returns a File& object to the file with the filename 'filename'. Throws an exception
   if the file is not found. */

const Helper::File& Helper::ArchiveDirectory::getFile(const std::string &fileName) const {
	const std::map<std::string, ArchiveDirectory::FileDirectory>::const_iterator i=mFileList.find(fileName);

	if (i==mFileList.end()) throw FileException("ArchiveDirectory::getFile(filename); The file '%s' does not exist in '%s'", fileName.c_str(), mDirectoryName.c_str());
		else return i->second;
}

// ---------------------------------------------------------------------------

/* Returns a File& object to the file with the index fileIndex in the fileList.
   Throws an exception if the index is out of bound. */

const Helper::File& Helper::ArchiveDirectory::getFile(const int fileIndex) const {

	if (fileIndex<0 || fileIndex>=mFileList.size()) {
		throw Helper::Exception("ArchiveDirectory::getFile[int]; Index out of bound (%d, range=0 to %d)", fileIndex, getFileCount());
	}

	std::map<std::string, ArchiveDirectory::FileDirectory>::const_iterator i=mFileList.begin();

	for (int C=0; C<fileIndex; C++, i++);	

	return i->second;
}

// ---------------------------------------------------------------------------

/* Creates a sub-directory to the root directory. */

void Helper::ArchiveDirectory::createDirectory(const std::string &directoryName) {

	std::string temp(mDirectoryName);
	temp+=directoryName;

	createRootDirectory(temp);
}

// -[FileDirectory]-----------------------------------------------------------

/* Remove the file. Does not complain if the file did not exist. */

void Helper::ArchiveDirectory::FileDirectory::remove() {
	if (!isWriteable()) throw Helper::Exception("ArchiveDirectory::FileDirectory; Cant remove '%s' due to no write access!", getName().c_str());

	mContext->remove(getName());
}

// ---------------------------------------------------------------------------

/* Loads the file. */

Helper::Blob Helper::ArchiveDirectory::FileDirectory::get() const {
	if (!isReadable()) throw Helper::Exception("ArchiveDirectory::FileDirectory; Cant read '%s' due to no read access", getName().c_str());

	return mContext->getData(getName(), getSize());
}

// ---------------------------------------------------------------------------