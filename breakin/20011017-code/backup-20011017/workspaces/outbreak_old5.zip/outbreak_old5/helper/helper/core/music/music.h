#ifndef HELPER_MUSIC_MUSIC_H
#define HELPER_MUSIC_MUSIC_H

#include <string>
#include "../typedefs.h"
#include "../../../fmod/api/fmod.h"

namespace Helper {

	class Music {
	private:
		FSOUND_STREAM *  mStream;
		bool             mPaused;

	public:

		Music();
		Music(const std::string &filename);
		~Music();

		void load(const std::string &filename);
		void unload();

		void play();
		void pause();

		// Beh�vs en stop? Samma som pause v�l? =)
		
		void setTimer(const float64 timer);
		const float64 getTimer() const;

	};
}

#endif
