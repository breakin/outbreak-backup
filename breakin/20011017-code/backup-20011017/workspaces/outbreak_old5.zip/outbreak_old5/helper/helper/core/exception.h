#ifndef HELPER_EXCEPTION_H
#define HELPER_EXCEPTION_H

#include "debug\debug.h"
#include <exception>
#include <stdarg.h>

namespace Helper {

	class Exception : public exception {
	public:

		Exception() {}
		Exception(const char * const message,...) {

			char m_message[256];
			
			va_list  args;
			va_start(args,message);
			vsprintf(m_message,message,args);

			exception::operator=(exception(m_message));

			Debug::logException("Exception", what());
		};
	};

	/**
	 * File Exception - thrown when any file IO error occurs
	 */
	class FileException : public Exception {
	public:

		FileException(const char * const message, ...) {
		
		char m_message[256];
			
			va_list  args;
			va_start(args,message);
			vsprintf(m_message,message,args);
			exception::operator=(exception(m_message));

			Debug::logException("FileException", what());
		}
	};

	/**
	 * Device Exception - thrown when device error occurs
	 */
	class DeviceException : public Exception {
	public:

		DeviceException(const char * const message,...) {
		
			char m_message[256];
			
			va_list  args;
			va_start(args,message);
			vsprintf(m_message,message,args);
			exception::operator=(exception(m_message));

			Debug::logException("DeviceException", what());
		}
	};
}

#endif