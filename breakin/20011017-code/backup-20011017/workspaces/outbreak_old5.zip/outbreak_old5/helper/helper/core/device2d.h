#ifndef __DEVICE2D_H__
#define __DEVICE2D_H__

//===============================================================================
// Includes
//===============================================================================
#include "typedefs.h"
#include <map>
#include <string>
#include "image32.h"
#include "message.h"
#include "config.h"
#include "pixelformat.h"

namespace Helper {

/**
 * Basic highlevel Device2D Interface, inherits CMsgQueue which 
 * makes devices works as message queus as well.
 * This will provide a stable, platform independent way of
 * getting messages/events from the OS.
 */
class Device2D : public MsgQueue
{
	public:
		
		/**
		 * Constructor, 
		 * Destructor - (virtual to make higher classes destructors to be called)
		 */
		Device2D(){}
		virtual	~Device2D(){}

		/**
		 * config - set up console before open
		 * All devices are configured this way, bye passing ex) "WIDTH","320"
		 * This makes it easy to add configuration parameters without changing
		 * the Device2D interface.
		 */
		virtual  void  config (const std::string field, const std::string value) { m_config[field] = value; }

		/**
		 * get and setConfig, makes it possible to explicit set and configure
		 * a device configuration, that can be used for other likewise devices
		 */
		virtual  void  getConfig(Helper::Config &cfgmap) { cfgmap = m_config;}
		virtual  void  setConfig(Helper::Config &cfgmap) { m_config = cfgmap;}

		/**
		 * Open console only width preset configuration
		 * Call open() when device has been proper configured.
		 * Open can be used, even after a device has been once opened.
		 * The device should then look through the configuration and
		 * detect the changes and perform the action needed.
		 */
		virtual  void	open()  = 0;
		virtual  void	close() = 0;

		/**
		 * update - will perform a screen(Window/Frame) update and blit
		 * the surface send to the actual screenbuffer
		 */
		virtual  void	update(Image32 &surface, bool needScreenUpdate=true) = 0;

		/**
		 * get.. methods to get a device's properties
		 */
		virtual  int	getWidth () const = 0;
		virtual  int	getHeight() const = 0;
		virtual  int	getPitch () const = 0;
		virtual  void	getPixelFormat(PixelFormat &format) const = 0;
			
	protected:
		
		/**
		 * m_config - STL template map class
		 * all devices based on IDevice2D will be provided with a m_config member
		 */
		Config m_config;
};

}// end namespace 
#endif

