#ifndef __HELPER_DEBUG_FILEMONITOR_H__
#define __HELPER_DEBUG_FILEMONITOR_H__

#include <stdio.h>
#include "monitor.h"

namespace Helper {

class DebugMonitorFile : public DebugMonitor {
	
	public:
		
		DebugMonitorFile(const char file[]);
		DebugMonitorFile();
		~DebugMonitorFile();

		void onDebugMessage(int msgType, const char message[]);

		void setFilter(int msgFilter) { m_filter = msgFilter; }
		int  getFilter() const { return m_filter; }

	protected:

		// open, close file methods
		void open();
		void close();

		// protected members
		int		m_filter;
		char    m_filename[64];
		bool	m_initalized;
		bool	m_opened;
		FILE*	m_handle;		
};

}


#endif
