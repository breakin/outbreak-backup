#ifndef __STANDARD_BLITTER__
#define __STANDARD_BLITTER__

//============================================================================================
// Includes
//============================================================================================
#include "..\image32.h"
#include "..\area.h"

 
//============================================================================================
// Namespace Aurora
//============================================================================================
namespace Helper {

//============================================================================================
// Class or method implementations
//============================================================================================
class Drawer
{		
	public:

		Drawer();
		
		/**
		 * scale routines, linear and bilinear
		 */
		virtual void scale_linear	(uint32 *src, const AreaInt &srcArea, int srcPitch,
									 uint32 *dst, const AreaInt &dstArea, int dstPitch);

		virtual void scale_bilinear	(uint32 *src ,const AreaInt &srcArea, int srcPitch, 
									 uint32 *dst, const AreaInt &dstArea, int dstPitch);			
		/**
		 * clear methods
		 * clear_argb - clear whole surface data, including alphachannel
		 * clear_rgb  - clear rgb channels but keep alpga channel as is.
		 */
		virtual void clear_rgb	(uint8 *dst, int width, int height, int dstPitch);
		virtual void clear_argb	(uint8 *dst, int width, int height, int dstPitch);

		
		/**
		 * Copy pixels from two addresses
		 */
		virtual void copy (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);

		
		/**
		 * blit routines, apply effects when tranfering pixels from src
		 * pixels to dstpixels.
		 */
		virtual void blit (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_colorkey (uint8 *src, uint8 *dst, uint32 colorkey, int width, int height, int srcPitch, int dstPitch);
		
		
		virtual void blit_saturation (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_colorkey_saturation (uint8 *src, uint8 *dst, int colorkey, int width, int height, int srcPitch, int dstPitch);

		
		virtual void blit_alpha	(uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_alpha_colorkey (uint8 *src, uint8 *dst, uint32 colorkey, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_alpha_saturation (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);

		virtual void blit_alpha_const (uint8 *src, uint8 *dst, int alpha, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_alpha_const_colorkey (uint8 *src, uint8 *dst, int alpha, uint32 colokey, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_alpha_const_saturation (uint8 *src, uint8 *dst, int alpha, int width, int height, int srcPitch, int dstPitch);
	
	
	protected:

		static int m_initialized;
};


}// end namespace

#endif