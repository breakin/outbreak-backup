#include "xmlparser.h"
#include "xmltag.h"
#include "../exception.h"

/* TODO: Rewrite writeXML for blob */

// ---------------------------------------------------------------------------

Helper::XmlParser::XmlParser() {
	parsed=false;
}

// ---------------------------------------------------------------------------

Helper::XmlParser::XmlParser(const Blob &input) {
	parsed=false;
	parseXml(input);
}

// ---------------------------------------------------------------------------

Helper::XmlParser::~XmlParser() {
	clear();
}

// ---------------------------------------------------------------------------

void Helper::XmlParser::clear() {
	XmlBase::clear();
	parsed=false;
}

// ---------------------------------------------------------------------------

void Helper::XmlParser::parseXml(const Blob &input) {
	if (parsed==true) throw Exception("XmlParser::parseXml; Parser has already parsed a xml-file, use clear() first!");

	try {

		std::cout << "Root" << std::endl;

		XmlTag startTag;

		const int parseResult=startTag.parse(input, parsed);
		
		if (parseResult==0) {
			throw Exception("XmlParser::parseXml; Could not read first tag from the blob!");
		}

		if (startTag.getClosed()) throw Exception("XmlParser::parseXml; Root tag is closed!");

		Iterator i=createIterator();
		i.getRoot().setTag(startTag);

		parseXml(input, parseResult, i);
	}

	catch(...) {
		throw Exception("Helper::XmlParser::parseXml; Error when parsing xml-file!");
	}
}

// ---------------------------------------------------------------------------

const int Helper::XmlParser::parseXml(const Blob &input, const int inputOffset, Iterator &parent) {

	XmlTag t;

	int parseResult=0;

	while (true) {

		parseResult+=t.parse(input, inputOffset+parseResult);

		// Jump out a branch if found end of current depth block
		if (t.getClosed() && t.getName()==parent.getRoot().getName()) {
			return parseResult;
		}

		Iterator i2=parent.addChild(t);

		if (!t.getClosed()) parseResult+=parseXml(input, inputOffset+parseResult, i2);
	}
}

// ---------------------------------------------------------------------------

void Helper::XmlParser::writeXml(std::ostream &outputStream, const std::string &intend) const {
	outputStream << createIterator().getRoot() << std::endl;

	writeXml(outputStream, createIterator(), intend, 1);
}

// ---------------------------------------------------------------------------

void Helper::XmlParser::writeXml(std::ostream &outputStream, IteratorConst &parent, const std::string &intend, const int depth) const {

	while (++parent) {
		for (int C=0; C<depth; C++) outputStream << intend;

		outputStream << *parent.operator->() << std::endl;
		if (!parent->getClosed()) writeXml(outputStream, parent.createIterator(), intend, depth+1);
	}

	for (int C=0; C<depth-1; C++) outputStream << intend;
	outputStream << "</" << parent.getRoot().getName() << ">" << std::endl;
}

// ---------------------------------------------------------------------------