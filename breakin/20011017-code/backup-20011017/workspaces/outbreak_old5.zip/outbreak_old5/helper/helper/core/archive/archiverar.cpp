#include "archiverar.h"
#include "urarfilelib/urarlib.h"
#include "../exception.h"

/* TODO: Fix the memoryleak (list is never deallocated...) */

// ---------------------------------------------------------------------------

Helper::ArchiveRAR::ArchiveRAR(const std::string &archiveName, const std::string &archivePassword) :
	mArchiveName(archiveName), mArchivePassword(archivePassword), Archive() {

	// Set up mFileList
	ArchiveList_struct *list = NULL;
	const int numberOfFiles = urarlib_list(const_cast<char*>(mArchiveName.c_str()), (ArchiveList_struct*)&list);

	if (list==NULL) throw Helper::Exception("ArchiveRAR::ArchiveRAR; '%s' was not found", archiveName.c_str());

	while (true) {

		if (list==NULL) return;

		FileRAR temp;

		temp.setName(list->item.Name);
		temp.setContext(this);
		temp.setSize(list->item.UnpSize);
		temp.setReadable(true);
		temp.setWriteable(false);

		mFileList[std::string(list->item.Name)]=temp;

		list=list->next;
	}
}

// ---------------------------------------------------------------------------

Helper::ArchiveRAR::~ArchiveRAR() {
}

// ---------------------------------------------------------------------------

const int Helper::ArchiveRAR::getFileCount() const {
	return mFileList.size();
}

// ---------------------------------------------------------------------------

const bool Helper::ArchiveRAR::isExist(const std::string &filename) const {
	if (mFileList.find(filename)==mFileList.end()) return false;
		else return true;
}

// ---------------------------------------------------------------------------

const Helper::File& Helper::ArchiveRAR::getFile(const std::string &fileName) const {
	const std::map<std::string, ArchiveRAR::FileRAR>::const_iterator i=mFileList.find(fileName);

	if (i==mFileList.end()) throw Helper::Exception("ArchiveRAR::getFile; '%s' does not exist in '%s'", fileName.c_str(), mArchiveName.c_str());
		else return i->second;
}

// ---------------------------------------------------------------------------

const Helper::File& Helper::ArchiveRAR::getFile(const int fileIndex) const {
	if (fileIndex<0 || fileIndex>=getFileCount()) throw Helper::Exception("ArchiveRAR::getFile(index); Index out of bound (%d, 0-%d)", fileIndex, getFileCount());

	std::map<std::string, ArchiveRAR::FileRAR>::const_iterator i=mFileList.begin();

	for (int C=0; C<fileIndex; C++, i++);	

	return i->second;
}

// ---------------------------------------------------------------------------

void Helper::ArchiveRAR::FileRAR::remove() {
	throw Helper::Exception("ArchiveRAR::FileRAR::remove; Could not remove '%s' from '%s' (no write access to rar-file)", getName().c_str(), mContext->mArchiveName.c_str());
}

// ---------------------------------------------------------------------------

Helper::Blob Helper::ArchiveRAR::FileRAR::get() const {
	if (!isReadable()) throw Helper::Exception("ArchiveRAR::FileRAR::get; Cant read '%s' from '%s' due to read access", getName().c_str(), mContext->mArchiveName.c_str());

	char *data_ptr=0;
	unsigned long data_size;

	// Read the file
	if(urarlib_get(&data_ptr, &data_size, 
		const_cast<char*>(getName().c_str()),
		const_cast<char*>(mContext->mArchiveName.c_str()),
		const_cast<char*>(mContext->mArchivePassword.c_str()))) {

		if (data_size!=getSize()) {
			delete [] data_ptr;
			throw Helper::Exception("ArchiveRAR::FileRAR::get; Cant read '%s' from '%s' due to changed filesize", getName().c_str(), mContext->mArchiveName.c_str());
		}

		// We must make a copy since Blob's use new[]/delete[] and unrarlib malloc/free
		Blob returnBlob((unsigned char*)data_ptr, data_size);
		free(data_ptr);

		return returnBlob;


	} else {
		throw Helper::Exception("ArchiveRAR::FileRAR::get; Cant read '%s' from '%s'", getName().c_str(), mContext->mArchiveName.c_str());
	}
}

// ---------------------------------------------------------------------------

void Helper::ArchiveRAR::createFile(const std::string &fileName, const Blob &source) {
	throw Helper::Exception("ArchiveRAR::FileRAR::createFile; Could not create '%s' in '%s' (can't create to rar-files)", fileName.c_str(), mArchiveName.c_str());
}

// ---------------------------------------------------------------------------