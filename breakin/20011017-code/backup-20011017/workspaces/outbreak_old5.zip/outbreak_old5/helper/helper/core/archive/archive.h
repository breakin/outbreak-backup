#ifndef HELPER_ARCHIVE_ARCHIVE_H
#define HELPER_ARCHIVE_ARCHIVE_H

#include "../typedefs.h"
#include "../blob.h"
#include <string>
#include "../file.h"

/* The entire archive directory belongs to Breakin. */

namespace Helper {

	class Archive {
	public:

		virtual ~Archive() {
		}

		virtual const bool  isExist(const std::string &filename) const =0;
		virtual const int   getFileCount() const = 0;

		virtual const File &getFile(const std::string &fileName) const = 0;
		virtual const File &getFile(const int fileIndex) const = 0;

		virtual void createFile(const std::string &fileName, const Blob &source) = 0;
	};
}

#endif