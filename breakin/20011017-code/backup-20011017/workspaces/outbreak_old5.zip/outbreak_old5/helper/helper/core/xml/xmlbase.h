#ifndef HELPER_XmlBASE_H
#define HELPER_XmlBASE_H

#include "xmltag.h"
#include <vector>

namespace Helper {

	class XmlBase {
	public:

		class Node;
		class IteratorConst;

		//---------------------------------------------------------------------//
		
		class Iterator {
		private:

			Node*				context;
			int					currentChild;
			bool				atEnd,
								atBegin;
			const std::string	searchCriteria;

		public:

			Iterator(Node *newContext, const std::string &newSearchCriteria="");
			~Iterator();

			const bool isAtBegin() const;
			const bool isAtEnd() const;			

			const XmlTag& getRoot() const;
			XmlTag& getRoot();
			void setRoot(const XmlTag &);
			
			XmlTag* operator->();
			const XmlTag* operator->() const;
			const bool operator++();

			Iterator addChild(const XmlTag &childTag);
			Iterator createIterator(const std::string &searchCriteria="") const;

			// This are needed for iteratorConst copy-constructor, you don't need them
			Node* getContext() const { return context; }
			std::string getSearchCriteria() const { return searchCriteria; }
			const int getCurrentChild() const { return currentChild; }
		};

		//---------------------------------------------------------------------//

		class IteratorConst {
		private:

			Node const *		context;
			int					currentChild;
			bool				atEnd,
								atBegin;
			std::string			searchCriteria;

		public:

			IteratorConst(const Node const *newContext, const std::string &newSearchCriteria);
			~IteratorConst();
			
			IteratorConst(const Iterator &i);
			void operator=(const Iterator &i);

			const bool isAtBegin() const;
			const bool isAtEnd() const;			
			
			const XmlTag& getRoot() const;
			const XmlTag* operator->() const;
			const XmlTag* operator* () const;
			const bool operator++();

			IteratorConst createIterator(const std::string &searchCriteria="") const;

			const Node * const getContext() const { return context; }
		};

		//---------------------------------------------------------------------//

		class Node {
		private:

			XmlTag tag;
			std::vector<Node*> children;

		public:

			Node();
			Node(const XmlTag &initTag);
			~Node();

			void clear();

			const int getChildrens() const;
			const Node& getChildren(const int index) const;
			Node& getChildren(const int index);

			void setTag(const XmlTag &newTag);
			const XmlTag& getTag() const;
			XmlTag& getTag();

			Iterator addChild(const int index, const XmlTag &childTag);

			Iterator createIterator(const std::string &searchCriteria="");
			IteratorConst createIterator(const std::string &searchCriteria="") const;
		};

		//---------------------------------------------------------------------//

	private:		

		Node root;

	public:

		XmlBase();
		~XmlBase();

		// TODO: Add argument so that you can get an iterator down the tree
		//       like createIterator("beat", "demo.scene[0].synch[0].beat[2]");
		Iterator createIterator(const std::string &searchCriteria="");
		IteratorConst createIterator(const std::string &searchCriteria="") const;

		virtual void clear();
	};
};

#endif