#ifndef __AURORA_DIRECTX_SURFACE__
#define __AURORA_DIRECTX_SURFACE__

#include <ddraw.h>
#include "..\core\baseimage32.h"
#include "..\core\debug\debug.h"
#include "..\core\pixelformat.h"

namespace Helper {


class DirectDrawImage : public BaseImage32
{
	public:
		
		DirectDrawImage():
		    m_locked(false),
			m_active(false),
			m_primary(NULL),
			m_secondary(NULL),
			m_clipper(NULL),
			m_initialized(false)
			{
				Debug::logSystem("DirectDrawImage::DirectDrawImage()","Constructing...");
			}

		~DirectDrawImage();

		void initialize(LPDIRECTDRAW7 directDraw, HWND clipWindow = NULL);
		void fullscreen(bool fullscreen);

		// create and resize ddsurface
		void resize(const int width, const int height);
		void clear();
		
		// directdraw surfaces needs to be locked
		// and unlocked before access to pixel data
		void  lock();
		void  unlock();

		// flip primary and backbuffer
		void flip();

		// override getpixels
		uint32* get();
		const uint32 * const getReadOnly() const { /* NO PURPOSE YET..*/ return NULL; }

		const AreaInt& getArea() const { return m_area; }
		int  getWidth()  const { return m_width; }
		int  getHeight() const { return m_height;}
		int  getPitch()  const { return m_pitches[m_currentBackbuffer]; }	

		
	private:
		
		// creates a windowed/fullscreen surface depending
		// if the m_fullscreen flag is set
		void createSurfaceWindowed(int width, int height);
		void createSurfaceFullscreen(int width , int height);

		LPDIRECTDRAW7		 m_directDraw;
		LPDIRECTDRAWSURFACE7 m_primary;
		LPDIRECTDRAWSURFACE7 m_secondary;
		LPDIRECTDRAWCLIPPER  m_clipper;
		HWND				 m_hwnd;
		bool				 m_initialized;
		bool				 m_fullscreen;
		bool				 m_hasClipper;
		bool				 m_locked;
		bool				 m_active;
		void*				 m_data;

		int					 m_width;
		int					 m_height;
		int					 m_pitches[2];
		int					 m_currentBackbuffer;
		PixelFormat			 m_pixelFormat;
		AreaInt				 m_area;
};


}


#endif
