#include "draw.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

using namespace Helper;

// declare static variables

int Drawer::m_initialized = false;

// Saturation Lookup Table
static int SLUT[512];


//===========================================================================================
// interpolate bilinear and return a filtered color
//===========================================================================================

uint32 calc_color_bilinear(uint32 *data, float xpos, float ypos, int width)
{
	int   r,g,b,a;
	int   r2,g2,b2,a2;
	int   intPart;
	float fraction;

	// add interpolated attributes
	intPart		= (int)xpos;
	fraction	= xpos - (float)intPart;
	
	// extract color attributes, from the current pixel and one to the left 
	a  = (data[0]>>24)& 0xff;
	r  = (data[0]>>16)& 0xff;
	g  = (data[0]>>8) & 0xff;
	b  =  data[0]     & 0xff;

	a2 = (data[1]>>24)& 0xff;
	r2 = (data[1]>>16)& 0xff;
	g2 = (data[1]>>8) & 0xff;
	b2 =  data[1]     & 0xff;

	// add interpolated attributes
	a = (int)(((1.0 - fraction) * (float)a) + fraction * (float)a2)&0xff;
	r = (int)(((1.0 - fraction) * (float)r) + fraction * (float)r2)&0xff;
	g = (int)(((1.0 - fraction) * (float)g) + fraction * (float)g2)&0xff;
	b = (int)(((1.0 - fraction) * (float)b) + fraction * (float)b2)&0xff;
	
	// calculate vertical interpolation
	intPart		= (int)ypos;
	fraction	= ypos - (float)intPart;
	
	// extract lower pixel's attributes
	a2 = (data[width]>>24)& 0xff;
	r2 = (data[width]>>16)& 0xff;
	g2 = (data[width]>>8) & 0xff;
	b2 =  data[width]     & 0xff;
	
	// add x and y interpolated attributes
	a =(int) (((1.0 - fraction) * (float)a) + fraction * (float)a2)&0xff;	
	r =(int) (((1.0 - fraction) * (float)r) + fraction * (float)r2)&0xff;
	g =(int) (((1.0 - fraction) * (float)g) + fraction * (float)g2)&0xff;
	b =(int) (((1.0 - fraction) * (float)b) + fraction * (float)b2)&0xff;

	// return color
	return ((a<<24)|(r<<16)|(g<<8)|b);
}


//=============================================================================================================

Drawer::Drawer()
{

	if (!m_initialized)
	{
		// initlize saturation lookup table
		for (int I=0; I<512; I++)
			if (I > 255)
				SLUT[I] = 255;
			else
				SLUT[I] = I;

		m_initialized = true;
	}

}


//=============================================================================================================

void Drawer::scale_bilinear(uint32* src, const AreaInt &srcArea, int srcPitch, uint32 *dst, const AreaInt &dstArea, int dstPitch)
{
	// variables..
	float deltax;
	float deltay;
	float x,y;


	/**
	 * calculate zoom deltas
	 */
	deltax = (float)srcArea.getWidth ()  / (float)dstArea.getWidth();
	deltay = (float)srcArea.getHeight()  / (float)dstArea.getHeight();
		
	/**
	 * calculate src offsets, first pixel
	 */
	src+=(srcArea.getLeft() + srcArea.getTop() * (srcPitch>>2));	


	x = 0;
	y = 0;
	
	for (int height = 0; height < dstArea.getHeight()-1; height++)
	{
		for (int width = 0; width < dstArea.getWidth()-1; width++)
		{
			dst[width] = calc_color_bilinear(&src[(int)x + (int)y * (srcPitch>>2) ], x, y, (srcPitch>>2));	
			x+=deltax;
		}
		dst+=(dstPitch>>2);
		y +=deltay;
		x  = 0;
	}
}

//=============================================================================================================

void Drawer::scale_linear(uint32 *src,const AreaInt &srcArea, int srcPitch, uint32* dst, const AreaInt &dstArea, int dstPitch)
{
	float deltax;
	float deltay;

	/**
	 * Calculate deltas
	 */
	deltax = (float)srcArea.getWidth()  / (float)dstArea.getWidth();
	deltay = (float)srcArea.getHeight() / (float)dstArea.getHeight();
		
	/**
	 * Calcate offset of src surface's first pixel
	 * Assume *dst points to first pixel in destination surface
	 * and that dstArea only contain a valid width, height pair
	 */
	src+=(srcArea.getLeft() + srcArea.getTop() * (srcPitch>>2));
	
	float xsrc = 0;
	float ysrc = 0;

	for (int height = 0; height < dstArea.getHeight(); height++)
	{
		for (int width = 0; width < dstArea.getWidth(); width++)
		{
			dst[width] = src[(int)xsrc + (int)ysrc * (srcPitch>>2)];
			xsrc+=deltax;
		}

		xsrc  = 0;
		ysrc += deltay;
		dst+=(dstPitch>>2);	
	}
}

//=============================================================================================================

void Drawer::blit(uint8 *srcPixels, uint8 *dstPixels, int width, int height, int srcPitch, int dstPitch)
{
	for (int Y =0; Y<height; Y++)
	{
		memcpy(dstPixels,srcPixels, (width * 4));
		srcPixels+= srcPitch;
		dstPixels+= dstPitch;
	}
}


//=============================================================================================================

void Drawer::blit_alpha(uint8 *srcPixels, uint8 *dstPixels, int width, int height, int srcPitch, int dstPitch)
{
	uint8 sr,sg,sb,sa;
	uint8 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;

		for (int X=0; X<width; X++)
		{
			// extract source channels
			sa = (uint8)(src[X] >> 24);
			sr = (uint8)(src[X] >> 16);
			sg = (uint8)(src[X] >> 8);
			sb = (uint8)(src[X]);
			
			// extract dest channels
			da = (uint8)(0xff - sa);
			dr = (uint8)(( (da * ((dst[X]>>16)&0xff)) + (sa * sr)) >> 8);
			dg = (uint8)(( (da * ((dst[X]>>8 )&0xff)) + (sa * sg)) >> 8);
			db = (uint8)(( (da * ((dst[X]	 )&0xff)) + (sa * sb)) >> 8);

			// pack pixel
			dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}
//=============================================================================================================

void Drawer::blit_alpha_const (uint8 *srcPixels, uint8 *dstPixels, int alpha, int width, int height, int srcPitch, int dstPitch)
{
	uint8 sr,sg,sb,sa;
	uint8 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;

		for (int X=0; X<width; X++)
		{
			// extract source channels
			sa = (uint8) alpha;
			sr = (uint8)(src[X] >> 16);
			sg = (uint8)(src[X] >> 8);
			sb = (uint8)(src[X]);
			
			// extract dest channels
			da = (uint8)(0xff - sa);
			dr = (uint8)(( (da * ((dst[X]>>16)&0xff)) + (sa * sr)) >> 8);
			dg = (uint8)(( (da * ((dst[X]>>8 )&0xff)) + (sa * sg)) >> 8);
			db = (uint8)(( (da * ((dst[X]	 )&0xff)) + (sa * sb)) >> 8);

			// pack pixel
			dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}
//=============================================================================================================

void Drawer::blit_colorkey(uint8 *srcPixels, uint8 *dstPixels, uint32 colorkey, int width, int height, int srcPitch, int dstPitch)
{
	uint32 *src;
	uint32 *dst;

	for (int H=0; H<height; H++)
	{
		src = (uint32*) srcPixels;
		dst = (uint32*) dstPixels;

		for (int W=0; W<width; W++)
		{
			if ((src[W]&0x00ffffff) != (colorkey&0x00ffffff)) src[W] = dst[W];
		}
		srcPixels += srcPitch;
		dstPixels += dstPitch;
	}	
}

//=============================================================================================================

void Drawer::copy(uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch)
{
	for (int H = 0; H < height; H++) 
	{
		memcpy(dst, src, width * 4);
		src += srcPitch;
		dst += dstPitch;
	}
}

//=============================================================================================================

void Drawer::clear_argb(uint8 *dstPixels, int width, int height, int dstPitch)
{

	for (int H=0; H<height; H++)
	{	
		// clear each line
		memset(dstPixels,0, (width << 2));	
		
		// move to next
		dstPixels += dstPitch;
	}
}

//=============================================================================================================

void Drawer::clear_rgb (uint8 *dstPixels, int width, int height, int dstPitch)
{
	uint32 *dst;

	for (int H=0; H<height; H++)
	{
		
		dst = (uint32*) dstPixels;

		for (int W=0; W<width; W++)
		{
			// clear all but alpha
			dst[W] &= 0xff000000;
		}	
		// move to next line
		dstPixels += dstPitch;
	}
}

//=============================================================================================================

void Drawer::blit_saturation (uint8 *srcPixels, uint8 *dstPixels,int width, int height, int srcPitch, int dstPitch)
{

	for (int H = 0; H < height; H++)
	{
		for (int W = 0; W < width * 4; W++)
		{
			dstPixels[W] = (uint8) SLUT[srcPixels[W] + dstPixels[W]];
		}	
		
		srcPixels += srcPitch;
		dstPixels += dstPitch;
	}

}

//=============================================================================================================

void Drawer::blit_alpha_saturation (uint8 *srcPixels, uint8 *dstPixels, int width, int height, int srcPitch, int dstPitch)
{
	uint8 sr,sg,sb,sa;
	uint8 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;

		for (int X=0; X<width; X++)
		{
			// extract source channels
			sa = (uint8)(src[X] >> 24);
			sr = (uint8)(src[X] >> 16);
			sg = (uint8)(src[X] >> 8);
			sb = (uint8)(src[X]);
			
			// extract dest channels
			da = (uint8)(0xff - sa);
			dr = (uint8)SLUT[((dst[X]>>16)&0xff) + ((sa * sr) >> 8)];
			dg = (uint8)SLUT[((dst[X]>>8 )&0xff) + ((sa * sg) >> 8)];
			db = (uint8)SLUT[(dst[X] &0xff) + ((sa * sb) >> 8)];

			// pack pixel
			dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}

//=============================================================================================================

void Drawer::blit_colorkey_saturation (uint8 *srcPixels, uint8 *dstPixels, int colorkey, int width, int height, int srcPitch, int dstPitch)
{
	for (int H = 0; H < height; H++)
	{
		for (int W = 0; W < width * 4; W++)
		{
			if (dstPixels[W] != colorkey)
				dstPixels[W] = (uint8) SLUT[srcPixels[W] + dstPixels[W]];
		}	
		
		srcPixels += srcPitch;
		dstPixels += dstPitch;
	}
}

//=============================================================================================================

void Drawer::blit_alpha_const_saturation (uint8 *srcPixels, uint8 *dstPixels, int alpha, int width, int height, int srcPitch, int dstPitch)
{
	uint8 sr,sg,sb,sa;
	uint8 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;

		for (int X=0; X<width; X++)
		{
			// extract source channels
			sa = (uint8) alpha;
			sr = (uint8)(src[X] >> 16);
			sg = (uint8)(src[X] >> 8);
			sb = (uint8)(src[X]);
			
			// extract dest channels
			da = (uint8)(0xff - sa);
			dr = (uint8)SLUT[((dst[X]>>16)&0xff) + ((sa * sr) >> 8)];
			dg = (uint8)SLUT[((dst[X]>>8 )&0xff) + ((sa * sg) >> 8)];
			db = (uint8)SLUT[(dst[X] &0xff) + ((sa * sb) >> 8)];

			// pack pixel
			dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}

//=============================================================================================================

void Drawer::blit_alpha_const_colorkey (uint8 *srcPixels, uint8 *dstPixels, int alpha, uint32 colorkey, int width, int height, int srcPitch, int dstPitch)
{
	uint8 sr,sg,sb,sa;
	uint8 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;

		for (int X=0; X<width; X++)
		{
			if (src[X] != colorkey)
			{
				// extract source channels
				sa = (uint8) alpha;
				sr = (uint8)(src[X] >> 16);
				sg = (uint8)(src[X] >> 8);
				sb = (uint8)(src[X]);
				
				// extract dest channels
				da = (uint8)(0xff - sa);
				dr = (uint8)(( (da * ((dst[X]>>16)&0xff)) + (sa * sr)) >> 8);
				dg = (uint8)(( (da * ((dst[X]>>8 )&0xff)) + (sa * sg)) >> 8);
				db = (uint8)(( (da * ((dst[X]	 )&0xff)) + (sa * sb)) >> 8);

				// pack pixel
				dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
			}
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}

//=============================================================================================================

void Drawer::blit_alpha_colorkey (uint8 *srcPixels, uint8 *dstPixels, uint32 colorkey, int width, int height, int srcPitch, int dstPitch)
{
	uint8 sr,sg,sb,sa;
	uint8 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;

		for (int X=0; X<width; X++)
		{
			if (src[X] != colorkey)
			{
				// extract source channels
				sa = (uint8)(src[X] >> 24);
				sr = (uint8)(src[X] >> 16);
				sg = (uint8)(src[X] >> 8);
				sb = (uint8)(src[X]);
				
				// extract dest channels
				da = (uint8)(0xff - sa);
				dr = (uint8)(( (da * ((dst[X]>>16)&0xff)) + (sa * sr)) >> 8);
				dg = (uint8)(( (da * ((dst[X]>>8 )&0xff)) + (sa * sg)) >> 8);
				db = (uint8)(( (da * ((dst[X]	 )&0xff)) + (sa * sb)) >> 8);

				// pack pixel
				dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
			}
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}
