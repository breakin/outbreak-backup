#include <helper/clock.h>
#include <stdio.h>
#include <conio.h>

/*
  Create: Breakin
  Comment:
    A program that uses the Clock-class.
    Resets time after each second.
*/

using namespace Helper;

void main(void) {
	
	Clock a;

	while (!kbhit()) {
		printf("%f\n", a.get());

		if (a.get()>1.0) a.reset();
	}
}