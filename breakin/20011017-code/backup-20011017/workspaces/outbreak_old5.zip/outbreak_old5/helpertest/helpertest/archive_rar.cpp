#include <windows.h>
#include <helper/core/exception.h>
#include <helper/core/archive/archivedirectory.h>
#include <helper/core/archive/archiverar.h>

using namespace Helper;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevinst, LPSTR cmdline, int showstate) {

	try {

		ArchiveRAR input("target/archive_rar/test.rar");
		ArchiveDirectory output("target/archive_rar");

		Blob a=input.getFile("a.txt").get();
		output.createFile("a.txt", a);
	}

	catch (Helper::Exception &e) {
		MessageBox(NULL, e.what(), "Helper::Exception", MB_OK);
	}

	return true;
}