#include <windows.h>
#include <helper/core/exception.h>
#include <helper/core/imagetool/imagetool.h>
#include <helper/core/archive/archivedirectory.h>
#include <helper/core/archive/archiverar.h>

using namespace Helper;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevinst, LPSTR cmdline, int showstate) {

	try {

		ImageTool it;
		ArchiveDirectory output("target/imagetool");
		ArchiveRAR input("target/imagetool/images.rar");

		Image32 inputImage=it.decode(input.getFile("test24.jpg"));
		output.createFile("out_test24.jpg.tga", it.encode(inputImage, "tga"));
		output.createFile("out_test24.jpg.jpg", it.encode(inputImage, "jpg"));

		inputImage=it.decode(input.getFile("testgrey.jpg"));
		output.createFile("out_testgrey.jpg.tga", it.encode(inputImage, "tga"));
		output.createFile("out_testgrey.jpg.jpg", it.encode(inputImage, "jpg"));
	}

	catch (Helper::Exception &e) {
		MessageBox(NULL, e.what(), "Helper::Exception", MB_OK);
	}

	return true;
}