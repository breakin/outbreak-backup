#pragma warning(disable:4786)
#include <helper\helper.h>
#include <helper\directx\dx_device2d.h>
#include <helper\win32\win32_device2d.h>
#include <helper\core\clock.h>
#include <e3d_scene.h>
#include <loader\3ds\e3d_3ds.h>
#include <math\e3d_vector.h>
#include <memory\pool\e3d_vtxpool.h>
#include <memory\pool\e3d_cornerpool.h>
#include <material\e3d_materialmanager.h>
#include <e3d_sysdef.h>
#include <iostream>
#include <e3d_exception.h>
#include <e3d_viewport.h>

//#define MIPPLE_MOPPLE_VIEWPORT

using namespace Helper;

void main() {

	try {
		
		Eternity::CViewPort viewPort;
		ImageDrawer			drawer;
		Msg					msg;
		DirectDrawDevice2D	device;
		Clock               clock;

	//	Win32Device2D	device;
		double				frames = 0;
		float				fr = 1.2f;
		
		// Eternity Objects
		Eternity::CMaterialManager mh;
		Eternity::CScene		scene;
		Eternity::CScene		scene2;
		Eternity::CLoader_3DS	loader3DS;
		
		// config device
		device.config("width","320");
		device.config("height","240");
		device.config("fullscreen","false");
		device.config("title","Eternity 3D Engine");
		device.config("bpp","32");
		
		// open device
		device.open();
		
		// load 3d scene
		//loader3DS.loadScene("max_ship.3ds",scene);
		loader3DS.loadScene("scene.3ds",scene);

		// prepare material manager for the scene
		Eternity::CMaterialFlat flatMaterial("flat");
		flatMaterial.setOwner(Eternity::CResource::OWNER_EXTERNAL);
		mh.addMaterial(flatMaterial);
		mh.rebuildMaterials(scene);
		

		bool frwd = true;
		float32 deg = 0.0f;
		bool run = true;
		bool done = false;

		Clock timer;
		
		// Get backbuffer
		BaseImage32 &backbuffer = device.getBackBuffer();
		
		// Widescreen
		viewPort.set((240-199)/2, 0, 320, 200);
		
		while (run) {
			
			if (device.getMessage(msg)) {

				switch (msg.message) {

				case Msg::MSG_KEYDOWN:
				case Msg::MSG_CLOSE:
				run = false;
				break;
				}
			}
			
			// clear facelist
			mh.clearFaceLists();

			// transform and update keyframing
			scene.updateKeyFraming(clock.get()*30);
			scene.transform();

			if (frames>10) mh.render(backbuffer, viewPort);
			
			device.update();
			
			drawer.clear(backbuffer,backbuffer.getArea());

			// merge pools
			Eternity::Global::vertexPool.merge();
			Eternity::Global::cornerPool.merge();
			
			frames += 1.0;
		}
			

		double stop = timer.get();
		char fps[128];
		sprintf (fps,"FPS = %.4f",frames / stop);
		MessageBox(NULL,fps,"FPS Meter",MB_OK);

	} catch (std::exception &e) {

		MessageBox(NULL,e.what(),"Eternity Exception",MB_OK);
	}
}
