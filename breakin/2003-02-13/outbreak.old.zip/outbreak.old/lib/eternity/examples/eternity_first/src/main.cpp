#pragma warning(disable:4786)
#include <e3d_scene.h>
#include <loader\3ds\e3d_3ds.h>
#include <math\e3d_vector.h>
#include <memory\pool\e3d_vtxpool.h>
#include <memory\pool\e3d_cornerpool.h>
#include <rasterizer\e3d_rasterizer.h>
#include <e3d_defs.h>
#include <helper\helper.h>
#include <helper\directx\dx_device2d.h>
#include <helper\core\clock.h>
#include <iostream>

using namespace Helper;

void main() {

	// Helper Objects
	ImageDrawer			drawer;
	Msg					msg;
	Image32				backbuffer;
	DirectDrawDevice2D	device;
	
	// Eternity Objects
	Eternity::CRasterizer	rasterizer;
	Eternity::CScene		scene;
	Eternity::CScene		scene2;
	Eternity::CLoader_3DS	loader3DS;
	Eternity::CFaceLists	faceLists;
	Eternity::CCamera		camera;
	

	// setup camera
	camera.setFOV((60.0 * Eternity::E3D_PI / 180.0));
	camera.setPosition(Eternity::CVector3d(0,0,-500));
	camera.setTarget(Eternity::CVector3d(0,0,10));
	camera.setRoll(Eternity::E3D_PI);
	camera.setOwner(camera.OWNER_EXTERNAL);

	// config device
	device.config("width","512");
	device.config("height","384");
	device.config("fullscreen","false");
	device.config("title","Eternity 3D Engine");
	device.config("bpp","32");
	
	// create backbuffer
	backbuffer.resize(512,384);

	// open device
	device.open();
	
	// load 3d scene
//	loader3DS.loadScene("d:\\prog\\sources\\a3d_research\\bin\\boom.3ds",scene);
	loader3DS.loadScene("boom.3ds",scene);
//	loader3DS.loadScene("p1.3ds",scene2);

	Eternity::CMesh *mesh;;// = scene2.getMesh("Torus01");
		
	if (mesh != mesh) {

		MessageBox(NULL,"FOUND OBJECT!","3DINFO",MB_OK);
		mesh->setOwner(Eternity::CObject::OWNER_EXTERNAL);
		mesh->setPosition(Eternity::CVector3d(-22,0,80));
		mesh->getBSphere().setClipMask(0x7fffffff);
		Eternity::CMesh *knot = scene.getMesh("Torus01");
		knot->addChild(mesh);
	}

	// add camera to scene
	scene.addCamera(&camera);

	Eternity::CMatrix4x4 &cmat = camera.getMatrix();

	bool run = true;
	float32 deg = 0;

//	timer.startTime();
	double frames = 0;

	Clock timer;
	Eternity::CMatrix4x4 matRot;
	Eternity::CMatrix4x4 matTrans;

	while (run) {
		
		deg = timer.get();
		
		//camera.setFOV(90 + cos(timer.get() / 10));
		camera.setRoll(deg);
		camera.setTarget(Eternity::CVector3d(100 * sin(timer.get()),0,10));
	//	camera.setTarget(Eternity::CVector3d(sinf(deg) * 50,cos(deg)* 1050.0,500));
		camera.setPosition(Eternity::CVector3d(0,100 + sin(deg*2) * 50,-400 + sin(deg*2) * 200));

		if (device.getMessage(msg)) {

			switch (msg.message) {

			case Msg::MSG_KEYDOWN:
			case Msg::MSG_CLOSE:
			run = false;
			break;
			}
		}
		
		// transform scene
		scene.transform(faceLists,0);
		rasterizer.render(faceLists,backbuffer);
		device.update(backbuffer);
		
		drawer.clear(backbuffer,backbuffer.getArea());
		// clear facelist
		faceLists.faces.clear();

		// merge pools
		Eternity::Global::vertexPool.merge();
		Eternity::Global::cornerPool.merge();
		
		frames += 1.0;
	}
		
	double stop = timer.get();

	std::cout << "FPS = " << frames / stop;
//	catch (Exception &e) {

//		MessageBox(NULL,e.what(),"Eternity Exception!",MB_OK);
//	}

//	delete mesh;
}
