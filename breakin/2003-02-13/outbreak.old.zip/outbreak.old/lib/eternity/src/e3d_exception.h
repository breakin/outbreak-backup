#ifndef __ETERNITY_EXCEPTION_INC__
#define __ETERNITY_EXCEPTION_INC__

#include <helper\core\exception.h>
#include <string>
#include <stdarg.h>

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CEternityException
	 * @brief	Eternity unique exception
	 * @author	Peter Nordlander
	 * @date	2001-06-05
	 */
	
	const char EXCEPTION_PREFIX[] = "[E3D] ";
	
	class CException : public Helper::Exception 
	{
	public:

		CException(const char msg[],...);
	};
}

#endif
