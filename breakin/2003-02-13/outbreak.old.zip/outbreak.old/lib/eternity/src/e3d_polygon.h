#ifndef __ETERNITY_POLYGON_INC__
#define __ETERNITY_POLYGON_INC__

#include "e_vertex.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CFace
	 * @brief	represents a face, belonging to a TriMesh object in scene
	 * @author	Peter Nordlander
	 * @date	2001-05-30
	 */

	struct CFace
	{
	
		enum {

			VISIBLE = 0x01,
			CLIPPED	= 0x02,
		};

		uint32	 m_flags;
		uint32	 m_color;
		uint32	 m_numBaseCorners;
		uint32	 m_numClipCorners;
		CCorner	 m_base[3];
		CCorner* m_clip;
	};
}

#endif
