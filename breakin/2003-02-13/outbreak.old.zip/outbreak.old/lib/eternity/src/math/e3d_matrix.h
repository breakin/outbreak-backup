#ifndef __ETERNITY_MATRIX4X4_INC__
#define __ETERNITY_MATRIX4X4_INC__

#include <cstring>
#include <helper\core\typedefs.h>
#include "..\e3d_sysdef.h"
#include "e3d_vector.h"
//#include <cstdlib>

using namespace Helper;

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CMatrix4x4
	 * @brief	Defines an infninite plane in space
	 * @author	Peter Nordlander
	 * @date	2001-05-23
	 */
		
	class CMatrix4x4
	{
	private:
		
		static CMatrix4x4	m_retMatrix[8];	// matrices used for returned data
		static CVector3d	m_retVector;	// vector used for referential return values
		static int			m_retCurrent;	// currently "free" matrix to use as return value
		
		union 
		{
			struct 
			{
				float32 _11,_12,_13,_14;
				float32 _31,_32,_33,_34;
				float32 _21,_22,_23,_24;
				float32 _41,_42,_43,_44;
			};
			
			struct 
			{
				CVector3d m_row1;
				CVector3d m_row2;
				CVector3d m_row3;
				CVector3d m_row4;
			};
		
			float32 m_rows[4][4];
			float32 m_data[16];
		};

	public:

		CMatrix4x4();			
	
		// zero matrix data
		void zero();
		
		// make predefined matrice transformations
		void makeIdentity();
		void makeScale(float32 sx, float32 sy, float32 sz);
		void makeRotX(float32 ang);
		void makeRotY(float32 ang);
		void makeRotZ(float32 ang);
		void makeViewLookAt(const CVector3d &pos, const CVector3d &lookAt, float32 roll);
		void makeViewDirection(const CVector3d &pos, const CVector3d &direction, float32 roll);		
		void makeRotXYZ(float32 xang, float32 yang, float32 zang);
		
		// assignment overload
		const CMatrix4x4& operator = (const CMatrix4x4 &other);
		
		// return the matrix inverse
		const CMatrix4x4& operator - () const;
		
		// aritmethic overloads vector mul matrix
		const CVector3d&  operator * (const CVector3d  &other) const;
		
		// aritmethic overloads		
		const CMatrix4x4& operator * (const CMatrix4x4 &other) const;
		const CMatrix4x4& operator - (const CMatrix4x4 &other) const;
		const CMatrix4x4& operator + (const CMatrix4x4 &other) const;
		const CMatrix4x4& operator / (const CMatrix4x4 &other) const;
		
		// indexation operator
		const float32 * const operator [] (int indexRow) const;
		float32 * operator [] (int indexRow);

		// self modifying operators
		void operator *= (const CMatrix4x4 &other);
		void operator += (const CMatrix4x4 &other);
		void operator -= (const CMatrix4x4 &other);
		void operator /= (const CMatrix4x4 &other);

		// return transpose and inverse of matrix, it's inverse
		const CMatrix4x4& getTranspose() const;
		const CMatrix4x4& getGaussInverse() const {};

		// get row vector[n]
		const CVector3d& getRow(int n) const;
		CVector3d& getRow(int n);
		
		// friend functions
		friend CVector3d& operator*(const CVector3d &vector, const CMatrix4x4 &matrix);

	private:

		// return index of current free matrix and sets index to next 
		int getReturnIndex() const {
			
			int current = m_retCurrent;
			m_retCurrent = ((m_retCurrent + 1) % 8);
			return current;
		}
	};

// ======================================================================================================

E3D_INLINE CMatrix4x4::CMatrix4x4() {

	zero();
	makeIdentity();
}

// ======================================================================================================

E3D_INLINE void CMatrix4x4::zero () {
	
	uint8 *dst = (uint8*)m_data;
	
	_asm {
	
		pxor mm0,mm0
		mov edi, dst
		movq [edi   ], mm0
		movq [edi+ 8], mm0
		movq [edi+16], mm0
		movq [edi+24], mm0
		movq [edi+32], mm0
		movq [edi+40], mm0
		movq [edi+48], mm0
		movq [edi+56], mm0
		emms
	}
}

// ======================================================================================================

E3D_INLINE void CMatrix4x4::makeIdentity() {

	_11 = _22 = _33 = _44 = 1.0;
}

//======================================================================================================

E3D_INLINE void CMatrix4x4::makeScale(float32 sx, float32 sy, float32 sz) {

	_11 = sx;
	_22 = sy;
	_33 = sz;
}

//======================================================================================================

E3D_INLINE void CMatrix4x4::makeRotX(float32 pitch) {

	_22 = cosf(pitch); 
	_32 = sinf(pitch);
	_23 = -sinf(pitch);
	_33 = cosf(pitch);
}

//======================================================================================================

E3D_INLINE void CMatrix4x4::makeRotY(float32 yaw) {

	_11 = cosf(yaw);
	_31 = -sinf(yaw);
	_13 = sinf(yaw);
	_33 = cosf(yaw);
}

//======================================================================================================

E3D_INLINE void CMatrix4x4::makeRotZ(float32 roll) {

	_11 = cosf(roll);
	_21 = -sinf(roll);
	_12 = sinf(roll);
	_22 = cosf(roll);
}

//======================================================================================================

E3D_INLINE void CMatrix4x4::makeRotXYZ(float32 pitch, float32 yaw, float32 roll) {

	CMatrix4x4 a;
	CMatrix4x4 b;
	CMatrix4x4 c;
	
	a.makeRotX(pitch);
	b.makeRotY(yaw);
	c.makeRotZ(roll);

	*this = a * b * c;
}

//======================================================================================================

E3D_INLINE void CMatrix4x4::makeViewLookAt(const CVector3d &pos, const CVector3d &target, float32 rollAng) {
	
	CMatrix4x4 a,b;

	// genereate y vector by rotating 0,1 round the z axis by roll deg.
	makeIdentity();

	// y rotated round z axis (roll)
	CVector3d y(sinf(rollAng),cosf(rollAng),0);
	
	// calculate look at
	CVector3d z = (target - pos);
	
	// z normalized
	z.normalize();

	// create x vector by taking the cross produkt betw. y and z
	CVector3d x = (y % z);
	
	// normalize x vector
	x.normalize();

	// correct the y vector to get mor accurat result
	y = (x % z);

	// normalize y vector, just in case
	y.normalize();
	
	// create matrix, free transpose by just setting the row vectors
	_11 = x.getX();
	_21 = x.getY();
	_31 = x.getZ();
	_12 = y.getX();
	_22 = y.getY();
	_32 = y.getZ();
	_13 = z.getX();
	_23 = z.getY();
	_33 = z.getZ();

	// zero translation 
	m_row4.make(0,0,0);

	b.m_row4 = pos * -1;
	
	// mlutiply negated translation with camera rotation
	(*this) = b * (*this);
}

//======================================================================================================

E3D_INLINE void CMatrix4x4::makeViewDirection(const CVector3d &pos, const CVector3d &target, float32 rollAng) {
	
	CMatrix4x4 a,b;

	// genereate y vector by rotating 0,1 round the z axis by roll deg.
	makeIdentity();

	// y rotated round z axis (roll)
	CVector3d y(sinf(rollAng),cosf(rollAng),0);
	
	// calculate direction vector
	CVector3d z = target;
	
	// z normalized
	z.normalize();

	// create x vector by taking the cross produkt betw. y and z
	CVector3d x = (y % z);
	
	// normalize x vector
	x.normalize();

	// correct the y vector to get mor accurat result
	y = (x % z);

	// normalize y vector, just in case
	y.normalize();
	
	// create matrix, free transpose by just setting the row vectors
	_11 = x.getX();
	_21 = x.getY();
	_31 = x.getZ();
	_12 = y.getX();
	_22 = y.getY();
	_32 = y.getZ();
	_13 = z.getX();
	_23 = z.getY();
	_33 = z.getZ();
	
	// zero translation 
	m_row4.make(0,0,0);

	b.m_row4 = pos * -1;
	
	// mlutiply negated translation with camera rotation
	(*this) = b * (*this);
}

//======================================================================================================

E3D_INLINE const CMatrix4x4& CMatrix4x4::operator * (const CMatrix4x4 &m) const {

	int returnIndex = getReturnIndex();

	// multiply all rows and cols.
	m_retMatrix[returnIndex]._11 = (_11 * m._11) + (_12 * m._21) + (_13 * m._31) + (_14 * m._41); 
	m_retMatrix[returnIndex]._12 = (_11 * m._12) + (_12 * m._22) + (_13 * m._32) + (_14 * m._42); 
	m_retMatrix[returnIndex]._13 = (_11 * m._13) + (_12 * m._23) + (_13 * m._33) + (_14 * m._43); 
	m_retMatrix[returnIndex]._14 = (_11 * m._14) + (_12 * m._24) + (_13 * m._34) + (_14 * m._44); 

	m_retMatrix[returnIndex]._21 = (_21 * m._11) + (_22 * m._21) + (_23 * m._31) + (_24 * m._41);
	m_retMatrix[returnIndex]._22 = (_21 * m._12) + (_22 * m._22) + (_23 * m._32) + (_24 * m._42); 
	m_retMatrix[returnIndex]._23 = (_21 * m._13) + (_22 * m._23) + (_23 * m._33) + (_24 * m._43); 
	m_retMatrix[returnIndex]._24 = (_21 * m._14) + (_22 * m._24) + (_23 * m._34) + (_24 * m._44);

	m_retMatrix[returnIndex]._31 = (_31 * m._11) + (_32 * m._21) + (_33 * m._31) + (_34 * m._41);
	m_retMatrix[returnIndex]._32 = (_31 * m._12) + (_32 * m._22) + (_33 * m._32) + (_34 * m._42); 
	m_retMatrix[returnIndex]._33 = (_31 * m._13) + (_32 * m._23) + (_33 * m._33) + (_34 * m._43); 
	m_retMatrix[returnIndex]._34 = (_31 * m._14) + (_32 * m._24) + (_33 * m._34) + (_34 * m._44);

	m_retMatrix[returnIndex]._41 = (_41 * m._11) + (_42 * m._21) + (_43 * m._31) + (_44 * m._41);
	m_retMatrix[returnIndex]._42 = (_41 * m._12) + (_42 * m._22) + (_43 * m._32) + (_44 * m._42); 
	m_retMatrix[returnIndex]._43 = (_41 * m._13) + (_42 * m._23) + (_43 * m._33) + (_44 * m._43); 
	m_retMatrix[returnIndex]._44 = (_41 * m._14) + (_42 * m._24) + (_43 * m._34) + (_44 * m._44);
	
	// return matrix and update retCnt
	return m_retMatrix[returnIndex];
}

//======================================================================================================

E3D_INLINE const CMatrix4x4& CMatrix4x4::operator + (const CMatrix4x4 &m) const {
	
	int returnIndex = getReturnIndex();

	for (int c=0; c < 16; c++)
		m_retMatrix[returnIndex].m_data[c]= m_data[c] + m.m_data[c]; 	
	
	return m_retMatrix[returnIndex];
}

//======================================================================================================

E3D_INLINE const CMatrix4x4& CMatrix4x4::operator - (const CMatrix4x4 &m) const {

	int returnIndex = getReturnIndex();

	for (int c=0; c < 16; c++)
		m_retMatrix[returnIndex].m_data[c]= m_data[c] - m.m_data[c]; 	
	
	return m_retMatrix[returnIndex];
}

// ======================================================================================================

E3D_INLINE const CMatrix4x4& CMatrix4x4::operator / (const CMatrix4x4 &other) const {

	return m_retMatrix[getReturnIndex()];
}

//======================================================================================================

E3D_INLINE const CMatrix4x4& CMatrix4x4::operator - () const {

	return getTranspose();
}

//======================================================================================================

E3D_INLINE void CMatrix4x4::operator *= (const CMatrix4x4 &m) {

	*this = *this * m;
}

//======================================================================================================

E3D_INLINE void CMatrix4x4::operator += (const CMatrix4x4 &m) {

	*this = *this * m;
}

//======================================================================================================

E3D_INLINE void CMatrix4x4::operator -= (const CMatrix4x4 &m) {

	*this = *this * m;
}

//======================================================================================================

E3D_INLINE void CMatrix4x4::operator /= (const CMatrix4x4 &m) {

	*this = *this * m;
}

//======================================================================================================

E3D_INLINE const CMatrix4x4& CMatrix4x4::getTranspose() const {
	
	int index = getReturnIndex();
	int index2 = getReturnIndex();
	
	m_retMatrix[index].zero();
	m_retMatrix[index2].zero();

	// copy diagonal
	m_retMatrix[index]._11 = _11;
	m_retMatrix[index]._22 = _22;
	m_retMatrix[index]._33 = _33;

	// mirror matrix
	m_retMatrix[index]._13 = _31;
	m_retMatrix[index]._31 = _13;
	m_retMatrix[index]._12 = _21;
	m_retMatrix[index]._21 = _12;
	m_retMatrix[index]._32 = _23;
	m_retMatrix[index]._23 = _32;

	// inverse translation
	m_retMatrix[index2]._41 = -_41;
	m_retMatrix[index2]._42 = -_42;
	m_retMatrix[index2]._43 = -_43;
	m_retMatrix[index2]._44 = 1;
	
	return m_retMatrix[index2] * m_retMatrix[index];
}

//======================================================================================================

E3D_INLINE const CVector3d&  CMatrix4x4::operator * (const CVector3d  &vector) const {

	m_retVector.x = vector.x * _11 + vector.y * _21 + vector.z * _31 + _41;
	m_retVector.y = vector.x * _12 + vector.y * _22 + vector.z * _32 + _42;
	m_retVector.z = vector.x * _13 + vector.y * _23 + vector.z * _33 + _43;

	return m_retVector;
}

//======================================================================================================

E3D_INLINE CVector3d& operator * (const CVector3d &vector, const CMatrix4x4 &matrix) {

	static CVector3d retVector;
//	return CVector3d(
	retVector.x = vector.x * matrix._11 + vector.y * matrix._21 + vector.z * matrix._31 + matrix._41;
	retVector.y = vector.x * matrix._12 + vector.y * matrix._22 + vector.z * matrix._32 + matrix._42;
	retVector.z = vector.x * matrix._13 + vector.y * matrix._23 + vector.z * matrix._33 + matrix._43;
//		);
	return retVector;
}

//======================================================================================================

E3D_INLINE const float32 * const CMatrix4x4::operator [] (int indexRow) const {

	return m_data + indexRow * 4;
}


//======================================================================================================

E3D_INLINE float32 * CMatrix4x4::operator [] (int indexRow) {

	return m_data + indexRow * 4;
}

//======================================================================================================

E3D_INLINE const CVector3d& CMatrix4x4::getRow(int n) const {

	return (CVector3d&)(m_data[n * 4]);	
}

//======================================================================================================

E3D_INLINE CVector3d& CMatrix4x4::getRow(int n) {

	return (CVector3d&)(m_data[n * 4]);	
}

//======================================================================================================

E3D_INLINE const CMatrix4x4& CMatrix4x4::operator = (const CMatrix4x4 &other) {

	void *dst = (void*)m_data;
	void *src = (void*)other.m_data;

	_asm {
		
		mov		esi, src
		mov		edi, dst
		movq	mm0,[esi     ]
		movq	mm1,[esi +  8]
		movq	mm2,[esi + 16]
		movq	mm3,[esi + 24]
		movq	mm4,[esi + 32]
		movq	mm5,[esi + 40]
		movq	mm6,[esi + 48]		
		movq	mm7,[esi + 56]
		movq	[edi	 ], mm0
		movq	[edi +  8], mm1
		movq	[edi + 16], mm2 
		movq	[edi + 24], mm3
		movq	[edi + 32], mm4
		movq	[edi + 40], mm5
		movq	[edi + 48],	mm6	
		movq	[edi + 56], mm7	
		emms
	}
	
	return *this;
}

//======================================================================================================

} // end namsspace

#endif
