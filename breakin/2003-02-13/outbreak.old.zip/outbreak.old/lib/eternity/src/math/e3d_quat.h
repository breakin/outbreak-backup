#ifndef __ETERNITY_MATH_QUATERNION_INC__
#define __ETERNITY_MATH_QUATERNION_INC__

#include <helper\core\typedefs.h>
#include "..\e3d_sysdef.h"
#include "e3d_vector.h"
#include "e3d_matrix.h"

using namespace Helper;

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CQuaternion
	 * @brief	Represent a quaternion
	 * @author	Peter Nordlander
	 * @date	2001-06-25
	 */
	
	class CQuaternion
	{
	public:
		
		CQuaternion(const float32 x, const float32 y, const float32 z, const float32 w);
		CQuaternion(const CVector3d axis, const float32 angle);
		CQuaternion() {};

		// get/set axis of rotation vector
		void setAxisOfRotation(const CVector3d &axis);
		CVector3d getAxisOfRotation() const;

		// set/get angle of rotation round current axis
		void setAngleOfRotation(const float32 theta);
		float32	getAngleOfRotation() const;

		// convert quat<-> matrix
		void convertFromMatrix(const CMatrix4x4 &mat);
		CMatrix4x4 convertToMatrix();
		
		// interpolate from this to other, and return Quat at f(t).
		CQuaternion interpolate(const CQuaternion &other, const float32 t);

		// operator overloads
		CQuaternion operator * (const CQuaternion &other) const;
		CQuaternion operator / (const CQuaternion &other) const;
		CQuaternion operator + (const CQuaternion &other) const;
		CQuaternion operator - (const CQuaternion &other) const;

		// self modifying operators
		void operator *= (const CQuaternion &other);
		void operator += (const CQuaternion &other);
		void operator -= (const CQuaternion &other);
		void operator /= (const CQuaternion &other);

	private:
		
		float32 w;		///< Quat Angle of rotation
		float32 x,y,z;	///< Quat (x,y,x)components
	};

//=============================================================================================

E3D_INLINE CQuaternion::CQuaternion(const float32 x, const float32 y, const float32 z, const float32 w) {


}

//=============================================================================================

E3D_INLINE CQuaternion::CQuaternion(const CVector3d axis, const float32 angle) {

	setAxisOfRotation(axis);
//	setAngleOfRotatation(angle);
}

//=============================================================================================

E3D_INLINE void CQuaternion::setAxisOfRotation(const CVector3d &axis) {
	
	float32 sa = (getAngleOfRotation() / 2);

//	x = axis[0];
//	y = axis[1];
//	z = axis[2];
}

//=============================================================================================

E3D_INLINE CVector3d CQuaternion::getAxisOfRotation() const {

	float angle = getAngleOfRotation() / 2;
	return CVector3d( x / sinf(angle), y / sinf(angle), z / sinf(angle));
}


//=============================================================================================

E3D_INLINE void CQuaternion::setAngleOfRotation(const float32 theta) {

	w = cosf(theta/2);
}

//=============================================================================================

E3D_INLINE float32	CQuaternion::getAngleOfRotation() const {

	return 2 * acosf(w);
}

//=============================================================================================

E3D_INLINE void CQuaternion::convertFromMatrix(const CMatrix4x4 &mat) {

}

//=============================================================================================

E3D_INLINE CMatrix4x4 CQuaternion::convertToMatrix() {

}

//=============================================================================================

E3D_INLINE CQuaternion CQuaternion::interpolate(const CQuaternion &other, const float32 t) {

}

//=============================================================================================

E3D_INLINE CQuaternion CQuaternion::operator * (const CQuaternion &other) const {

}

//=============================================================================================

E3D_INLINE CQuaternion CQuaternion::operator / (const CQuaternion &other) const {

}

//=============================================================================================

E3D_INLINE CQuaternion CQuaternion::operator + (const CQuaternion &other) const {

}

//=============================================================================================

E3D_INLINE CQuaternion CQuaternion::operator - (const CQuaternion &other) const {

}

//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================
//=============================================================================================

}

#endif