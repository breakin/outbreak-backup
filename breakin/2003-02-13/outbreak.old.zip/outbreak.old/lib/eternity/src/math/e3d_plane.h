#ifndef __ETERNITY_PLANE_INC__
#define __ETERNITY_PLANE_INC__

#include <helper\core\typedefs.h>
#include "e3d_vector.h"

using namespace Helper;

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CPlane
	 * @brief	Defines an infninite plane in space
	 * @author	Peter Nordlander
	 * @date	2001-05-23
	 */

namespace Eternity {

	class CPlane
	{
	private:
		
		CVector3d	m_normal;	///< normal to plane
		float32		m_d;		///< distance to origo

	public:

		// contructors
		CPlane(float32 a=0, float32 b=0, float32 c=0, float32 d=0) : m_normal(a,b,c), m_d(d) {}
		CPlane(const CVector3d &p1,const CVector3d &p2,const CVector3d &p3);
		CPlane(const CVector3d &n, float32 d);

		// construct and calculate plane eq. based on differnet input data
		void make(float32 a, float32 b, float32 c, float32 d);
		void make(const CVector3d &normal, float32 d);	
		void make(const CVector3d &p1,const CVector3d &p2,const CVector3d &p3);
		
		// set plane components
		void setA(float32 a) { m_normal.setX(a); }
		void setB(float32 b) { m_normal.setY(b); }
		void setC(float32 c) { m_normal.setZ(c); }
		void setD(float32 d) { m_d = d;}
		
		// get plane normal
		const CVector3d& getNormal() const;
		
		// get plane components
		float32 getA() const { return m_normal.getX(); }
		float32 getB() const { return m_normal.getY(); }
		float32 getC() const { return m_normal.getZ(); }
		float32 getD() const { return m_d; };

		// get point/ray distances from plane 
		// negative result = behind plane
		// positiv result = in front of plane
		float32 getPointDistance(const CVector3d &v) const;
		float32 getRayIntersection(const CVector3d &p, const CVector3d &d) const;	
	};
}

#endif
