#ifndef __ETERNITY_FPU_INC__
#define __ETERNITY_FPU_INC__

namespace Eternity {

const int32 fixedMul = 65536;

#define E3D_FLOAT_TO_INT(a, b)\
	__asm {	fld		a}\
	__asm { fistp	b}\


#define E3D_FLOAT_TO_FIXED(a, b)\
	__asm { fld		a	 }\
	__asm { fmul	fixedMul}\
	__asm { fistp	b	 } \

#define E3D_FLOAT_MUL(a, b)

#define E3D_FLOAT_DIV(a, b)

}

#endif