#include "e3d_plane.h"

using namespace Eternity;

//=======================================================================================

void CPlane::make(float32 a, float32 b, float32 c, float32 d) {

	m_normal = CVector3d(a,b,c);
	m_normal.normalize();
	m_d = d;
}

//=======================================================================================

void CPlane::make(const CVector3d &p1,const CVector3d &p2,const CVector3d &p3) {

	m_normal = (p2 - p1) % (p3 - p1);
	m_normal.normalize();
	m_d = p1 * m_normal;
}

//=======================================================================================

void CPlane::make(const CVector3d &normal, float32 d) {

	m_normal = normal;
	m_normal.normalize();
	m_d = d;
}

//=======================================================================================

float32 CPlane::getPointDistance(const CVector3d &v) const {

	return (v * m_normal) - m_d;
}

//=======================================================================================

float32 CPlane::getRayIntersection(const CVector3d &p, const CVector3d &d) const {
	
	float32 cosAlpha = d * m_normal;

	// check if ray never intersects (cos = 0)
	if (cosAlpha == 0)
		return -1.0f;

	return -(p * m_normal) / cosAlpha;
}

//=======================================================================================
