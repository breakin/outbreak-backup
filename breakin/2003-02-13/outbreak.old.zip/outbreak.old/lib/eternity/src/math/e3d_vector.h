#ifndef __ETERNITY_VECTOR_INC__
#define __ETERNITY_VECTOR_INC__

#include <math.h>
#include <helper\core\typedefs.h>
#include "..\e3d_sysdef.h"

using namespace Helper;

namespace Eternity {
	
	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CVector3d
	 * @brief	3D Vector mathematics class
	 * @author	Peter Nordlander
	 * @date	2001-05-23
	 */
	
	// forw. declarations
	class CMatrix4x4;

	class CVector3d
	{		
	public:
	
		union {

			struct {
			
				float32	x;
				float32 y;
				float32 z;
				float32 w;
			};

			struct {

				float32 r;
				float32 g;
				float32 b;
				float32 a;
			};
		};
		
		// constructors
		explicit CVector3d (float32 x=0,float32 y=0,float32 z=0) : x(x), y(y), z(z), w(1.0f){} ;
		CVector3d (const CVector3d &init, const CVector3d &term);

		// make vector methods
		void make(float32 px, float32 py, float32 pz);
		void setX(float32 px) { x = px;}
		void setY(float32 py) { y = py;}
		void setZ(float32 pz) { z = pz;}
		void setW(float32 pw) { w = pw;}
		
		// get vector components
		float32 getX() const { return x; }
		float32 getY() const { return y; }
		float32 getZ() const { return z; }
		float32 getW() const { return w; }

		// calculates and return length of vector
		float32 getLength() const;

		// calculates and return length of vector ^2
		float32 getLengthBy2() const;

		// returns a vector with the same direction, but with length 1.0
		CVector3d getNormalized() const;
		
		// calculates and return <this> reflection vector against <normal>
		CVector3d getReflection(const CVector3d &normal) const;

		// normalizes and scales down vector to length = 1.0
		void normalize();

		// overloaded self modified operators
		void operator += (const CVector3d &other);
		void operator -= (const CVector3d &other);
		void operator /= (const CVector3d &other);
		void operator %= (const CVector3d &other);
		void operator *= (const float32 scalar);

		// operator[] - returns the vector component [1] - x, [2] - y, [3] - z, [4] - w
		float32& operator[] (int i);

		// overloaded aritmethic operators
		float32	  operator * (const CVector3d &other) const;	
		CVector3d operator - () const;
		CVector3d operator * (const float32 scalar) const;
		CVector3d operator % (const CVector3d &other) const;
		CVector3d operator / (const CVector3d &other) const;
		CVector3d operator + (const CVector3d &other) const;
		CVector3d operator - (const CVector3d &other) const;
	
		// friend functions
		friend CVector3d& operator*(const CVector3d &vector, const CMatrix4x4 &matrix);
		friend CVector3d  operator*(float32 scalar, const CVector3d &v);
		friend class CMatrix4x4;
	};


// ====================================================================================================

E3D_INLINE CVector3d CVector3d::getReflection(const CVector3d &normal) const {
	
	return ((normal * 2) % (*this % normal)) - *this;
}
// ====================================================================================================

E3D_INLINE CVector3d::CVector3d (const CVector3d &init, const CVector3d &term) {
	
	// make vector from init->term
	make(term.x - init.x, term.y - init.y, term.z - init.z);
}

// ====================================================================================================

E3D_INLINE void CVector3d::make(float px, float py, float pz) {

	x = px; y = py; z = pz;
}

// ====================================================================================================

E3D_INLINE float32 CVector3d::getLength() const {

	return (sqrtf(x * x + y * y + z * z));
}

// ====================================================================================================

E3D_INLINE float32 CVector3d::getLengthBy2() const {

	return (x * x + y * y + z * z);
}

// ====================================================================================================

E3D_INLINE CVector3d CVector3d::getNormalized() const {

	CVector3d res(*this);
	res.normalize();
	return res;
}

// ====================================================================================================

E3D_INLINE void CVector3d::normalize() {

	float l = getLength();
	x /= l;
	y /= l;
	z /= l;
}

// ====================================================================================================

E3D_INLINE CVector3d CVector3d::operator-() const {

	return CVector3d(-x,-y,-z);
}

// ====================================================================================================

E3D_INLINE CVector3d CVector3d::operator*(const float32 scalar) const {
	
	return CVector3d(x * scalar, y * scalar, z * scalar);
}

// ====================================================================================================

E3D_INLINE CVector3d CVector3d::operator%(const CVector3d &other) const {

	return CVector3d (
		y * other.z - z * other.y, 
		z * other.x - x * other.z,
		x * other.y - y * other.x );
}

// ====================================================================================================

E3D_INLINE CVector3d CVector3d::operator/(const CVector3d &other) const {
	
	return CVector3d(x / other.x, y / other.y, z / other.z);
}

// ====================================================================================================

E3D_INLINE CVector3d CVector3d::operator+(const CVector3d &other) const {

	return CVector3d(x + other.x, y + other.y, z + other.z);
}

// ====================================================================================================

E3D_INLINE CVector3d CVector3d::operator-(const CVector3d &other) const {
	
	return CVector3d(x - other.x, y - other.y, z - other.z);
}

// ====================================================================================================

E3D_INLINE void CVector3d::operator*=(const float32 scalar) {

	x*=scalar;
	y*=scalar;
	z*=scalar;
}

// ====================================================================================================

E3D_INLINE void CVector3d::operator+=(const CVector3d &other) {

	x+=other.x;
	y+=other.y;
	z+=other.z;
}

// ====================================================================================================

E3D_INLINE void CVector3d::operator-=(const CVector3d &other) {

	x-=other.x;
	y-=other.y;
	z-=other.z;
}

// ====================================================================================================

E3D_INLINE void CVector3d::operator /= (const CVector3d &other) {

	x /= other.x;
	y /= other.y;
	z /= other.z;
	w /= other.w;
}

// ====================================================================================================

E3D_INLINE void CVector3d::operator%=(const CVector3d &other) {

	make(y * other.z - z * other.y, 
		z * other.x - x * other.z, 
		x * other.y - x * other.y);
}

// ====================================================================================================

E3D_INLINE float32 CVector3d::operator*(const CVector3d &other) const {

	return x * other.x + y * other.y + z * other.z;
}

// ====================================================================================================

E3D_INLINE CVector3d operator*(float32 scalar, const CVector3d &v) {

	return CVector3d(v.x * scalar, v.y * scalar, v.z * scalar);
}

// ====================================================================================================

E3D_INLINE float32& CVector3d::operator[] (int i) {

	return *((float*)&x + i); 
}
// ====================================================================================================

} // end namespace

#endif
