#include "e3d_matrix.h"

using namespace Eternity;

CMatrix4x4	CMatrix4x4::m_retMatrix[8];
int			CMatrix4x4::m_retCurrent = 0;
CVector3d	CMatrix4x4::m_retVector;
