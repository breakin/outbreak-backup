#ifndef __ETERNITY_SCENE_INC__
#define __ETERNITY_SCENE_INC__

#include "face\e3d_face.h"
#include "object\light\e3d_light.h"
#include "object\camera\e3d_camera.h"
#include "object\mesh\e3d_mesh.h"
#include "e3d_facelists.h"
#include <list>

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CScene
	 * @brief	represents a face, belonging to a TriMesh object in scene
	 * @author	Peter Nordlander
	 * @date	2001-05-30
	 */
	
	class CScene
	{
	public:

		enum {

			OBJECT_MESH		= 0x01,
			OBJECT_LIGHT	= 0x02,
			OBJECT_CAMERA	= 0x04,
			OBJECT_ALL		= 0xff,
		};
		
		// constructor, destructor
		CScene();
		~CScene();
		
		// release and delete all object's within scene
		void release();

		// retrieve pointers to scene object lists
		std::list<CMesh*>* getMeshList();
		std::list<CLight*>* getLightList();
		std::list<CCamera*>* getCameraList();
			
		// get obj type by name
		CMesh*	getMesh(const std::string &name);
		CLight*	getLight(const std::string &name);
		CCamera* getCamera(const std::string &name);
		CObject* getObject(const std::string &name);
		
		// add object's to scene
		void addMesh(CMesh *mesh);
		void addLight(CLight *light);
		void addCamera(CCamera *camera);
		
		// remove specfic obj.types from scene. return(true - found, false - not found)
		bool removeMesh(const std::string &name);
		bool removeLight(const std::string &name);
		bool removeCamera(const std::string &name);
		bool removeObject(const std::string &name);
		
		// set active camera
		void setActiveCamera(CCamera *camera);
		CCamera* getActiveCamera();

		// transforms scene and store visible faces in a face list
		void transform();
		
		// update scene animation
		void updateKeyFraming(const float32 frameIndex);		

		// set/get lock/unlock for a specific group of objects, 
		void setCameraLock(const bool lock);
		bool getCameraLock() const;

		void setMeshLock(const bool lock);
		bool getMeshLock() const;

		void setLightLock(const bool lock);
		bool getLightLock() const;

		// lock/unlock any combination of objcets
		void setObjectLock(uint32 objEnumType, const bool lock);
		bool getObjectLock(uint32 objEnumType) const;

		// Active methods
		void setActive(const bool active=true) { m_active = active; }
		const bool getActive() { return m_active; }


	protected:
		
		// initialization, reset of scene data members
		void init();

		// create a default active camera.
		void createDefaultCamera();

		// travers the mesh and light list and unlink the <object>
		// from any object, having the <object> as a child.
		void removeFromChildren(CObject *object);
		
		// removes items from list bt their address, only to be called if
		// object actually exist in the object type's list
		void removeMesh(CMesh *mesh);
		void removeLight(CLight *light);
		void removeCamera(CCamera *camera);

		// search methods used to find named objects in scene
		CMesh* findMesh(const std::string &name);
		CLight* findLight(const std::string &name);
		CCamera* findCamera(const std::string &name);
	
		std::list<CMesh*>	m_listMesh;		///< List of Mesh objects in scene
		std::list<CLight*>	m_listLight;	///< List of Lights
		std::list<CCamera*>	m_listCamera;	///< List of Cameras
		uint32				m_frameStart;	///< Scene animation start frame
		uint32				m_frameEnd;		///< Scene animation start frame
		CCamera*			m_activeCamera;	///< Scene's currently active camera
		CCamera*			m_defaultCamera;///< Scene's default camera, set to active if no other camera is selected
		bool				m_lockCamera;	///< Cameras is not updated with kf animation if true
		bool				m_lockLight;	///< Lights is not updated with kf animation if true
		bool				m_lockMesh;		///< Meshess is not updated with kf animation if true

		bool                m_active;       ///< Is the object active?
	};

	
	// default camera settings


}

#endif
