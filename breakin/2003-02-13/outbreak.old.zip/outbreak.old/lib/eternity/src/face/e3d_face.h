#ifndef __ETERNITY_FACE_INC__
#define __ETERNITY_FACE_INC__

#include "..\e3d_vertex.h"

namespace Eternity {

	class CMaterial;

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CFace
	 * @brief	represents a face, belonging to a TriMesh object in scene
	 * @author	Peter Nordlander
	 * @date	2001-05-30
	 */

	class CFace
	{
	public:
		struct CCorner
		{
			CLumel		lumel;		///< Corner lightmap cordinates 
			CTexel		texel;		///< Corner texel corndinates
			CVertex*	vertex;		///< Corner shared vertex
		};
			
		CVector3d	normal;			///< Face normal
		bool		visible;		///< Face visible
		uint32		color;			///< Face color
		uint32		numCorners;		///< Number of corners, when clipped
		CCorner		baseCorners[3];	///< Face base corners
		CCorner*	corners;		///< Face corners after ex) clipping
		CFace*		nextFace;		///< Face pointer to next face in list 

		std::string materialName;   ///< Name of the material, alter this, np.
		CMaterial*  material;       ///< Pointer to material, do NOT set up manually

		// Constructor and destructor
		CFace();
		~CFace();
	};
}

#endif
