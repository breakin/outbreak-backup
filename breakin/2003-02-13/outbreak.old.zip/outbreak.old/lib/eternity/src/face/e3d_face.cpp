#include "e3d_face.h"

using namespace Eternity;

//===========================================================================

CFace::CFace() {

	// Set materialname to default
	materialName="default";

	// Set material pointer to NULL so it will find a new one
	material = NULL;
}

//===========================================================================

CFace::~CFace() {

}

//===========================================================================

