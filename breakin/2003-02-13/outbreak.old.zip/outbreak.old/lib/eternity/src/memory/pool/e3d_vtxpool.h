#ifndef __ETERNITY_VERTEX_POOL_INC__
#define __ETERNITY_VERTEX_POOL_INC__

#pragma warning(disable:4786)

#include "..\..\template\e3d_pool.h"
#include "..\..\e3d_vertex.h"

namespace Eternity {

	namespace Global {

		// typedef pool of class CVertex 
		// page size = 1024
		// merge padding = 32
		typedef TPool<CVertex, 1024, 32> CVertexPool;
		extern CVertexPool vertexPool;
	}
}

#endif