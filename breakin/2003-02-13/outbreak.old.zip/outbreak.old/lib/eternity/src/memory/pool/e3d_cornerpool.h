#ifndef __ETERNITY_CORNER_POOL_INC__
#define __ETERNITY_CORNER_POOL_INC__

#pragma warning(disable:4786)

#include "..\..\template\e3d_pool.h"
#include "..\..\face\e3d_face.h"

namespace Eternity {
	
	namespace Global {
		
		// typedef pool of class CCorder 
		// page size = 1024
		// merge padding = 32
		typedef TPool<CFace::CCorner,1024,32> CCornerPool;
		extern CCornerPool cornerPool;
	}
}

#endif