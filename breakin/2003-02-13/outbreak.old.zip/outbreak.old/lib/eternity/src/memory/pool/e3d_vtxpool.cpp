#include "e3d_vtxpool.h"

/**
 * Global Vertex Pool 
 */

namespace Eternity {

	namespace Global {
	
	CVertexPool vertexPool;
	}
}