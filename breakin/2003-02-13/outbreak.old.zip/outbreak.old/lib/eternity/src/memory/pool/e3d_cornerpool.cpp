#include "e3d_cornerpool.h"

/**
 * Global Face Corner Pool 
 */

namespace Eternity {

	namespace Global {
		
		CCornerPool cornerPool;
	}
}