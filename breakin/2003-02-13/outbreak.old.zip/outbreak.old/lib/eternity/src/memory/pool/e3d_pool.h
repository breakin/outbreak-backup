#ifndef __ETERNITY_VERTEXPOOL_INC__
#define __ETERNITY_VERTEXPOOL_INC__

#include "..\..\e3d_sysdef.h"
#include "..\..\e3d_types.h"
#include "..\..\e3d_vertex.h"
#include <vector>

namespace Eternity {
	
	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	TPool
	 * @brief	A Template Memory manager, handling allocation of and provides preallocated linear data of any size.
	 * @author	Peter Nordlander
	 * @date	2001-06-09
	 */
	
	template <typename T, int SIZE>
	class TPool
	{
	public:
		
		// constant defult page size
		enum {
		
			PAGE_SIZE = SIZE,
		};
		
		TPool();
		~TPool();

		// returns a linear array of [n] vertices
		T* get(int n = 1);

		// unreference and merge pages
		void merge();

		// deallocates all memory within the pool
		void release();

		// initialize Pool and setup the first page
		void init(int initPageSize = SIZE);

	private:
		
		// creates a new page 
		void newPage();
		
		struct TPage 
		{
			T*		m_data;		// array of vertices
			uint32	m_size;		// size of array, ie) amount of elements (vertices) in array
			uint32	m_next;		// next available free slot in page
		};
		
		std::vector<TPage*> m_pages;
		TPage* m_current;
	};

//==================================================================================================

template <typename T, int SIZE>
E3D_INLINE TPool<T,SIZE>::TPool() {

	init(SIZE);
}

//==================================================================================================

template <typename T, int SIZE>
E3D_INLINE TPool<T,SIZE>::~TPool() {
	
	release();
}

//==================================================================================================

template <typename T, int SIZE>
E3D_INLINE T* TPool<T,SIZE>::get(int n) {
	
	// check if there is available space in current page
	if (m_current->m_size - m_current->m_next > n) {

		m_current->m_next += n;
		return m_current->m_data + m_current->m_next - n;
	}
		
	// allocate new page, no space for linear vertices was found in current
	TPage *page = new TPage;
	page->m_size = SIZE;
	page->m_next = 0;
	page->m_data = new T[SIZE];
	m_current = page;

	// add page to list
	m_pages.push_back(page);

	// return linear array of T elements
	return m_current->m_data;
}

//==================================================================================================

template<typename T, int SIZE>
E3D_INLINE void TPool<T,SIZE>::merge() {

	int maxSize = 0;
	
	// find current frame's peeksize
	for (int n=0; n < m_pages.size(); n++) {
		
		maxSize += m_pages[n]->m_next;	
	}
	
	// check so that we never decreases page size!
	if (maxSize < PAGE_SIZE)
		maxSize = PAGE_SIZE;
	
	// merge space to a linear sized array
	init(maxSize);
}

//==================================================================================================

template<typename T, int SIZE>
E3D_INLINE void TPool<T,SIZE>::release() {

	for (int n=0; n < m_pages.size(); n++) {
		
		delete[] m_pages[n]->m_data;
		delete m_pages[n];
	}

	m_pages.clear();
}
		
//==================================================================================================

template<typename T, int SIZE>
E3D_INLINE void TPool<T,SIZE>::init(int initPageSize) {

	if (!m_pages.empty())
		release();

	TPage* page = new TPage;
	
	page->m_data = new T[initPageSize];
	page->m_size = initPageSize; 
	page->m_next = 0;

	m_current = page;
	m_pages.push_back(page);
}

//==================================================================================================

}

#endif
