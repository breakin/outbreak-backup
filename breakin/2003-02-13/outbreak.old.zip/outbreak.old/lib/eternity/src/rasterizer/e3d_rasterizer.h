#ifndef __ETERNITY_RASTERIZER_INC__
#define __ETERNITY_RASTERIZER_INC__

#include <helper\helper.h>

#include "..\e3d_facelists.h"
#include "..\e3d_viewport.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CRasterizer
	 * @brief	Component handling all graphical output/ rendering within the Eternity system.
	 * @author	Peter Nordlander
	 * @date	2001-06-19
	 */
	
	static float half=0.5f;
	inline float SUB_PIX(const float input) {
			float   retCode;

			_asm {
				fld     input
				fld     input
				fsub    dword ptr half
				frndint
				fsubp   st(1), st
				fld1
				fsubrp  st(1), st
				fstp    retCode
			}

			return retCode;
	}


	class CRasterizer {
	private:
		uint32	m_renderState;		///< Rasterizer render state

	public:

		enum {
			
			STATE_WIREFRAME = 0x01,
			STATE_FLATSHADE = 0x02,
			STATE_GOURAUDSHADE = 0x04,
		};

		void render(CViewPort &viewPort, CFaceLists &faceLists, Helper::BaseImage32 &image32);
	};
}

#endif

