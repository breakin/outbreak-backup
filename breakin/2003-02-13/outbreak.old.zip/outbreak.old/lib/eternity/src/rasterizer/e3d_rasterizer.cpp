#include "e3d_rasterizer.h"

using namespace Eternity;

//===========================================================================

void CRasterizer::render(CViewPort &viewPort, CFaceLists &faceLists, Helper::BaseImage32 &image32) {

	CFace	*face = faceLists.faces.getFirstFace();
	
	while (face != NULL) {

		face = face->nextFace;
	}
}

//===========================================================================
