#ifndef __ETERNITY_MATERIALMANAGER_INC__
#define __ETERNITY_MATERIALMANAGER_INC__

#include <vector>

#include "e3d_material.h"
#include "e3d_material_flat.h"
#include "..\e3d_facelists.h"
#include "..\e3d_viewport.h"
#include "..\e3d_scene.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CMaterialManager
	 * @brief	Material Manager
	 * @author	Albert Sandberg
	 * @date	2001-12-28
	 */
	
	class CMaterialManager {
	private:
		// Material List
		std::vector<CMaterial*> materialList;

		// Default material
		CMaterial defaultMaterial;

	protected:
	public:
		// Constructor and destructor
		CMaterialManager();
		~CMaterialManager();

		// Add / Get / Remove materials
		void addMaterial(CMaterial& material);
		CMaterial& getMaterial(const std::string& name);
		void removeMaterial(const std::string& name);

		// Clear face lists
		void clearFaceLists();

		// Rebuild facelist material pointers
		void rebuildMaterials(Eternity::CScene& scene);

		// Render, calls every materials render method
		void render(BaseImage32& dest, CViewPort& viewPort);
	};
}

#endif

