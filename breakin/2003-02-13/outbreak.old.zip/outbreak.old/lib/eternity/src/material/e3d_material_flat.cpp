#include "e3d_material_flat.h"

using namespace Eternity;


//===========================================================================

CMaterialFlat::CMaterialFlat(const std::string& newName) : CMaterial(newName) {

	// Set default color is yellow
	color = 0xff00ff;
}

//===========================================================================

CMaterialFlat::~CMaterialFlat() {

}

//===========================================================================

void CMaterialFlat::render(BaseImage32& dest, CViewPort& viewPort) {

	// Lock pixelbuffer
	uint32* destBuffer = dest.get();

	// Default material, render pixels in debug mode.
	CFace	*face = faceList.getFirstFace();

	uint32 faceNr=0;

	// Go through all faces
	while (face != NULL) {

		faceNr++;

		uint32 color = 200 - int(face->corners[0].vertex->screen.z/1000 * 127);
		color = (color<<16) | (color<<8);

		uint32 topVertex=0;

		int32 origox=0;
		int32 origoy=0;
		uint32 origoColor=0xff0000;

		// Get top coordinate
		for (uint32 i=0; i<face->numCorners; i++) { // skall b�rja p� 1!!! Bara d�r f�r origox och origoy's skull

			origox+= (160 + ((face->corners[i].vertex->screen.x * 159)>>16));
			origoy+= (120 + ((face->corners[i].vertex->screen.y * 119)>>16));

			if (face->corners[i].vertex->screen.y < face->corners[topVertex].vertex->screen.y) {
				
				// Remember top vertex
				topVertex = i;
			}
		}

		origox/=(face->numCorners);
		origoy/=(face->numCorners);

		int32 leftVertex = topVertex;
		int32 rightVertex = topVertex;
		int32 nextLeftVertex = (leftVertex + face->numCorners -1) % face->numCorners;
		int32 nextRightVertex = (rightVertex + 1) % face->numCorners;

		int32 lx  = (160<<16) + (face->corners[leftVertex].vertex->screen.x     * 159);
		int32 nlx = (160<<16) + (face->corners[nextLeftVertex].vertex->screen.x * 159);
		int32 ly  = (120<<16) + (face->corners[leftVertex].vertex->screen.y     * 119);
		int32 nly = (120<<16) + (face->corners[nextLeftVertex].vertex->screen.y * 119);

		int32 rx  = (160<<16) + (face->corners[rightVertex].vertex->screen.x     * 159);
		int32 nrx = (160<<16) + (face->corners[nextRightVertex].vertex->screen.x * 159);
		int32 ry  = (120<<16) + (face->corners[rightVertex].vertex->screen.y     * 119);
		int32 nry = (120<<16) + (face->corners[nextRightVertex].vertex->screen.y * 119);

		int32 left = lx;
		int32 right = rx;

		//int32 leftHeight = (nly - ly) >> 16;
		//int32 rightHeight = (nry - ry) >> 16;
		int32 leftHeight = (nly >> 16) - (ly >> 16);
		int32 rightHeight = (nry >> 16) - (ry >> 16);

//		if (leftHeight!=0 || rightHeight!=0) {

			// Load height
			int32 currentHeight = ly >> 16;

			// Calculate left delta
			int32 leftDelta = 0;
			if (leftHeight!=0) {
				leftDelta = (nlx - lx) / leftHeight;
			}
		
			// Calculate right delta
			int32 rightDelta = 0;
			if (rightHeight!=0) {
				rightDelta = (nrx - rx) / rightHeight;
			}

			// Loop through polygon
			while (true) {
				// Calculate smallest height
				int32 height = leftHeight;
				if (rightHeight<leftHeight) height = rightHeight;

				origoColor=0x00ff00;

				// If negative, we passed bottom and can quit easily.
				if (height < 0) break;

				origoColor=0xffffff;

				for(int i = 0; i < height; i++) {
					
					int32 x1 = left>>16;
					int32 x2 = right>>16;

					//if (x1<320 && x1>0) destBuffer[(currentHeight*320) + x1] = color;
					//if (x2<320 && x2>0) destBuffer[(currentHeight*320) + x2] = color;
					//destBuffer[(currentHeight*320) + x1] = color;
					//destBuffer[(currentHeight*320) + x2] = color;

					if (x1<x2) {
						if (x1<320 && x1>0 && x2>0 && x2<320 && currentHeight>0 && currentHeight<240) {
							for (int i=x1; i<x2; i++) destBuffer[currentHeight*320 + i] = color&0x88;
						}
					} else {
						if (x1<320 && x1>0 && x2>0 && x2<320 && currentHeight>0 && currentHeight<240) {
							for (int i=x2; i<x1; i++) destBuffer[currentHeight*320 + i] = color;
						}
					}

					currentHeight++;
					left += leftDelta;
					leftHeight--;
					right += rightDelta;
					rightHeight--;
				}

				if (!leftHeight) {

					// Load new vertices
					leftVertex = nextLeftVertex;
					nextLeftVertex = (leftVertex + face->numCorners -1) % face->numCorners;

					// Calculate new vertices
					lx = nlx;
					ly = nly;
					nlx = (160<<16) + (face->corners[nextLeftVertex].vertex->screen.x * 159);
					nly = (120<<16) + (face->corners[nextLeftVertex].vertex->screen.y * 119);

					left = lx;

					// Calculate new left height
					//leftHeight = (nly - ly) >> 16;
					leftHeight = (nly >> 16) - (ly >> 16);

					// Calculate new left delta
					leftDelta = 0;
					if (leftHeight!=0) {
						leftDelta = (nlx - lx) / leftHeight;
					}
				}

				if (!rightHeight) {

					// Load new vertices
					rightVertex = nextRightVertex;
					nextRightVertex = (rightVertex + 1) % face->numCorners;

					// Calculate new vertices
					rx = nrx;
					ry = nry;
					nrx = (160<<16) + (face->corners[nextRightVertex].vertex->screen.x * 159);
					nry = (120<<16) + (face->corners[nextRightVertex].vertex->screen.y * 119);

					right = rx;

					// Calculate new left height
					//rightHeight = (nry - ry) >> 16;
					rightHeight = (nry >> 16) - (ry >> 16);

					// Calculate new left delta
					rightDelta = 0;
					if (rightHeight!=0) {
						rightDelta = (nrx - rx) / rightHeight;
					}
				}
			}
//		}
		
		if (origox>0 && origox<320 && origoy>0 && origoy<240) {
			
			destBuffer[origoy*320+origox]=origoColor;
		}

		// Go to next face
		face = face->nextFace;
	}

	//printf("FaceNr: %d\n", faceNr);

}

//===========================================================================
