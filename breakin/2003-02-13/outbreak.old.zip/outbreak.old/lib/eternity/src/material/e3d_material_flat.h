#ifndef __ETERNITY_MATERIAL_FLAT_INC__
#define __ETERNITY_MATERIAL_FLAT_INC__

#include "e3d_material.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CMaterialFlat
	 * @brief	Material, flatmap
	 * @author	Albert Sandberg
	 * @date	2001-12-29
	 */
	
	class CMaterialFlat : public CMaterial {
	private:
	protected:
	public:
		// Constructor and destructor
		CMaterialFlat(const std::string& newName="");
		virtual ~CMaterialFlat();

		// Render flat polygon with defined color
		virtual void render(BaseImage32& dest, CViewPort& viewPort);
	};
}

#endif

