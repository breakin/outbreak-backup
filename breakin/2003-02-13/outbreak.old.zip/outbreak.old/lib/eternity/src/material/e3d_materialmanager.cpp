#include "e3d_materialmanager.h"

#include "..\e3d_exception.h"

using namespace Eternity;

//===========================================================================

CMaterialManager::CMaterialManager() {

	// Set parameters to default material
	defaultMaterial.setName("default");
	defaultMaterial.setOwner(CResource::OWNER_EXTERNAL);

	// Add default material to materiallist
	addMaterial(defaultMaterial);
}

//===========================================================================

CMaterialManager::~CMaterialManager() {

	// Delete materials
	while (!materialList.empty()) {
		
		// Remove material from list
		CMaterial* m = materialList.back();
		materialList.pop_back();

		// Delete material if owner
		if (m->getOwner() == CResource::OWNER_INTERNAL) {

			delete m;
		}
	}
}

//===========================================================================

void CMaterialManager::addMaterial(CMaterial& material) {

	// Add material to list
	materialList.push_back(&material);
}

//===========================================================================

CMaterial& CMaterialManager::getMaterial(const std::string& name) {

	// Loop through materials
	for (uint32 i=0; i<materialList.size(); i++) {
		
		// If name found, return material
		if (materialList[i]->getName() == name) {
			
			return *materialList[i];
		}
	}

	// If no material is found, throw an exception
	throw CException("MaterialManager-> Can't find material '%s' in getMaterial(name)", name.c_str());
}

//===========================================================================

void CMaterialManager::removeMaterial(const std::string& name) {

	// Loop through materials
	for (uint32 i=0; i<materialList.size(); i++) {
		
		// If name found, return material
		if (materialList[i]->getName() == name) {
			
			// Save for delete
			CMaterial* m = materialList[i];

			// Remove item
			materialList.erase(materialList.begin()+i);

			// Delete item and return
			delete m;
			return;
		}
	}
}

//===========================================================================

void CMaterialManager::clearFaceLists() {

	// Go through all materials
	for (uint32 i=0; i<materialList.size(); i++) {
		
		// Clear facelist
		materialList[i]->getFaceList().clear();
	}
}

//===========================================================================

void CMaterialManager::rebuildMaterials(Eternity::CScene& scene) {

	std::list<CMesh*>::iterator i = scene.getMeshList()->begin();

	// Go through all meshes.
	while (i != scene.getMeshList()->end()) {
		
		// Grab Facebuffer
		CFace* faces = (*i)->getFaceBuffer()->get();

		// Go through all faces
		for (uint32 f=0; f<(*i)->getFaceCount(); f++) {
			
			// Find material with the right name.
			faces[f].material = &getMaterial(faces[f].materialName);

		}


		// Jump to next mesh
		++i;
	}
}

//===========================================================================

void CMaterialManager::render(BaseImage32& dest, CViewPort& viewPort) {
	
	// Go through all materials, assume no transperacy
	for (uint32 i=0; i<materialList.size(); i++) {
		
		// Render material
		materialList[i]->render(dest, viewPort);
	}
}

//===========================================================================
