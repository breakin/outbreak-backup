#ifndef __ETERNITY_MATERIAL_INC__
#define __ETERNITY_MATERIAL_INC__

#include <helper\core\baseimage32.h>

#include "..\template\e3d_facelist.h"
#include "..\e3d_viewport.h"
#include "..\e3d_resource.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CMaterial
	 * @brief	Default material. Renders pixels at every vertex [in debug mode] just to show this really is default.
	 * @author	Albert Sandberg
	 * @date	2001-12-29
	 */
	
	class CMaterial : public CResource {
	private:
	protected:
		// Name
		std::string name;

		// Facelist, updated each frame
		CFaceList faceList;

		// Color
		uint32 color;

	public:
		// Constructor and destructor
		CMaterial(const std::string& newName="");
		virtual ~CMaterial();

		// Name methods
		virtual void setName(const std::string& newName) { name = newName; }
		virtual	std::string& getName() { return name; }

		// Facelist methods
		virtual CFaceList& getFaceList() { return faceList; }

		// Color methods
		virtual void setColor(const uint32 newColor) { color = newColor; }
		virtual uint32 getColor() { return color; }

		// Rendering method
		virtual void render(BaseImage32& dest, CViewPort& viewPort);
	};
}

#endif

