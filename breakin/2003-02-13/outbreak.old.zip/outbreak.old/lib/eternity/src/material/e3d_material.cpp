#include "e3d_material.h"

using namespace Eternity;

//===========================================================================

CMaterial::CMaterial(const std::string& newName) {

	// Set name
	setName(newName);

	// Set default color is white
	color = 0xffffff;

	// Set default owner
	setOwner(CResource::OWNER_INTERNAL);
}

//===========================================================================

CMaterial::~CMaterial() {

}

//===========================================================================

void CMaterial::render(BaseImage32& dest, CViewPort& viewPort) {

	// Lock pixelbuffer
	uint32* destBuffer = dest.get();

	// Default material, render pixels in debug mode.
	CFace	*face = faceList.getFirstFace();

	// Go through all faces
	while (face != NULL) {
	
		// Write each vertex
		for (uint32 i=0; i<face->numCorners; i++) {
			
			// Get coordinates
			int x = 160 + ((face->corners[i].vertex->screen.x*158)>>16);
			int y = 120 + ((face->corners[i].vertex->screen.y*118)>>16);
			// Write coordinate
			if ((x>0) && (x<320) && (y>0) && (y<240)) {
				destBuffer[int(y)*viewPort.getWidth() + int(x)] = color;
			} else {
				destBuffer[0] = 0xFF3333;
				destBuffer[1] = 0xFF3333;
				destBuffer[320] = 0xFF3333;
				destBuffer[321] = 0xFF3333;

				_asm { int 3 }
			}
		}

		// Go to next face
		face = face->nextFace;
	}

}

//===========================================================================
