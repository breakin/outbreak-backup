#ifndef __ETERNITY_SYSTEM_CONFIGURATION_INC__
#define __ETERNITY_SYSTEM_CONFIGURATION_INC__

// include files
#include <helper\core\typedefs.h>
#include <helper\core\debug\debug.h>
#include <helper\core\debug\assert.h>

using namespace Helper;

namespace Eternity {

//========================================================================
// Sys/OS, dependant definitions
//========================================================================

#ifdef WIN32
#define E3D_API	   __fastcall
#define E3D_INLINE __forceinline
#else 
#define E3D_API		
#define E3D_INLINE inline
#endif WIN32

//========================================================================
// Debug macro
//========================================================================
	
#define E3D_LOG Helper::Debug::logSystem
#define E3D_ASSERT DEBUG_ASSERT

//========================================================================
// Constants
//========================================================================

const float32 E3D_PI		= 3.1415926535897932384626433832795f;
const float32 E3D_TWOPI		= 6.283185307179586476925286766559f;
const float32 E3D_EPSILON	= 0.001f;
const float32 E3D_DEGTORAD	= 0.017453292519943295769236907684886f;
const float32 E3D_RADTODEG	= 57.295779513082320876798154814105f;
	
//========================================================================

} // end namespace

#endif


