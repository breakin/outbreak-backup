#ifndef __ETERNITY_FRUSTUM_INC__
#define __ETERNITY_FRUSTUM_INC__

#include <helper\core\typedefs.h>
#include "e3d_bsphere.h"
#include "e3d_bbox.h"
#include "memory\pool\e3d_vtxpool.h"
#include "memory\pool\e3d_cornerpool.h"
#include "math\e3d_plane.h"
#include "face\e3d_face.h"
#include <vector>

using namespace Helper;

namespace Eternity {
	
	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CPlane
	 * @brief	Defines an frustrum made up of an arbitrary amount of planes
	 * @author	Peter Nordlander
	 * @date	2001-05-23
	 */
	
	class CFrustum
	{
	private:
		
		CPlane				m_far;
		CPlane				m_near;
		std::vector<CPlane>	m_planes;		///< Frustrum planes
		int					m_numPlanes;	///< Amound of planes in frustrum
		
	public:

		CFrustum() {};
		~CFrustum();
			
		// add plane to frustrum
		void addPlane(const CPlane &plane);
		
		void setFar(const CPlane &plane);
		void setNear(const CPlane &plane);

		// clip face aganint planes within planeMask
		void clip(CFace &face, const uint32 mask = 0x7fffffff) const;

		// checkCollision against an bounding entity
		void checkCollision(CBSphere &sphere) const;
		void checkCollision(CBBox &box) const;
		
		// clear list of planes, remove all elements 
		void clear();
	};

}

#endif