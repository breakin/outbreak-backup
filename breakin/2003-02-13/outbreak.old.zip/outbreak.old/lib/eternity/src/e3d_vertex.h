#ifndef __ETERNITY_VERTEX_INC__
#define __ETERNITY_VERTEX_INC__

#include <vector>
#include "math\e3d_vector.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CTexel/CLumel/CPixel/CVertex/ CCorner
	 * @brief	Lowerlevel Mesh building blocks 
	 * @author	Peter Nordlander
	 * @date	2001-05-30
	 */
	
//========================================================================================
// Texture coordinates

	struct CTexel 
	{
		float32	u;
		float32 v;
	};
		
	typedef CTexel CLumel; 	// Lightmap coordinates

//========================================================================================
// projected screen coordinates	

	struct CPixel
	{
		fixed32 x;					///< Pixel vertical position in 16:16 fixed point format
		fixed32 y;					///< Pixel horizontal position in 16:16 fixed point format
		float   z;
	};
	
//========================================================================================
// vertex structure

	struct CVertex
	{		
		CVector3d   normal;			///< vertex normal
		CVector3d   local;			///< original object x,y,z
		CVector3d   transformed;	///< transformed object x,y,z
		CVector3d   color;			///< vertex rgb triplet
		CPixel      screen;			///< projected screen x,y and z (for zbuffering)
	};
	
//========================================================================================
}

#endif
