#ifndef __ETERNITY_VIEWPORT_INC__
#define __ETERNITY_VIEWPORT_INC__

#include "e3d_zbuffer.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CViewPort
	 * @brief	Represents a rendering viewport, on which area the rasterizer should project the 3D scene
	 * @author	Peter Nordlander
	 * @date	2001-07-10
	 */

	class CViewPort {
	private:
		CZBuffer* zBuffer;   // zbuffer

		uint32	top;         // upper(y) cordinate offset for rendering
		uint32	left;        // left(x) cordinate offset for rendering
		uint32	width;       // with of viewport in pixels
		uint32	height;      // height of viewport in pixels
	
	public:
		
		// Constructor & destructor
		CViewPort(uint32 left=0, uint32 top=0, uint32 width=0, uint32 height=0);
		~CViewPort();

		// Resize
		set(uint32 left, uint32 top, uint32 width, uint32 height);

		// Entity methods
		const uint32 getLeft()   { return left; }
		const uint32 getTop()    { return top; }
		const uint32 getWidth()  { return width; }
		const uint32 getHeight() { return height; }

		// ZBuffer methods
		void createZBuffer();
		void releaseZBuffer();

		const CZBuffer* getZBuffer() { return zBuffer; }
		void setZBuffer(CZBuffer* _zBuffer) { zBuffer = _zBuffer; }
	};
}

#endif