#ifndef __ETERNITY_KEYFRAMING_KEYS_INC__
#define __ETERNITY_KEYFRAMING_KEYS_INC__

#include <helper\core\typedefs.h>
#include "..\math\e3d_quat.h"
#include "..\math\e3d_vector.h"
#include "..\template\e3d_key.h"

using namespace Helper;

namespace Eternity {

	typedef TKey<float32>		CKeyFloat;	///< Key with float data
	typedef TKey<CVector3d>		CKeyVector;	///< Key with vector3d data
	typedef TKey<CQuaternion>	CKeyQuat;	///< Key with quaternion data
}

#endif