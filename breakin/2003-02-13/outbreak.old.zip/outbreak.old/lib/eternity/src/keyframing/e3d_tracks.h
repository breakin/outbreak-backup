#ifndef __ETERNITY_KEYFRAMING_TRACKS_INC__
#define __ETERNITY_KEYFRAMING_TRACKS_INC__

#include "e3d_keys.h"
#include "..\math\e3d_quat.h"

namespace Eternity {
	
	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CTrack
	 * @brief	Common track data and functionality
	 * @author	Peter Nordlander
	 * @date	2001-07-01
	 */
	
	class CTrack
	{
	public:
		
		enum {

			TRACK_ROLL	= 0x01,
			TRACK_REPEAT= 0x02,
			TRACK_SINGLE= 0x04,
		};

		CTrack() : m_frameCount(0), m_keyCount(0) {}
		virtual ~CTrack() {};
				
		/// get number of keys in track
		const uint32 getKeyCount() const {
			
			return m_keyCount;
		}
		
		/// get total frames in an�mation
		const uint32 getFrameCount() const {
		
			return m_frameCount;
		}

		/// get total frames in an�mation
		void setFrameCount(uint32 frameCount) {

			m_frameCount = frameCount;
		}

		/// set track mode TRACK_ROLL, TRACK_SINGLE or TRACK_REPEAT
		void setTrackMode(uint32 mode) {

			m_trackMode = mode;
		}

		/// get track mode TRACK_ROLL, TRACK_SINGLE or TRACK_REPEAT
		const uint32 getTrackMode() const {
		
			return m_trackMode;
		}


	protected:
		
		uint32	m_frameCount;		///< Frames in animation
		uint32	m_keyCount;			///< Amount of keys in track
		uint32	m_trackMode;		///< Track mode, roll, single, repeat
	};


	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CTrackFLoat
	 * @brief	Keyframing track of floats
	 * @author	Peter Nordlander
	 * @date	2001-07-01
	 */
	
	class CTrackFloat : public CTrack
	{
	public:
		
		CTrackFloat() : m_keys(NULL) {}

		/// destructor
		~CTrackFloat() {release();}

		// resize array of keys
		void resize(int n);

		// release arrary of keys, delete data
		void release();

		// get access to keys
		CKeyFloat* getKeys();

		// operator[], get float val at frame <index>
		float operator[](int index);
		
		// returns a float repr. the current value at frameIndex
		float getKey(float32 frameIndex);

		// calculate inc/outg. TCB spline tangents
		void calculateTangents();
	
	protected:
		
		CKeyFloat*	m_keys;		///< Track key data
	};
	
	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CTrackQuat
	 * @brief	Keyframing track of quaternions.
	 * @author	Peter Nordlander
	 * @date	2001-07-01
	 */
	
	class CTrackQuat : public CTrack
	{
	public:

		CTrackQuat() : m_keys(NULL) {}

		/// destructor
		~CTrackQuat() { release(); }

		// resize array of keys
		void resize(int n);

		// release arrary of keys, delete data
		void release();

		// get access to keys
		CKeyQuat* getKeys();

		/// operator[] get quat at frame <index>
		CQuaternion operator[] (int index);

		// returns a float repr. the current value at frameIndex
		CQuaternion getKey(float32 frameIndex) { return CQuaternion(); }

		// calculate inc/outg. TCB spline tangents
		void calculateTangents(){};

	private:
		
		CKeyQuat*	m_keys;	///< Track of quaternion keys
	};

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CTrackVector
	 * @brief	Keyframing track of vectors
	 * @author	Peter Nordlander
	 * @date	2001-07-01
	 */
	
	class CTrackVector : public CTrack
	{
	public:
		
		CTrackVector() : m_keys(NULL) {}

		/// destructor
		~CTrackVector() { release();}

		// resize array of keys
		void resize(int n);
		
		// release arrary of keys, delete data
		void release();

		// get arrary of vector keys
		CKeyVector* getKeys();

		/// operator[] get vector at frame <index>
		CVector3d operator[] (int index);
	
		// returns a vector repr. the current value at frameIndex
		CVector3d getKey(float32 frameIndex);

		// calculate inc/outg. TCB spline tangents
		void calculateTangents();

	private:

		CKeyVector*	m_keys;	///< Track of vector keys
	};
}



#endif