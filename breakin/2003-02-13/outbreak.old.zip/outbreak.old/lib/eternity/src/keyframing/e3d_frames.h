#ifndef __ETERNITY_KEYFRAMING_FRAMES_INC__
#define __ETERNITY_KEYFRAMING_FRAMES_INC__

#include "..\e3d_types.h"

namespace Eternity {

	class CAnimation
	{
	public:

		CFrames(uint32 start = 0, uint32 end = 0, float32 time = 0);
		
		void setStartFrame(uint32 start);
		const uint32 getStartFrame() const;

		void setEndFrame(uint32 start);
		const uint32 getEndFrame() const;

		void setTime(float32 time);
		const float32 getTime() const;

		uint32 getFrame(float32 t);
		
	private:

		uint32	m_start;	///< Frame start
		uint32	m_end;		///< Frame end	
		float32 m_time;		///< Animation time
	};
}


#endif