#include "e3d_tracks.h"

using namespace Eternity;

//===================================================================================

void CTrackFloat::resize(int n) {

	release();

	m_keys = new CKeyFloat[n];
	m_keyCount = n;
}

//===================================================================================

void CTrackFloat::release() {

	if (m_keys != NULL) {

		m_keyCount = 0;
		delete[] m_keys;
		m_keys = NULL;
	}
}

//===================================================================================

void CTrackVector::resize(int n) {

	release();

	m_keys = new CKeyVector[n];
	m_keyCount = n;
}

//===================================================================================

void CTrackVector::release() {

	if (m_keys != NULL) {

		delete[] m_keys;
		m_keyCount = 0;
		m_keys = NULL;
	}	
}

//===================================================================================

void CTrackQuat::resize(int n) {

	release();

	m_keys = new CKeyQuat[n];
	m_keyCount = n;
}

//===================================================================================

void CTrackQuat::release() {

	if (m_keys != NULL) {

		delete[] m_keys;
		m_keyCount = 0;
		m_keys = NULL;
	}
}

//===================================================================================

CKeyFloat* CTrackFloat::getKeys() {

	return m_keys;
}

//===================================================================================

CKeyVector* CTrackVector::getKeys() {

	return m_keys;
}

//===================================================================================

CKeyQuat* CTrackQuat::getKeys() {

	return m_keys;
}

//===================================================================================
// HERMIT SPLINE (TCB) INTERPOLATION CODE 
//****************************************
//===================================================================================

__forceinline float Ease( float t, float a, float b)	{
	float32 k;
	float32 s = a+b;

	if (s == 0.0f) return t;
	if (s > 1.0f) {
		a = a/s;
		b = b/s;
	}
	k = 1.0f/(2.0f-a-b);
	if (t < a) return ((k/a)*t*t);
	else	{
		if (t < 1.0f-b)	{
			return (k*(2.0f * t - a));
		}	else {
			t = 1.0f -t;
			return (1.0f-(k/b)*t*t);
		}
	}
}

CVector3d CTrackVector::getKey(float32 frameIndex) {

	int p1Index;	/// index of first point
	int p2Index;	/// index of second point
	
	// check if higher that last frame or track only has 1 frame
	// return last (locked) in that case
	if (frameIndex >= m_keys[m_keyCount-1].frameNumber)
		return m_keys[m_keyCount-1].data;

	// special case 2, only 2 keys in track
	if (m_keyCount == 2) {
		
		p1Index = 0;
		p2Index = 1;
	}
	else {

		/// find first frame
		for (int n=0; n < (int)m_keyCount; n++) {
			
			if (m_keys[n].frameNumber >= frameIndex) {
				
				// if exact position found, return data
				if (m_keys[n].frameNumber == frameIndex)
					return m_keys[n].data;

				// set from index
				p1Index = n-1;
				p2Index = n;
				break;
			}
		}
	}
	
	// fromIndex, and toIndex contains data to be interpolated
	float32 total = m_keys[p2Index].frameNumber - m_keys[p1Index].frameNumber;
	float32 t  = (frameIndex - m_keys[p1Index].frameNumber) / total;

	t = Ease(t,m_keys[p1Index].easeFrom,m_keys[p2Index].easeTo);
	
	// precalc. t^2 , t^3 and other known scalar values
	float32 t2	 = t * t;
	float32 t3	 = t2 * t;
	float32 t2_3 = 3 * t2;
	float32 t3_2 = 2 * t3;
	
	// get points
	CVector3d p1 = m_keys[p1Index].data;
	CVector3d p2 = m_keys[p2Index].data;

	// fet incoming and outgoing tangents
	CVector3d r1 = m_keys[p1Index].tangentIn;
	CVector3d r2 = m_keys[p1Index].tangentOut;

	
	return ((p1*(t3_2 - t2_3 + 1)) + (r1*(t3 - 2*t2 + t)) + 
			(p2*(-t3_2 + t2_3)) + (r2*(t3 - t2)));
}

//===================================================================================

float32 CTrackFloat::getKey(float32 frameIndex) {

	int p1Index;	/// index of first point
	int p2Index;	/// index of second point
	int t1Index;	/// index of p1 - 1 
	int t2Index;	/// index of p2 + 1 

	// check if higher that last frame or track only has 1 frame
	// return last (locked) in that case
	if (frameIndex >= m_keys[m_keyCount-1].frameNumber)
		return m_keys[m_keyCount-1].data;

	// special case 2, only 2 keys in track
	if (m_keyCount == 2) {
		
		t1Index = 0;
		t2Index = 1;
	}
	else {

		/// find first frame
		for (int n=0; n < (int)m_keyCount; n++) {

			if (m_keys[n].frameNumber >= frameIndex) {

				// if exact position found, return data
				if (m_keys[n].frameNumber == frameIndex)
					return m_keys[n].data;
				
				// set from index
				p1Index = n-1;
				p2Index = n;
				break;
			}
		}
	}
	
	// fromIndex, and toIndex contains data to be interpolated
	float32 total = m_keys[p2Index].frameNumber - m_keys[p1Index].frameNumber;
	float32 t  = (frameIndex - m_keys[p1Index].frameNumber) / total;

	t = Ease(t,m_keys[p1Index].easeFrom,m_keys[p2Index].easeTo);
	
	// precalc. t^2 , t^3 and other known scalar values
	float32 t2	 = t * t;
	float32 t3	 = t2 * t;
	float32 t2_3 = 3.0f * t2;
	float32 t3_2 = 2.0f * t3;
	
	// get points
	float32 p1 = m_keys[p1Index].data;
	float32 p2 = m_keys[p2Index].data;

	// fet incoming and outgoing tangents
	float32 r1 = m_keys[p1Index].tangentIn;
	float32 r2 = m_keys[p1Index].tangentOut;

	return (p1*(t3_2 - t2_3 + 1.0f) + r1*(t3 - 2*t2 + t) + p2*(-t3_2 + t2_3) + r2*(t3 - t2));
}

//===================================================================================

void CTrackFloat::calculateTangents() {

	float32		g1,g2,g3;
	float32		p1,p2;
	float32		T,C,B;
	int			t1Index, t2Index;
	int			p1Index, p2Index;

	// handle if only 1 key in track
	if (m_keyCount == 1)
		return;

	for (uint32 n=0; n < m_keyCount; n++) {

		p1Index = n;
		p2Index = n + 1;
		t1Index = p1Index - 1;
		t2Index = p2Index + 1;

		if (p1Index < 0)
			p2Index = 0;

		if (p2Index > int(m_keyCount - 1)) 
			p2Index = (m_keyCount - 1);

		if (t1Index < 0)
			t1Index = 0;

		if (t2Index > int(m_keyCount - 1)) 
			t2Index = int(m_keyCount - 1);
			
		// get T, C and B parameters
		T = m_keys[n].tension;
		C = m_keys[n].continuity;
		B = m_keys[n].bias;

		p1 = m_keys[p1Index].data;
		p2 = m_keys[p2Index].data;

		// calc inc. tangent
		g1 = (p1 - m_keys[t1Index].data) * (1.0f + B);
		g2 = (p2 - p1) * (1.0f - B);
		g3 = (p2 - p1);

		m_keys[p1Index].tangentIn = (g1 + g3 * (0.5f + 0.5f * C)) * (1.0f - T);

		// calc out. tangent
		g1 = (p2 - p1) * (1.0f + B);
		g2 = (m_keys[t2Index].data - p2) * (1.0f - B);
		g3 = (p2 - p1);

		m_keys[p1Index].tangentOut = (g1 + g3 * (0.5f - 0.5f * C)) * (1.0f - T);
	}
}

//===================================================================================

void CTrackVector::calculateTangents() {

	CVector3d	g1,g2,g3;
	CVector3d	p1,p2;
	float32		T,C,B;
	int			t1Index, t2Index;
	int			p1Index, p2Index;

	// handle if only 1 key in track
	if (m_keyCount == 1)
		return;

	for (uint32 n=0; n < m_keyCount; n++) {

		p1Index = n;
		p2Index = n + 1;
		t1Index = p1Index - 1;
		t2Index = p2Index + 1;

		if (p1Index < 0)
			p2Index = 0;

		if (p2Index > int(m_keyCount - 1)) 
			p2Index = (m_keyCount - 1);
		
		if (t1Index < 0)
			t1Index = 0;

		if (t2Index > int(m_keyCount - 1)) 
			t2Index = (m_keyCount - 1);
			
		// get T, C and B parameters
		T = m_keys[n].tension;
		C = m_keys[n].continuity;
		B = m_keys[n].bias;

		p1 = m_keys[p1Index].data;
		p2 = m_keys[p2Index].data;

		// calc inc. tangent
		g1 = (p1 - m_keys[t1Index].data) * (1.0f + B);
		g2 = (p2 - p1) * (1.0f - B);
		g3 = (p2 - p1);

		m_keys[p1Index].tangentIn = (g1 + (g3 * (0.5f + 0.5f * C))) * (1.0f - T);

		// calc out. tangent
		g1 = (p2 - p1) * (1.0f + B);
		g2 = (m_keys[t2Index].data - p2) * (1.0f - B);
		g3 = (p2 - p1);

		m_keys[p1Index].tangentOut = (g1 + (g3 * (0.5f - 0.5f * C))) * (1.0f - T);
	}
}

//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
