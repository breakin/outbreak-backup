#include "e3d_mesh.h"
#include "..\..\e3d_sysdef.h"
#include "..\..\material\e3d_material.h"

using namespace Eternity;

//===========================================================================

CMesh::CMesh() {

}

//===========================================================================

CMesh::~CMesh() {

	m_faces.release();
	m_vertices.release();
}

//===========================================================================

const CVertexBuffer const * CMesh::getVertexBuffer() const {
	
	// return address of base vertex buffer
	return &m_vertices;
}

//===========================================================================

CVertexBuffer* CMesh::getVertexBuffer() {

	// return address of base vertice buffer
	return &m_vertices;
}

//===========================================================================

CFaceBuffer* CMesh::getFaceBuffer() {
	
	// return address of face buffer
	return &m_faces;
}

//===========================================================================

const CFaceBuffer const * CMesh::getFaceBuffer() const {

	// return address of face buffer
	return &m_faces;
}

//===========================================================================

void CMesh::transform(const CCamera& camera, const CMatrix4x4 &parent) {

	/***********************************************************************
	 
		TODO : 
		1. remove 100% projection and only mult by focal length
		2. recurse transformation to object's children
		3. optimze clipping ;)

	************************************************************************/
			
	// get camera frustrum
	const CFrustum viewFrustum = camera.getFrustum();
	const float32 focalLength= camera.getFocalLength();
	const uint32  planeMask = m_boundSphere.getClipMask();

	CMatrix4x4 matTrns;
	CMatrix4x4 matRots;

	matTrns = getToParent() * parent;
	matRots = parent;

	// create rotation matrix for face normals by removing translation
	matRots.getRow(3) = CVector3d(0,0,0);

	// declare pointers to begining of buffers
	CFace* faceData	= m_faces.get();
	CVertex * vtxData = m_vertices.get();
	
	// transform children
	std::list<CObject*>::iterator i = m_children.begin();

	while (i!=m_children.end()) {
		
		(*i)->transform(camera,matTrns);
		++i;
	}

	int n = 0;

	// transform vertices
	while (n < m_vertices.getSize()) {
	
		vtxData[n].transformed = vtxData[n].local * matTrns;
		++n;
	}
	
	n = 0;
	
	// temporary normal storage
	CVector3d normal;

	// perform backfaceculling
	int faceCount = m_faces.getSize();

	while (n < faceCount) {
			
		normal = faceData[n].normal * matRots;
			
		// calculate a vector from a vertex on face to the camera
		CVector3d dir(faceData[n].baseCorners[1].vertex->transformed, CVector3d(0,0,0));
		
		// dot procuct them to find their angular relationship
		float32 cosAng = dir * normal;
		
		// set default visiblity to false
		faceData[n].visible = false;
		
		// if angle greater than 90deg (cos 0) set face to visible
		if (cosAng > 0.0) {

			faceData[n].visible = true;
			
			// check if plane is inside
			if (planeMask == CBSphere::INSIDE) {
				
				faceData[n].color = 0x00ff00;
				// no clipping needs to be performed on face
				// allocate 3 vertices from pool and copy to cornersClipped
				faceData[n].corners = faceData[n].baseCorners;
				faceData[n].numCorners = 3;

			} else {
				
				faceData[n].color =  0x00bb00;
				
				// clip face
				viewFrustum.clip(faceData[n],planeMask);
				
				// check if clipped out
				if (faceData[n].visible == false) {
	
					++n;
					continue;
				}
			}
			
			// project face vertices
			for (int p = 0; p < faceData[n].numCorners; p++) {
				
				float32 multiplier = focalLength / faceData[n].corners[p].vertex->transformed[2];

				// Calculate screen coordinates
				// faceData[n].corners[p].vertex->screen.x = (faceData[n].corners[p].vertex->transformed[0] * multiplier);
				// faceData[n].corners[p].vertex->screen.y = (faceData[n].corners[p].vertex->transformed[1] * multiplier);
				faceData[n].corners[p].vertex->screen.z = (faceData[n].corners[p].vertex->transformed[2]);

				// Fixed point
				faceData[n].corners[p].vertex->screen.x = (65536.0 * (faceData[n].corners[p].vertex->transformed[0] * multiplier));
				faceData[n].corners[p].vertex->screen.y = (65536.0 * (faceData[n].corners[p].vertex->transformed[1] * multiplier));
			}
			
			// add face to draw list
			//faceLists.faces.addFace(&faceData[n]);
			faceData[n].material->getFaceList().addFace(&faceData[n]);
		}

		++n;
	}
}

//===========================================================================

uint32 CMesh::getVertexCount() const {

	return m_vertices.getSize();
}

//===========================================================================

uint32 CMesh::getFaceCount() const {

	return m_faces.getSize();
}

//===========================================================================

CBSphere& CMesh::getBSphere() {

	return m_boundSphere;
}

//===========================================================================

void CMesh::updateMatrix() {

	m_matrix.zero();
	m_matrix.makeIdentity();
	m_matrix.makeScale(m_scale[0],m_scale[1],m_scale[2]);
	m_matrix.getRow(3) = m_position;
	m_boundSphere.setRadius(m_boundSphere.getRadius() + m_scale.getLength());
	
}

//===========================================================================

void CMesh::updateKeyFraming(float32 frameIndex) {

	if (!m_locked) {
		
		m_position	= m_trackPosition.getKey(frameIndex);
		m_rotation	= m_trackRotation.getKey(frameIndex);
		m_scale		= m_trackScale.getKey(frameIndex);
		m_invalidMatrix = true;
	}
}

//===========================================================================

CTrackVector* CMesh::getScaleTrack() {

	return &m_trackScale;
}

//===========================================================================

CTrackQuat* CMesh::getRotationTrack() {

	return &m_trackRotation;
}

//===========================================================================
