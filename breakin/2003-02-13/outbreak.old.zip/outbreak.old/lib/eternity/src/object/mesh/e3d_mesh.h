#ifndef __ETERNITY_OBJECT_MESH_INC__
#define __ETERNITY_OBJECT_MESH_INC__

#include "..\e3d_object.h"
#include "..\camera\e3d_camera.h"
#include "..\..\e3d_bsphere.h"
#include "..\..\face\e3d_face.h"
#include "..\..\e3d_vertex.h"
#include "..\..\e3d_buffers.h"
#include "..\..\math\e3d_quat.h"
#include "..\..\keyframing\e3d_tracks.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CMesh
	 * @brief	Triangual mesh object
	 * @author	Peter Nordlander
	 * @date	2001-06-07
	 */

	class CMesh : public CObject
	{
	public:
		
		CMesh();
		virtual ~CMesh();

		// get constant face and vertex buffers
		const CVertexBuffer const * getVertexBuffer() const;
		CFaceBuffer* getFaceBuffer();
		
		// get read/write face and vertex buffers
		const CFaceBuffer const * getFaceBuffer() const;
		CVertexBuffer* getVertexBuffer();
		
		// transform vertices
		void transform(const CCamera &camera, const CMatrix4x4 &parent);

		// get numer of faces/vertices
		uint32 getVertexCount() const;
		uint32 getFaceCount() const;

		// get mesh's bounding sphere
		CBSphere& getBSphere();
		
		// update mesh's matrix
		virtual void updateMatrix();

		// update mesh's keyframing
		virtual void updateKeyFraming(float32 frameIndex);

		// get pointer to mesh's tracks
		CTrackVector* getScaleTrack();
		CTrackQuat* getRotationTrack();
	
	protected:
			
		CTrackQuat		m_trackRotation;		///< Mesh rotation track
		CTrackVector	m_trackScale;			///< Mesh scale track
		CQuaternion		m_rotation;				///< Mesh rotation
		CVector3d		m_scale;				///< Mesh scale
		CBSphere		m_boundSphere;			///< Mesh bounding sphere
		CVertexBuffer	m_vertices;				///< Mesh vertices
		CFaceBuffer		m_faces;				///< Mesh faces
		CVector3d		m_pivot;				///< Mesh pivot point, default(0,0,0);
		bool			m_isChild;				///< Mesh child state
	};
}


#endif
