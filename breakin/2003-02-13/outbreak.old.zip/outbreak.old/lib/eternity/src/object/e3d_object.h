#ifndef __ETERNITY_OBJECT_INC__
#define __ETERNITY_OBJECT_INC__

#include <list>
#include "..\keyframing\e3d_tracks.h"
#include "..\math\e3d_matrix.h"
#include "..\math\e3d_vector.h"
#include "..\e3d_facelists.h"
#include "..\e3d_frustum.h"

namespace Eternity {

	// forw class descl.
	class CLight;
	class CCamera;

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CObject
	 * @brief	common interface towards all items in the 3d scene environment
	 * @author	Peter Nordlander
	 * @date	2001-05-30
	 */
	
	class CObject
	{
	public:

		enum {

			ACTIVE	= 0x01,
			INACTIVE= 0x02,
		};
		
		enum {

			OWNER_SCENE		= 0x01,
			OWNER_EXTERNAL	= 0x02,
		};

		CObject() : m_invalidMatrix(false) , m_locked(false) {}
		virtual ~CObject();

		// get object't constant matrices 
		virtual const CMatrix4x4& getToLocal();
		virtual const CMatrix4x4& getToParent();
		
		// get/set object's name
		virtual void setName(const std::string& name);
		virtual const std::string& getName() const;
		
		// get/set object's avtivateState
		virtual void setActivationState(uint32 activationState);
		virtual uint32 getActivationState() const;

		// get/set object's owner
		virtual void setOwner(uint32 owner);
		virtual uint32 getOwner() const;

		// get/set object's matrix
		virtual CMatrix4x4& getMatrix();
		virtual void setMatrix(const CMatrix4x4 &matrix);

		// get/set object's position/translation in world space
		virtual const CVector3d&  getPosition() const;
		virtual void setPosition(const CVector3d& posistion);
			
		// apply position and matrix
		virtual void updateKeyFraming(float32 frameIndex);
		
		// returns amount of children attatched to object
		virtual uint32 getChildCount() const;

		// adds a child to object
		virtual void addChild(CObject *object);

		// remove (unreference) a child from list of children
		virtual void removeChild(CObject *object);
		
		// remove (unreference) a child from list by it's name, returns NULL if not found,
		// othwise poitner to child removed from list
		virtual CObject* removeChildByName(const std::string &name);

		// update object matrix, must be overriden by underclasses
		virtual void updateMatrix() = 0;

		// transform and lit object and childs
		virtual void transform(const CCamera &camera, const CMatrix4x4 &parent) = 0;
		
		// get pointer to object's position track
		CTrackVector* getPositionTrack();

		// lock/unlock object : if object is locked, it will not be 
		// animated or influenced by any keyframing
		virtual void lock();
		virtual	void unlock();

	protected:
		
		std::string			m_name;			///< Object name;
		CMatrix4x4			m_matrix;		///< Object transformation matrix
		CVector3d			m_position;		///< Object position
		uint32				m_visible;		///< Object visiblilty enum set
		uint32				m_owner;		///< Object owner
		bool				m_isChild;		///< Object child state
		bool				m_invalidMatrix;///< Object has an invalid matrix, which needs to be updated
		std::list<CObject*> m_children;		///< Object child list
		CTrackVector		m_trackPosition;///< Object position track
		bool				m_locked;		///< Object lock state
	};


}

#endif
