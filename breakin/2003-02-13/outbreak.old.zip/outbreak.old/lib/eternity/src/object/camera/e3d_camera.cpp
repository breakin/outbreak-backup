#include "e3d_camera.h"
#include "..\..\e3d_sysdef.h"

using namespace Eternity;

//==========================================================================

CCamera::CCamera() {

}

//==========================================================================

CCamera::~CCamera() {

}

//==========================================================================

float32	CCamera::getFOV() const {

	return m_fov;
}

//==========================================================================

void CCamera::setFOV(const float32 fovAngle) {
	
	// no unncessecary calculations
	if (fovAngle == m_fov)
		return;

	// set fov
	m_fov = fovAngle;

	// update view frustrum
	makeViewFrustum(fovAngle);
	m_invalidMatrix = true;
}

//==========================================================================

float32 CCamera::getRoll() const {

	return m_roll;
}

//==========================================================================

void CCamera::setRoll(const float32 rollAngle) {

	m_roll = rollAngle;
	m_invalidMatrix = true;
}

//==========================================================================

const CVector3d& CCamera::getTarget() {

	return m_target;
}

//==========================================================================

void CCamera::setTarget(const CVector3d &lookAt) {

	m_target = lookAt;
	m_invalidMatrix=true;
}

//==========================================================================

const CFrustum& CCamera::getFrustum() const {

	return m_frustum;
}

//==========================================================================

void CCamera::makeViewFrustum(float32 fov) {

	m_frustum.clear();
	m_frustum.addPlane(CPlane(0,-cosf(fov/2),sinf(fov/2),0));
	m_frustum.addPlane(CPlane(0,cosf(fov/2),sinf(fov/2),0));
	m_frustum.addPlane(CPlane(cosf(fov/2),0,sinf(fov/2),0));
	m_frustum.addPlane(CPlane(-cosf(fov/2),0,sinf(fov/2),0));

	m_frustum.addPlane(CPlane(0,0,1.0f,-255.0f));
//	m_frustum.addPlane(CPlane(0,0,1.0f,1.0f));

//	m_frustum.addPlane(CPlane(0,0,-1.0f,-1500.0f));
}

//==========================================================================

float32 CCamera::getFocalLength() const {

	return (1.0 / tanf(m_fov/2));
}

//==========================================================================

void CCamera::updateMatrix() {

	// make a view vector
	m_matrix.makeViewLookAt(m_position,m_target,m_roll);
	m_invalidMatrix = false;
}

//==========================================================================

const CMatrix4x4& CCamera::getToParent() {

	if (m_invalidMatrix)
		updateMatrix();

	return (-m_matrix);
}

//==========================================================================

const CMatrix4x4& CCamera::getToLocal() {

	if (m_invalidMatrix)
		updateMatrix();

	return m_matrix;
}

//==========================================================================

void CCamera::updateKeyFraming(float32 frameIndex) {
	
	if (!m_locked) {
		
		m_position	= m_trackPosition.getKey(frameIndex);	
		m_roll		= m_trackRoll.getKey(frameIndex) * E3D_PI / 180.0;
		m_target	= m_trackTarget.getKey(frameIndex);	
		setFOV(m_trackFOV.getKey(frameIndex) * E3D_PI / 180.0);
		m_invalidMatrix = true;
	}
}

//==========================================================================

CTrackFloat* CCamera::getRollTrack() {

	return &m_trackRoll;
}

//==========================================================================

CTrackFloat* CCamera::getFOVTrack() {

	return &m_trackFOV;
}

//==========================================================================

CTrackVector* CCamera::getTargetTrack() {

	return &m_trackTarget;
}

//==========================================================================
