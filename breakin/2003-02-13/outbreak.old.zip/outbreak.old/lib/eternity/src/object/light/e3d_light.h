#ifndef __ETERNITY_LIGHT_INC__
#define __ETERNITY_LIGHT_INC__

#include "..\e3d_object.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CLight
	 * @brief	Common interface towards all lights
	 * @author	Peter Nordlander
	 * @date	2001-05-31
	 */

	class CLight : public CObject
	{
	public:
		
		CLight();
		virtual ~CLight();
		
		// set/get light's strength
		const CVector3d& getColor() const;
		void setColor(const CVector3d &rgb);
	
		// set/get light's strength
		float32 getStrength() const;
		void setStrength(const float32 strength);
	
	protected:

		float32		m_strength;
		CVector3d	m_color;
	};
}

#endif
