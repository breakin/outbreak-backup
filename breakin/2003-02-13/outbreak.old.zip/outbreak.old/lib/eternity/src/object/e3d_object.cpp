#include "e3d_object.h"

using namespace Eternity;

//=====================================================================================================

CObject::~CObject() {

}

//=====================================================================================================

CMatrix4x4& CObject::getMatrix() {

	// return a non const reference to object's matrix
	return m_matrix;
}

//=====================================================================================================

const CMatrix4x4& CObject::getToLocal(){

	// if matrix object transormation has changed, update matrix
	if (m_invalidMatrix)
		updateMatrix();

	// return inverse of object matrix
	return (-m_matrix);
}

//=====================================================================================================

const CMatrix4x4& CObject::getToParent(){

	// if matrix object transormation has changed, update matrix
	if (m_invalidMatrix)
		updateMatrix();
	
	// return object's transformation matrix
	return m_matrix;
}

//=====================================================================================================

const CVector3d& CObject::getPosition() const {

	// return object's position in worldspace
	return m_position;
}

//=====================================================================================================

void CObject::setPosition(const CVector3d& position) {

	// set position in world space
	m_position	= position;
	m_invalidMatrix = true;
}

//=====================================================================================================

void CObject::setMatrix(const CMatrix4x4 &matrix) {
	
	// set object's matrix
	m_matrix = matrix;
	m_invalidMatrix = false;
}

//=====================================================================================================

void CObject::updateKeyFraming(float32 frameIndex) {

}

//=====================================================================================================

uint32 CObject::getChildCount() const {

	// return amount of children in list
	return m_children.size();
}

//=====================================================================================================

void CObject::addChild(CObject *object) {

	// add child to end of list
	m_children.push_back(object);
}

//=====================================================================================================

void CObject::setName(const std::string &name) {

	m_name = name;
}

//=====================================================================================================

const std::string& CObject::getName() const {

	return m_name;
}

//=====================================================================================================

void CObject::removeChild(CObject *object) {

	// pass name to removeByName
	m_children.remove(object);

}

//=====================================================================================================

CObject* CObject::removeChildByName(const std::string &name) {

	std::list<CObject*>::iterator i = m_children.begin();

	while (i != m_children.end()) {
		
		// if found remove from list and ruturn
		if ((*i)->getName().compare(name) == 0) {
			
			CObject *r = (CObject*)(*i);
			m_children.remove((*i));
			return r;
		}

		++i;
	}

	return NULL;
}

//=====================================================================================================

uint32 CObject::getOwner() const {

	return m_owner;
}

//=====================================================================================================

void CObject::setOwner(uint32 owner) {

	m_owner = owner;
}

//=====================================================================================================

uint32 CObject::getActivationState() const {

	return m_visible;
}
//=====================================================================================================

void CObject::setActivationState(uint32 activationState) {

	m_visible = activationState;
}

//=====================================================================================================

CTrackVector* CObject::getPositionTrack() {

	return &m_trackPosition;
}

//=====================================================================================================

void CObject::lock() {

	m_locked = true;
}

//=====================================================================================================

void CObject::unlock() {

	m_locked = false;
}
//=====================================================================================================
