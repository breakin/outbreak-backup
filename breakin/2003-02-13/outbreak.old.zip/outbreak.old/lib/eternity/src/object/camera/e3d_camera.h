#ifndef __ETERNITY_CAMERA_INC__
#define __ETERNITY_CAMERA_INC__

#include "..\e3d_object.h"
#include "..\..\e3d_frustum.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CCamera
	 * @brief	Camerea viewport class
	 * @author	Peter Nordlander
	 * @date	2001-05-31
	 */
	
	class CCamera : public CObject
	{
	public:
		
		CCamera();
		virtual ~CCamera();
		

		// camera overides getToParent/Local
		const CMatrix4x4& getToParent();
		const CMatrix4x4& getToLocal();

		// get field of view
		float32	getFOV() const;
		void setFOV(const float32 fovAngle);
		
		// get/ set focal length
		float32 getFocalLength() const;

		// get/set roll angle
		float32 getRoll() const;
		void setRoll(const float32 rollAngle);

		// get/set camera look-at vector
		const CVector3d& getTarget();
		void setTarget(const CVector3d &lookAt);

		// get view frustum
		const CFrustum& getFrustum() const;

		// update camera matrix
		void updateMatrix();
		
		// update camera keyframing
		void updateKeyFraming(float32 frameIndex);

		// needs overide, but has no implementation purpose
		void transform(const CCamera &camera, const CMatrix4x4 &parent){
		}

		// get pointer to camera's tracks
		CTrackFloat* getRollTrack();
		CTrackFloat* getFOVTrack();
		CTrackVector* getTargetTrack();
	
	protected:

		void makeViewFrustum(float32 fov);
		
		CFrustum		m_frustum;		///< Camera view frustrum
		CVector3d		m_target;		///< Camera look at point
		float32			m_fov;			///< Camera field of view
		float32			m_roll;			///< Camera roll angle
		CTrackVector	m_trackTarget;	///< Camera target track
		CTrackFloat		m_trackRoll;	///< Camera track roll
		CTrackFloat		m_trackFOV;		///< Camera track roll
	};
}


#endif
