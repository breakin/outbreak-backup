#include "e3d_scene.h"
#include "e3d_sysdef.h"
#include "e3d_exception.h"

using namespace Eternity;

// ====================================================================================
// Default camera settings
// ====================================================================================

const float32	DEFAULT_CAMERA_FOV		= 90.0;
const float32	DEFAULT_CAMERA_ROLL		= 0.0;
const char *	DEFAULT_CAMERA_NAME		= "DefaultCam01";
const CVector3d DEFAULT_CAMERA_POS		= CVector3d(0,0,-256);
const CVector3d DEFAULT_CAMERA_TARGET	= CVector3d(0,0,0);

//=====================================================================================
// CScene methods
//=====================================================================================

CScene::CScene() {
	
	// initialize data members
	init();

	// Active
	m_active = true;
}	

//=====================================================================================

CScene::~CScene() {
	
	// descruction code here
	release();
}

//=====================================================================================

void CScene::init() {

	m_activeCamera	= NULL;		// active camera to null
	m_defaultCamera = NULL;		// default camera to null
	m_lockCamera	= false;	// reset obj. locks
	m_lockMesh		= false;
	m_lockLight		= false;
}

//=====================================================================================

void CScene::transform() {

	/***********************************************************************
	 
		TODO : 
		1.	Not use the first camera in list, use the currently selected.
		2.	Only transform objects which do NOT has their childstate set.
		3.	Need to *more nicely* implement bsphere to frustrum test.
			maybe fix so that each object itself sets its bsphere's centre to its
			current worldspace position.

	************************************************************************/
	
	std::list<CMesh*>::iterator i = m_listMesh.begin();
	CVector3d objSphereCentre;
                                                                                          
	// get first camera
	if (m_activeCamera == NULL)
		m_activeCamera = getActiveCamera();

	while (i != m_listMesh.end()) {
		
		// check objects bounding sphere against frustum 
		
		// transform object's bsphere into view space
		CBSphere objSphere = (*i)->getBSphere();
		objSphereCentre = (*i)->getPosition() * m_activeCamera->getToLocal();

		objSphere.setCentre(objSphereCentre);
		
		m_activeCamera->getFrustum().checkCollision(objSphere);
		(*i)->getBSphere().setClipMask(objSphere.getClipMask());
			
		if ((*i)->getBSphere().getClipMask() != CBSphere::OUTSIDE) {
			
			(*i)->transform(*m_activeCamera,m_activeCamera->getToLocal());
		}

		++i;
	}
}

//=====================================================================================

std::list<CMesh*>* CScene::getMeshList() {

	// return address to list of meshes
	return &m_listMesh;
}

//=====================================================================================

std::list<CLight*>* CScene::getLightList() {

	// return address to list of lights
	return &m_listLight;
}

//=====================================================================================

std::list<CCamera*>* CScene::getCameraList() {

	// return address to list of cameras
	return &m_listCamera;
}

//=====================================================================================

CMesh* CScene::findMesh(const std::string &name) {
	
	std::list<CMesh*>::iterator i = m_listMesh.begin();
	
	// traverse list
	while (i != m_listMesh.end()) {

		// check if we got a match
		if ((*i)->getName().compare(name) == 0)
			return (*i);

		++i;
	}

	return NULL;
}

//=====================================================================================

CLight* CScene::findLight(const std::string &name) {

	std::list<CLight*>::iterator i = m_listLight.begin();
	
	// traverse list
	while (i != m_listLight.end()) {

		// check if we got a match
		if ((*i)->getName().compare(name) == 0)
			return (*i);

		++i;
	}

	return NULL;
}

//=====================================================================================

CCamera* CScene::findCamera(const std::string &name)  {

	std::list<CCamera*>::iterator i = m_listCamera.begin();
	
	// traverse list
	while (i != m_listCamera.end()) {

		// check if we got a match
		if ((*i)->getName().compare(name) == 0)
			return (*i);

		++i;
	}

	return NULL;
}

//=====================================================================================

CMesh* CScene::getMesh(const std::string &name)  {

	CMesh *retObject = findMesh(name);
	
	if (!retObject)
		throw CException("CScene::getMesh(%s), object not found!",name.c_str());

	return retObject;		
}

//=====================================================================================

CLight* CScene::getLight(const std::string &name) {

	CLight *retObject = findLight(name);
	
	if (!retObject)
		throw CException("CScene::getLight(%s), object not found!",name.c_str());
	
	return retObject;
}

//=====================================================================================

CCamera* CScene::getCamera(const std::string &name) {

	CCamera *retObject = findCamera(name);

	if (!retObject)
		throw CException("CScene::findLight(%s), object not found!",name.c_str());

	return retObject;
}

//=====================================================================================

CObject* CScene::getObject(const std::string &name) {

	CObject* ret;

	// look for object in mesh list
	ret = findMesh(name);
	if (ret != NULL)
		return ret;

	// look for object in light list
	ret = findLight(name);
	if (ret != NULL)
		return ret;

	// look for object in camera list
	ret = findCamera(name);
	if (ret != NULL)
		return ret;

	// throw exception if object not found
	throw CException("CScene::findObject(%s), object not found!",name.c_str());
}

//=====================================================================================

void CScene::addMesh(CMesh *mesh) {

	// add mesh to end of sequence
	m_listMesh.push_back(mesh);
}

//=====================================================================================

void CScene::addLight(CLight *light) {

	// add light to end of sequence
	m_listLight.push_back(light);
}

//=====================================================================================

void CScene::addCamera(CCamera *camera) {

	// add light to end of sequence
	m_listCamera.push_back(camera);
}

//=====================================================================================

void CScene::removeMesh(CMesh *mesh) {

	m_listMesh.remove(mesh);
	removeFromChildren(mesh);

	if (mesh->getOwner() == CObject::OWNER_SCENE)
		delete mesh;
}

//=====================================================================================

bool CScene::removeMesh(const std::string& name) {
	
	// find object
	CMesh *object = findMesh(name);
	
	if (object != NULL) {

		removeMesh(object);
		return true;
	}

	return false;
}

//=====================================================================================

void CScene::removeLight(CLight *light) {

	// remove from lsit
	m_listLight.remove(light);
	removeFromChildren(light);	

	if (light->getOwner() == CObject::OWNER_SCENE)
		delete light;

}

//=====================================================================================

bool CScene::removeLight(const std::string &name) {

	CLight *object = findLight(name);
	
	if (object != NULL) {

		removeLight(object);
		return true;
	}

	return false;
}

//=====================================================================================

void CScene::removeCamera(CCamera *camera) {

	m_listCamera.remove(camera);
	
	if (camera->getOwner() == CObject::OWNER_SCENE)
		delete camera;
}

//=====================================================================================

bool CScene::removeCamera(const std::string &name) {

	CCamera *object = findCamera(name);
	
	if (object != NULL) {

		removeCamera(object);
		return true;
	}

	return false;
}

//=====================================================================================

bool CScene::removeObject(const std::string &name) {

	if (removeMesh(name))
		return true;
	if (removeLight(name))
		return true;
	if (removeCamera(name))
		return true;

	return false;
}

//=====================================================================================

void CScene::release() {

	// check if scene has created a default camera
	if (m_defaultCamera != NULL) {

		delete m_defaultCamera;
		m_defaultCamera = NULL;
	}

	// delete all lights
	while (!m_listLight.empty()) {
		
		// remove node from list
		CLight* pl = m_listLight.front();
		m_listLight.pop_front();
	
		// check scene ownership
		if (pl->getOwner() == CObject::OWNER_SCENE)
			delete pl;
	}

	// deletae all meshes
	while (!m_listMesh.empty()) {
		
		// remove node from list
		CMesh* m = m_listMesh.front();
		m_listMesh.pop_front();
		
		// check scene ownership
		if (m->getOwner() == CObject::OWNER_SCENE)
			delete m;
	}

	// deletae all cameras
	while (!m_listCamera.empty()) {
		
		// remove node from list
		CCamera* c = m_listCamera.front();
		m_listCamera.pop_front();

		// check scene ownership
		if (c->getOwner() == CObject::OWNER_SCENE)
			delete c;
	}

	// initialize member data to default
	init();
}

//=====================================================================================
		
void CScene::removeFromChildren(CObject *object) {

	std::list<CMesh*>::iterator i = m_listMesh.begin();
	std::list<CLight*>::iterator j = m_listLight.begin();

	// look for child references in mesh list
	while (i != m_listMesh.end()) {

		(*i)->removeChild(object);
		++i;
	}

	// look for chuld references in light list
	while (j != m_listLight.end()) {

		(*j)->removeChild(object);
		++j;
	}
	
}

//=====================================================================================

void CScene::updateKeyFraming(const float32 frameIndex) {


	if (!m_lockMesh) {

		std::list<CMesh*>::iterator i = m_listMesh.begin();
	
		while (i != m_listMesh.end()) {
			
			(*i)->updateKeyFraming(frameIndex);
			++i;
		}
	
	}

	if (!m_lockCamera) {

		std::list<CCamera*>::iterator j = m_listCamera.begin();

		while (j != m_listCamera.end()) {
			
			(*j)->updateKeyFraming(frameIndex);
			++j;
		}
	}
}

//=====================================================================================

void CScene::setActiveCamera(CCamera *camera) {

	m_activeCamera = camera;
}

//=====================================================================================

CCamera* CScene::getActiveCamera() {
	
	// chech if not active camera is set
	if (m_activeCamera == NULL) {

		// if there are cameras in list, set first camera in list to active
		if (m_listCamera.size() != 0) {
		
			m_activeCamera = m_listCamera.front();
		}
		// else create a default camera and set it to active
		else {

			if (!m_defaultCamera)
				createDefaultCamera();
			
			m_activeCamera = m_defaultCamera;
		}
	}

	// return active camera
	return m_activeCamera;
}

//=====================================================================================

void CScene::createDefaultCamera() {

	if (m_defaultCamera == NULL) {

		m_defaultCamera = new CCamera;
		m_defaultCamera->setFOV(DEFAULT_CAMERA_FOV * E3D_PI / 180.0);
		m_defaultCamera->setRoll(DEFAULT_CAMERA_ROLL);
		m_defaultCamera->setTarget(DEFAULT_CAMERA_TARGET);
		m_defaultCamera->setPosition(DEFAULT_CAMERA_POS);
		m_defaultCamera->setName(DEFAULT_CAMERA_NAME);

		m_defaultCamera->lock();
	}
}

//=====================================================================================

void CScene::setCameraLock(const bool lock) {

	m_lockCamera = lock;
}

//=====================================================================================

bool CScene::getCameraLock() const {

	return m_lockCamera;
}

//=====================================================================================

void CScene::setMeshLock(const bool lock){

	m_lockMesh = lock;
}

//=====================================================================================

bool CScene::getMeshLock() const {

	return m_lockMesh;
}

//=====================================================================================

void CScene::setLightLock(const bool lock){

	m_lockLight = lock;
}

//=====================================================================================

bool CScene::getLightLock() const {

	return m_lockLight;
}

//=====================================================================================

void CScene::setObjectLock(uint32 objEnumType, const bool lock) {

	if (objEnumType & OBJECT_MESH)
		m_lockMesh = lock;

	if (objEnumType & OBJECT_LIGHT)
		m_lockLight = lock;
	
	if (objEnumType & OBJECT_CAMERA)
		m_lockCamera = lock;
}

//=====================================================================================

bool CScene::getObjectLock(uint32 objEnumType) const {

	if (objEnumType & OBJECT_MESH)
		return m_lockMesh;

	if (objEnumType & OBJECT_LIGHT)
		return m_lockLight;
	
	if (objEnumType & OBJECT_CAMERA)
		return m_lockCamera;

	return false;
}