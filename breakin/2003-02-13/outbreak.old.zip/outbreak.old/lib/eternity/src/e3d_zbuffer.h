#ifndef __ETERNITY_ZBUFFER_INC__
#define __ETERNITY_ZBUFFER_INC__

#include <helper\core\typedefs.h>
#include "e3d_sysdef.h"

using namespace Helper;

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CZBuffer
	 * @brief	Fixed Point ZBuffer with internal framecounter 
	 * @author	Peter Nordlander
	 * @date	2001-07-17
	 */

	class CZBuffer
	{
	public:
		
		/// constructor/ destructir
		CZBuffer(int32 width = 0, int32 height = 0);
		~CZBuffer();
		
		/// create/release/resizeresize zbuffer
		void create(int32 width, int32 height);
		void release();
		
		/// get ZBuffer's properties
		int32 getWidth() const;
		int32 getHeight() const;
		int32 getFrame() const;

		/// get instant access to zbuffer's data
		fixed32 * get();
		const fixed32 * const get() const;
			
		/// operator[] returns fixed value with respect to frame
		fixed32& operator[] (const int index);
		const fixed32& operator[] (const int index) const;
		
		/// clear zbuffer and reset framecounter
		void clear();

		/// update frame counter
		void update();
		
	protected:
		
		/// Max ZBuffer frame constant
		enum {
		
			MAX_FRAME = 0xffff,
		};

		int32		m_width;	///< ZBuffer's width
		int32		m_height;	///< ZBuffer's height
		int32		m_frame;	///< ZBuffer's current frame
		fixed32*	m_data;		///< ZBuffer data
		
	};	

//=============================================================================

E3D_INLINE fixed32& CZBuffer::operator[] (const int index) {
	
	E3D_ASSERT(m_data != NULL);
	return m_data[index];
}

//=============================================================================

E3D_INLINE const fixed32& CZBuffer::operator[] (const int index) const {
	
	E3D_ASSERT(m_data != NULL);
	return m_data[index];
}

}

#endif
