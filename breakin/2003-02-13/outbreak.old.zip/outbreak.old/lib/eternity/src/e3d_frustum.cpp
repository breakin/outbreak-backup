#include "e3d_frustum.h"
#include "memory\pool\e3d_vtxpool.h"
#include "memory\pool\e3d_cornerpool.h"

using namespace Eternity;

// =====================================================================================

CFrustum::~CFrustum() {

	m_planes.clear();
}

// =====================================================================================

void CFrustum::addPlane(const CPlane &plane) {

	m_planes.push_back(plane);
	m_numPlanes++;
}

// =====================================================================================

void CFrustum::clip(CFace &face, const uint32 boundMask) const {

	// temporary corner storage
	static CFace::CCorner  cTemp1[6];
	static CFace::CCorner  cTemp2[6];
	static CFace::CCorner* cTemp [2] = {cTemp1,cTemp2};
	
	// temporary vertex storage
	static CVertex  vTemp1[6];
	static CVertex  vTemp2[6];
	static CVertex* vTemp [2] = {vTemp1,vTemp2};

	// copy base vertices int arrays
	cTemp1[0] =  face.baseCorners[0];
	cTemp1[1] =  face.baseCorners[1];
	cTemp1[2] =  face.baseCorners[2];
	vTemp1[0] = *(cTemp1[0].vertex);
	vTemp1[1] = *(cTemp1[1].vertex);
	vTemp1[2] = *(cTemp1[2].vertex);

	// temporary indexes
	int current= 0;
	int in = 0;
	int out = 1;
	int numOut = 0;
	int numIn  = 3;
	
	float dist1;
	float dist2;
	
	for (int n=0; n < m_planes.size(); n++) {
		
		if (boundMask & (1 << n)) {
			
			// calc dist1 for loop 0, d�st 1 = dist 2 every other loop
			dist1 = m_planes[n].getPointDistance(vTemp[in][0].transformed);
			
			for (int c = 0; c < numIn; c++) {
				
				// precalc second vertex index in edge
				int next = (c+1) % numIn;

				// get distance to both edge points
				//	dist1 = m_planes[n].getPointDistance(vTemp[current][c].transformed);
				dist2 = m_planes[n].getPointDistance(vTemp[in][next].transformed);
				
				// *** case BOTH INSIDE *****************
				if ((dist1 > 0) && (dist2 > 0)) {
						
					// store init vertex
					vTemp[out][numOut] = vTemp[in][c];
					numOut++;
				}

				// *** case ENTER plane ********************
				else if ((dist1 <= 0) && (dist2 > 0)) {
					
					// calc t
					float32 t = dist1 / (dist1 - dist2);
					
					// store intersection vertex
					vTemp[out][numOut].transformed = vTemp[in][c].transformed + (t * (vTemp[in][next].transformed - vTemp[in][c].transformed));
					//vTemp[out][numOut].color  = vTemp[in][c].color  + (t * (vTemp[in][next].color  - vTemp[in][c].color));	
	
					numOut++;
				}
				
				// *** case LEAVE plane ********************
				else if ((dist1 >= 0) && (dist2 < 0)) {
				
					// calc t
					float32 t = dist1 / (dist1 - dist2);

					// store init vertex + intersection vertex
					vTemp[out][numOut  ].transformed = vTemp[in][c].transformed;
					//vTemp[out][numOut  ].color  = vTemp[in][c].color;	
					vTemp[out][numOut+1].transformed = vTemp[in][c].transformed + (t * (vTemp[in][next].transformed - vTemp[in][c].transformed));
					//vTemp[out][numOut+1].color  = vTemp[in][c].color  + (t * (vTemp[in][next].color  - vTemp[in][c].color));	
				
					numOut+=2;
				}			
				
				// distance 1 is the same the distance 2 in former loop
				dist1 = dist2;
			}
			
			// if not vertices were kept, return and set face to hidden
			if (numOut == 0) {
				
				face.visible = false;
				return;
			}

			// set next numIn to amount of vertices fetched during last plane clip
			numIn	= numOut;
			numOut	= 0;
			current = 1 - current;
			in		= current;
			out		= !current;
		}
	}
	
	// get memory for vertices and corners from pools
	face.numCorners		= numIn;
	face.corners		= Global::cornerPool.get(numIn);
	CVertex* faceVerts  = Global::vertexPool.get(numIn);
	
	// copy clipped data
	n = 0;
	while (n < face.numCorners) {

		face.corners[n].vertex	= faceVerts;
		*face.corners[n].vertex = vTemp[in][n];
		faceVerts++;
		n++;
	}
}

// =====================================================================================

void CFrustum::checkCollision(CBSphere &sphere) const {

	float		radius = sphere.getRadius();
	CVector3d	centre = sphere.getCentre();
	uint32		result = 0;
	uint32		planes = m_planes.size();

	for (int n=0; n < planes; n++) {

		float d = m_planes[n].getPointDistance(centre);

		// check if entering plane
		if (d < 0) {

			if (-d < radius) 
				result |= (1 << n);
			//else its totally outside and so is sphere, return and set hidden flag
			else {

				sphere.setClipMask(CBSphere::OUTSIDE);
				return;
			}
		}
		// else check if leaving plane
		else {
			
			if (d < radius)
				result |= (1 << n);
		}
	}

	// return bitmask - specifying which planes the sphere
	// is clipped against
	sphere.setClipMask(result);
}

// =====================================================================================

void CFrustum::checkCollision(CBBox &box) const {

	return;
}

// =====================================================================================

void CFrustum::clear() {

	m_planes.clear();
}

// =====================================================================================
