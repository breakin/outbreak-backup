#ifndef __ETERNITY_BUFFERS_INC__
#define __ETERNITY_BUFFERS_INC__

#include "template\e3d_buffer.h"
#include "face\e3d_face.h"
#include "e3d_vertex.h"

namespace Eternity {

	typedef TBuffer<CVertex> CVertexBuffer;	///< Buffer of vertices 
	typedef TBuffer<CFace>	 CFaceBuffer;	///< Buffer of faces
}

#endif