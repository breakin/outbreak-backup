#ifndef __ETERNITY_RESOURCE_LOADER_3DS_INC__
#define __ETERNITY_RESOURCE_LOADER_3DS_INC__

#include <stdio.h>
#include "..\..\e3d_scene.h"
#include "..\..\math\e3d_vector.h"
#include "..\..\math\e3d_quat.h"
#include "..\..\keyframing\e3d_tracks.h"

namespace Eternity {

	class CLoader_3DS 
	{
	public:
		
		/// Chunk structure
		struct Chunk 
		{
			uint16	m_id;		///< Chunk ID	
			uint32	m_length;	///< Chunk Length
		};
		
		/// Constructor
		CLoader_3DS();

		/// Destructor
		~CLoader_3DS();
		
		/// loads a scene from file
		void loadScene(const char filename[], CScene &scene);


	private:
		
		/// reads any type from file
		template <typename T>
		void readData(T &data) const {
		
			fread(&data,sizeof(T),1,m_fptr);
		}
		
		/// vector specialization of read template
		template <> 
		void readData<CVector3d>(CVector3d &data) const {

			readData(data[0]);
			readData(data[2]);
			readData(data[1]);
		}

		/// reads a nullterminated character string from file
		void readString(char str[]) const;

		/// reads [n] amount of bytes into data
		void read(void *data, int n);

		/// reads a chuck structure from file
		void readChunk(Chunk &chunk) const;

		// load objects from .3ds 
		void loadObject(const std::string &name, CScene &object, long chunkLength);
		void loadLight();
		void loadCamera(const std::string &name, CScene &object, long chunkLength);
		void loadTriMesh(CMesh &object, long chunkLength);
		void loadEditScene(CScene &object, long chunkLength);
		
		// load keyframing
		void loadKeyFraming(CScene &scene, long chunkLength);
		void loadKeyFramingFrames(CScene &scene);
		void loadKeyFramingLight(CScene &scene, long);
		void loadKeyFramingCamera(CScene &scene, long);
		void loadKeyFramingCameraTarget(CScene &scene, long);
		void loadKeyFramingMesh(CScene &scene, long);

		// find object which owns keyframing
		CObject* getKeyFramingObject(CScene &scene);
		
		/// load keyframing keys ===========================================================

		template <typename T>
		void loadKeys(T* keys, int keyCount) {
		
			int		n = 0;		/// loop counter
			uint16	accFlags;	/// acceeleration flags
			uint32	frameNumber;	

			while (n < keyCount) {
					
				readData(frameNumber);
				keys[n].frameNumber = (float32)frameNumber;

				readData(accFlags);

				/// read acceleration data when found
				for (int C = 0; C < 5; C++) {

					if (accFlags & (1 << C))  {

						switch (1 << C) {

						case TENSION :
						readData(keys[n].tension);
						Helper::Debug::log("E3D::3DS","T = %.2f",keys[n].tension);
						break;
						case CONINUITY :
						readData(keys[n].continuity);
						Helper::Debug::log("E3D::3DS","C = %.2f",keys[n].continuity);
						break;
						case BIAS :
						readData(keys[n].bias);
						Helper::Debug::log("E3D::3DS","B = %.2f",keys[n].bias);
						break;
						case EASE_TO :
						readData(keys[n].easeTo);
						Helper::Debug::log("E3D::3DS","EF = %.2f",keys[n].easeFrom);
						break;
						case EASE_FROM :						
						readData(keys[n].easeFrom);
						Helper::Debug::log("E3D::3DS","ET = %.2f",keys[n].easeTo);
						break;						
						}
					}
				}	
				
				readData(keys[n].data);
				n++;
			}
		}

		/// load keyframing tracks ===========================================================

		template <typename T>
		void loadTrack(T *track) {

			uint32	keysTotal;
			uint16	flags;
			char 	unknown[8];
			
			// read trackmode flags
			readData(flags);

			// read past 8 unknown garb. bytes
			read(unknown,8);

			// read amount of keys in track
			readData(keysTotal);
			track->resize(keysTotal);
			
			Helper::Debug::log("E3D::3DS","TOTAL KEYS IN TRACK = %d\n",keysTotal);

			// load keys
			loadKeys(track->getKeys(), keysTotal);
				
			// precalculate TCB tangents
			track->calculateTangents(); 
		}
		
		/// ==================================================================================
		
		// trimesh data
		void loadTriMeshVertices(CMesh &object);
		void loadTriMeshFaces(CMesh &object);
		void loadTriMeshMatrix(CMesh &object);
		void loadTriMeshMapping(CMesh &object);
		
		/// Chunk type enumeration
		enum {
			
			CHUNK_MAIN			=	0x4d4d,		///< Main chunk
			CHUNK_EDIT			=	0x3d3d,		///< 3DS edit chunk
			
			CHUNK_OBJ			=	0x4000,		///< Object block chunk
			CHUNK_OBJ_HIDE		=	0x4010,		///< Object hidden
			CHUNK_OBJ_CAST		=	0x4012,		///< Object casting 
			CHUNK_OBJ_TRIMESH	=	0x4100,		///< Object trimesh
			CHUNK_OBJ_LIGHT		=	0x4600,		///< Object light
			CHUNK_OBJ_CAMERA	=	0x4700,		///< Object camera
			
			CHUNK_TRIMESH_VLIST	=	0x4110,		///< Trimesh vertex list
			CHUNK_TRIMESH_FLIST	=	0x4120,		///< Trimesh face list
			CHUNK_TRIMESH_MLIST	=	0x4140,		///< Trimesh mapping coordinate list
			CHUNK_TRIMESH_LOCAL	=	0x4160,		///< Trimesh local coordinate system
			CHUNK_TRIMESH_EDCOL	=	0x4165,		///< Trimesh color in editor
			
			CHUNK_FLIST_MATLIST	=	0x4130,		///< Face material list
			
			CHUNK_LIGHT_SPOT	=	0x4610,		///< Light spotlight
			CHUNK_LIGHT_OFF		=	0x4620,		///< Light off
			CHUNK_LIGHT_ATTOFF	=	0x4625,		///< Light attenuation off
			CHUNK_LIGHT_RNGSTRT =	0x4659,		///< Light range start
			CHUNK_LIGHT_RNGSTOP	=	0x465a,		///< Light range 
			CHUNK_LIGHT_MULTIP	=	0x465b,		///< Light multiplier

			CHUNK_MTRL			=	0xafff,		///< Material block chunk
			CHUNK_MTRL_NAME		=	0xa000,		///< Material name
			CHUNK_MTRL_AMBIENT	=	0xa010,		///< Material ambient color
			CHUNK_MTRL_DIFFUSE	=	0xa020,		///< Material diffuse color
			CHUNK_MTRL_SPECULAR =	0xa030,		///< Material specular color
			CHUNK_MTRL_SHINEPER =	0xa040,		///< Material shininess percent
			CHUNK_MTRL_SHINESTR =	0xa040,		///< Material shininess strength percent
			CHUNK_MTRL_ALPHAPER =	0xa050,		///< Material alpha percent
			CHUNK_MTRL_ALPHASTR =	0xa052,		///< Material alpha strength percent
			
			CHUNK_KEYFRAME			=	0xb000,	///< Keyframing block chunk
			
			CHUNK_KF_LIGHT_AMBIENT	=	0xb001,	///< KeyFrame ambient light info
			CHUNK_KF_LIGHT_OMNI		=	0xb005, ///< KeyFrame omni light info
			CHUNK_KF_LIGHT_SPOT		=	0xb006, ///< KeyFrame omni light info
			CHUNK_KF_LIGHT_TARGET	=	0xb007, ///< KeyFrame omni light info
			CHUNK_KF_MESH			=	0xb002, ///< KeyFrame mesh info
			CHUNK_KF_CAMERA			=	0xb003, ///< KeyFrame camera info
			CHUNK_KF_CAMERA_TARGET	=	0xb004, ///< KeyFrame camera target info
			CHUNK_KF_FRAMES			=	0xb008,	///< Keyframe start and end frame
			CHUNK_KF_OBJECT_PIVOT	=	0xb013,	///< Keyframe object pivot point
			CHUNK_KF_OBJECT_NAME	=	0xb010,	///< Keyframe object pivot point
			
			CHUNK_TRACK_POS			=	0xb020,	///< Keyframe position track
			CHUNK_TRACK_ROT			=	0xb021,	///< Keyframe rotation track
			CHUNK_TRACK_SCALE		=	0xb022,	///< Keyframe scale track
			CHUNK_TRACK_FOV			=	0xb023,	///< Keyframe field of view track
			CHUNK_TRACK_ROLL		=	0xb024,	///< Keyframe roll track
			CHUNK_TRACK_COLOR		=	0xb025,	///< Keyframe color track
			CHUNK_TRACK_MORPH		=	0xb026,	///< Keyframe morph track
			CHUNK_TRACK_HOTSPOT		=	0xb027,	///< Keyframe hotspot track
			CHUNK_TRACK_FALLOFF		=	0xb028,	///< Keyframe falloff track
			CHUNK_TRACK_HIDE		=	0xb029,	///< Keyframe hide track		
		};	

		// keyframe acceleration data bitsettings
		enum ACC_SET {

			TENSION		= 0x01,
			CONINUITY	= 0x02,
			BIAS		= 0x04,
			EASE_TO		= 0x08,
			EASE_FROM	= 0x10,
		};

		FILE*	m_fptr;		///< FILE pointer
	};


//================================================================================
}


#endif
