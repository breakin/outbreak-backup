#include "e3d_3ds.h"
#include <helper\core\debug\debug.h>
#include <windows.h>
#include "..\..\e3d_exception.h"
#include "..\..\e3d_sysdef.h"
#include "..\..\math\e3d_vector.h"
#include "..\..\keyframing\e3d_tracks.h"

using namespace Eternity;

CLoader_3DS::CLoader_3DS() {

}

//================================================================

CLoader_3DS::~CLoader_3DS() {

}

//================================================================

void CLoader_3DS::readChunk(CLoader_3DS::Chunk &chunk) const {

	readData(chunk.m_id);
	readData(chunk.m_length);
}

//================================================================

void CLoader_3DS::read(void *data, int n) {

	fread(data,1,n,m_fptr);
}

//================================================================

void CLoader_3DS::readString(char str[]) const {

	int ch;
	int C =0;

	ch = fgetc(m_fptr);
	
	while (ch != '\0' && ch != EOF) {//getc(m_fptr))//m_fptr)) != NULL) {
		
		str[C++] = ch;
		ch = fgetc(m_fptr);	
	}
	
	str[C] = '\0';
//	E3D_LOG("E3D::3DS","NAME = %s\n",str,C);
}

//================================================================

void CLoader_3DS::loadScene(const char filename[], CScene &scene) {

	m_fptr = fopen(filename,"rb");

	if (m_fptr == NULL)
		throw CException("CLoader_3DS::Could not load %s",filename);

	
	Chunk chunk;
	
	// read main chunk
	readChunk(chunk);
	if (chunk.m_id != 0x4D4D) {
		
		throw CException("CLoader_3DS::%s in not a valid .3ds file!",filename);
	}

	// set C to 6 (sizof chunk)
	long C = 6;

	// L is Limit - size of 3ds data
	long L = chunk.m_length;
	
	// read version
	readChunk(chunk);
	
	uint32 version;
	readData(version);

	C += chunk.m_length;

	while (C < L) {
		
		readChunk(chunk);
			
		switch (chunk.m_id) {
			
		case CHUNK_EDIT:
			loadEditScene(scene, chunk.m_length - 6);
			//C = L; // return when 1 object where loaded
		break;

		case CHUNK_KEYFRAME:
			E3D_LOG("E3D::3DS","loading keyframing!\n");
			loadKeyFraming(scene, chunk.m_length - 6);
		break;
		
		default:
			fseek(m_fptr,chunk.m_length - 6,SEEK_CUR);
		}

		C+= chunk.m_length;
	}
	
	// update initial matrices
	scene.updateKeyFraming(0.0f);

	fclose (m_fptr);
}

//================================================================

void CLoader_3DS::loadTriMesh(CMesh &object, long chunkLength) {

	long	C=0;
	Chunk	chunk;
	int		extra;
	
	while (C < chunkLength) {
	
		readChunk(chunk);
		
		extra = 0;
		switch (chunk.m_id) {

		// case vertexlist
		case CHUNK_TRIMESH_VLIST:
		//extra = 2;
		loadTriMeshVertices(object);
		break;
		
		// case facelist
		case CHUNK_TRIMESH_FLIST:
		loadTriMeshFaces(object);
		break;
		
		case CHUNK_TRIMESH_MLIST:
		loadTriMeshMapping(object);
		break;
		// case local object matrix
		case CHUNK_TRIMESH_LOCAL:
		loadTriMeshMatrix(object);
		break;

		default:
		C+=chunk.m_length;
		fseek(m_fptr,chunk.m_length - 6, SEEK_CUR);
		break;
		}
		//C+=chunk.m_length;
		//fseek(m_fptr,chunk.m_length - 6 - extra,SEEK_CUR);
	}
}

//================================================================

void CLoader_3DS::loadTriMeshMapping(CMesh &object) {

	uint16 nVerts;

	readData(nVerts);
	
	// SKIP FOR NOW

	// check if vertices not yet are allocated
	if (object.getVertexBuffer()->getSize() == 0)
		object.getVertexBuffer()->resize(nVerts);
	
	float32 u,v;

	for (int C =0 ; C < nVerts; C++) {
	
		readData(u);
		readData(v);
	//	E3D_LOG("E3D::3DS","UV = [%.2f,%.2f]\n",object.verts[C].u,object.verts[C].v);
	}
}

//================================================================

void CLoader_3DS::loadTriMeshMatrix(CMesh &object) {
	
	CMatrix4x4 &objMatrix = object.getMatrix();
	
	// skip rotation part of matrix
	float32 temp;
	
	for (int n = 0; n < 9; n++)
		readData(temp);
	
	objMatrix.zero();
	objMatrix.makeIdentity();

	// read translation
	readData(objMatrix[3][0]);
	readData(objMatrix[3][2]);
	readData(objMatrix[3][1]);
}

//================================================================

void CLoader_3DS::loadLight() {

}

//================================================================

void CLoader_3DS::loadCamera(const std::string &name, CScene &scene, long chunkLength) {

	CCamera	*cam;		// new camera
	float32	px,py,pz;	// position vector comp
	float32 tx,ty,tz;	// target vector comp
	float32 bank,lense;	// bank, lens of camera
	
	// allocate a new camera and add it to scene
	cam = new CCamera;
	scene.addCamera(cam);
	
	// set camera name
	cam->setName(name);
		
	E3D_LOG("E3D::3DS","CAMERA NAME = %s\n",name.c_str());
	// set owner to scene
	cam->setOwner(cam->OWNER_SCENE);

	// read position vector
	readData(px);
	readData(pz);
	readData(py);	
	
	// read target vector
	readData(tx);
	readData(tz);
	readData(ty);
	
	// read bank and lense
	readData(bank);
	readData(lense);

	// set position
	cam->setPosition(CVector3d(px,py,pz));
	cam->setTarget(CVector3d(tx,ty,tz));
	cam->setRoll(0);
	cam->setFOV(45.0 * E3D_PI / 180.0);
}

//================================================================

void CLoader_3DS::loadEditScene(CScene &scene, long chunkLength) {

	Chunk chunk;
	char objName[256];
	uint32 C = 0;

	while (C < chunkLength) {
		
		readChunk(chunk);
		
		long pos = ftell(m_fptr);

		// check id to determine which type
		switch (chunk.m_id) {
		
		case CHUNK_OBJ:
			
			// get object name
			readString(objName);
			loadObject(objName, scene, chunk.m_length - 6 - strlen(objName) - 1);
		
		break;
		
		default:	
			
			// read past chunk
			fseek(m_fptr,chunk.m_length - 6,SEEK_CUR);
		}
		
		// manually seek to chunk after object, in case something wasn't correcly read..
		fseek(m_fptr,pos + chunk.m_length - 6,SEEK_SET);
		C+= chunk.m_length;
	}
	
}

//================================================================

void CLoader_3DS::loadObject(const std::string &name, CScene &scene, long chunkLength) {

	Chunk		chunk;
	long		C = 0;
	int			D;
	float		radius;
	CMatrix4x4	m;
	CVector3d	a,b;
	CMesh*		mesh;
	CVertex*	meshVerts;
	CFace*		meshFaces;
		
	while (C < chunkLength) {
		
		readChunk(chunk);
		
		switch (chunk.m_id) {
		
		case CHUNK_OBJ_TRIMESH:
			
			mesh = new CMesh;
			mesh->setName(name);
			mesh->setOwner(mesh->OWNER_SCENE);
			
			// add mesh to scene
			scene.addMesh(mesh);
			
			// load trimesh
			loadTriMesh(*mesh, chunk.m_length - 6);
					
			// obain 
			meshVerts = mesh->getVertexBuffer()->get();
			meshFaces = mesh->getFaceBuffer()->get();
			
			// transform vertices into objectspace
			for (D=0; D < mesh->getVertexCount(); D++) {

				float x = mesh->getMatrix()[3][0];
				float y = mesh->getMatrix()[3][1];
				float z = mesh->getMatrix()[3][2];	
				
				meshVerts[D].local -= CVector3d(x,y,z);
				mesh->setPosition(CVector3d(x,y,z));
			}
			

			// calc face normals
			for (D=0; D < mesh->getFaceCount(); D++) {

				a = meshFaces[D].baseCorners[1].vertex->local - meshFaces[D].baseCorners[0].vertex->local;
				b = meshFaces[D].baseCorners[2].vertex->local - meshFaces[D].baseCorners[0].vertex->local;

				a.normalize();
				b.normalize();

				meshFaces[D].normal = b % a;
				meshFaces[D].normal.normalize();
			}
				
			// set bsphere's centre 
			mesh->getBSphere().setCentre(CVector3d(mesh->getMatrix()[3][0],mesh->getMatrix()[3][1],mesh->getMatrix()[3][2]));

			// calculate bounding sphere
			radius = meshVerts[0].local.getLength();

			for (D=1; D < mesh->getVertexCount(); D++) {
		
				if (meshVerts[D].local.getLength() > radius)
					radius = meshVerts[D].local.getLength();
			}

			mesh->getBSphere().setRadius(radius);

		break;
				
		case CHUNK_OBJ_CAMERA:
			loadCamera(name,scene,chunk.m_length - 6);
		break;

		case CHUNK_OBJ_LIGHT:
		// fall through to default
		default:
			fseek(m_fptr,chunk.m_length - 6,SEEK_CUR);
		}
		
		C+= chunk.m_length;
	}
}

//================================================================

void CLoader_3DS::loadTriMeshVertices(CMesh &object) {
	
	uint16 vtxCnt;
	readData(vtxCnt);
	
	// resize and obtain pointer to mesh's vertices
	object.getVertexBuffer()->resize(vtxCnt);
	CVertex* verts = object.getVertexBuffer()->get();
		
	for (int C=0; C < vtxCnt; C++) {
		
		// store vertice data, y = z and z = inverse of y (-1 * y)
		readData(verts[C].local[0]);
		readData(verts[C].local[2]);	
		readData(verts[C].local[1]);
		//verts[C].local[2] = - (verts[C].local[2]);
	}
}

//================================================================

void CLoader_3DS::loadTriMeshFaces(CMesh &object) {
	
	uint16 fceCnt;
	uint16 fceIdx;
	static int j = 0;

	// read amount of faces
	readData(fceCnt);

	// get vertex buffer
	CVertex *vertices = object.getVertexBuffer()->get();
	
	// get facebuffer
	CFaceBuffer *faceBuffer = (object.getFaceBuffer());
		
	// resize facebuffer
	faceBuffer->resize(fceCnt);
	
	// load faces from disc
	for (int C=0, everySecond=0;  C < fceCnt; C++, everySecond=1-everySecond) {
	
			readData(fceIdx);
			faceBuffer->operator[](C).baseCorners[0].vertex = &vertices[fceIdx];
			readData(fceIdx);
			faceBuffer->operator[](C).baseCorners[1].vertex = &vertices[fceIdx];
			readData(fceIdx);
			faceBuffer->operator[](C).baseCorners[2].vertex = &vertices[fceIdx];
		
		// set face color, every second to a different color.
		if (j == 0) 
			faceBuffer->operator[](C).color = (j == 0) ? 0x000022 : 0x00120000;
		else 
			faceBuffer->operator[](C).color = 0x002211;
		
		// Set default material
		if (everySecond==0) {
			faceBuffer->operator[](C).materialName = "flat";
		} else {
			faceBuffer->operator[](C).materialName = "flat";
		}

		j = 1 - j;		
		
		readData(fceIdx);
	}
}

//================================================================

void CLoader_3DS::loadKeyFraming(CScene &scene, long chunkLength) {

	long C = 0;
	Chunk chunk;

	while (C < chunkLength) {

		readChunk(chunk);

		switch (chunk.m_id) 
		{
		
		case CHUNK_KF_LIGHT_AMBIENT:
		loadKeyFramingLight(scene, chunk.m_length - 6);
		break;
		
		case CHUNK_KF_LIGHT_OMNI:
		loadKeyFramingLight(scene, chunk.m_length - 6);
		break;

		case CHUNK_KF_LIGHT_SPOT:
		loadKeyFramingLight(scene, chunk.m_length - 6);
		break;

		case CHUNK_KF_LIGHT_TARGET:
		loadKeyFramingLight(scene, chunk.m_length - 6);
		break;
		
		case CHUNK_KF_MESH:		
		loadKeyFramingMesh(scene, chunk.m_length - 6);
		break;

		case CHUNK_KF_CAMERA:
		E3D_LOG("E3D::3DS","CAMERA\n");
		loadKeyFramingCamera(scene, chunk.m_length - 6);
		break;

		case CHUNK_KF_CAMERA_TARGET:
		E3D_LOG("E3D::3DS","CAMERA TARGET\n");
		loadKeyFramingCameraTarget(scene, chunk.m_length - 6);
		break;
		
		case CHUNK_KF_FRAMES:
		loadKeyFramingFrames(scene);
		break;

		default:	
		fseek(m_fptr,chunk.m_length - 6,SEEK_CUR);
		}
		
		C+= chunk.m_length;
	}
}

//================================================================

void CLoader_3DS::loadKeyFramingFrames(CScene &scene) {

	uint32 start;
	uint32 end;
	readData(start);
	readData(end);

	E3D_LOG("E3D::3DS","KFINFO : START/END FRAME = [%d,%d]\n",start,end);
}

//================================================================

void CLoader_3DS::loadKeyFramingLight(CScene &scene, long length) {

	E3D_LOG("E3D::3DS","KFINFO : Load Light Keyframing\n");
	fseek(m_fptr,length,SEEK_CUR);
}

//================================================================

void CLoader_3DS::loadKeyFramingCamera(CScene &scene, long length) {

 	E3D_LOG("E3D::3DS","KFINFO : Load Camera Keyframing\n");
	
	// DO NOT READ CAMERA DATA
//	fseek(m_fptr,length,SEEK_CUR);
//	return;

	Chunk		chunk;
	CCamera*	camera;
	long		C = 0;
	long		current;

	while (C < length) {

		readChunk(chunk);

		switch (chunk.m_id) {
		
		case CHUNK_KF_OBJECT_NAME:

		// store current file position
		current = ftell(m_fptr);
		current+= chunk.m_length-6;

		camera= (CCamera*)getKeyFramingObject(scene);

		// set to offset after chunk
		fseek(m_fptr,current,SEEK_SET);
		break;	
		
		// mesh tracks
		case CHUNK_TRACK_POS:
		E3D_LOG("E3D::3DS","CAMERA POS!!\n");
		loadTrack(camera->getPositionTrack());
		break;

		case CHUNK_TRACK_FOV:
		E3D_LOG("E3D::3DS","CAMERA FOV!!\n");
		loadTrack(camera->getFOVTrack());
		break;
		
		case CHUNK_TRACK_ROLL:
		E3D_LOG("E3D::3DS","CAMERA ROLL!!\n");
		loadTrack(camera->getRollTrack());
		break;
		
		case CHUNK_TRACK_ROT:
		E3D_LOG("E3D::3DS","CAMERA ROT!!\n");

		case CHUNK_KF_OBJECT_PIVOT:
		case CHUNK_TRACK_COLOR:		
		case CHUNK_TRACK_MORPH:
		default:
		fseek(m_fptr,chunk.m_length-6,SEEK_CUR);
		}
	
		C+=chunk.m_length;
	}
}

//================================================================

void CLoader_3DS::loadKeyFramingCameraTarget(CScene &scene, long length) {

 	E3D_LOG("E3D::3DS","KFINFO : Load Camera Target Keyframing\n");
	
	Chunk		chunk;
	CCamera*	camera;
	long		C = 0;
	long		current;

	while (C < length) {

		readChunk(chunk);

		switch (chunk.m_id) {
		
		case CHUNK_KF_OBJECT_NAME:

		// store current file position
		current = ftell(m_fptr);
		current+= chunk.m_length-6;

		camera= (CCamera*)getKeyFramingObject(scene);

		// set to offset after chunk
		fseek(m_fptr,current,SEEK_SET);
		break;	
		
		// mesh tracks
		case CHUNK_TRACK_POS:
		loadTrack(camera->getTargetTrack());
		break;

		case CHUNK_TRACK_FOV:
		E3D_LOG("E3D::3DS","CAMERA TARGET FOV!!\n");
		loadTrack(camera->getFOVTrack());
		break;
		
		case CHUNK_TRACK_ROLL:
		E3D_LOG("E3D::3DS","CAMERA TARGET ROLL!!\n");
		loadTrack(camera->getRollTrack());
		break;
		
		case CHUNK_TRACK_ROT:
		E3D_LOG("E3D::3DS","CAMERA ROTATION!!\n");
		case CHUNK_KF_OBJECT_PIVOT:
		case CHUNK_TRACK_COLOR:		
		case CHUNK_TRACK_MORPH:
		default:
		fseek(m_fptr,chunk.m_length-6,SEEK_CUR);
		}
	
		C+=chunk.m_length;
	}
}

//================================================================

void CLoader_3DS::loadKeyFramingMesh(CScene &scene, long length) {

	E3D_LOG("E3D::3DS","KFINFO : Load Mesh Keyframing\n");
	Chunk	chunk;
	CMesh*	mesh;
	long	C = 0;
	long	current;

	while (C < length) {

		readChunk(chunk);

		switch (chunk.m_id) {
		
		case CHUNK_KF_OBJECT_NAME:

		// store current file position
		current = ftell(m_fptr);
		current+= chunk.m_length-6;

		mesh = (CMesh*)getKeyFramingObject(scene);

		// set to offset after chunk
		fseek(m_fptr,current,SEEK_SET);
		break;	
		
		// mesh tracks
		case CHUNK_TRACK_POS:
		loadTrack(mesh->getPositionTrack());
		break;

		case CHUNK_TRACK_ROT:
		loadTrack(mesh->getRotationTrack());
		break;
		
		case CHUNK_TRACK_SCALE:
		loadTrack(mesh->getScaleTrack());
		break;

		case CHUNK_KF_OBJECT_PIVOT:
		case CHUNK_TRACK_COLOR:		
		case CHUNK_TRACK_MORPH:
		default:
		fseek(m_fptr,chunk.m_length-6,SEEK_CUR);
		}
	
		C+=chunk.m_length;
	}
	
}

//================================================================

CObject* CLoader_3DS::getKeyFramingObject(CScene &scene) {
	
	static char name[255];
	uint16		flags[3];
	
	readString(name);
	E3D_LOG("E3D::3DS","NAME OF OBJECT TO FIND = %s\n",name);
	readData(flags[0]);
	readData(flags[1]);
	readData(flags[2]);
	return scene.getObject(name);
}

//================================================================
