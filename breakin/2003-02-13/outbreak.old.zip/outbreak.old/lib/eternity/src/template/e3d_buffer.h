#ifndef __ETERNITY_TEMPLATE_BUFFER_INC__
#define __ETERNITY_TEMPLATE_BUFFER_INC__

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	TBuffer
	 * @brief	A Template container of linearly sequenced data.
	 * @author	Peter Nordlander
	 * @date	2001-06-19
	 */

	template<typename T>
	class TBuffer 
	{
	public:
	
		TBuffer(int size = 0);
		~TBuffer();
		
		// resize buffer to [size] elements
		void resize(int size);

		// release buffer, deallocate memory
		void release();
		
		// returns number of elements in sequence
		int getSize() const;

		// get direct access to data
		T* get();
		const T const * get() const;

		// operator [] return reference to element at index [i]
		T& operator[] (int index) const;

	protected:
		
		int	m_size;		///< Buffer size (in <T>elements)
		T*	m_data;		///< Buffer data
	};

//=======================================================================

template<typename T>
TBuffer<T>::TBuffer(int size) {

	// initialize m_data to NULL	
	m_data = NULL;
	m_size = 0;

	// check invalid range
	if (size > 0)
		resize(size);
}
//=======================================================================

template<typename T>
TBuffer<T>::~TBuffer() {

	// release and deallocate data
	release();
}

//=======================================================================

template<typename T>
void TBuffer<T>::resize(int size) {
	
	if (m_data != NULL)
		release();
	
	// check range

	m_data = new T[size];
	m_size = size;
}

//=======================================================================

template<typename T>
void TBuffer<T>::release() {
	
	if (m_size > 0) {
		// delete allocated data
		delete[] m_data;
		m_data = NULL;
		m_size = 0;
	}
}

//=======================================================================

template<typename T>
E3D_INLINE int TBuffer<T>::getSize() const {

	return m_size;
}

//=======================================================================

template <typename T>
const T const * TBuffer<T>::get() const {

	return m_data;
}

//=======================================================================

template <typename T>
T* TBuffer<T>::get() {

	return m_data;
}

//=======================================================================

template <typename T>
T& TBuffer<T>::operator[] (int index) const {

	return m_data[index];
}

}

#endif