#ifndef __ETERNITY_TEMPLATE_FACELIST_INC__
#define __ETERNITY_TEMPLATE_FACELIST_INC__

#include "..\e3d_sysdef.h"
#include "..\face\e3d_face.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	TFaceList
	 * @brief	List template for different face formats
	 * @author	Peter Nordlander
	 * @date	2001-06-19
	 */
	
	template <typename T>
	class TFaceList {
	public:
		
		// constructor
		TFaceList();

		// add a face to beginning of list
		void addFace(T *face);
		
		// clear list, ie) unlink all elements by setting first to NULL
		void clear();
		
		// return first face in list
		T* getFirstFace() const;

	protected:

		T*	m_first;	///< Pointer to first element
	};

	// Typedefs
	typedef TFaceList<CFace> CFaceList;

//=================================================================================

template <typename T>
E3D_INLINE TFaceList<T>::TFaceList() {

	m_first = NULL;
}		

//=================================================================================

template <typename T>
E3D_INLINE void TFaceList<T>::addFace(T *face) {

	face->nextFace = m_first;
	m_first = face;
}

//=================================================================================

template <typename T>
E3D_INLINE void TFaceList<T>::clear() {

	m_first = NULL;
}

//=================================================================================

template <typename T>
E3D_INLINE T* TFaceList<T>::getFirstFace() const {

	return m_first;
}

//=================================================================================
//=================================================================================
//=================================================================================

}

#endif