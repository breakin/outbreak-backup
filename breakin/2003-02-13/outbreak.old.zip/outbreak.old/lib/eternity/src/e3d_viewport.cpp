#include "e3d_viewport.h"

using namespace Eternity;

//====================================================================================

CViewPort::CViewPort(uint32 left, uint32 top, uint32 width, uint32 height) {

	// Call set
	set(left, top, width, height);
}

//====================================================================================

CViewPort::~CViewPort() {

	// Remove zbuffer
	releaseZBuffer();
}

//====================================================================================

CViewPort::set(uint32 _left, uint32 _top, uint32 _width, uint32 _height) {
	
	uint32 oldWidth  = width;
	uint32 oldHeight = height;

	// Set coords and size
	left   = _left;
	top    = _top;
	width  = _width;
	height = _height;

	// Only change zbuffer if size is changed
	if (width!=oldWidth || height!=oldHeight) {
	
		// ZBuffer
		zBuffer = NULL;
		if (width && height) createZBuffer();
	}
}

//====================================================================================

void CViewPort::createZBuffer() {

	// Release if neccessary
	if (zBuffer != NULL) releaseZBuffer();

	// Create ZBuffer with same size
	zBuffer = new CZBuffer(width, height);
}

//====================================================================================

void CViewPort::releaseZBuffer() {

	// Delete ZBuffer and set to NULL
	delete zBuffer;
	zBuffer = NULL;
}

//====================================================================================
