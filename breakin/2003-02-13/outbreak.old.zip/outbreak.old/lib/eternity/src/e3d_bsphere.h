#ifndef __ETERNITY_BSPHERE_INC__
#define __ETERNITY_BSPHERE_INC__

#include "math\e3d_vector.h"

namespace Eternity {
	
	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CBSphere
	 * @brief	Represents an objects bounding sphere, and its functionality
	 * @author	Peter Nordlander
	 * @date	2001-05-28
	 */
	
	class CBSphere
	{
	private:
		
		float32		m_radius;	///< Sphere radius
		CVector3d	m_centre;	///< Sphere centre
		uint32		m_clipMask;	///< Sphere plane index intersecion mask
		
	public:
		
		// Bound Sphere intersection constants
		enum {

			INSIDE  = 0x00000000,
			OUTSIDE = 0x80000000,
		};

		// get bitmask containing all planes within a frustum the spheres intersects with
		void setClipMask(const uint32 clipMask);
		uint32 getClipMask() const;
		
		// get/set radius of sphere
		float32 getRadius() const;
		void setRadius(const float32 radius);

		// get/set centre position
		const CVector3d& getCentre() const;     
		void setCentre(const CVector3d &centre);
	};

//=================================================================================================

E3D_INLINE float32 CBSphere::getRadius() const{

	return m_radius;
}

//=================================================================================================

E3D_INLINE const CVector3d& CBSphere::getCentre() const{

	return m_centre;
}

//=================================================================================================

E3D_INLINE void CBSphere::setCentre(const CVector3d &centre) {

	m_centre = centre;
}

//=================================================================================================

E3D_INLINE void CBSphere::setRadius(const float32 radius) {

	m_radius = radius;
}

//=================================================================================================

E3D_INLINE uint32 CBSphere::getClipMask() const {

	return m_clipMask;
}

//=================================================================================================

E3D_INLINE void CBSphere::setClipMask(const uint32 clipMask) {

	m_clipMask = clipMask;
}

//=================================================================================================
}

#endif