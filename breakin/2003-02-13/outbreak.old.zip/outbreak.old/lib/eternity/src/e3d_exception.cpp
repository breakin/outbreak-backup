#include "e3d_exception.h"
#include "e3d_sysdef.h"

using namespace Eternity;

//======================================================================

CException::CException(const char msg[],...) {

	char excMsg[256];
	std::string prefix;

	va_list args;
	va_start(args,msg);
	vsprintf (excMsg,msg,args);
	prefix = (EXCEPTION_PREFIX);
	prefix+= (excMsg);
	exception::operator = (prefix.c_str());
	
	// log exception messaga
	E3D_LOG("EXCEPTION", excMsg);
}

//======================================================================



