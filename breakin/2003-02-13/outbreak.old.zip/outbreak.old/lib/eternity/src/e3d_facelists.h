#ifndef __ETERNITY_FACELISTS_INC__
#define __ETERNITY_FACELISTS_INC__

#include "template\e3d_facelist.h"
#include "face\e3d_face.h"

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CFaceLists
	 * @brief	Container for list's of different face formats
	 * @author	Peter Nordlander
	 * @date	2001-05-23
	 */
		
//==============================================================================
// typedef face formats template list's

	typedef TFaceList<CFace> CFaceList;
	
//==============================================================================
// CFaceList container structure

	struct CFaceLists
	{
		CFaceList	faces;			///< Facelist of dynamic faces
		CFaceList	facesAlpha;		///< Facelist of transparent faces
		CFaceList	facesBSP;		///< Facelist of BSP sorted faces
	};

//==============================================================================

}

#endif
