#ifndef __ETERNITY_BOUNDING_BOX_INC__
#define __ETERNITY_BOUNDING_BOX_INC__

namespace Eternity {

	/**
	 * [eTernity 3D Engine]
	 * ====================
	 * @class	CBoundingBox
	 * @brief	 
	 * @author	Peter Nordlander
	 * @date	2001-05-30
	 */

	class CBBox
	{
	public:
		
		CBBox();
		~CBBox();
			
	protected:

		CVector3d	m_min;
		CVector3d	m_max;
	};
}

#endif