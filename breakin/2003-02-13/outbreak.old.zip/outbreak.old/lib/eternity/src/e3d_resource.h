#ifndef __ETERNITY_RESOURCE_INC__
#define __ETERNITY_RESOURCE_INC__

namespace Eternity {

	class CResource {

	private:
		// Owner variable
		uint32 m_owner;

	public:
		// Enumerates for external use
		enum {
			OWNER_INTERNAL = 0x01,
			OWNER_EXTERNAL = 0x02,
		};

		// Constructor and destructor
		CResource() { }
		~CResource() { }

		// Set ownership
		void setOwner(uint32 owner) { m_owner = owner; }

		// Get ownership
		const uint32 getOwner() { return m_owner; }
	};
}

#endif