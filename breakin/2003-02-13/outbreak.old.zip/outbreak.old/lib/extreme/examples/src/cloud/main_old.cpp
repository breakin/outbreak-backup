#include <x3m_typedef.h>
#include <win32\x3m_threadwindow.h>
#include <x3m_exception.h>
#include <x3m_clock.h>
#include <x3m_color.h>
#include <x3m_system.h>
#include <windows.h>
#include <resource\x3m_materialmanager.h>
#include <resource\x3m_modelmanager.h>
#include <math\x3m_matrix.h>

#include <set>

#include "cloudnode.h"
#include "cloudrender.h"



#include <d3d8.h>
#include <d3dx8math.h>
#define X_WIDTH 640.0f
#define X_HEIGHT 480.0f

#define NUMCLOUDS 10
#define NUMPARTICLESPERCLOUD 50
#define NUMPARTICLES (NUMCLOUDS*NUMPARTICLESPERCLOUD)

//********************************************************************************

struct Particle {
	Extreme::Vector3 pos, viewPos;
	Extreme::uint32  color;
	Extreme::float32 radius;
	Extreme::float32 transparency;

	const bool operator<(const Particle &other) const {
		if (viewPos.z>other.viewPos.z) return true;
			else return false;
	}
};

//********************************************************************************

inline float EvalHermite(float pA, float pB, float vA, float vB, float u)
{
  float u2=(u*u), u3=u2*u;
  float B0 = 2*u3 - 3*u2 + 1;
  float B1 = -2*u3 + 3*u2;
  float B2 = u3 - 2*u2 + u;
  float B3 = u3 - u;
  return( B0*pA + B1*pB + B2*vA + B3*vB );
}

Extreme::TextureHandle createSplatTexture(const int size) {

	Extreme::Debug::log("createSplatTexture", "size=%d", size);

	Extreme::int32 pitch;
	Extreme::Texture::Desc desc;

	Extreme::TextureHandle textureHandle=Extreme::TextureManager::getInstance().createTexture("splatTexture", size,size,32,1);;

	unsigned char *dest=(unsigned char*)(textureHandle->lock(0, pitch, desc));

	Extreme::Debug::log("createSplatTexture", "pitch=%d, dest=%p", pitch, dest);

	// TODO: Check power of 2
	if (desc.mWidth!=desc.mHeight) throw Extreme::Exception("blah");

	std::vector<float> M;
	M.resize(2*size*size);

	float X,Y,Y2,Dist;
	float Incr = 2.0f/float(size);
	int i=0;  
	int j = 0;
	Y = -1.0f;

	for (int y=0; y<size; y++, Y+=Incr) {
	
		Y2=Y*Y;
		X = -1.0f;

		for (int x=0; x<size; x++, X+=Incr, i+=2, j+=4)	{
			Dist = (float)sqrt(X*X+Y2);
			if (Dist>1) Dist=1;
			M[i+1] = M[i] = EvalHermite(0.4f,0,0,0,Dist);// * (1 - noise);
			dest[j+3] = dest[j+2] = dest[j+1] = dest[j] = (unsigned char)(M[i] * 255);
		}

		j+=pitch-size*4;
	}

	textureHandle->unlock();

	return textureHandle;
}              

//********************************************************************************

using namespace Extreme;

struct Vertex
{
	Vector3 mPos;
	uint32	mDiffuse;
	float32 mU;
	float32 mV;
};


// TODO: Optimize, bake eveything into projectionmatrix
//		 Add IndexBuffer
void addQuad(Vertex2D *buffer, const Vector3 &position, const float radius, const uint32 color, const Matrix4x4 &project) {

	buffer[0].mPos.x = (position.x-radius);
	buffer[0].mPos.y = (position.y-radius);
	buffer[0].mU		= 0.0f;
	buffer[0].mV		= 0.0f;

	buffer[1].mPos.x = (position.x+radius);
	buffer[1].mPos.y = (position.y-radius);
	buffer[1].mU		= 1.0f;
	buffer[1].mV		= 0.0f;

	buffer[2].mPos.x = (position.x+radius);
	buffer[2].mPos.y = (position.y+radius);
	buffer[2].mU		= 1.0f;
	buffer[2].mV		= 1.0f;

	buffer[3]=buffer[0];
	buffer[4]=buffer[2];

	buffer[5].mPos.x = (position.x-radius);
	buffer[5].mPos.y = (position.y+radius);
	buffer[5].mU=0.0;
	buffer[5].mV=1.0;
	
	for (int j=0; j<6; j++) {

		buffer[j].mRHW	= 1.0f;
		buffer[j].mDiffuse=color;
		buffer[j].mPos.z=position.z;
		buffer[j].mPos=buffer[j].mPos*project;
		// This (below) could be baked into project matrix (most of)
		
		buffer[j].mPos.x=buffer[j].mPos.x/buffer[j].mPos.z*X_WIDTH /2.0+ X_WIDTH/2.0;
		buffer[j].mPos.y=buffer[j].mPos.y/buffer[j].mPos.z*X_HEIGHT/2.0+X_HEIGHT/2.0;
	}

}

int WINAPI WinMain(HINSTANCE hi, HINSTANCE pi, LPSTR cmdLine, int cmd) {

	try {

		System system;
		RenderSystem	*rs	= system.getRenderSystem();
		SoundSystem		*ss	= system.getSoundSystem();

		rs->config("appl.title","Breakin - Particle1");
		rs->config("appl.windowed","true");
		rs->config("backbuffer.bitdepth","32");
		rs->config("backbuffer.width","640");
		rs->config("backbuffer.height","480");
		rs->config("backbuffer.count", "1");
		rs->config("device.layer", "hal");
		rs->config("device.vsync","false");
		rs->config("fsaa.enable","false");
		rs->config("fsaa.samples","2");
		
		rs->startup();
		
		double frames = 0.0;

		// create vertexbuffers
		VertexBufferHandle particlesVB = ModelManager::getInstance().createVertexBuffer(std::string("particles"), ( D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1), NUMPARTICLES*6, VertexBuffer::USAGE_DYNAMIC);

		// create materials
		MaterialHandle hMaterial = MaterialManager::getInstance().createMaterial(std::string("particleMaterial"), 1);
		
		// get texturelayers
		TextureLayerHandle texLayer = hMaterial->getTextureLayer(0);

		// set texturealayer properties (1)
		texLayer->mTexture=createSplatTexture(32);
		
		texLayer->mEnabled = true;
		texLayer->mAddressMode = TextureLayer::TEXADDRESS_WRAP;
		texLayer->mFilter = TextureLayer::TEXFILTER_ANISOTROPIC;

		ColorValue clearColor;
		Matrix4x4 projectMatrix;
		Matrix4x4 viewMatrix;
		Matrix4x4 matrixScale;

		Msg	msg;

		struct Cloud {
			Extreme::Vector3 pos;
			float32 radius;
			float32 density;
		};

		Cloud clouds[NUMCLOUDS];

		for (int c=0; c<NUMCLOUDS; c++) {
			clouds[c].pos=Vector3(((rand()%1000)-500)/2.0,((rand()%1000)-500)/4.0,((rand()%1000)-500)/4.0);
			clouds[c].radius=(rand()&0xaf)+30;
			clouds[c].density=((rand()&0x3f))+20;
		}

		Particle pdata[NUMPARTICLES];

		const Vector3 lightPos(100,200,-50);
		const Vector3 lightColor(255,255,255);
		const Vector3 lightDirection=(Vector3(0,0,0)-lightPos).getNormalized();

		int p;
		for (c=0, p=0; c<NUMCLOUDS; c++) {
			for (int d=0; d<NUMPARTICLESPERCLOUD; d++, p++) {
				pdata[p].pos.x=(rand()%10000)/10000.0*clouds[c].radius;
				pdata[p].pos.y=(rand()%10000)/10000.0*clouds[c].radius;
				pdata[p].pos.z=(rand()%10000)/10000.0*clouds[c].radius;
				pdata[p].pos+=clouds[c].pos;
				pdata[p].radius=20.0+float(rand()%10000)/10000.0*clouds[c].density;

				float a=500.0/(pdata[p].pos-lightPos).getLength();

				Extreme::Vector3 intensity=lightColor*a;

				if (intensity.x>255.0) intensity.x=255.0;
				if (intensity.y>255.0) intensity.y=255.0;
				if (intensity.z>255.0) intensity.z=255.0;

				pdata[p].color=((rand()%0xff)<<24)+(int(intensity.x)<<16)+(int(intensity.y)<<8)+int(intensity.z);
			}
		}
		
		//projectMatrix.makeProjection(X3M_PI/6, 1.0, 200.0f);
		D3DXMatrixPerspectiveFovLH(
		 (D3DXMATRIX*)&projectMatrix,
		 X3M_PI / 3.0f,
		 X_WIDTH/X_HEIGHT,
		 1.0f, 1000.0f
		 ); 
		
		clearColor.mR = 0.2f;
		clearColor.mG = 0.2f;
		clearColor.mB = 0.7f;
		clearColor.mA = 1.0f;

		bool run = true;

		/* initialize material */
		hMaterial->mShadeMode = Material::SHADE_GOURAUD;
		hMaterial->mFillMode  = Material::FILL_SOLID;
		hMaterial->mCullMode  = Material::CULL_NONE;
		hMaterial->mBlendMode.mSrcFactor = BlendMode::FACTOR_ONE;
		hMaterial->mBlendMode.mDstFactor = BlendMode::FACTOR_INVSRCALPHA;
		hMaterial->mBlendMode.mOp = BlendMode::OP_ADD;
		hMaterial->mDepthBufferEnable=false; // TODO: Should read
		hMaterial->mLightingEnable = false;
		hMaterial->mBlendEnable = true;
		
		Clock timer;
		timer.start();
		frames = 0.0f;

		float deg=0.0;

		while (run) {
			
			const Vector3 camPos(sinf(deg)*900.0, sinf(deg*2.0)*100.0, cosf(deg)*900.0);
			viewMatrix.makeViewLookAt(camPos,pdata[0].pos, deg);

			if (rs->getMessage(msg)) {

				switch (msg.mMsg) 
				{
					case Extreme::MSG_KEYDOWN:

						if (msg.mParam == VK_ESCAPE)
							run = false;
						if (msg.mParam == VK_SPACE) {
							
							rs->config("display.windowed", "false");
							rs->reset();
						}
					break;
					case Extreme::MSG_CLOSE:
						run = false;
				}
			}

			#define SQR(a) ((a)*(a))

			// Transform all particles into viewSpace
			std::set<Particle> particleList;

			for (int p=0; p<NUMPARTICLES; p++) {
				pdata[p].viewPos=pdata[p].pos*viewMatrix;
				if (pdata[p].viewPos.z>1.0) {
					particleList.insert(pdata[p]);					
				}
			}

			int transp=(1.0-exp(-80.0))*255.0;
			if (transp<0) transp=0;
			if (transp>255) transp=255;

			// Create VB for particles
			Vertex2D *buffer=(Vertex2D*)particlesVB->lock(NUMPARTICLES*6);
			
			for (std::set<Particle>::const_iterator i=particleList.begin(); i!=particleList.end(); ++i) {

				float factor=.75*(1.0+SQR((camPos-i->pos).getNormalized()*lightDirection));

				if (factor>1.0) factor=1.0;
				
				const uint32 color=i->color;

				// Make w/o floats
				const uint32 colorWithFactor=
					(int (float( color     &0xff)*factor))+
					(int (float((color>>8 )&0xff)*factor)<<8)+
					(int (float((color>>16)&0xff)*factor)<<16)+
					//(int (float((color>>24)&0xff)*factor)<<24);
					//(color&0xff000000);
					//(int (float((color>>24)&0xff)*factor)<<24);
					(transp<<24);
					

				// TODO: Discard when colorWithFactor equals 0 (or very small)

				addQuad(buffer,i->viewPos,i->radius, colorWithFactor, projectMatrix);
				buffer+=6;
			}

			particlesVB->unlock();
								
			// Begin rendering
			rs->beginScene();
					
			/** set transformation matrices */
			rs->setViewMatrix(viewMatrix);	
			rs->setProjectionMatrix(projectMatrix);

			/** set resources */
			hMaterial->mDepthBufferEnable = false;
			
			/** set matrices */
			//matrix.makeRotXYZ(deg, deg, deg);
			//rs->setWorldMatrix(matrix);
			
			/** render first primitive */
			rs->setMaterial(hMaterial);
			rs->setVertexBuffer(particlesVB);
			rs->renderPrimitive(VertexBuffer::PT_TRILIST, particleList.size()*2);

			rs->endScene();
			rs->present();
			rs->clear(clearColor);
			frames += 1.0f;
			deg+=0.0017f;
		}

		// nulling handles
		particlesVB = NULL;
		hMaterial = NULL;

		rs->shutdown();

		timer.stop();

		// ss->stop();
		char fps_msg[256];
		sprintf (fps_msg, "FPS = %02f", frames/timer.getTime());
		//MessageBox(NULL, fps_msg, "FPS Info", MB_OK);		
		
	}
	catch (Extreme::Exception &e) {
		MessageBox(NULL, e.what(), "Extreme Exception", MB_OK);
	}
	
	return 0;
}