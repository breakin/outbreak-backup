#ifndef CLOUD_PUFF
#define CLOUD_PUFF

#include <x3m_typedef.h>
#include <x3m_exception.h>
#include <x3m_system.h>
#include <math/x3m_vector.h>
#include "cloudrender.h"

namespace Cloud {

	struct Puff {
		
		Extreme::Vector3 pos;
		Extreme::float32 radius;
		Extreme::float32 density;
	};
}

#endif