#ifndef CLOUD_PARTICLE
#define CLOUD_PARTICLE

#include <x3m_typedef.h>
#include <x3m_exception.h>
#include <x3m_system.h>
#include <math/x3m_vector.h>
#include "cloudrender.h"

namespace Cloud {

	struct Particle {
		
		Extreme::Vector3 pos;
		Extreme::float32 radius;
		Extreme::float32 transparency;
		
		// An intensity for this particle PER LIGHT
		std::vector<float> intensity; // char8?
	};
}

#endif