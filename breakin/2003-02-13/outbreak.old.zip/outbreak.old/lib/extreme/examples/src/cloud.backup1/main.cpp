#include <x3m_typedef.h>
#include <win32\x3m_threadwindow.h>
#include <x3m_exception.h>
#include <x3m_clock.h>
#include <x3m_color.h>
#include <x3m_system.h>
#include <windows.h>
#include <resource\x3m_materialmanager.h>
#include <resource\x3m_modelmanager.h>
#include <math\x3m_matrix.h>

#include <set>

#include "cloudnode.h"
#include "cloudrender.h"

#include <d3d8.h>
#include <d3dx8math.h>

#define X_WIDTH 640.0f
#define X_HEIGHT 480.0f

using namespace Extreme;

int WINAPI WinMain(HINSTANCE hi, HINSTANCE pi, LPSTR cmdLine, int cmd) {

	try {

		System system;
		RenderSystem	*rs	= system.getRenderSystem();
		SoundSystem		*ss	= system.getSoundSystem();

		rs->config("appl.title","Breakin - Particle1");
		rs->config("appl.windowed","true");
		rs->config("backbuffer.bitdepth","32");
		rs->config("backbuffer.width","640");
		rs->config("backbuffer.height","480");
		rs->config("backbuffer.count", "1");
		rs->config("device.layer", "hal");
		rs->config("device.vsync","false");
		rs->config("fsaa.enable","false");
		rs->config("fsaa.samples","2");
		
		rs->startup();
		
		double frames = 0.0;

		// Molnpuffar
		Cloud::Puff p;
		p.pos=(Vector3(-100,0,100));
		p.radius=30.0f;
		p.density=0.8f;

		Cloud::Puff p2;
		p.pos=(Vector3(150,0,100));
		p.radius=30.0f;
		p.density=0.2f;

		Cloud::Puff p3;
		p.pos=(Vector3(150,50,-50));
		p.radius=55.0f;
		p.density=1.0f;

		Cloud::Puff p4;
		p.pos=(Vector3(-150,-50,0));
		p.radius=65.0f;
		p.density=1.0f;

		Cloud::PuffList puffList;
		puffList.puffList.push_back(&p);
		puffList.puffList.push_back(&p2);
		puffList.puffList.push_back(&p3);
		puffList.puffList.push_back(&p4);

		// Lampor
		Cloud::Light sun;
		sun.pos=Vector3(0,1000.0,0);
		sun.dir=(Vector3(0,0,0)-sun.pos).getNormalized();
		sun.color=Vector3(200,200,200);		// this one can be changed dynamically
		sun.intensity=1.0;					// this one can be changed dynamically

		Cloud::LightList lightList;
		lightList.ambientColor=Vector3(25,5,5);
		lightList.lightList.push_back(&sun);

		// Initialisera renderingen (imposterhanteraren i framtiden)
		Cloud::Render render;
		render.init();

		// Initalisera molnsystemet
		Cloud::ParticleNode node;
		node.init(render, puffList, lightList);

		ColorValue clearColor;
		
		Matrix4x4 projectMatrix;
		Matrix4x4 viewMatrix;
		
		Msg	msg;

		//projectMatrix.makeProjection(X3M_PI/6, 1.0, 200.0f);
		D3DXMatrixPerspectiveFovLH(
		 (D3DXMATRIX*)&projectMatrix,
		 X3M_PI / 3.0f,
		 X_WIDTH/X_HEIGHT,
		 1.0f, 1000.0f
		 ); 
		
		clearColor.mR = 0.2f;
		clearColor.mG = 0.2f;
		clearColor.mB = 0.7f;
		clearColor.mA = 1.0f;

		bool run = true;
		
		Clock timer;
		timer.start();
		frames = 0.0f;

		float deg=0.0;

		while (run) {

			deg=timer.getTime();
			const float r=sinf(deg)*300.0+400.0;
			const Vector3 camPos(sinf(deg*0.5)*r, cosf(deg*.25)*100.0, cosf(deg*0.5)*r);
			viewMatrix.makeViewLookAt(camPos,Vector3(0,0,0), deg);

			//sun.intensity=sinf(deg)*0.5+0.5;

			if (rs->getMessage(msg)) {

				switch (msg.mMsg) 
				{
					case Extreme::MSG_KEYDOWN:

						if (msg.mParam == VK_ESCAPE)
							run = false;
						if (msg.mParam == VK_SPACE) {
							
							rs->config("display.windowed", "false");
							rs->reset();
						}
					break;
					case Extreme::MSG_CLOSE:
						run = false;
				}
			}

			// Begin rendering
			rs->beginScene();
					
			/** set transformation matrices */
			rs->setViewMatrix(viewMatrix);	
			rs->setProjectionMatrix(projectMatrix);

			/** set matrices */
			//matrix.makeRotXYZ(deg, deg, deg);
			//rs->setWorldMatrix(matrix);

			render.prepareFrame(X_WIDTH,X_HEIGHT);
			node.render(render, lightList,viewMatrix, projectMatrix, camPos);
			render.finishFrame();

			X3M_DEBUG("tjo", "particles drawn=%d, cameraDistTo000=%f", render.mProcessedTotal, camPos.getLength());
		
			rs->endScene();
			rs->present();
			rs->clear(clearColor);
			frames += 1.0f;
		}

		rs->shutdown();

		timer.stop();

		// ss->stop();
		char fps_msg[256];
		sprintf (fps_msg, "FPS = %02f", frames/timer.getTime());
		//MessageBox(NULL, fps_msg, "FPS Info", MB_OK);		
		
	}
	catch (Extreme::Exception &e) {
		MessageBox(NULL, e.what(), "Extreme Exception", MB_OK);
	}
	
	return 0;
}