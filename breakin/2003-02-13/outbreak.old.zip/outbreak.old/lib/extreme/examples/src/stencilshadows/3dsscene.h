#ifndef __EXTREME_3DS_SCENEFORMAT_INC__
#define __EXTREME_3DS_SCENEFORMAT_INC__

#include <math\x3m_vector.h>
#include <x3m_typedef.h>
#include <keyframing\x3m_tracks.h>

// stl
#pragma warning (disable:4786)
#include <vector>
#include <string>
#include <list>


namespace Zippo {

	using namespace Extreme;
	

	/**
	 * 3DS Matrix class
	 */
	struct Matrix_3DS
	{
		/// operator[] 
		float32 * operator [] (int row) { return (float32*)(m_data + (row * 4)); }

		float32 m_data[16];
	};
	/**
	 * 3DS Color
	 */
	struct Color_3DS
	{
		float32	m_r;			///< Red	(0..1)
		float32 m_g;			///< Green	(0..1)
		float32 m_b;			///< Blue	(0..1)
		float32 m_a;			///< Alpha	(0..1)
	};
	
	/**
	 * Texture file entry
	 */
	struct Texture_3DS
	{
		/**
		 * ID number given for invalid ID's or materials which does not contain a texturemap
		 */
		enum {

			ID_NONE	= -1,
		};

		std::string	m_name;		///< Textures filename
		uint32		m_id;		///< Texture ID
		uint32		m_refCount;	///< Texture referencecount
	};

	/**
	 * 3DS Texture properties for a meterial
	 */
	struct TextureInfo_3DS
	{			
		TextureInfo_3DS() { memset (this,0,sizeof(TextureInfo_3DS)); }
		
		uint16		m_flags;	///< Texture flags
		float32		m_percent;	///< Texture percentage
		float32		m_blur;		///< Texture blurriness
		float32		m_scaleU;	///< Texture scale u
		float32		m_scaleV;	///< Texture scale v
		float32		m_offsetU;	///< Texture offset u
		float32		m_offsetV;	///< Texture offset v
		float32		m_rotation;	///< Texture rotation
		Color_3DS	m_rgbTint_1;///< Texture RGB Tint 1
		Color_3DS	m_rgbTint_2;///< Texture RGB Tint 2
		Color_3DS	m_rgbTint_r;///< Texture RGB Tint Red
		Color_3DS	m_rgbTint_g;///< Texture RGB Tint Green
		Color_3DS	m_rgbTint_b;///< Texture RGB Tint Blue
		
		int32		m_textureID;///< Texture's given ID in scene's texture manager
		bool		m_valid;	///< True if texture exists within a material, false otherwise  
	};

	/**
	 * 3DS Material
	 */
	struct Material_3DS
	{	
		/**
		 * Material shade types
		 */
		enum eShadeType
		{
			SHADE_WIRE_FRAME = 0x00,///< Shade with wireframe
			SHADE_FLAT		 = 0x01,///< Shade with flat/face normal calculation
			SHADE_GOURAUD	 = 0x02,///< Shade with vertexcolor interpolation
			SHADE_PHONG		 = 0x03,///< Shade with vertexnormal interpolation
			SHADE_METAL		 = 0x04,///< Shade with lightcalc per pixel 
		};

		// constructor
		Material_3DS() { memset(this, 0 , sizeof (Material_3DS)); }

		/// Material properties
		char 		m_name[80];		///< Material's Name
		Color_3DS	m_diffuse;		///< Material's diffuse color
		Color_3DS	m_specular;		///< Material's specular color
		Color_3DS	m_ambient;		///< Material's ambient color
		float32		m_shininess;	///< Material's shininess percent
		float32		m_shineStrength;///< Material's shininess strength
		float32		m_transparency;	///< Material's transparency percent
		float32		m_transStrength;///< Material's transparency strength
		float32		m_wireFrameSize;///< Material's wireframe size value
		int16		m_shadeType;	///< MAterial's shading type (FLAT/GOURAUD...)
		uint32		m_ID;			///< Material's ID

		/// Material flags
		bool		m_twoSided;		///< Material is two sided
		bool		m_additive;		///< Material is using additive blending
		bool		m_faceMap;		///< Material has a face map
		bool		m_phongSoft;	///< Marerial is using phong softness shading
		bool		m_wireFramed;	///< Material is wireframes?
		bool		m_wireAbs;		///< Material is using wireframe absolut values

		/// Materials textures
		TextureInfo_3DS	m_textMap1;
		TextureInfo_3DS m_textMask1;
		TextureInfo_3DS	m_textMap2;
		TextureInfo_3DS m_textMask2;
		TextureInfo_3DS m_opacMap;
		TextureInfo_3DS m_opacMask;
		TextureInfo_3DS m_bumpMap;
		TextureInfo_3DS m_bumpMask;
		TextureInfo_3DS m_specMap;
		TextureInfo_3DS m_specMask;
		TextureInfo_3DS m_shineMap;
		TextureInfo_3DS m_shineMask;
		TextureInfo_3DS m_reflectMap;
		TextureInfo_3DS m_reflectMask;
	};


	/**
	 * 3DS Texel
	 */
	struct Texel_3DS
	{
		Texel_3DS() : m_u (0.0f), m_v(0.0f) {}

		float32 m_u;	///< U/X axis of mapping pair
		float32 m_v;	///< V/Y axis of mapping pair
	};

	/**
	 * 3DS Face
	 */
	struct Face_3DS
	{
		uint32		m_smoothingGroup;
		std::string	m_material;		///< Face's attached material
		Vector3		m_normal;		///< Face's normal
		int32		m_vertices[3];	///< Face's vertices 
		Extreme::Vector3 m_vertex_normals[3];
		Color_3DS	m_color;
	};

	/**
	 * 3DS TriMesh
	 */
	struct Object_3DS
	{
		virtual ~Object_3DS() {}

		std::string m_name;
	};

	struct TriMesh_3DS : public Object_3DS
	{
		/// constructor/destructor
		TriMesh_3DS() :
					m_bsphere(0.0f) {}

		~TriMesh_3DS() {}
		
		Matrix_3DS				m_matrix;			///< Mesh Matrix
		float32					m_bsphere;			///< Mesh bounding sphere
		Vector3					m_position;			///< Mesh position in world space
		Vector3					m_pivot;			///< Mesh pivot point
		std::vector<Vector3>	m_vertices;			///< Mesh vertices
		std::vector<Texel_3DS>	m_mapping;			///< Mesh mapping cordinates
		std::vector<Face_3DS>	m_faces;			///< Mesh faces

		/// animation tracks
		TrackVector				m_trackPos;		///< Mesh keyframing position track
		TrackVector				m_trackScale;	///< Mesh keyframing scale track
	};

	/**
	 * 3DS Light
	 */
	struct Light_3DS : public Object_3DS
	{
		float32		m_hotspot;
		float32		m_falloff;
		Vector3		m_target;
		Vector3		m_position;

		// animation tracks
		TrackVector		m_trackTarget;
		TrackVector		m_trackPos;
		TrackFloat		m_trackFalloff;
		TrackFloat		m_trackHotspot;
	};

	/**
	 * 3DS Camera
	 */
	struct Camera_3DS : public Object_3DS
	{
		Vector3	m_position;
		Vector3	m_target;
		float32	m_roll;
		float32	m_fov;

		// animation tracks
		TrackVector	m_trackPos;
		TrackVector	m_trackTarget;
		TrackFloat	m_trackRoll;
		TrackFloat	m_trackFov;
	};

	/**
	 * 3DS Scene
	 */
	class Scene_3DS 
	{
	public:

		Scene_3DS() {};
		~Scene_3DS() {};

  		std::list<TriMesh_3DS*>	 m_listMesh;			/// Mesh list
		std::list<Light_3DS*>	 m_listLight;		/// Light list
		std::list<Camera_3DS*>	 m_listCamera;		/// Camera list
		std::vector<Material_3DS>m_listMaterial;		/// Material list		
		std::vector<Texture_3DS> m_textureManager;	///< List raw texture filename as lonh as it's id
	};

}

#endif

