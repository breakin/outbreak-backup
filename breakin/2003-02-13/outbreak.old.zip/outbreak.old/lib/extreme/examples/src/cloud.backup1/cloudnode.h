#ifndef CLOUD_NODE
#define CLOUD_NODE

#include <x3m_typedef.h>
#include <x3m_exception.h>
#include <x3m_system.h>
#include <math/x3m_vector.h>

#include "cloudparticle.h"
#include "cloudrender.h"

#define TRANSPAR Extreme::uint32((1.0-exp(-80.0))*255.0)

namespace Cloud {

	struct Light {
		Extreme::Vector3 pos, color, dir;
		Extreme::float32 intensity;
	};

	struct LightList {
		Extreme::Vector3 ambientColor;
		std::vector<Light*> lightList;
	};

	struct Puff {
		Extreme::Vector3 pos;
		Extreme::float32 radius, density;
	};

	struct PuffList {
		std::vector<Puff*> puffList;
	};

	class ParticleNode {
	private:

		ParticleNode*		childs[8];
		
		bool				leaf;
		Particle			particleLOD;

		void initInternal(const Render &render, const Extreme::Vector3 &midPoint, const Extreme::float32 boxSize, const PuffList &puffList,  const LightList &lightList) {

			particleLOD.pos=midPoint;
			particleLOD.radius=boxSize*2.0;
			particleLOD.intensity.push_back(1.0);

			leaf=true;

			if (boxSize<4.0) {
				// We feel good about being a leaf
				return;
			}

			for (int C=0, X=-1; X<2; X+=2) {
				for (int Y=-1; Y<2; Y+=2) {
					for (int Z=-1; Z<2; Z+=2, C++) {

						const Extreme::Vector3 pos=midPoint+Extreme::Vector3(float(X)*boxSize/2.0,float(Y)*boxSize/2.0,float(Z)*boxSize/2.0);
						
						float childTrans=1.0f;

						for (int p=0; p<puffList.puffList.size(); p++) {
							const Puff* puff=puffList.puffList[p];

							Extreme::Vector3 p=(pos-puff->pos);

							if ((fabs(p.x)-puff->radius<boxSize/2.0) ||
								(fabs(p.y)-puff->radius<boxSize/2.0) ||
								(fabs(p.z)-puff->radius<boxSize/2.0)) {

								childTrans-=puff->density;
							}
						}

						if (childTrans<1.0f) {

							// OK we've got a child
							childs[C]=new ParticleNode;
							childs[C]->initInternal(render, midPoint+Extreme::Vector3(float(X)*boxSize/2.0,float(Y)*boxSize/2.0,float(Z)*boxSize/2.0), boxSize/2.0, puffList, lightList);
							
							// Since we now have a child we can't be a leaf, can we?
							leaf=false;

						} else {

							//X3M_DEBUG("ParticleNode::init", "Ignore %d", C);
							childs[C]=NULL;
						}
					}
				}
			}
		}
		
	public:

		

		void init(const Render &render, const PuffList &puffList,  const LightList &lightList) {

			// Calculate extend of puffs

			bool inited=false;
			Extreme::Vector3 min, max;

			for (int p=0; p<puffList.puffList.size(); p++) {

				Puff *puff=puffList.puffList[p];

				Extreme::Vector3 newMin, newMax;

				newMin=puff->pos-puff->radius*Extreme::Vector3(1,1,1);
				newMax=puff->pos+puff->radius*Extreme::Vector3(1,1,1);

				if (inited=false) {
					min=newMin;
					max=newMax;
				} else {

					if (newMin.x<min.x) min.x=newMin.x;
					if (newMin.y<min.y) min.y=newMin.y;
					if (newMin.z<min.z) min.z=newMin.z;
					if (newMax.x>max.x) max.x=newMax.x;
					if (newMax.y>max.y) max.y=newMax.y;
					if (newMax.z>max.z) max.z=newMax.z;
				}
			}

			const Extreme::Vector3 midPoint=(min+max)*0.5;
			const Extreme::float32 boxSize=(min-max).getLength()/2.0;
			
			X3M_DEBUG("ParticleNode::init", "Center of puffs=(%f %f %f), boxSize=%f", midPoint.x,midPoint.y,midPoint.z,boxSize);

			initInternal(render, midPoint, boxSize, puffList, lightList);

		}

		ParticleNode() {
			for (int c=0; c<8; c++) childs[c]=0;
		}

		~ParticleNode() {
			for (int c=0; c<8; c++) {
				delete childs[c];
				childs[c]=0;
			}
		}

		void render(Render &render, const LightList &lights, const Extreme::Matrix4x4 &viewMatrix, const Extreme::Matrix4x4 &projectMatrix, const Extreme::Vector3 &cameraPosition) {

			// We have six planes (3 with normal=-normal)
			// (char is enough)

			// Parent is supposed to transform childs pos
			particleLOD.viewPos=particleLOD.pos*viewMatrix;
		
			renderNode(render, lights, viewMatrix, projectMatrix, cameraPosition); 
		}

		void renderParticle(Render &render, const LightList &lights, const Extreme::Matrix4x4 &viewMatrix, const Extreme::Matrix4x4 &projectMatrix, const Extreme::Vector3 &cameraPosition) {

			// Fixed-point?


			// Start with ambient
			Extreme::Vector3 color=lights.ambientColor;

			for (int l=0; l<lights.lightList.size(); l++) {
				const Light &light=*lights.lightList[l];

				const Extreme::Vector3 eyeParticleDir=(cameraPosition-particleLOD.pos).getNormalized();

				const float rCosAlpha=eyeParticleDir*light.dir;

				const float factor=.75*(1.0+rCosAlpha*rCosAlpha);

				color+=light.color*(particleLOD.intensity[l]*factor*light.intensity);	
			}

			if (color.x>255.0) color.x=255.0;
			if (color.y>255.0) color.y=255.0;
			if (color.z>255.0) color.z=255.0;

			// Optimize
			Extreme::uint32 col=(TRANSPAR<<24)+(int(color.x)<<16)+(int(color.y)<<8)+int(color.z);

			render.drawQuad(particleLOD.viewPos, particleLOD.radius, col, viewMatrix, projectMatrix);
		}

		// TODO: We need a lightList with { lightDIR, lightINTENSITY, lightColor }
		void renderNode(Render &render, const LightList &lights, const Extreme::Matrix4x4 &viewMatrix, const Extreme::Matrix4x4 &projectMatrix, const Extreme::Vector3 &cameraPosition) {

			// Use a view-frustum.. expand SOME due to our radius*2.0

			const float detail=0.0725f;

			// TODO: perhaps we can optimize because we have particle in viewSpace already

			const float cameraDist=(particleLOD.pos-cameraPosition).getLength();
			const float eval=particleLOD.radius/cameraDist;

			//X3M_DEBUG("haj", "leaf=%d, rad=%f, r=%f, eval=%f detail=%f", leaf, particleLOD.radius, cameraDist, eval, detail);

			if (leaf==true || eval<=detail) {
				
				// This is a leaf so no childs, just render particle
				renderParticle(render, lights, viewMatrix, projectMatrix, cameraPosition);
				return;
			}

			// This fucks up if several at same z
			// Slow too
			std::map<Extreme::float32,ParticleNode*> nodeList;

			// Recurse childs, sort them on z
			for (int c=0; c<8; c++) {

				ParticleNode * node=childs[c];

				// Node active?
				if (node!=NULL) {

					// TODO: No need to transform if z<=0, calculate z first
					
					// Transform node-particle midpoint, we need z for sorting
					node->particleLOD.viewPos=viewMatrix*node->particleLOD.pos;

					// Can we see the node mid-point?
					if (node->particleLOD.viewPos.z>0) {
	
						nodeList[-node->particleLOD.viewPos.z]=node;
					}
				}
			}

			for (std::map<float,ParticleNode*>::iterator i=nodeList.begin(); i!=nodeList.end(); ++i) {
				i->second->render(render, lights, viewMatrix, projectMatrix, cameraPosition);
			}
		}
	};
}



#endif