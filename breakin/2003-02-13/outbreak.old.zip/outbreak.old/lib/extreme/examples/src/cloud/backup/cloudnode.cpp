#include "cloudnode.h"

//****************************************************************************

void Cloud::ParticleNode::init(Render &render, std::vector<Particle> &particleList, const PuffList &puffList,  const LightList &lightList) {

	// Calculate extend of puffs
	bool inited=false;
	Extreme::Vector3 min, max;

	for (int p=0; p<puffList.puffList.size(); p++) {

		const Puff &puff=puffList.puffList[p];

		Extreme::Vector3 newMin, newMax;

		newMin=puff.pos-puff.radius*Extreme::Vector3(1,1,1);
		newMax=puff.pos+puff.radius*Extreme::Vector3(1,1,1);

		if (inited=false) {
			min=newMin;
			max=newMax;
		} else {

			if (newMin.x<min.x) min.x=newMin.x;
			if (newMin.y<min.y) min.y=newMin.y;
			if (newMin.z<min.z) min.z=newMin.z;
			if (newMax.x>max.x) max.x=newMax.x;
			if (newMax.y>max.y) max.y=newMax.y;
			if (newMax.z>max.z) max.z=newMax.z;
		}
	}

	// OBB?
	mLeaf=true;
	mMidPoint=(min+max)*0.5;
	mBoxSize=(min-max).getLength()/2.0;
	
	X3M_DEBUG("ParticleNode::init", "Center of puffs=(%f %f %f), mBoxSize=%f", mMidPoint.x,mMidPoint.y,mMidPoint.z,mBoxSize);

	Particle part;
	part.frameCount=render.getFrameCount();
	
	// TODO: Make a particleManager that holds the particles and "NEVER" invalidates pointers...
	// (use a getParticle() that returns a particle and rellocated blocks of particles when needed)
	particleList.resize(100*puffList.puffList.size());
	part.intensity.push_back(0);

	// Let's create particles in the puffs (ok do something better, perlin+whatever)
	for (p=0; p<puffList.puffList.size(); p++) {

		const Puff &puff=puffList.puffList[p];
		part.transparency=1.0-puff.density;
		
		for (int c=0; c<100; c++) {

			part.intensity[0]=0.5+float(rand()%500)/1000.0;

			const Extreme::Vector3 randDir=
				(((rand()%1000)-500)/500.0*Extreme::Vector3(1,0,0)+
				 ((rand()%1000)-500)/500.0*Extreme::Vector3(0,1,0)+
				 ((rand()%1000)-500)/500.0*Extreme::Vector3(0,0,1)).getNormalized();

			part.radius=(rand()%int(puff.radius))*0.5+2.0;
			part.pos=puff.pos+randDir*((rand()%1000)/1000.0*(puff.radius-part.radius));
		
			//X3M_DEBUG("ParticleNode::init", "Insert particle %d at (%f %f %f) with radius %f", c, part.pos.x, part.pos.y, part.pos.z, part.radius);
			
			particleList[p*100+c]=part;

			insertParticle(&particleList[p*100+c]);
		}
	}

	// Precalculate lightning. First we should set up a RenderTarget
	// Our boundingSphere has the radius sqrt(boxSize*boxSize*3)

	X3M_DEBUG("Cloud::ParticleNode::init", "Our boundingsphere has the radius %f", sqrt(mBoxSize*mBoxSize*3.0));

	for (std::vector<Light*>::const_iterator i=lightList.lightList.begin(); i!=lightList.lightList.end(); ++i) {
		precalc(render, **i);
	}

	//render.clearPrecalc(); // TODO
}

//****************************************************************************

/* Precalculate lighting for node using Light "light" (adding one intensity to particle */

void Cloud::ParticleNode::precalc(Render &render, const Light &light) {

	if (mLeaf==true) {

		// Calculate extend of render target (TOD: Find shared particle too and make bigger than mBoxSize!)
		const Extreme::float32 radius=sqrt(mBoxSize*mBoxSize*3.0);
		const int pixels=radius*10.0;

		X3M_DEBUG("Cloud::ParticleNode::precalc", "Leaf node with %d particles, renderTarget shall be %dx%d pixels", mParticles.size(), pixels, pixels);

		// Create our renderTarget
		//render.newPrecalc(pixels,pixels);
		
		// Draw ALL renderTargets to our renderTarget (no blending, just copy)
		//render.drawPrecalc();

		// Sort particles
		// For each particle
  		//   Read data for particle n
		//   Set color for particle n
		//   Draw particle n

	} else {

		for (int c=0; c<8; c++) {
			
			if (mChilds[c]!=0) {
				mChilds[c]->precalc(render, light);
			}
		}

		// TODO: Traverse child nodes in correct order
	}
}

//****************************************************************************

void Cloud::ParticleNode::insertParticle(Particle *particle) {

	// Code below can remove very small cells not wanted for precalc
	// No empty cells will be created
	if (mParticles.size()==0 && mBoxSize>50) {
		mLeaf=false;
	}

	// If we have childs we insert into them, otherwise we might keep particle here
	if (mLeaf) {		

		mParticles.push_back(particle);

		if (mBoxSize<50.0 || mParticles.size()<100) { 
			// We're happy about particle ending up in mParticles
			return;
		}

		// Ok we shall create child nodes
		// Both particle and everything in mParticles are added to childnodes instead

		const Extreme::float32 childBoxSize=mBoxSize/2.0;				

		// Let's transform mParticles into childs
		for (int C=0; C<8; C++) {

			// Midpoint for new node
			const Extreme::Vector3 childMidPoint=mMidPoint+
				Extreme::Vector3(
					(float(2*((C   )&0x1)-1))*childBoxSize,
					(float(2*((C>>1)&0x1)-1))*childBoxSize,
					(float(2*((C>>2)&0x1)-1))*childBoxSize);
			
			for (std::list<Particle*>::iterator i=mParticles.begin(); i!=mParticles.end(); ++i) {
				
				const Extreme::float32 px=childMidPoint.x-(*i)->pos.x;
				const Extreme::float32 py=childMidPoint.y-(*i)->pos.y;
				const Extreme::float32 pz=childMidPoint.z-(*i)->pos.z;

				// Is particle within bound box of this child
				if ((fabs(px)<childBoxSize) &&
					(fabs(py)<childBoxSize) &&
					(fabs(pz)<childBoxSize)) {

				/*if ((fabs(px)-(*i)->radius<childBoxSize) &&
					(fabs(py)-(*i)->radius<childBoxSize) &&
					(fabs(pz)-(*i)->radius<childBoxSize)) {*/

					// Create child if first particle here
					if (mChilds[C]==0) {
						mChilds[C]=new ParticleNode(childMidPoint, childBoxSize);
					}

					//X3M_DEBUG("Insert", "particle %p goes into %d (%d %d %d)", *i, C, C&0x1, C&0x2, C&0x4);
					
					mChilds[C]->insertParticle(*i);
					
				}
			}
		}

		// All particle are moved to child so we remove our particleList here
		mLeaf=false;
		mParticles.clear();
		return;
	}

	const Extreme::float32 childBoxSize=mBoxSize/2.0;

	// Insert in correct child, create new child if needed
	for (int C=0; C<8; C++) {

		if (mChilds[C]==0) {

			const Extreme::Vector3 childMidPoint=mMidPoint+
				Extreme::Vector3(
					(float(2*((C   )&0x1)-1))*childBoxSize,
					(float(2*((C>>1)&0x1)-1))*childBoxSize,
					(float(2*((C>>2)&0x1)-1))*childBoxSize);

			const Extreme::float32 px=childMidPoint.x-particle->pos.x;
			const Extreme::float32 py=childMidPoint.y-particle->pos.y;
			const Extreme::float32 pz=childMidPoint.z-particle->pos.z;

			if ((fabs(px)<childBoxSize) &&
				(fabs(py)<childBoxSize) &&
				(fabs(pz)<childBoxSize)) {

			/*if ((fabs(px)-particle->radius<childBoxSize) &&
				(fabs(py)-particle->radius<childBoxSize) &&
				(fabs(pz)-particle->radius<childBoxSize)) {*/

				mChilds[C]=new ParticleNode(childMidPoint, childBoxSize);
				mChilds[C]->insertParticle(particle);
			}					

		} else {

			const Extreme::float32 px=mChilds[C]->mMidPoint.x-particle->pos.x;
			const Extreme::float32 py=mChilds[C]->mMidPoint.y-particle->pos.y;
			const Extreme::float32 pz=mChilds[C]->mMidPoint.z-particle->pos.z;

			if ((fabs(px)<childBoxSize) &&
				(fabs(py)<childBoxSize) &&
				(fabs(pz)<childBoxSize)) {

/*			if ((fabs(px)-particle->radius<childBoxSize) &&
				(fabs(py)-particle->radius<childBoxSize) &&
				(fabs(pz)-particle->radius<childBoxSize)) {*/

				mChilds[C]->insertParticle(particle);
			}					
		}
	}
}

//****************************************************************************
