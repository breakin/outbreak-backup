#ifndef CLOUD_RENDER
#define CLOUD_RENDER

#include <x3m_typedef.h>
#include <x3m_exception.h>
#include <x3m_system.h>
#include <math/x3m_vector.h>
#include <resource\x3m_materialmanager.h>
#include <resource\x3m_modelmanager.h>

// Maximum particles per drawPrimtive-call
#define PART 100

namespace Cloud {

	struct Vertex2D	{
		Extreme::Vector3 mPos;
		Extreme::float32	mRHW;
		Extreme::uint32	mDiffuse;
		Extreme::float32 mU;
		Extreme::float32 mV;
	};

	struct Render {

		Extreme::float32 mScreenWidth, mScreenHeight;

		// Only valid between prepareFrame and finishFrame
		Vertex2D *mBuffer;

		Extreme::VertexBufferHandle mVertexBuffer;
		//Extreme::IndexBufferHandle mIB;
		Extreme::RenderSystem *mRenderSystem;
		
		Extreme::MaterialHandle mMaterial;

		int mProcessed, mProcessedTotal;

		Render() {
			mBuffer=0;
		}

		~Render() {
			if (mBuffer!=0) {
				delete [] mBuffer;
				mBuffer=0;
			}

			// I think everything else should free itself, right?
		}

		void init() {

			mBuffer=new Vertex2D[PART*6];
			
			// Create the vertexBuffer
			mVertexBuffer = Extreme::ModelManager::getInstance().createVertexBuffer(std::string("cloudSystem"), ( D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1), PART*6, Extreme::VertexBuffer::USAGE_DYNAMIC);

			mMaterial = Extreme::MaterialManager::getInstance().createMaterial(std::string("cloudMaterial"), 1);

			// get texturelayers
			Extreme::TextureLayerHandle texLayer = mMaterial->getTextureLayer(0);

			// set texturealayer properties (1)
			texLayer->mTexture=createSplatTexture(32);
			
			texLayer->mEnabled = true;
			texLayer->mAddressMode = Extreme::TextureLayer::TEXADDRESS_WRAP;
			
			texLayer->mFilter = Extreme::TextureLayer::TEXFILTER_BILINEAR;
			
			/* initialize material */
			mMaterial->mShadeMode = Extreme::Material::SHADE_GOURAUD;
			mMaterial->mFillMode  = Extreme::Material::FILL_SOLID;
			mMaterial->mCullMode  = Extreme::Material::CULL_NONE;
			mMaterial->mBlendMode.mSrcFactor = Extreme::BlendMode::FACTOR_ONE;
			mMaterial->mBlendMode.mDstFactor = Extreme::BlendMode::FACTOR_INVSRCALPHA;
			mMaterial->mBlendMode.mOp = Extreme::BlendMode::OP_ADD;
			mMaterial->mDepthBufferEnable=false; // TODO: Should read
			mMaterial->mLightingEnable = false;
			mMaterial->mBlendEnable = true;
		}

		void prepareFrame(const Extreme::float32 width,const Extreme::float32 height) {

			mScreenWidth=width;
			mScreenHeight=height;

			mRenderSystem=&Extreme::RenderSystem::getInstance();

			mProcessed=0;
			mProcessedTotal=0;

			mRenderSystem->setMaterial(mMaterial);
			mRenderSystem->setVertexBuffer(mVertexBuffer);
		}

		void finishFrame() {
			if (mProcessed>0) {
				flushVertexBuffer();
			}
		}

		void flushVertexBuffer() {
			mVertexBuffer->upload(mBuffer, 0, mProcessed*6);
			mRenderSystem->renderPrimitive(Extreme::VertexBuffer::PT_TRILIST, mProcessed*2);
			mProcessed=0;
		}

		void drawQuad(Extreme::Vector3 &pos, Extreme::float32 radius, Extreme::uint32 color, const Extreme::Matrix4x4 &viewMatrix, const Extreme::Matrix4x4 &projectMatrix) {

			const int baseOffset=mProcessed*6;

			// Add quad to VertexBuffer
			// Optimize and add IndexBuffer
			mBuffer[baseOffset+0].mPos.x = (pos.x-radius);
			mBuffer[baseOffset+0].mPos.y = (pos.y-radius);
			mBuffer[baseOffset+0].mU		= 0.0f;
			mBuffer[baseOffset+0].mV		= 0.0f;

			mBuffer[baseOffset+1].mPos.x = (pos.x+radius);
			mBuffer[baseOffset+1].mPos.y = (pos.y-radius);
			mBuffer[baseOffset+1].mU		= 1.0f;
			mBuffer[baseOffset+1].mV		= 0.0f;

			mBuffer[baseOffset+2].mPos.x = (pos.x+radius);
			mBuffer[baseOffset+2].mPos.y = (pos.y+radius);
			mBuffer[baseOffset+2].mU		= 1.0f;
			mBuffer[baseOffset+2].mV		= 1.0f;

			mBuffer[baseOffset+3]=mBuffer[baseOffset+0];
			mBuffer[baseOffset+4]=mBuffer[baseOffset+2];

			mBuffer[baseOffset+5].mPos.x = (pos.x-radius);
			mBuffer[baseOffset+5].mPos.y = (pos.y+radius);
			mBuffer[baseOffset+5].mU=0.0;
			mBuffer[baseOffset+5].mV=1.0;
			
			for (int j=baseOffset; j<baseOffset+6; j++) {

				mBuffer[j].mRHW	= 1.0f;
				mBuffer[j].mDiffuse=color;
				mBuffer[j].mPos.z=pos.z;
				mBuffer[j].mPos=mBuffer[j].mPos*projectMatrix;
				// This (below) could be baked into project matrix (most of)
				
				mBuffer[j].mPos.x=mBuffer[j].mPos.x/mBuffer[j].mPos.z*mScreenWidth /2.0+ mScreenWidth/2.0;
				mBuffer[j].mPos.y=mBuffer[j].mPos.y/mBuffer[j].mPos.z*mScreenHeight/2.0+mScreenHeight/2.0;
			}

			mProcessed++;
			mProcessedTotal++;

			// Flush if we can fit no more quads in the VertexBuffer
			if ((mProcessed+1)*6>PART) {
				flushVertexBuffer();
			}
		}

		//********************************************************************************

		inline float EvalHermite(float pA, float pB, float vA, float vB, float u)
		{
		  float u2=(u*u), u3=u2*u;
		  float B0 = 2*u3 - 3*u2 + 1;
		  float B1 = -2*u3 + 3*u2;
		  float B2 = u3 - 2*u2 + u;
		  float B3 = u3 - u;
		  return( B0*pA + B1*pB + B2*vA + B3*vB );
		}

		Extreme::TextureHandle createSplatTexture(const int size) {

			Extreme::Debug::log("createSplatTexture", "size=%d", size);

			Extreme::int32 pitch;
			Extreme::Texture::Desc desc;

			Extreme::TextureHandle textureHandle=Extreme::TextureManager::getInstance().createTexture("splatTexture", size,size,32,1);

			unsigned char *dest=(unsigned char*)(textureHandle->lock(0, pitch, desc));

			Extreme::Debug::log("createSplatTexture", "pitch=%d, dest=%p", pitch, dest);

			// TODO: Check power of 2
			if (desc.mWidth!=desc.mHeight) throw Extreme::Exception("blah");

			std::vector<float> M;
			M.resize(2*size*size);

			float X,Y,Y2,Dist;
			float Incr = 2.0f/float(size);
			int i=0;  
			int j = 0;
			Y = -1.0f;

			for (int y=0; y<size; y++, Y+=Incr) {
			
				Y2=Y*Y;
				X = -1.0f;

				for (int x=0; x<size; x++, X+=Incr, i+=2, j+=4)	{
					Dist = (float)sqrt(X*X+Y2);
					if (Dist>1) Dist=1;
					M[i+1] = M[i] = EvalHermite(0.4f,0,0,0,Dist);// * (1 - noise);
					dest[j+3] = dest[j+2] = dest[j+1] = dest[j] = (unsigned char)(M[i] * 255);
				}

				j+=pitch-size*4;
			}

			textureHandle->unlock();

			return textureHandle;
		}              
	};
}

#endif