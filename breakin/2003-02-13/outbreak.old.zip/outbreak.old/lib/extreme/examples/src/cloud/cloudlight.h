#ifndef CLOUD_LIGHT
#define CLOUD_LIGHT

#include <x3m_typedef.h>
#include <x3m_exception.h>
#include <x3m_system.h>
#include <math/x3m_vector.h>

/* This class represents a particle OR a puff of cloud where trans=1.0-density */

namespace Cloud {

	struct Light {
		Extreme::Vector3 pos, dir, color;
		Extreme::float32 intensity;
	};
}

#endif