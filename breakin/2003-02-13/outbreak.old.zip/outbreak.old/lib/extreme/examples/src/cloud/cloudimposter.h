#ifndef CLOUD_IMPOSTER
#define CLOUD_IMPOSTER

#include <x3m_typedef.h>
#include <x3m_exception.h>
#include <x3m_system.h>
#include <math/x3m_vector.h>
#include "cloudrender.h"

namespace Cloud {

	struct Imposter {
		
		// Up and Right-vector (at the moment of creation)
		// They have the length of the width/height
		Extreme::Vector3 upVector, rightVector;

		Extreme::Vector3 midPoint;
		
		// Where was the camera when this imposter was created
		Extreme::Vector3 cameraPosition;

		int resolutionWidth, resolutionHeight;

		// The texture, somehow.. if NULL then we have no imposter at all...
	};
}

#endif