#include <x3m_typedef.h>
#include <win32\x3m_threadwindow.h>
#include <x3m_exception.h>
#include <x3m_clock.h>
#include <x3m_color.h>
#include <x3m_system.h>
#include <windows.h>
#include <resource\x3m_materialmanager.h>
#include <resource\x3m_modelmanager.h>
#include <math\x3m_matrix.h>

#include <d3d8.h>
#include <d3dx8math.h>
#define X_WIDTH 640.0f
#define X_HEIGHT 480.0f

using namespace Extreme;

struct Vertex
{
	Vector3 mPos;
	uint32	mDiffuse;
	float32 mU;
	float32 mV;
};

struct Vertex2D
{
	Vector3 mPos;
	float	mRHW;
	float32 mU;
	float32 mV;
};

#define VERT_SIZE 32

Vertex vertices[VERT_SIZE];

Vertex2D layer[4];

int WINAPI WinMain(HINSTANCE hi, HINSTANCE pi, LPSTR cmdLine, int cmd) {

	try {

		vertices[0].mPos = Vector3(-10,10,10);
		vertices[0].mDiffuse = 0x7f7f7f;
		vertices[0].mU = 0;
		vertices[0].mV = 0;

		vertices[1].mPos = Vector3(10,10,10);
		vertices[1].mDiffuse = 0x7f7f7f;
		vertices[1].mU = 1;
		vertices[1].mV = 0;
		
		vertices[2].mPos = Vector3(10,-10,10);
		vertices[2].mDiffuse = 0x7f7f7f;
		vertices[2].mU = 1;
		vertices[2].mV = 1;

		vertices[3].mPos = Vector3(-10,10,10);
		vertices[3].mDiffuse = 0x7f7f7f;
		vertices[3].mU = 0;
		vertices[3].mV = 0;

		vertices[4].mPos = Vector3(10,-10,10);
		vertices[4].mDiffuse = 0x7f7f7f;
		vertices[4].mU = 1;
		vertices[4].mV = 1;
		
		vertices[5].mPos = Vector3(-10,-10,10);
		vertices[5].mDiffuse = 0x7f7f7f;
		vertices[5].mU = 0;
		vertices[5].mV = 1;

		/// side 2
		vertices[6].mPos = Vector3(-10,10,10);
		vertices[6].mDiffuse = 0x7f7f7f;
		vertices[6].mU = 0;
		vertices[6].mV = 0;

		vertices[7].mPos = Vector3(-10,10,-10);
		vertices[7].mDiffuse = 0x7f7f7f;
		vertices[7].mU = 1;
		vertices[7].mV = 0;
		
		vertices[8].mPos = Vector3(-10,-10,-10);
		vertices[8].mDiffuse = 0x7f7f7f;
		vertices[8].mU = 1;
		vertices[8].mV = 1;

		vertices[9].mPos = Vector3(-10,10,10);
		vertices[9].mDiffuse = 0x7f7f7f;
		vertices[9].mU = 0;
		vertices[9].mV = 0;

		vertices[10].mPos = Vector3(-10,-10,-10);
		vertices[10].mDiffuse = 0x7f7f7f;
		vertices[10].mU = 1;
		vertices[10].mV = 1;
		
		vertices[11].mPos = Vector3(-10,-10,10);
		vertices[11].mDiffuse = 0x7f7f7f;
		vertices[11].mU = 0;
		vertices[11].mV = 1;

			/// side 3
		vertices[12].mPos = Vector3(10,10,-10);
		vertices[12].mDiffuse = 0x7f7f7f;
		vertices[12].mU = 0;
		vertices[12].mV = 0;

		vertices[13].mPos = Vector3(10,10,10);
		vertices[13].mDiffuse = 0x7f7f7f;
		vertices[13].mU = 1;
		vertices[13].mV = 0;
		
		vertices[14].mPos = Vector3(10,-10,10);
		vertices[14].mDiffuse = 0x7f7f7f;
		vertices[14].mU = 1;
		vertices[14].mV = 1;

		vertices[15].mPos = Vector3(10,10,-10);
		vertices[15].mDiffuse = 0x7f7f7f;
		vertices[15].mU = 0;
		vertices[15].mV = 0;

		vertices[16].mPos = Vector3(10,-10,10);
		vertices[16].mDiffuse = 0x7f7f7f;
		vertices[16].mU = 1;
		vertices[16].mV = 1;
		
		vertices[17].mPos = Vector3(10,-10,-10);
		vertices[17].mDiffuse = 0x7f7f7f;
		vertices[17].mU = 0;
		vertices[17].mV = 1;

		/// side 4
		vertices[18].mPos = Vector3(-10,-10,10);
		vertices[18].mDiffuse = 0x323242;
		vertices[18].mU = 0;
		vertices[18].mV = 0;

		vertices[19].mPos = Vector3(10,-10,10);
		vertices[19].mDiffuse = 0x323242;
		vertices[19].mU = 1;
		vertices[19].mV = 0;
		
		vertices[20].mPos = Vector3(10,-10,-10);
		vertices[20].mDiffuse = 0x323242;
		vertices[20].mU = 1;
		vertices[20].mV = 1;

		vertices[21].mPos = Vector3(-10,-10,10);
		vertices[21].mDiffuse = 0x323242;
		vertices[21].mU = 0;
		vertices[21].mV = 0;

		vertices[22].mPos = Vector3(10,-10,-10);
		vertices[22].mDiffuse = 0x323242;
		vertices[22].mU = 1;
		vertices[22].mV = 1;
		
		vertices[23].mPos = Vector3(-10,-10,-10);
		vertices[23].mDiffuse = 0x323242;
		vertices[23].mU = 0;
		vertices[23].mV = 1;

		/// side 5
		vertices[24].mPos = Vector3(-10,10,-10);
		vertices[24].mDiffuse = 0x323242;
		vertices[24].mU = 0;
		vertices[24].mV = 0;

		vertices[25].mPos = Vector3(10,10,-10);
		vertices[25].mDiffuse = 0x323242;
		vertices[25].mU = 1;
		vertices[25].mV = 0;
		
		vertices[26].mPos = Vector3(10,10,10);
		vertices[26].mDiffuse = 0x323242;
		vertices[26].mU = 1;
		vertices[26].mV = 1;

		vertices[27].mPos = Vector3(-10,10,-10);
		vertices[27].mDiffuse = 0x323242;
		vertices[27].mU = 0;
		vertices[27].mV = 0;

		vertices[28].mPos = Vector3(10,10,10);
		vertices[28].mDiffuse = 0x323242;
		vertices[28].mU = 1;
		vertices[28].mV = 1;
		
		vertices[29].mPos = Vector3(-10,10,10);
		vertices[29].mDiffuse = 0x323242;
		vertices[29].mU = 0;
		vertices[29].mV = 1;

		layer[0].mPos	= Vector3(0.0f,0.0f,0.0f);
		layer[0].mRHW	= 1.0f;
		layer[0].mU		= 0.0f;
		layer[0].mV		= 0.0f;

		layer[1].mPos	= Vector3(X_WIDTH,0.0f,1.0f);
		layer[1].mRHW	= 1.0f;
		layer[1].mU		= 1.0f;
		layer[1].mV		= 0.0f;

		layer[2].mPos	= Vector3(X_WIDTH,X_HEIGHT,1.0f);
		layer[2].mRHW	= 1.0f;
		layer[2].mU		= 1.0f;
		layer[2].mV		= 1.0f;

		layer[3].mPos	= Vector3(0.0f,X_HEIGHT,1.0f);
		layer[3].mRHW	= 1.0f;
		layer[3].mU		= 0.0f;
		layer[3].mV		= 1.0f;

		System system;
		RenderSystem	*rs	= system.getRenderSystem();
		SoundSystem		*ss	= system.getSoundSystem();

		rs->config("appl.title","Extreme Presentation");
		rs->config("appl.windowed","true");	
		rs->config("backbuffer.bitdepth","32");
		rs->config("backbuffer.width","640");
		rs->config("backbuffer.height","480");
		rs->config("backbuffer.count", "1");
		rs->config("device.layer", "hal");
		rs->config("device.vsync","false");
		rs->config("fsaa.enable","false");
		rs->config("fsaa.samples","2");
		
		rs->startup();
		
		float32 deg = 0;
		
		double frames = 0.0;

		// create vertexbuffers
		VertexBufferHandle handle = ModelManager::getInstance().createVertexBuffer(std::string("test01"), ( D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1), VERT_SIZE, VertexBuffer::USAGE_STATIC);
		VertexBufferHandle layerHandle = ModelManager::getInstance().createVertexBuffer(std::string("layer1"), ( D3DFVF_XYZRHW | D3DFVF_TEX1),4, VertexBuffer::USAGE_STATIC);

		// create materials
		MaterialHandle hMaterial = MaterialManager::getInstance().createMaterial(std::string("mat01"), 1);
		MaterialHandle hMaterial2 = MaterialManager::getInstance().createMaterial(std::string("mat02"), 1);
		
		// get texturelayers
		TextureLayerHandle texLayer = hMaterial->getTextureLayer(0);
		TextureLayerHandle texLayer2 = hMaterial2->getTextureLayer(0);
		
		// set texturealayer properties (1)
		texLayer->mEnabled = true;
		texLayer->mTexture = TextureManager::getInstance().createTexture("text4.jpg");
		texLayer->mAddressMode = TextureLayer::TEXADDRESS_WRAP;
		texLayer->mFilter = TextureLayer::TEXFILTER_ANISOTROPIC;
		
		// set texturealayer properties (2)
		texLayer2->mEnabled = true;
		texLayer2->mTexture = TextureManager::getInstance().createTexture("extremelogo.jpg");
		texLayer2->mAddressMode = TextureLayer::TEXADDRESS_WRAP;
		texLayer2->mFilter = TextureLayer::TEXFILTER_BILINEAR;
		
		ColorValue clearColor;
		Matrix4x4 matrix;
		Matrix4x4 projectMatrix;
		Matrix4x4 viewMatrix;
		Matrix4x4 matrixScale;

		D3DXMatrixIdentity((D3DXMATRIX*)(&matrix));
		
		viewMatrix.makeViewLookAt(Vector3(0,0,-20), Vector3(0,0,100), 0.12f);

		Msg	msg;
		
		/** upload vertices to hw resources */
		layerHandle->upload((void*)layer, 0, 4);
		handle->upload((void*)vertices, 0, VERT_SIZE);

		//projectMatrix.makeProjection(X3M_PI/6, 1.0, 200.0f);
		D3DXMatrixPerspectiveFovLH(
		 (D3DXMATRIX*)&projectMatrix,
		 X3M_PI / 3.0f,
		 X_WIDTH/X_HEIGHT,
		 1.0f, 1000.0f
		 ); 
		
		clearColor.mR = 0.0f;
		clearColor.mG = 0.0f;
		clearColor.mB = 0.5f;
		clearColor.mA = 1.0f;

		bool run = true;

		/* initialize material */
		hMaterial->mShadeMode = Material::SHADE_GOURAUD;
		hMaterial->mFillMode  = Material::FILL_SOLID;
		hMaterial->mCullMode  = Material::CULL_NONE;
		hMaterial->mBlendMode.mSrcFactor = BlendMode::FACTOR_ONE;
		hMaterial->mBlendMode.mDstFactor = BlendMode::FACTOR_SRCCOLOR;
		hMaterial->mBlendMode.mOp = BlendMode::OP_ADD;	
		hMaterial->mLightingEnable = false;
		hMaterial->mBlendEnable = true;
		
		/* intialize material 2 */
		hMaterial2->mShadeMode = Material::SHADE_GOURAUD;
		hMaterial2->mFillMode  = Material::FILL_SOLID;
		hMaterial2->mCullMode  = Material::CULL_NONE;
		hMaterial2->mBlendMode.mSrcFactor = BlendMode::FACTOR_ZERO;
		hMaterial2->mBlendMode.mDstFactor = BlendMode::FACTOR_SRCCOLOR;
		hMaterial2->mBlendMode.mOp = BlendMode::OP_ADD;
		hMaterial2->mLightingEnable = false;
		hMaterial2->mBlendEnable = false;
		hMaterial2->mDepthBufferEnable = false;

		
		Matrix4x4 tempMat;

		/* setup transformation matrix */
		matrix.makeIdentity();
		Matrix4x4 viewMatrix2;
		Clock timer;
		timer.start();
		frames = 0.0f;

		while (run) {
			
			viewMatrix.makeViewLookAt(Vector3(0,0,-20 + sinf(deg)*20), Vector3(0,0,100), deg);

			if (rs->getMessage(msg)) {

				switch (msg.mMsg) 
				{
					case Extreme::MSG_KEYDOWN:

						if (msg.mParam == VK_ESCAPE)
							run = false;
						if (msg.mParam == VK_SPACE) {
							
							rs->config("display.windowed", "false");
							rs->reset();
						}
					break;
					case Extreme::MSG_CLOSE:
						run = false;
				}
			}
					
			rs->beginScene();
					
			/** set transformation matrices */
			rs->setViewMatrix(viewMatrix);	
			rs->setProjectionMatrix(projectMatrix);

			/** set resources */
			hMaterial->mBlendEnable = true;
			hMaterial->mDepthBufferEnable = true;
			
			/** set matrices */
			matrix.makeRotXYZ(deg, deg, deg);
			rs->setWorldMatrix(matrix);	
			
			/** render first primitive */
			hMaterial2->mDepthWriteEnable = false;
			rs->setMaterial(hMaterial2);
			rs->setVertexBuffer(layerHandle);
			rs->renderPrimitive(VertexBuffer::PT_TRIFAN, 2);

			/** render first primitive */
			rs->setMaterial(hMaterial);
			rs->setVertexBuffer(handle);
			rs->renderPrimitive(VertexBuffer::PT_TRILIST, 12);
			
			rs->endScene();
			rs->present();
			rs->clear(clearColor);
			frames += 1.0f;
			clearColor = ColorValue(0,0,0,0);
			deg+=0.0017f;
		}

		// nulling handles
		handle = NULL;
		hMaterial = NULL;

		rs->shutdown();

		timer.stop();

		// ss->stop();
		char fps_msg[256];
		sprintf (fps_msg, "FPS = %02f", frames/timer.getTime());
	//	MessageBox(NULL, fps_msg, "FPS Info", MB_OK);		
		
	}
	catch (Extreme::Exception &e) {
		MessageBox(NULL, e.what(), "Extreme Exception", MB_OK);
	}
	
	return 0;
}