#ifndef __EXTREME_RESOURCE_LOADER_3DS_INC__
#define __EXTREME_RESOURCE_LOADER_3DS_INC__

#include <stdio.h>
#include "3dsscene.h"
#include <math\x3m_vector.h>
#include <x3m_typedef.h>
#include <keyframing\x3m_tracks.h>

namespace Zippo {

	using namespace Extreme;

	class Loader_3DS 
	{
	public:
		
		/**
		 * Chunk structure
		 */
		struct Chunk 
		{
			uint16	m_id;		///< Chunk ID	
			uint32	m_length;	///< Chunk Length
		};
		
		/// Constructor
		Loader_3DS();

		/// Destructor
		~Loader_3DS();
		
		/// loads a scene from file
		void loadScene(const char filename[], Scene_3DS &scene);//, IScene &scene);

	private:
		
		/// reads any type from file
		template <typename T>
		void readData(T &data) const {
		
			fread(&data,sizeof(T),1,m_fptr);
		}

		/// Color_3DS specializaion of readData
		template <>
		void readData<Color_3DS>(Color_3DS &color) const {
			
			uint8 r,g,b;
			readData(r);
			readData(g);
			readData(b);

			float32 recip = 1.0f / 255.0f;
			color.m_r = (float32)r * recip;
			color.m_g = (float32)g * recip;
			color.m_b = (float32)b * recip;
			color.m_a = 1.0f;
		}
		
		/// vector specialization of read template
		template <> 
		void readData<Vector3>(Vector3 &data) const {

			readData(data[0]);
			readData(data[2]);
			readData(data[1]);
		}

		/// reads a nullterminated character string from file
		void readString(char str[]) const;
		
		/// reads a percentage value and convertes to float (0.0 - 1.0) 
		void readIntPercent(float32 &dst);

		/// reads [n] amount of bytes into data
		void read(void *data, int n);

		/// reads a chuck structure from file
		void readChunk(Chunk &chunk) const;

		/// load objects from .3ds 
		void loadObject(const std::string &name, Scene_3DS &object, long chunkLength);
		
		/// Load a 3DS light
		void loadLight (const std::string &name, Scene_3DS &object, long chunkLength);

		/// Load a 3DS camera + subchunks
		void loadCamera(const std::string &name, Scene_3DS &object, long chunkLength);

		/// Load a 3DS trimesh + subchunks
		void loadTriMesh(TriMesh_3DS &object, long chunkLength);

		/// Load a 3DS Scene + subchunks
		void loadEditScene(Scene_3DS &object, long chunkLength);
	
		/// load scene material
		void loadMaterial(Scene_3DS &scene, long chunkLength);
		
		/// load material texture info
		void loadMaterialTextureInfo(Scene_3DS &scene, TextureInfo_3DS &texInfo, long chunkLength);
		
		/// load a texture in scene, returns the given ID/Index for that texture
		int32 loadSceneTexture(Scene_3DS &scene);
		
		/// load keyframing
		void loadKeyFraming(Scene_3DS &scene, long chunkLength);
		
		/// load keyframing frame info
		void loadKeyFramingFrames(Scene_3DS &scene);

		/// load keyframing tracks for lights
		void loadKeyFramingLight(Scene_3DS &scene, long);

		/// load keyframing tracks for cameras
		void loadKeyFramingCamera(Scene_3DS &scene, long);

		/// load keyframing tracks for camera target
		void loadKeyFramingCameraTarget(Scene_3DS &scene, long);

		/// load keyframing tracks for a treimesh
		void loadKeyFramingMesh(Scene_3DS &scene, long);

		// find object which owns keyframing
		Object_3DS* getKeyFramingObject(Scene_3DS &scene);
		
		/// load keyframing keys ===========================================================

		template <typename T>
		void loadKeys(T* keys, int keyCount) {
		
			int		n = 0;		/// loop counter
			uint16	accFlags;	/// acceeleration flags
			uint32	frameNumber;	

			while (n < keyCount) {
					
				readData(frameNumber);
				keys[n].frameNumber = (float32)frameNumber;

				readData(accFlags);

				/// read acceleration data when found
				for (int C = 0; C < 5; C++) {

					if (accFlags & (1 << C))  {

						switch (1 << C) {

						case TENSION :
						readData(keys[n].tension);
						Debug::debug("Loader_3DS::loadKeys","T = %.2f",keys[n].tension);
						break;
						case CONINUITY :
						readData(keys[n].continuity);
						Debug::debug("Loader_3DS::loadKeys","C = %.2f",keys[n].continuity);
						break;
						case BIAS :
						readData(keys[n].bias);
						Debug::debug("Loader_3DS::loadKeys","B = %.2f",keys[n].bias);
						break;
						case EASE_TO :
						readData(keys[n].easeTo);
						Debug::debug("Loader_3DS::loadKeys","EF = %.2f",keys[n].easeFrom);
						break;
						case EASE_FROM :						
						readData(keys[n].easeFrom);
						Debug::debug("Loader_3DS::loadKeys","ET = %.2f",keys[n].easeTo);
						break;						
						}
					}
				}	
				
				readData(keys[n].data);
				n++;
			}
		}

		/// load keyframing tracks ===========================================================

		template <typename T>
		void loadTrack(T *track) {

			uint32	keysTotal;
			uint16	flags;
			char 	unknown[8];
			
			// read trackmode flags
			readData(flags);

			// default single
			track->setTrackMode(Track::TRACK_SINGLE);

			// check tracktype
			switch (flags & 0x03) {
		
			case Track::TRACK_SINGLE:
				track->setTrackMode(Track::TRACK_SINGLE); 
				Debug::debug("Loader_3DS::loadTrack","TrackMode [SINGLE]");
			break;
			case Track::TRACK_REPEAT:
				track->setTrackMode(Track::TRACK_REPEAT); 
				Debug::debug("Loader_3DS::loadTrack","TrackMode [REPEAT]");
			break;
			case Track::TRACK_ROLL:
				Debug::debug("Loader_3DS::loadTrack","TrackMode [ROLL]");
				track->setTrackMode(Track::TRACK_ROLL); 
			break;
			}

			// read past 8 unknown garb. bytes
			read(unknown,8);

			// read amount of keys in track
			readData(keysTotal);
			track->resize(keysTotal);
			
			Debug::debug("Loader_3DS::loadTrack","Total keys in track [%d]\n",keysTotal);

			// load keys
			loadKeys(track->getKeys(), keysTotal);
				
			// precalculate TCB tangents
			track->calculateTangents(); 
		}
		
		/// ==================================================================================
		
		// trimesh data
		void loadTriMeshVertices(TriMesh_3DS &object);
		void loadTriMeshFaces(TriMesh_3DS &object);
		void loadTriMeshMatrix(TriMesh_3DS &object);
		void loadTriMeshMapping(TriMesh_3DS &object);
		void loadTriMeshMaterial(TriMesh_3DS &object);
		void loadTriMeshSmoothingGroups(TriMesh_3DS &object);
		
		/// Chunk type enumeration
		enum {
			
			CHUNK_MAIN			=	0x4d4d,		///< Main chunk
			CHUNK_EDIT			=	0x3d3d,		///< 3DS edit chunk
			
			CHUNK_COLOR_24		=	0x0011,		///< Byte RGB Color
			CHUNK_COLOR_24_G	=	0x0012,		///< Byte RGB Color gamma corrected

			CHUNK_PERCENT_INT16	=	0x0030,		///< Percentage in int16 format
			CHUNK_PERCENT_FLOAT	=	0x0031,		///< Percentage in float32 format

			/// object chunks
			CHUNK_OBJ			=	0x4000,		///< Object block chunk
			CHUNK_OBJ_HIDE		=	0x4010,		///< Object hidden
			CHUNK_OBJ_CAST		=	0x4012,		///< Object casting 
			CHUNK_OBJ_TRIMESH	=	0x4100,		///< Object trimesh
			CHUNK_OBJ_LIGHT		=	0x4600,		///< Object light
			CHUNK_OBJ_CAMERA	=	0x4700,		///< Object camera
			
			/// trimesh chunks
			CHUNK_TRIMESH_VLIST	=	0x4110,		///< Trimesh vertex list
			CHUNK_TRIMESH_FLIST	=	0x4120,		///< Trimesh face list
			CHUNK_TRIMESH_MLIST	=	0x4140,		///< Trimesh mapping coordinate list
			CHUNK_TRIMESH_LOCAL	=	0x4160,		///< Trimesh local coordinate system
			CHUNK_TRIMESH_EDCOL	=	0x4165,		///< Trimesh color in editor
			CHUNK_TRIMESH_SMOOTH=   0x4150,
			
			CHUNK_FLIST_MATLIST	=	0x4130,		///< Face material list
			
			/// light chunks
			CHUNK_LIGHT_SPOT	=	0x4610,		///< Light spotlight
			CHUNK_LIGHT_OFF		=	0x4620,		///< Light off
			CHUNK_LIGHT_ATTOFF	=	0x4625,		///< Light attenuation off
			CHUNK_LIGHT_RNGSTRT =	0x4659,		///< Light range start
			CHUNK_LIGHT_RNGSTOP	=	0x465a,		///< Light range 
			CHUNK_LIGHT_MULTIP	=	0x465b,		///< Light multiplier

			/// material chunks
			CHUNK_MTRL				=	0xafff,	///< Material block chunk
			CHUNK_MTRL_NAME			=	0xa000,	///< Material name
			CHUNK_MTRL_AMBIENT		=	0xa010,	///< Material ambient color
			CHUNK_MTRL_DIFFUSE		=	0xa020,	///< Material diffuse color
			CHUNK_MTRL_SPECULAR		=	0xa030,	///< Material specular color
			CHUNK_MTRL_SHINEPCT		=	0xa040,	///< Material shininess percent
			CHUNK_MTRL_SHINESTR		=	0xa041,	///< Material shininess strength percent
			CHUNK_MTRL_ALPHAPCT		=	0xa050,	///< Material alpha percent
			CHUNK_MTRL_ALPHASTR		=	0xa052,	///< Material alpha strength percent
			CHUNK_MTRL_ADDITIVE		=	0xa083,	///< Material is addiditve
			CHUNK_MTRL_WIREFRAMED	=	0xa085,	///< Material is wireframed 
			CHUNK_MTRL_FACEMAP		=	0xa088,	///< Material ha a face map
			CHUNK_MTRL_PHONGSOFT	=	0xa08c,	///< Material phong soft parameter
			CHUNK_MTRL_WIRE_ABS		=	0xa08e,	///< Material Wire frame units
			CHUNK_MTRL_WIRE_SIZE	=	0xa087,	///< Material Wire frame line width
			CHUNK_MTRL_SHADING		=	0xa100,	///< Material Shading (WIRE/FLAT/GOURAUD/PHONG etc)
			CHUNK_MTRL_TWOSIDE		=	0xa081,	///< Material is twosided
			
			/// material texture info
			CHUNK_MTRL_TEXTURE		=	0xa200,	///< Material Texture
			CHUNK_MTRL_TEXMASK		=	0xa33e,	///< Material Texture mask
			
			CHUNK_MTRL_TEXTURE2		=	0xa33a,	///< Material Texture 2
			CHUNK_MTRL_TEXMASK2		=	0xa340,	///< Material Texture mask

			CHUNK_MTRL_BUMPMAP		=	0xa230, ///< Material Bump map
			CHUNK_MTRL_BUMPMASK		=	0xa344,	///< Material Bump mask

			CHUNK_MTRL_SPECMAP		=	0xa204,	///< Material Specualar map
			CHUNK_MTRL_SPECMASK		=	0xa348,	///< Material Specualar map
			
			CHUNK_MTRL_OPACMAP		=	0xa210,	///< Material Opacy map
			CHUNK_MTRL_OPACMASK		=	0xa342,	///< Material Opacy mask
			
			CHUNK_MTRL_SHINMAP		=	0xa33c,	///< Material Shininess map
			CHUNK_MTRL_SHINMASK		=	0xa346,	///< Material Shininess mask
			
			CHUNK_MTRL_RFLCTMAP		=	0xa220,	///< Material Reflect map
			CHUNK_MTRL_RFLCTMASK	=	0xa34c,	///< Material Reflect mask

			/// texture chunks
			CHUNK_TMAP_NAME			=	0xa300,	///< Texture filename
			CHUNK_TMAP_TILING		=	0xa351,	///< Texture tiling
			CHUNK_TMAP_BLUR			=	0xa353,	///< Texture blur
			CHUNK_TMAP_SCALEU		=	0xa354,	///< Texture scale u
			CHUNK_TMAP_SCALEV		=	0xa356,	///< Texture scale v
			CHUNK_TMAP_OFFSETU		=	0xa358,	///< Texture offset u
			CHUNK_TMAP_OFFSETV		=	0xa35a,	///< Texture offset v
			CHUNK_TMAP_ROTATION		=	0xa35c,	///< Texture rotation angle
			CHUNK_TMAP_COLOR1		=	0xa360,	///< Texture color 1
			CHUNK_TMAP_COLOR2		=	0xa362, ///< Texture color 2
			CHUNK_TMAP_REDCOL		=	0xa364,	///< Texture Red color
			CHUNK_TMAP_GREENCOL		=	0xa366,	///< Texture Green color
			CHUNK_TMAP_BLUECOL		=	0xa368,	///< Texture Blue color

			/// keyframing chunks
			CHUNK_KEYFRAME			=	0xb000,	///< Keyframing block chunk
			
			CHUNK_KF_LIGHT_AMBIENT	=	0xb001,	///< KeyFrame ambient light info
			CHUNK_KF_LIGHT_OMNI		=	0xb005, ///< KeyFrame omni light info
			CHUNK_KF_LIGHT_SPOT		=	0xb006, ///< KeyFrame omni light info
			CHUNK_KF_LIGHT_TARGET	=	0xb007, ///< KeyFrame omni light info
			CHUNK_KF_MESH			=	0xb002, ///< KeyFrame mesh info
			CHUNK_KF_CAMERA			=	0xb003, ///< KeyFrame camera info
			CHUNK_KF_CAMERA_TARGET	=	0xb004, ///< KeyFrame camera target info
			CHUNK_KF_FRAMES			=	0xb008,	///< Keyframe start and end frame
			CHUNK_KF_OBJECT_PIVOT	=	0xb013,	///< Keyframe object pivot point
			CHUNK_KF_OBJECT_NAME	=	0xb010,	///< Keyframe object pivot point
			
			CHUNK_TRACK_POS			=	0xb020,	///< Keyframe position track
			CHUNK_TRACK_ROT			=	0xb021,	///< Keyframe rotation track
			CHUNK_TRACK_SCALE		=	0xb022,	///< Keyframe scale track
			CHUNK_TRACK_FOV			=	0xb023,	///< Keyframe field of view track
			CHUNK_TRACK_ROLL		=	0xb024,	///< Keyframe roll track
			CHUNK_TRACK_COLOR		=	0xb025,	///< Keyframe color track
			CHUNK_TRACK_MORPH		=	0xb026,	///< Keyframe morph track
			CHUNK_TRACK_HOTSPOT		=	0xb027,	///< Keyframe hotspot track
			CHUNK_TRACK_FALLOFF		=	0xb028,	///< Keyframe falloff track
			CHUNK_TRACK_HIDE		=	0xb029,	///< Keyframe hide track		
		};	

		// keyframe acceleration data bitsettings
		enum ACC_SET {

			TENSION		= 0x01,
			CONINUITY	= 0x02,
			BIAS		= 0x04,
			EASE_TO		= 0x08,
			EASE_FROM	= 0x10,
		};

		FILE*	m_fptr;		///< FILE pointer
	};


//================================================================================
}


#endif
