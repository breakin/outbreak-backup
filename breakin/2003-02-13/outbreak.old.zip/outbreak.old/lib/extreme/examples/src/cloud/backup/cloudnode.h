#ifndef CLOUD_NODE
#define CLOUD_NODE

#include <x3m_typedef.h>
#include <x3m_exception.h>
#include <x3m_system.h>
#include <math/x3m_vector.h>

#include "cloudparticle.h"
#include "cloudrender.h"
#include "cloudlight.h"

#define TRANSPAR Extreme::uint32((1.0-exp(-80.0))*255.0)

/* TODO:
	If we define two sets of particle per cell, 'unique' and 'shared' we could 

	1) get rid of frameCount check for unique and
	2) make som form of LOD for unique later (but not shared) (will this look like shite?)

	Sorting MIGHT be a problem, but we could keep a list of sorted particles
	that contains ALL shared and those from whatever LOD-level used (problem here with LOD-shading,
	but perhaps with this method LOD-shading could be avoided)
*/

namespace Cloud {

	class TreeNode {
	private:

		Extreme::Vector3	mMidPoint;
		Extreme::float32	mBoxSize; // width, height, depth of (half box) ... "radius"

		std::list<Particle*> mParticles;

		bool				mLeaf;
		TreeNode*		mChilds[8];
	
		
	public:

		void insertPuffs(const std::vector<Particle*> &puffs);
		void insertParticle(Particle *particle);

		TreeNode(const Extreme::Vector3 &midPoint=Extreme::Vector3(0,0,0), const Extreme::float32 boxSize=0) : mMidPoint(midPoint), mBoxSize(boxSize) {
			X3M_DEBUG("TreeNode::TreeNode", "midPoint=(%f %f %f), boxSize=%f", mMidPoint.x, mMidPoint.y, mMidPoint.z, mBoxSize);
			
			mLeaf=true;
			for (int c=0; c<8; c++) mChilds[c]=0;
		}

		~TreeNode() {
			for (int c=0; c<8; c++) {
				delete mChilds[c];
			}
		}

		

		void renderParticle(Render &render, const Particle *particle, const std::vector<Light> &lights, const Extreme::Vector3 &ambientColor, const Extreme::Matrix4x4 &viewMatrix, const Extreme::Matrix4x4 &projectMatrix, const Extreme::Vector3 &cameraPosition) {

			// Fixed-point?

			// Start with ambient
			Extreme::Vector3 color=ambientColor;

			// Sum light for all lightsources
			for (int l=0; l<lights.size(); l++) {
				
				const Extreme::Vector3 eyeParticleDir=(cameraPosition-particle->pos).getNormalized();

				const float rCosAlpha=eyeParticleDir*lights[l].dir;

				const float factor=.75*(1.0+rCosAlpha*rCosAlpha);

				color+=lights[l].color*(particle->intensity[l]*factor*lights[l].intensity);	
			}

			if (color.x>255.0) color.x=255.0;
			if (color.y>255.0) color.y=255.0;
			if (color.z>255.0) color.z=255.0;

			// Optimize
			const Extreme::uint32 col=(TRANSPAR<<24)+(int(color.x)<<16)+(int(color.y)<<8)+int(color.z);

			render.drawQuad(particle->viewPos, particle->radius, col, viewMatrix, projectMatrix);
		}

		void render(Render &render, const std::vector<Light> &lights, const Extreme::Vector3 &ambientColor, const Extreme::Matrix4x4 &viewMatrix, const Extreme::Matrix4x4 &projectMatrix, const Extreme::Vector3 &cameraPosition) {

			// Use a view-frustum.. 
			
			if (mLeaf) {
				
				// This is a leaf so no childs, just render particles

				// TODO: Unless LOD is used we could pre-transform all vertices in one sweep
				// Since we have a vector that would be rather fast... also some of the projection
				// could be done there... just an idea

				// TODO: If we sort our list of particle (due to their view Z)
				// then we can keep the list, only update with sort when cameraError

				std::map<float, Particle*> sortList;

				for (std::list<Particle*>::iterator i=mParticles.begin(); i!=mParticles.end(); ++i) {
					(*i)->viewPos=viewMatrix*(*i)->pos;

					if ((*i)->viewPos.z>0.0) {
						sortList[-(*i)->viewPos.z]=*i;
					}
				}

				for (std::map<float,Particle*>::iterator im=sortList.begin(); im!=sortList.end(); ++im) {
					renderParticle(render, im->second, lights, ambientColor, viewMatrix, projectMatrix, cameraPosition);
				}

				return;
			}

			// This fucks up if several at same z
			// Slow too
			std::map<Extreme::float32,TreeNode*> nodeList;

			// Recurse childs, sort them on z
			for (int c=0; c<8; c++) {

				TreeNode * node=mChilds[c];

				// Node active?
				if (node!=NULL) {

					// Transform node-particle midpoint (TODO: we only need z!)
					const Extreme::Vector3 viewMid=viewMatrix*node->mMidPoint;

					// Can we see the node at all?
					if (viewMid.z+node->mBoxSize>0) {
	
						nodeList[-viewMid.z]=node;
					}
				}
			}

			for (std::map<float,TreeNode*>::iterator i=nodeList.begin(); i!=nodeList.end(); ++i) {
				i->second->render(render, lights, ambientColor, viewMatrix, projectMatrix, cameraPosition);
			}
		}
	};
}



#endif