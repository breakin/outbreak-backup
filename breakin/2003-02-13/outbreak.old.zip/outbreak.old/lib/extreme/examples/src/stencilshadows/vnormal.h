#ifndef ZIPPO_VNORMAL
#define ZIPPO_VNORMAL

// See max-sdk advanced topics on calculatin face/vertex-normals

#include <x3m_typedef.h>
#include <math/x3m_vector.h>

namespace Zippo {

	class VNormal {
	private:

		Extreme::Vector3 m_normal;
		Extreme::uint32  m_smooth;
		VNormal*		 m_next;
		bool			 m_init;

	public:

		VNormal() { 
			m_next=NULL;
			m_smooth=0;
			m_init=false;
		}

		VNormal(const Extreme::Vector3 &normal, const Extreme::uint32 smooth) {
			m_next=NULL;
			m_normal=normal;
			m_smooth=smooth; 
			m_init=false;
		}

		~VNormal() { 
			delete m_next;
		}

		void addNormal(const Extreme::Vector3 &normal, const Extreme::uint32 smooth) {
			if (!(smooth & m_smooth) && m_init) {
				if (m_next) {
					m_next->addNormal(normal,smooth);
				} else {
					m_next=new VNormal(normal,smooth);
				}
			} else {
				m_normal+=normal;
				m_smooth|=smooth;
				m_init=true;
			}
		}

		const Extreme::Vector3 &getNormal(const Extreme::uint32 smooth) const {
			if ((smooth & m_smooth) || (!m_next)) {
				return m_normal;
			} else {
				return m_next->getNormal(smooth);
			}
		}

		void normalize() {
			VNormal *ptr=m_next, *prev=this;

			while (ptr) {
				if (ptr->m_smooth&m_smooth) {
					m_normal+=ptr->m_normal;
					prev->m_next=ptr->m_next;
					delete ptr;
					ptr=prev->m_next;
				} else {
					prev=ptr;
					ptr=ptr->m_next;
				}
			}

			m_normal.normalize();
			if (m_next) m_next->normalize();
		}
	};
}

#endif