#ifndef CLOUD_PARTICLE
#define CLOUD_PARTICLE

#include <x3m_typedef.h>
#include <x3m_exception.h>
#include <x3m_system.h>
#include <math/x3m_vector.h>
#include "cloudrender.h"

namespace Cloud {

	struct Particle {
		
		int	frameCount;

		Extreme::Vector3 pos,viewPos;
		Extreme::float32 radius;
		Extreme::float32 transparency;
		
		// An intensity for this particle PER LIGHT
		std::vector<float> intensity; // float32?
	};
}

#endif