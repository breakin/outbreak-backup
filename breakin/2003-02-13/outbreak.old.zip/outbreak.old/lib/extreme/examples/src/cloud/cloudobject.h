#ifndef CLOUD_OBJECT
#define CLOUD_OBJECT

#include <x3m_typedef.h>
#include <x3m_exception.h>
#include <x3m_system.h>
#include <math/x3m_vector.h>

#include "cloudrender.h"
#include "cloudlight.h"
#include "cloudpuff.h"
#include "cloudparticle.h"

namespace Cloud {

	struct Object {

		// When rendering this is the amount of transparity to use (alpha in color)
		static const unsigned char mTransparity;
		
		Extreme::BSphere mBSphere;

		std::list<Puff> mPuffs;
		std::vector<Particle> mParticles;

		Object(const Extreme::BSphere &b) : mBSphere(b) {
			X3M_DEBUG("Cloud::Object::Object", "Constructing object %p", this);
		}

		~Object() {
			X3M_DEBUG("Cloud::Object::~Object", "Destructing object %p", this);
		}

		void createParticles() {
			X3M_DEBUG("Cloud::Object::createParticles", "Creating particles for cloud %p", this);

			// Decide, based on mPuffs, how many particles we need

			mParticles.resize(mPuffs.size()*25);

			int c=0;
			for (std::list<Puff>::const_iterator p=mPuffs.begin(); p!=mPuffs.end(); ++p) {

				for (int d=0; d<25; d++, c++) {
					mParticles[c].pos.x=p->pos.x+p->radius*(-0.5+1.0*float(rand()%1000)/1000.0);
					mParticles[c].pos.y=p->pos.y+p->radius*(-0.5+1.0*float(rand()%1000)/1000.0);
					mParticles[c].pos.z=p->pos.z+p->radius*(-0.5+1.0*float(rand()%1000)/1000.0);
					mParticles[c].radius=p->radius*0.5*(0.7+0.3*float(rand()%1000)/1000.0); // 30% of total radius
					mParticles[c].transparency=1.0-p->density;
				}
			}
		}
		

		void precalc(const std::list<Object*> &objects, const Light &light) {
			X3M_DEBUG("Cloud::Object::precalc", "Precalcing %p with regard to light %p", this, &light);
		}

		void render(Render &render, const std::vector<Light> &mLights,const Extreme::Vector3 &ambientColor,const Extreme::Vector3 &cameraPosition, const Extreme::Matrix4x4 &viewMatrix, const Extreme::Matrix4x4 &projectMatrix) {

			/* Idea: We can check each PUFF for inside/outside-frustum (we know object is inside or we would not have
				gotten here). That way we will get rather good rejection. Furthermore we could store all the particles
				in different list, one list for each PUFF-combination... ie particles in PUFF 1,2,3 is in one list.
				That way we could reject particles too (and only store them once). */

			/*  Do we need a new imposter? If not jump to draw imposter
			
				Calculate extend of imposter

					We want the largest bounding-sphere-diameter INSIDE view frustum
					  (this could be obtained by testing all smaller puffs)

					We want some kind of resolution factor so clouds CLOSE to camera get LOWER resolution
						(they will be blurred anyway)

				Create the imposter (via render?)

				Sort all particles, closes to camera last

				Render all particles to the imposter

				Draw imposter
			*/
			
			// This is shit
			for (int p=0; p<mParticles.size(); p++) {
				const Extreme::Vector3 viewPos=mParticles[p].pos*viewMatrix;

				if (viewPos.z>0) {
					render.drawQuad(viewPos, mParticles[p].radius, (mTransparity<<24)+0xffffff, viewMatrix, projectMatrix);
				}

			}

		}
	};
}

#endif
	