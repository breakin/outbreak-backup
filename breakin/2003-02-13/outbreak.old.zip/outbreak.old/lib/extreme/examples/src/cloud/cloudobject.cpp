#include "cloudobject.h"
#include <math.h>

const unsigned char Cloud::Object::mTransparity=((1.0-exp(-80.0))*255.0);