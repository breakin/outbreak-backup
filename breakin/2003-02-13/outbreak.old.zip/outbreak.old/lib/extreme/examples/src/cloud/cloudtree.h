#ifndef CLOUD_TREE
#define CLOUD_TREE

#include <x3m_typedef.h>
#include <x3m_exception.h>
#include <x3m_system.h>
#include <math/x3m_vector.h>

#include "cloudrender.h"
#include "cloudparticle.h"
#include "cloudobject.h"
#include "cloudpuff.h"

namespace Cloud {

	class Tree {
	private:

		Extreme::Vector3		mAmbientColor;

		std::vector<Light>		mLights;

		std::list<Object*>		mObjects;

		Render mRender;
		
	public:

		~Tree() {
			for (std::list<Object*>::iterator o=mObjects.begin(); o!=mObjects.end(); ++o) {
				delete *o;
			}
		}

		// Load objects'n'puffs'n'lights'n'ambient from file
		void init() {

			// Create 10 objects...
			for (int o=0; o<10; o++) {

				const Extreme::Vector3 pos(rand()%1000-500,rand()%1000-500,rand()%1000-500);
				const Extreme::float32 radius=(rand()%180)+180;

				Object *object=new Object(Extreme::BSphere(pos,radius));

				// ...with 5 puffs each
				for (int p=0; p<5; p++) {

					Cloud::Puff temp;
					temp.pos.x=pos.x+radius*(-0.5+1.0*float(rand()%1000)/1000.0);
					temp.pos.y=pos.y+radius*(-0.5+1.0*float(rand()%1000)/1000.0);
					temp.pos.z=pos.z+radius*(-0.5+1.0*float(rand()%1000)/1000.0);
					temp.radius=radius*0.5*(0.7+0.3*float(rand()%1000)/1000.0); // 50% of total radius
					temp.density=0.1+0.9*float(rand()%1000)/1000.0;

					object->mPuffs.push_back(temp);
				}

				object->createParticles();

				mObjects.push_back(object);
			}

			// Lampor
			Cloud::Light sun;
			sun.pos=Extreme::Vector3(0,1000.0,0);
			sun.dir=(Extreme::Vector3(0,0,0)-sun.pos).getNormalized();
			sun.color=Extreme::Vector3(200,200,200);		// this one can be changed dynamically
			sun.intensity=1.0;			// this one can be changed dynamically

			mLights.push_back(sun);

			// Ambient color
			mAmbientColor=Extreme::Vector3(0,0,0);

			// Precalculate lightning per light

			for (std::vector<Light>::iterator l=mLights.begin(); l!=mLights.end(); ++l) {

				// Sort mObjects with regard to light l
				// (closes first)
				
				// Precalculate lightning for light l for each object
				// We send in mObjects so cloud objects can be shaded by
				// clouds inbetween them and the light
				// (just iterator until *this is found, then stop)

				for (std::list<Object*>::iterator o=mObjects.begin(); o!=mObjects.end(); ++o) {
					(*o)->precalc(mObjects,*l);
				}
			}

			// Calculate maximum amount of particles PER OBJECT and feed into render::init
			// as maximum-particles-per-drawPrim-call
			mRender.init();
		}

		void render(const Extreme::float32 width, const Extreme::float32 height, const Extreme::Matrix4x4 &viewMatrix, const Extreme::Matrix4x4 &projectMatrix, const Extreme::Vector3 &cameraPosition) {

			// We must create up/right-vectors for render so it can draw quads
			// in viewspace

			mRender.prepareFrame(width,height); // viewMatrix,projectMatrix

			for (std::list<Object*>::iterator i=mObjects.begin(); i!=mObjects.end(); ++i) {
				(*i)->render(mRender,mLights,mAmbientColor,cameraPosition,viewMatrix,projectMatrix);
			}

			mRender.finishFrame();
		}
	};
}

#endif