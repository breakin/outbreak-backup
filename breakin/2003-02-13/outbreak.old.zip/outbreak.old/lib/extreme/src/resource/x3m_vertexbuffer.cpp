//==========================================================================================
// Include files
//==========================================================================================

#include "x3m_vertexbuffer.h"
#include "x3m_modelmanager.h"
#include "..\debug\x3m_assert.h"
#include "..\rendersystem\x3m_rendersystem.h"
#include "..\rendersystem\x3m_d3dutil.h"


//==========================================================================================
// Namespace usage
//==========================================================================================

using namespace Extreme;

//==========================================================================================
// Method definitions
//==========================================================================================

VertexBuffer::VertexBuffer(ModelManager * manager) : Resource(manager) {

	X3M_DEBUG ("VertexBuffer","Constructing...");
	init();
}

//==========================================================================================

VertexBuffer::~VertexBuffer() {
	
	X3M_DEBUG ("VertexBuffer","Destructing...");
	release();
}

//==========================================================================================

void VertexBuffer::init() {

	memset (&mD3DVertexBufferDesc,0,sizeof (mD3DVertexBufferDesc));
	mD3DVertexBuffer = NULL;
	mVertexStride = 0;
	mVertexCount = 0;
	mPosition = 0;
	mLocked = false;
}

//==========================================================================================

void VertexBuffer::create(const int32 numVertices, const uint32 fvf, const VertexBuffer::eUsage usage) {

	X3M_ASSERT(mD3DVertexBuffer == NULL);
	
	// get the vertexsize for vertex with the given format
	int32 stride = Direct3DUtil::getInstance().getVertexSize(fvf);
	
	// set default pool and usage to readonly swbuffer
	D3DPOOL d3dPool = D3DPOOL_SYSTEMMEM;
	DWORD d3dUsage = D3DUSAGE_SOFTWAREPROCESSING;

	// determine which pool to allocate vertexbuffer in
	if (usage == USAGE_DYNAMIC) {
		d3dPool = D3DPOOL_DEFAULT;
		d3dUsage = D3DUSAGE_DYNAMIC | D3DUSAGE_WRITEONLY;
	}
	else if (usage == USAGE_STATIC) {
		d3dPool = D3DPOOL_MANAGED;
		d3dUsage = D3DUSAGE_WRITEONLY;
	}

	// initialize vertexbuffer description
	memset(&mD3DVertexBufferDesc, 0, sizeof (mD3DVertexBufferDesc));
    mD3DVertexBufferDesc.Type   = D3DRTYPE_VERTEXBUFFER;
    mD3DVertexBufferDesc.Usage  = d3dUsage;
	mD3DVertexBufferDesc.Pool   = d3dPool;
    mD3DVertexBufferDesc.Size	= numVertices * stride;
    mD3DVertexBufferDesc.FVF	= fvf;
	mD3DVertexBufferDesc.Format = D3DFMT_VERTEXDATA;
	
	// set stride, size of a single vertex
	mVertexStride = stride;
	mVertexCount  = numVertices;
	mUsage = usage;
	
	// set pointer to NULL
	mD3DVertexBuffer = NULL;

	// create the vertexbuffer
	HRESULT result = RenderSystem::getInstance().getD3DDevice()->CreateVertexBuffer(
			mD3DVertexBufferDesc.Size, 
			mD3DVertexBufferDesc.Usage, 
			fvf, 
			mD3DVertexBufferDesc.Pool, 
			&mD3DVertexBuffer
			);

	// check result
	if (result != D3D_OK)
		throw Exception ("Could not create a Direct3D VertexBuffer, result(%s)", Direct3DUtil::getInstance().resultToString(result));

	/// allocate memory for sw backup of vertices
//	mVertexData = new uint8[stride * numVertices];
}

//==========================================================================================

const int32 VertexBuffer::getSize() const {
	return mVertexCount;
}

//==========================================================================================

void VertexBuffer::release() {
	X3M_DEBUG ("VertexBuffer", "Releasing VertexBuffer resource (%s)", getName().c_str());
	unlock();
	COM_SAFE_RELEASE(mD3DVertexBuffer);
	init();
}

//==========================================================================================

void VertexBuffer::dispose() {

	// only dispose hw resources, nonmanaged
	if (mD3DVertexBufferDesc.Pool == D3DPOOL_DEFAULT) {
	
		unlock();
		COM_SAFE_RELEASE(mD3DVertexBuffer);
		mDisposed = true;
	}
}

//==========================================================================================

void VertexBuffer::restore() {

	if (mDisposed) {
		// restore hw resource
		HRESULT result = RenderSystem::getInstance().getD3DDevice()->CreateVertexBuffer(mVertexCount, 
			mD3DVertexBufferDesc.Usage, 
			mD3DVertexBufferDesc.FVF, 
			mD3DVertexBufferDesc.Pool, 
			&mD3DVertexBuffer);
		
		if (result != D3D_OK)
			throw Exception ("Failed to restore vertexbuffer resource!");
	}
}

//==========================================================================================

void VertexBuffer::unlock() {

	X3M_ASSERT (mD3DVertexBuffer);

	if (mLocked) {
		// upload swbuffer
		mD3DVertexBuffer->Unlock();
		mLocked = false;
	}
}

//==========================================================================================

const bool VertexBuffer::isLocked() const {
	return mLocked;
}

//==========================================================================================

const VertexBuffer::eUsage VertexBuffer::getUsage() const {
	return mUsage;
}

//==========================================================================================

const int32 VertexBuffer::getStride() const {
	return mVertexStride;
}

//==========================================================================================

const int32 VertexBuffer::getDataSize() const {
	return mD3DVertexBufferDesc.Size;
}

//==========================================================================================

const uint32 VertexBuffer::getFormat() const {
	return mD3DVertexBufferDesc.FVF;
}

//==========================================================================================

const void * VertexBuffer::lock(const int32 lockSize) const {
	return const_cast<const VertexBuffer *>(this)->lock(lockSize);
}

//==========================================================================================

void * VertexBuffer::lock(const int32 pLockSize) {

	X3M_ASSERT (mD3DVertexBuffer);
	void * vertexData;
	uint32 lockFlags = D3DLOCK_NOSYSLOCK;
	uint32 lockPosition = 0;
	uint32 lockSize = pLockSize == 0 ? mD3DVertexBufferDesc.Size : pLockSize * mVertexStride;

	if (!mLocked) {
	
		// treat locks of dynamic vertexbuffers more optimal 
		if (mD3DVertexBufferDesc.Usage & D3DUSAGE_DYNAMIC) {

			// default lock to append/no overwrite
			lockFlags = LOCK_APPEND;

			// check if we should flush and discard 
			if ((mPosition + lockSize) > mVertexCount) {
			
				mPosition = 0;
				lockFlags = LOCK_FLUSH;
			}
		
			// set locally declared lock-offset
			lockPosition = mPosition;
		}
		
		// lock buffer
		HRESULT result = mD3DVertexBuffer->Lock(	
			lockPosition * mVertexStride, 
			lockSize, 
			reinterpret_cast<BYTE**>(&vertexData), 
			lockFlags);

		// check result
		if (result != D3D_OK) {
			X3M_ERROR ("VertexBuffer", "Could not lock D3D VertexBuffer, reason (%s)", Direct3DUtil::getInstance().resultToString(result));
			return NULL;
		}

		// set lockflag and return data
		mLocked = true;
		mPosition += lockSize;
		return vertexData;
	}

	return NULL;
}

//==========================================================================================

IDirect3DVertexBuffer * VertexBuffer::getD3DVertexBuffer() {
	return mD3DVertexBuffer;
}

//==========================================================================================

void VertexBuffer::upload(const void * srcData,const int32 dstOffs, const int32 numVertices) {

	// lock and calculate vertexoffsets
	uint8 * dstData = (uint8*)lock(numVertices);
	dstData += dstOffs * mVertexStride;

	// copy srcdata into vertexbuffer
	if (dstData) {
		memcpy(dstData, srcData, numVertices * mVertexStride);
		unlock();
	}
	else
		throw Exception ("Not able to upload vertices to vertexbuffer!");
}

//==========================================================================================

const VertexBuffer::ePrimitiveType VertexBuffer::getPrimitiveType() const {
	return mPrimitiveType;
}

//==========================================================================================

void VertexBuffer::setPrimitiveType(const VertexBuffer::ePrimitiveType primType) {
	mPrimitiveType = primType;
}

//==========================================================================================
