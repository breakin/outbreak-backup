#ifndef __EXTREME_RESOURCE_SUBMODEL_INC__
#define __EXTREME_RESOURCE_SUBMODEL_INC__

#include "..\x3m_typedef.h"
#include "..\rendersystem\x3m_renderunit.h"
#include "x3m_material.h"
#include "x3m_vertexbuffer.h"
#include "x3m_indexbuffer.h"

namespace Extreme {

	/**
	 * @class	SubModel
	 * @brief	Part of a Model geometry, associated with a certain material
	 * @author	Peter Nordlander
	 * @date	2002-04-20
	 */

	class Model;
	class SubModel
	{
	public:
		
		/**
		 * Constructor
		 */
		SubModel(Model * parent);

		/**
		 * Destructor
		 */
		virtual ~SubModel();

		/**
		 * Set submodel's material
		 * @param material Handle to a material
		 */
		void setMaterial(const MaterialHandle material);
		
		/**
		 * Get submodel's material
		 * @return The submodel's material
		 */
		const MaterialHandle getMaterial() const;
		
		/**
		 * Set the amount of primitives represented by this submodel
		 * @param primCount Amount of primitives represented by this submodel
		 */
		void setPrimitiveCount(const int32 primCount);

		/**
		 * Set startoffset in vertexbuffer, or indexbuffer if model has indexed geometry data
		 * @param startOffset Startoffset in vertexbuffer, or indexbuffer if model has indexed geometry data
		 */
		void setStartOffset(const int32 startOffset);
		
		/**
		 * Retrieve amount of primitives that this submodel manage
		 * @return Amount of primitives that this submodel manage
		 */
		const int32 getPrimitiveCount() const { return mPrimCount; }
	
		/**
		 * Retrieve Index/Vertex-buffer startoffset for this submodel
		 * @return Index/Vertex-buffer startoffset for this submodel
		 */
		const int32 getStartOffset() const { return mPrimStart; }

		/**
		 * Retrive the submodels's associated vertexbuffer
		 * @return Handle to the vertexbuffer that this submodel is attached to
		 */
		const RenderUnit createInstance() const;

	protected:
		
		Model *			mParentModel;	///< SubModel's parent
		int32			mPrimCount;		///< Number of primitives in this submodel
		int32			mPrimStart;		///< Start index in vertexbuffer if non indexed, otherwise in indexbuffer
		MaterialHandle	mMaterial;		///< Material used for this submodel
	};

	typedef TSmartPtr<SubModel> SubModelHandle;
}

#endif
