//==========================================================================================
// Include files
//==========================================================================================

#include "x3m_texture.h"
#include "..\debug\x3m_assert.h"
#include "..\rendersystem\x3m_rendersystem.h"
#include "..\rendersystem\x3m_d3dutil.h"


/// d3d includes
#include <d3dx8.h>

//==========================================================================================
// Namespace usage
//==========================================================================================

using namespace Extreme;

//==========================================================================================
// Method definitions
//==========================================================================================
			
Texture::Texture(TextureManager * creator) : Resource(creator) {
	init();
}

//==========================================================================================

Texture::~Texture() {
	release();
}

//==========================================================================================

void Texture::init() {

	mDisposed = true;
	mD3DTexture = NULL;

	mDesc.mWidth = 0;
	mDesc.mHeight = 0;
	mDesc.mBitDepth = 32;
	mDesc.mMipLevels = 0;

	mLockedLevel = -1;
}

//==========================================================================================

void Texture::create(const std::string &fileName) {
	
	X3M_ASSERT (mD3DTexture == NULL);
	X3M_ASSERT (RenderSystem::getInstance().getD3DDevice() != NULL);	
	
	D3DXIMAGE_INFO d3dImageInfo;
	
	// store name
	mName = fileName;

	// load texture from file
	HRESULT res = D3DXCreateTextureFromFileEx(
		RenderSystem::getInstance().getD3DDevice(),
		mName.c_str(), 0, 0 , 1, 0, D3DFMT_UNKNOWN, D3DPOOL_DEFAULT,
		D3DX_FILTER_LINEAR, D3DX_FILTER_LINEAR , 0, 
		&d3dImageInfo, NULL, &mD3DTexture);

	if (res != D3D_OK)
		throw Exception ("Could not load texture [%s] D3DERR[%s]", mName.c_str(), Direct3DUtil::getInstance().resultToString(res));

	// fill in texture properties
	mDesc.mWidth = d3dImageInfo.Width;
	mDesc.mHeight = d3dImageInfo.Height;
	mDesc.mBitDepth = d3dImageInfo.Depth;
	mDesc.mMipLevels = d3dImageInfo.MipLevels;
	mDisposed = false;
}

//==========================================================================================

void Texture::create(const std::string &name, const Texture::Desc & desc) {
	
	X3M_ASSERT (mD3DTexture == NULL);
	X3M_ASSERT (RenderSystem::getInstance().getD3DDevice() != NULL);	
	
	// store name
	mName = name;
	mDesc = desc;

	// create the texture
	HRESULT res = RenderSystem::getInstance().getD3DDevice()->CreateTexture(
		mDesc.mWidth,
		mDesc.mHeight,
		mDesc.mMipLevels,
		mDesc.mUsage,
		D3DFMT_A8R8G8B8,
		D3DPOOL_MANAGED,
		&mD3DTexture
		);
		
	if (res != D3D_OK)
		throw Exception ("Could not load texture [%s] D3DERR[%s]", mName.c_str(), Direct3DUtil::getInstance().resultToString(res));

	mDisposed = false;
}

//==========================================================================================

void Texture::release() {
	COM_SAFE_RELEASE(mD3DTexture);
	init();
}

//==========================================================================================

void Texture::dispose() {
	COM_SAFE_RELEASE(mD3DTexture);
	mDisposed = true;
}

//==========================================================================================

void Texture::restore() {
	if (mDisposed)
		create(mName);
}

//==========================================================================================

const int32 Texture::getDataSize() const {
	return mDesc.mWidth * mDesc.mHeight * (mDesc.mBitDepth >> 3);
}

//==========================================================================================

const Texture::Desc& Texture::getDesc(const int32 level) const {
	
	if (!level)
		return mDesc;

	static Texture::Desc levelDesc;
	D3DSURFACE_DESC surfDesc;

	mD3DTexture->GetLevelDesc(level, &surfDesc);
	levelDesc.mBitDepth = Direct3DUtil::getInstance().formatToBitDepth(surfDesc.Format);
	levelDesc.mUsage = (Texture::eUsage)surfDesc.Usage;
    levelDesc.mWidth= surfDesc.Width;
    levelDesc.mHeight = surfDesc.Height;
	return levelDesc;
}

//==========================================================================================

IDirect3DBaseTexture * Texture::getD3DTexture() const {
	return mD3DTexture;
}

//==========================================================================================

const uint32 * Texture::lock(const int32 level, int32 & pitch, Texture::Desc &levelDesc) const {
	
	X3M_ASSERT (mD3DTexture);
	X3M_ASSERT (mLockedLevel == -1);
	
	X3M_DEBUG ("Texture", "Lock texture(%s), level(%d)", mName.c_str(), level);

	D3DLOCKED_RECT rect;
	D3DSURFACE_DESC surfDesc;
	mD3DTexture->GetLevelDesc(level, &surfDesc);
	levelDesc.mBitDepth = Direct3DUtil::getInstance().formatToBitDepth(surfDesc.Format);
	levelDesc.mUsage = (Texture::eUsage)surfDesc.Usage;
    levelDesc.mWidth= surfDesc.Width;
    levelDesc.mHeight = surfDesc.Height;

	mD3DTexture->LockRect(level,&rect, NULL, 0);
	
	pitch = rect.Pitch;
	mLockedLevel = level;
	mLockedDesc = levelDesc;
	return (uint32 *)rect.pBits;
}

//==========================================================================================

uint32 * Texture::lock(const int32 level, int32 &pitch, Texture::Desc &levelArea) {
	return const_cast<uint32*>(const_cast<const Texture*>(this)->lock(level, pitch, levelArea));
}

//==========================================================================================

void Texture::unlock() const {
		
	if (mLockedLevel != -1) {
	
		X3M_DEBUG ("Texture", "Unlock texture(%s), level(%d)", mName.c_str(), mLockedLevel);
		mD3DTexture->UnlockRect(mLockedLevel);
		mLockedLevel = -1;
	}
}

//==========================================================================================

void Texture::resize(const Texture::Desc & newDesc) {

	std::string tempName = mName;

	// release old texture
	release();	
	
	// recreate texture, use same name
	create(tempName, newDesc);
}

//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
