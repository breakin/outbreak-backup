#ifndef __EXTREME_RESOURCE_CUBETEXTURE_INC__
#define __EXTREME_RESOURCE_CUBETEXTURE_INC__

#include "x3m_texture.h"

namespace Extreme {

	class CubeTexture : public Texture
	{


	};
}

#endif