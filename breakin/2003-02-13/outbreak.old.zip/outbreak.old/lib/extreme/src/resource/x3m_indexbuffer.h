#ifndef __EXTREME_RESOURCE_INDEXBUFFER_INC__
#define __EXTREME_RESOURCE_INDEXBUFFER_INC__

#include "x3m_resource.h"
#include "..\x3m_typedef.h"
#include "..\template\x3m_smartptr.h"
#include "..\template\x3m_refcount_resource.h"
#include "..\rendersystem\x3m_d3dversion.h"

namespace Extreme {

	/**
	 * @class  IndexBuffer
	 * @brief  Class storing indicies information into vertexbuffers
	 * @author Peter Nordlander
	 * @date   2002-04-20
	 */
	class ModelManager;
	class IndexBuffer : public Resource
	{
	public:
		
		/**
		 * Indexbuffer allocation/usage models
		 */
		enum eUsage 
		{
			USAGE_DYNAMIC  = 0x01,	///< Index buffer contains dynamically/runtime changabe data
			USAGE_STATIC   = 0x02,	///< Index buffer contains static data
		};

		/**
		 * Index bitcout
		 */
		enum eIndexType
		{
			INDEX_16		= 0x01,	///< 16bit Indexes
			INDEX_32		= 0x02,	///< 32bit Indexes
		};

		/**
		 * Constructor
		 */
		IndexBuffer(ModelManager * creator);

		/**
		 * Destructor
		 */
		~IndexBuffer();

		/**
		 * Create a new indexbuffer
		 * @param indexType Index bitdepth, either 16 or 32 bit indexes, @see eIndexType
		 * @param length Length of indexbuffer in indices
		 * @param usage How the indexbuffer will be used, @see IndexBuffer::eUsage
		 */
		void create(const int32 length, const eIndexType indexType, const eUsage usage);
		
		/**
		 * Lock indexbuffer
		 * @param startOffs Start of region to lock
		 * @param lockSize Size of locked region, in indices
		 * @param discardContents True if we do not care about the former contents
		 * @return Address of indexbuffer's internal data, NULL on failure on not locked 
		 */
		void * lock(const int32 startOffs = 0, const int32 size = 0, const bool discardContents = false);

		/**
		 * Lock indexbuffer
		 * @param startOffs Start of region to lock
		 * @param lockSize Size of locked region, in indices
		 * @param discardContents True if we do not care about the former contents
		 * @return Address of indexbuffer's internal data, NULL on failure on not locked 
		 */
		const void * lock(const int32 startOffs, const int32 size, const bool discardContents) const;

		/**
		 * Release indexbuffer
		 */
		void release();

		/**
		 * Unlock vertexbuffer
		 */
		void unlock();

		/** 
		 * Check weither indexbuffer is locked
		 * @return true if indexbuffer is locked, false otherwise
		 */
		const bool isLocked() const;

		/**
		 * Get indexbuffer usage
		 * @return The usage of this indexbuffer, @see IndexBuffer::eUsage
		 */
		const eUsage getUsage() const;

		/**
		 * Get indexbuffer's indicestype, size of each index
		 * @return The indextype set and allocated for this indexbuffer, @see IndexBuffer::eIndexType
		 */
		const eIndexType getIndexType() const;

		/**
		 * Get size if indexbuffer
		 * @return Size of indexbuffer, in indices
		 */
		const int32 getSize() const;

		/**
		 * Get the total allocated size of this indexbuffer
		 * @return Size of indexbuffer, in bytes
		 */
		const int32 getDataSize() const { return mDesc.Size; }

		IDirect3DIndexBuffer * getD3DIndexBuffer() { return mD3DIndexBuffer; }


	protected:

		/**
		 * Initialize members to their default values
		 */
		void init();

		D3DINDEXBUFFER_DESC		mDesc;				///< IndexBuffer description
		IDirect3DIndexBuffer*	mD3DIndexBuffer;	///< Direct3D COM interface
		bool					mLocked;			///< Locking indicator
		int32					mSize;				///< Size of buffer, amount of indices
	};

	typedef TSmartPtr<IndexBuffer, TRefCountResource<IndexBuffer> > IndexBufferHandle;
}

#endif
