//==========================================================================================
// Include files
//==========================================================================================

#include "..\debug\x3m_debug.h"
#include "..\rendersystem\x3m_texturelayer.h"
#include "x3m_material.h"
#include "x3m_materialmanager.h"

//==========================================================================================
// Namespace usage
//==========================================================================================

using namespace Extreme;

//==========================================================================================
// Method definitions
//==========================================================================================
			
Material::Material(MaterialManager * creator) : 
	
	// initialize material defaults
	Resource(creator)
{
	init();
	X3M_DEBUG ("Material", "Constructing...");	
}

//=============================================================================================================

void Material::init() {
	mFillMode  = Material::FILL_SOLID;
	mShadeMode = Material::SHADE_GOURAUD;
	mCullMode  = Material::CULL_CCW;
	mAmbientColorSource  = Material::COLORSRC_SURFACE;
	mDiffuseColorSource  = Material::COLORSRC_SURFACE;
	mSpecularColorSource = Material::COLORSRC_SURFACE;
	mLightingEnable = false;
	mDepthBufferEnable = true;
	mDepthWriteEnable = true;
	mBlendEnable = true;
	mTextureLayers.clear();
}

//=============================================================================================================

Material::~Material(){
	X3M_DEBUG ("Material", "Destructing...");
	removeAllTextureLayers();
}

//=============================================================================================================

const int32 Material::getDataSize() const {

	// this is not actually used, so we skip the texture layers for now ;)
	return sizeof (Material);
}

//=============================================================================================================

void Material::create(const std::string &name, const int32 numTextureLayers) {
	
	// init default values
	init();

	// set name
	mName = name;

	// resize texturelayer list
	for (int iTextureLayer = 0; iTextureLayer < numTextureLayers; iTextureLayer++)
		addTextureLayer();
}

//=============================================================================================================

void Material::release() {
	X3M_DEBUG ("Material", "Releasing material (%s)", getName().c_str());
	removeAllTextureLayers();
}

//=============================================================================================================

TextureLayerHandle Material::getTextureLayer(const int32 stage) {
	X3M_ASSERT (stage < mTextureLayers.size());
	return &mTextureLayers[stage];
}

//=============================================================================================================

TextureLayerHandle Material::addTextureLayer() {

	TextureLayer layer;
	layer.init();
	X3M_DEBUG ("Material", "Create a new texturelayer");
	mTextureLayers.push_back(layer);
	X3M_DEBUG ("Material", "Layer was given stage-id(%d)", mTextureLayers.size() - 1);
	return &mTextureLayers[mTextureLayers.size() - 1];
}

//=============================================================================================================

const int32 Material::removeTextureLayer() {
	if (mTextureLayers.size() > 0)
		mTextureLayers.resize(mTextureLayers.size() - 1);
	
	return mTextureLayers.size();
}

//=============================================================================================================

void Material::removeAllTextureLayers() {
	mTextureLayers.clear();
}

//=============================================================================================================

const bool Material::isTransparent() const {
	return mBlendEnable;
}

//=============================================================================================================
