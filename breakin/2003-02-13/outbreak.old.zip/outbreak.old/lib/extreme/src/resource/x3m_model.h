#ifndef __EXTREME_RESOURCE_MODEL_INC__
#define __EXTREME_RESOURCE_MODEL_INC__

#include "..\x3m_typedef.h"
#include "..\scene\volume\x3m_bsphere.h"
#include "x3m_resource.h"
#include "x3m_submodel.h"

namespace Extreme {

	class ModelManager;

	/**
	 * @class Model 
	 * @brief Model-description for a 3D-mesh object.
	 * @author Peter Nordlander
	 */
	class Model : public Resource
	{
	public:
		
		/**
		 * Destructor
		 */
		virtual ~Model();

		/**
		 * Create Model
		 * @param name Name of Model Resouce
		 * @param numVertices Number of vertices in model
		 * @param FVF Vertexformat used in this model
		 * @param primType PrimitiveType describing how the data is organized in the vertexbuffer
		 * @param numIndices Number of indices used in this model
		 */		
		void create(const std::string &name, const int32 numVertices, const uint32 FVF, VertexBuffer::ePrimitiveType primType, const int32 numIndices = 0);

		/**
		 * Release the model
		 */
		void release();

		/**
		 * Create/applends a new submodel to this model
		 * @return The new submodel attached to this model
		 */
		SubModelHandle createSubModel();

		/**
		 * Remove a submodel attached to this model
		 * @param name Name of submodel 
		 * @return A new submodel attached to this model, a null-handle if already exist
		 */		
		void removeSubModel(const SubModelHandle handle);
		
		/**
		 * Remove all submodels attached to this model
		 */
		void removeAllSubModels();
		
		/**
		 * Remove submodel by its index
		 * @param index Index of submodel to remove
		 */
		void removeSubModel(const int32 index);

		/**
		 * Get a submodel by its index
		 * @param index Index of submodel to retrieve
		 * @return SubModel with index @a index, null-handle if out-of-bound index
		 */
		SubModelHandle getSubModel(const int32 index);
	
		/**
		 * Retrive a submodel by its index
		 * @param index Index of submodel to retrieve
		 * @return The submodel corresponding to index @a index, NULL if out-of-bound index
		 */
		const SubModelHandle getSubModel(const int32 index) const;

		/**
		 * Retrieve amount of submodels for this model
		 * @return The amount of submodels attached to this model
		 */
		const int32 getNumSubModels() const;

		/**
		 * Get datasize of this model
		 * @remarks As a modelobject is a combined object, consiting only of other resources.
		 * this method always returns 0.
		 */
		const int32 getDataSize() const { return 0; }
	
		/**
		 * Get the model's vertexbuffer
		 * @return Model's vertexbuffer's handle
		 */
		VertexBufferHandle getVertexBuffer();
		
		/**
		 * Get the model's vertexbuffer
		 * @return Model's vertexbuffer's handle
		 */
		const VertexBufferHandle getVertexBuffer() const;

		/**
		 * Get the model's indexbuffer
		 * @return Model's indexbuffer's handle
		 */
		IndexBufferHandle getIndexBuffer();

		/**
		 * Get the model's indexbuffer
		 * @return Model's indexbuffer's handle
		 */
		const IndexBufferHandle getIndexBuffer() const;

		/**
		 * Convert this model's submodels to their renderunit representation
		 * @param renderUnits RenderUnits built from this model and its submodels
		 * @remarks The renderunits are not complete, transformation is kept empty
		 * so that each mesh reffering to this model can fill in its own transformation matrix
		 */
		void getRenderUnits(RenderUnits &renderUnits);

		/**
		 * Get this model's bounding sphere
		 * @return This model's bounding sphere
		 */
		BSphere & getBoundingSphere();

		/**
		 * Get this model's bounding sphere
		 * @return This model's bounding sphere
		 */
		const BSphere & getBoudingSphere() const;

	protected:
		
		friend class ModelManager;

		/**
		 * Constructor
		 * @param The modelmanager that created this object
		 */
		Model(ModelManager * creator);

		/** 
		 * Initialize data to their defaultvalues
		 */
		void init();

		typedef std::vector<SubModelHandle> SubModelList;
		
		SubModelList		mSubModels;			///< List of submodels 
		VertexBufferHandle	mSysVertexBuffer;	///< Copy of vertexdata in SYSRAM (used to clone this model)
		IndexBufferHandle	mSysIndexBuffer;	///< Copy of indexdata in SYSRAM (used to clone this mode)
		VertexBufferHandle	mVertexBuffer;		///< 
		IndexBufferHandle	mIndexBuffer;
		BSphere				mBoundSphere;
	};

	typedef TSmartPtr<Model, TRefCountResource<Model> > ModelHandle;
}

#endif
