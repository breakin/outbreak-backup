//==========================================================================================
// Include files
//==========================================================================================

#include "x3m_texturemanager.h"
#include "x3m_texture.h"
#include "..\debug\x3m_assert.h"
#include "..\rendersystem\x3m_rendersystem.h"
#include "..\rendersystem\x3m_d3dutil.h"

/// d3d includes
#include <d3dx8.h>

//==========================================================================================
// Namespace usage
//==========================================================================================

using namespace Extreme;

//==========================================================================================

TextureManager * TSingleton<TextureManager>::sSingletonObject = NULL;

//==========================================================================================
// Method definitions
//==========================================================================================

TextureManager::TextureManager() {
	Debug::debug ("TextureManager", "Constructing... (0x%x)", this);
}

//==========================================================================================

TextureManager::~TextureManager() {
	Debug::debug ("TextureManager", "Destructing...(0x%x)", this);
}

//==========================================================================================

TextureHandle TextureManager::createTexture(const std::string &name, const int32 width, const int32 height, const int32 bitDepth , const int32 mipLevels) {

	TextureMap::iterator handleItor = mTextures.find(name);

	X3M_DEBUG ("TextureManager", "Request for texture (%s)", name.c_str()); 
	
	// check if texture where found in database
	if (handleItor != mTextures.end()) {
			
		X3M_DEBUG ("TextureManager", "Texture (%s) already existed in manager, return shared object...", name.c_str());
		return handleItor->second;
	}
	
	X3M_DEBUG ("TextureManager", "Not found, create new texture");

	// create new texture
	TextureHandle handle;
	handle = new Texture(this);

	// insert in database
	mTextures[name] = handle;
	
	Texture::Desc desc;
	desc.mWidth = width;
	desc.mHeight = height;
	desc.mMipLevels = mipLevels;
	desc.mBitDepth = bitDepth;
	desc.mUsage = Texture::USAGE_DEFAULT;

	// set name and load the texture
	handle->create(name, desc);

	// return the new texture
	return handle;
}

//==========================================================================================

TextureHandle TextureManager::createTexture(const std::string &name) {
		
	TextureMap::iterator handleItor = mTextures.find(name);

	X3M_DEBUG ("TextureManager", "Request for texture (%s)", name.c_str()); 
	
	// check if texture where found in database
	if (handleItor != mTextures.end()) {
			
		X3M_DEBUG ("TextureManager", "Texture (%s) already existed in manager, return shared object...", name.c_str());
		return handleItor->second;
	}
	
	X3M_DEBUG ("TextureManager", "Not found, create new texture");

	// create new texture
	TextureHandle handle;
	handle = new Texture(this);

	// insert in database
	mTextures[name] = handle;

	// set name and load the texture
	handle->create(name);

	// return the new texture
	return handle;
}

//==========================================================================================

const uint32 TextureManager::getAvailableTextureMemory() {
	
	if (RenderSystem::getInstance().getD3DDevice() == NULL)
		throw Exception ("TextureManager", "Available texturememory cannot be retrieved, rendersystem is not started!");

	return RenderSystem::getInstance().getD3DDevice()->GetAvailableTextureMem();
}


//==========================================================================================

const uint32 TextureManager::remove(const std::string &name) {

	TextureMap::iterator handleItor = mTextures.find(name);

	if (handleItor != mTextures.end()) {

		X3M_DEBUG ("TextureManager", "Texture (%s) removed from manager", name.c_str());
		mTextures.erase(name);
		return 0;
	}

	X3M_ERROR ("TexturManager", "Texture (%s) not found in manager!", name.c_str());

	return 0;
}

//==========================================================================================

void TextureManager::releaseAll() {
	
	X3M_DEBUG ("TextureManager", "Releasing all textures in manager...");

	if (mTextures.size() > 0) {

		TextureMap::iterator handleItor = mTextures.begin();
	
		while (handleItor != mTextures.end()) {
				
			handleItor->second->release();
			handleItor++;
		}
	}
}

//==========================================================================================
