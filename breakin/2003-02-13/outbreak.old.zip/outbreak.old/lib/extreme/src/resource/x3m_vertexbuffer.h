#ifndef __EXTREME_SCENE_VERTEXBUFFER_INC__
#define __EXTREME_SCENE_VERTEXBUFFER_INC__

#include "..\template\x3m_smartptr.h"
#include "..\template\x3m_refcount_resource.h"
#include "..\rendersystem\x3m_d3dversion.h"
#include "x3m_resource.h"

namespace Extreme {

	/** Forw descl.*/
	class ModelManager;

	/**
	 * @class	VertexBuffer
	 * @brief	Encapuslates functionallity of a Direct3D vertexbuffer together with an indexbuffer
	 * @author	Peter Nordlander
	 * @date	2001-12-05
	 * @TODO	Add support to keep a software only buffer inside the vertexbuffer for reading of vertices
	 */
	class VertexBuffer : public Resource
	{
	public:

		/**
		 * Primitive types
		 */
		enum ePrimitiveType
		{
			PT_POINTLIST = D3DPT_POINTLIST,			///< Vertexbuffer contain pointlist data
			PT_LINELIST	 = D3DPT_LINELIST,			///< Vertexbuffer contain linelist data
			PT_TRILIST	 = D3DPT_TRIANGLELIST,		///< Vertexbuffer contain trianglelist data
			PT_TRIFAN	 = D3DPT_TRIANGLEFAN,		///< Vertexbuffer contain trianglefan data
			PT_TRISTRIP	 = D3DPT_TRIANGLESTRIP,		///< Vertexbuffer contain trianglestip data
			PT_DEFAULT	 = PT_TRILIST,				///< Vertexbuffer defult primitivetype
		};

		/**
		 * Vertexbuffer allocation/usage models
		 */
		enum eUsage 
		{
			USAGE_READONLY = 0x00,					///< Vertex buffer will be used for readonly purposes, always in sysram and cannot be rendered
			USAGE_DYNAMIC  = 0x01,					///< Vertex buffer contains dynamically/runtime changabe data
			USAGE_STATIC   = 0x02,					///< Vertex buffer contains static data
		};
		
		/**
		 * Lockflags for dynamic vertexbuffers
		 */
		enum eLockFlags
		{
			LOCK_FLUSH  = D3DLOCK_NOSYSLOCK | D3DLOCK_DISCARD,		///< Flush contents of vertexbuffer
			LOCK_APPEND = D3DLOCK_NOSYSLOCK | D3DLOCK_NOOVERWRITE,	///< Still room for more data, use it
		};

		/**
		 * Constructor
		 */
		VertexBuffer(ModelManager * manager);

		/**
		 * Destructor
		 */
		virtual ~VertexBuffer();
		
		/** 
		 * Create with explicit, non predefined vertexformat
		 * @param d3dfvf Direct3D Flexible Vertexformat combination
		 * @param numvertice Number of vertices to allocate room for in this buffer
		 * @param usage How the vertexdata will be used, @see eUsage
		 */
		virtual void create(const int32 numVertices, const uint32 fvf, const eUsage usage);
		
		/**
		 * Release vertexbuffer, deallocata memory and resources on gfxboard
		 */
		virtual void release();
	
		/**
		 * Unlock vertexbuffer to give others access to its data
		 */
		void unlock();

		/**
		 * Checkes weiher a buffer is locked
		 * @return true if locked, false if free to use 
		 */
		const bool isLocked() const;

		/**
		 * Retrieve information about how this vertexbuffer is used
		 * @return A value of eUsage, @see eUsage.
		 */
		const eUsage getUsage() const;

		/**
		 * Get vertex stride, ie) size of a vertex which this buffer contains
		 * @return The size, in bytes, of one vertex corresponding to the vertexformat which this buffer was created for.
		 */
		const int32 getStride() const;
		
		/**
		 * Get the amount of vertices contained in the buffer
		 * @return The amount of vertices in this buffer
		 */
		const int32 getSize() const;

		/**
		 * Get total size in bytes of this buffer
		 * @return The total size of all vertices contained and allocated in this buffer
		 */
		const int32 getDataSize() const;

		/**
		 * Get the vertexformat corresponding to the vertexdata stored in this buffer
		 * @return The format constant for the vertex structure contained within this buffer
		 */
		const uint32 getFormat() const;

		/**
		 * Temporarily dispose the vertexbuffer, basically tell the resource to save its state and release itself
		 */
		void dispose();

		/**
		 * Restore a temporarily disposed resource from its saved settins and states
		 */
		void restore();
		
		/**
		 * Lock and get exclusive access to the vertexdata
		 * @param size Amount of vertices to lock
		 * @return Pointer to first vertex stored in this buffer
		 */
		void * lock(const int32 size = 0);

		/**
		 * Lock and get exclusive access to the vertexdata, read only from const object
		 * @param size Amount of vertices to lock
		 * @return Pointer to first vertex stored in this buffer
		 */
		const void * lock(const int32 size = 0) const;

		/**
		 * Get access to the direct3d hardware vertexbuffer interface
		 * @return An IDirect3DVertexBuffer interface used for lowlevel programming against Direct3D.
		 */
		IDirect3DVertexBuffer * getD3DVertexBuffer();
	
		/**
		 * Upload vertexdata to videomemory/AGP vertexbudder
		 */
		void upload(const void * srcData,const int32 dstVertexOffs, const int32 numVertices);

		/**
		 * Get primitivetype for this vertexbuffer
		 * @return The primitivetype for this buffer
		 */
		const ePrimitiveType getPrimitiveType() const;

		/**
		 * Explicitly set primitivetypedata for this vertexbuffer
		 * @param primType @see VertexBuffer::ePrimitiveType
		 */
		void setPrimitiveType(const ePrimitiveType primType);

	protected:
			
		/**
		 * Initialize all memberdata to their default values, mostly used interally and should not be needed
		 */
		void init();
		
		eUsage					 mUsage;				///< How this vertexbuffer is used
		ePrimitiveType			 mPrimitiveType;		///< Primitive data stored in this vertexbuffer
		int32					 mVertexCount;			///< Size of vertexbuffer, in vertices
		int32					 mVertexStride;			///< Size of a single vertex
		uint32					 mPosition;
		bool					 mLocked;				///< Vertexbuffer lockflag
		D3DVERTEXBUFFER_DESC	 mD3DVertexBufferDesc;	///< Vertexbuffer description
		IDirect3DVertexBuffer  * mD3DVertexBuffer;		///< Vertexbuffer object
	};

	typedef TSmartPtr<VertexBuffer, TRefCountResource<VertexBuffer> > VertexBufferHandle;
}
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================
//==============================================================================================

#endif
