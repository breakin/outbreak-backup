#ifndef __EXTREME_RESOURCE_SURFACE_INC__
#define __EXTREME_RESOURCE_SURFACE_INC__

#include "..\x3m_area.h"
#include "..\rendersystem\x3m_d3dversion.h"
#include "x3m_resource.h"

namespace Extreme {

	class Surface : public Resource
	{
	public:
		
		/**
		 * Surface types
		 */
		enum eType
		{
			TYPE_IMAGE		  = 0x01,
			TYPE_RENDERTARGET = 0x02,
			TYPE_DEPTHSTENCIL = 0x04,
			TYPE_DEFAULT	  = TYPE_IMAGE,
		};

		/**
		 * Surface color format
		 */
		enum eFormat
		{
			FMT_A8R8G8B8 = D3DFMT_A8R8G8B8,	///< 32bpp ARGB format
			FMT_R8G8B8	 = D3DFMT_R8G8B8,	///< 24bpp RGB format
		};

		/**
		 * Destructor
		 */
		~Surface();

		/**
		 * Get surface area
		 * @return The area of this surface (measured in pixels)
		 */
		const Area & getArea() const;

		/**
		 * Get surface area
		 * @return The area of this surface (measured in pixels)
		 */
		Area & getArea();
		
		/**
		 * Create a new rendertarget surface
		 * @param area The area of this surface (measured in pixels)
		 * @param nMultiSamples Amount of multisamples to be applied on this surface
		 */
		void createRenderTarget(const Area &area, const int32 bitDepth, const int32 multiSampleCount = 0);
		
		/**
		 * Create depthbuffer/stencilbuffer surface
		 * @param area The area of this surface (measured in pixels)
		 * @param nMultiSamples Amount of multisamples to be applied on this surface
		 */
		void createDepthStencil(const Area &area, const int32 stencilBits, const int32 depthBits, const int32 nMultiSamples = 0);

		/**
		 * Create plain image surface
		 * @param area The area of this surface (measured in pixels)
		 * @param nMultiSamples Amount of multisamples to be applied on this surface
		 */
		void createImage(const Area &area, const int32 bitDepth);

		/**
		 * Release surface
		 */
		void release();

		/** 
		 * Lock surface
		 * @param area Area of pixels/data to lock
		 * @param pitch Pitch of surface, in bytes
		 * @return pointer to first pixel within the locked area @a area
		 */
		const uint32 * lock(const Area & area, int32 &pitch) const;
		
		/** 
		 * Lock surface
		 * @param area Area of pixels/data to lock
		 * @param pitch Pitch of surface, in bytes
		 * @return pointer to first pixel within the locked area @a area
		 */
		uint32 * lock(const Area &area, int32 &pitch);

		/** 
		 * Explicitly set the surface area
		 * @param area Area of pixels/data
		 * @remarks This method should be used with care, should only be used internally by Extreme objects
		 */
		void setArea(const Area &area);

		/** 
		 * Explicitly set the surface D3D interface
		 * @param area D3D surface interface
		 * @remarks This method should be used with care, should only be used internally by Extreme objects
		 */
		void setD3DSurface(const IDirect3DSurface * d3dSurface);

		/**
		 * Check weither surface is locked
		 * @return true if surface is locked
		 */
		const bool isLocked() const;

	protected:
		
		/**
		 * Initialize members to their default values
		 */
		void init();

		/**
		 * Constructor
		 */
		Surface();
		
		eType				mType;			///< Surface type
		D3DSURFACE_DESC		mDesc;			///< D3D Surface description
		IDirect3DSurface *	mD3DSurface;	///< D3D Surface interface	
		Area				mArea;			///< Surface area
		bool				mLocked;		///< Set if surface is locked
	};

}

#endif
