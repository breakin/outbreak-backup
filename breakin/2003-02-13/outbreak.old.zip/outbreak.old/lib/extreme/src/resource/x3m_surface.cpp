//==========================================================================================
// Include files
//==========================================================================================

#include "x3m_surface.h"
#include "..\rendersystem\x3m_rendersystem.h"
#include "..\rendersystem\x3m_d3dutil.h"
#include "..\debug\x3m_assert.h"
#include "..\debug\x3m_debug.h"

#include <d3d8.h>

//==========================================================================================
// Namespace usage
//==========================================================================================

using namespace Extreme;

//==========================================================================================
// Method definitions
//==========================================================================================

Surface::Surface() : Resource (NULL) {
	init();
}

//==========================================================================================

Surface::~Surface() {

}

//==========================================================================================

void Surface::createImage(const Area & area, const int32 bitDepth) {
	
	IDirect3DDevice * d3dDevice = RenderSystem::getInstance().getD3DDevice();
	X3M_ASSERT (d3dDevice);

	if (mD3DSurface)
		release();
		
	mType = Surface::TYPE_IMAGE;

	// set area
	mArea = area;

	// convert format
	D3DFORMAT fmt = (bitDepth == 32) ? D3DFMT_A8R8G8B8 : D3DFMT_R8G8B8;

	// create surface
	HRESULT result = d3dDevice->CreateImageSurface(area.mWidth, area.mHeight, fmt, &mD3DSurface);
	
	if (result != D3D_OK) 
		throw Exception ("Could not create an image surface, reason (%s)", Direct3DUtil::getInstance().resultToString(result));

	// obtain desc
	mD3DSurface->GetDesc(&mDesc);
}

//==========================================================================================

void Surface::createDepthStencil(const Area & area, const int32 stencilBits, const int32 depthBits, const int32 multiSampleCount) {
	
	IDirect3DDevice * d3dDevice = RenderSystem::getInstance().getD3DDevice();
	X3M_ASSERT (d3dDevice);

	if (mD3DSurface)
		release();

	// set area
	mArea = area;

	mType = Surface::TYPE_DEPTHSTENCIL;

	// convert format
	D3DFORMAT fmt = Direct3DUtil::getInstance().getDepthStencilFormat(stencilBits, depthBits);

	// check format
	if (fmt == D3DFMT_UNKNOWN)
		throw Exception ("Could not create an image surface, unkown format (s%d,d%d)", stencilBits, depthBits);

	// create surface
	HRESULT result = d3dDevice->CreateDepthStencilSurface(area.mWidth, area.mHeight, fmt , Direct3DUtil::getInstance().intToMultiSampleType(multiSampleCount), &mD3DSurface);
	
	if (result != D3D_OK) 
		throw Exception ("Could not create an depth/stencil surface (s%d, d%d), reason (%s)", stencilBits, depthBits,  Direct3DUtil::getInstance().resultToString(result));

	// obtain desc
	mD3DSurface->GetDesc(&mDesc);
}

//==========================================================================================

void Surface::createRenderTarget(const Area & area, const int32 bitDepth, const int32 msc) {
	
	IDirect3DDevice * d3dDevice = RenderSystem::getInstance().getD3DDevice();
	X3M_ASSERT (d3dDevice);

	if (mD3DSurface)
		release();

	// set area
	mArea = area;

	// set surface type
	mType = Surface::TYPE_RENDERTARGET;

	// convert format
	D3DFORMAT fmt = (bitDepth == 32) ? D3DFMT_A8R8G8B8 : D3DFMT_R8G8B8;

	// create surface
	HRESULT result = d3dDevice->CreateRenderTarget(area.mWidth, area.mHeight, fmt,  Direct3DUtil::getInstance().intToMultiSampleType(msc), TRUE, &mD3DSurface);
	
	if (result != D3D_OK) 
		throw Exception ("Could not create an image surface, reason (%s)", Direct3DUtil::getInstance().resultToString(result));

	// obtain desc
	mD3DSurface->GetDesc(&mDesc);
}

//==========================================================================================

void Surface::release() {

	COM_SAFE_RELEASE(mD3DSurface);
	mArea.clear();
}

//==========================================================================================

void Surface::init() {
	mD3DSurface = NULL;
	mArea.clear();
	mLocked = false;
	memset (&mDesc, 0, sizeof (D3DSURFACE_DESC));
}

//==========================================================================================

uint32 * Surface::lock(const Area & area, int32 &pitch) {
	
	X3M_ASSERT (mD3DSurface);

	RECT rect;
	D3DLOCKED_RECT lockedRect;

	SetRect(&rect, area.mLeft, area.mTop, area.mWidth + area.mLeft, area.mTop + area.mHeight);

	HRESULT result = mD3DSurface->LockRect(&lockedRect,&rect,0);

	if (result != D3D_OK) {
		X3M_ERROR ("Surface", "Not able to lock surface!");
		return NULL;
	}
	
	pitch = lockedRect.Pitch;
	return (uint32*)lockedRect.pBits;

}

//==========================================================================================

const uint32 * Surface::lock(const Area &area, int32 &pitch) const {
	return const_cast<Surface*>(this)->lock(area, pitch);
}

//==========================================================================================

void Surface::setD3DSurface(const IDirect3DSurface * d3dSurface) {
	mD3DSurface = const_cast<IDirect3DSurface*>(d3dSurface);
}

//==========================================================================================

void Surface::setArea(const Area &area) {
	mArea = area;
}

//==========================================================================================

const bool Surface::isLocked() const {
	return mLocked;
}

//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
