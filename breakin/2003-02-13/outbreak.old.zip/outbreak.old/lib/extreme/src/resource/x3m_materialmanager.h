#ifndef __EXTREME_RESOURCE_MATERIALMANAGER_INC__
#define __EXTREME_RESOURCE_MATERIALMANAGER_INC__

#pragma warning (disable : 4786)

#include "x3m_material.h"
#include "x3m_resourcemanager.h"

namespace Extreme {

	/**
	 * @class	MaterialManager
	 * @brief	Material resource manager within the Extreme engine
	 * @author	Peter Nordlander
	 * @date	2002-01-07
	 */

	class MaterialManager : public ResourceManager, public TSingleton<MaterialManager>
	{
	public:
	
		/**
		 * Constructor
		 */
		MaterialManager();

		/**
		 * Destructor
		 */
		~MaterialManager();

		/**
		 * Create a new material, or inc. referance count on an already existing one
		 * @param name Name of material to create/retrieve
		 * @return The handle to the material corresponding to @a name
		 */
		MaterialHandle createMaterial(const std::string &name, const int32 textureLayers = 1);

		/**
		 * Remove a resource from repository
		 * @param resouce Resouce to release
		 * @return The amount of references left of this resource
		 * @remarks This should never be invoked explicitly
		 */
		const uint32 remove(const std::string &name);

		/**
		 * Release all materials
		 */
		void releaseAll();

	protected:
		
		typedef std::map<std::string, MaterialHandle> MaterialMap;
		MaterialMap mMaterials;	///< Map name->handle
	};
}

#endif
