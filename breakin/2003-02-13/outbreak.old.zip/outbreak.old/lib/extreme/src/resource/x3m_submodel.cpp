//==========================================================================================
// Include files
//==========================================================================================

#include "x3m_submodel.h"
#include "x3m_model.h"
#include "..\debug\x3m_assert.h"
#include "..\debug\x3m_debug.h"

//==========================================================================================
// Namespace usage
//==========================================================================================

using namespace Extreme;

//==========================================================================================
// Method definitions
//==========================================================================================

SubModel::~SubModel() {
	X3M_DEBUG ("SubModel", "Destructing...");
}

//==========================================================================================

SubModel::SubModel(Model * parent) {
	X3M_DEBUG ("SubModel", "Constructing...");
	mParentModel = parent;
}

//==========================================================================================

const MaterialHandle SubModel::getMaterial() const {
	return mMaterial;
}

//==========================================================================================
void SubModel::setMaterial(const MaterialHandle material) {
	mMaterial = material;
}

//==========================================================================================

const RenderUnit SubModel::createInstance() const {
	
	RenderUnit ru;
	ru.setIndexBuffer(mParentModel->getIndexBuffer());
	ru.setVertexBuffer(mParentModel->getVertexBuffer());
	ru.setMaterial(mMaterial);
	ru.setPrimitiveCount(mPrimCount);
	ru.setStartOffset(mPrimStart);
	ru.setMatrix(NULL);

	return ru;
}


//==========================================================================================
