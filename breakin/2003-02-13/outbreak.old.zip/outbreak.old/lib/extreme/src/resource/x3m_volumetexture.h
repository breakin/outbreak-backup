#ifndef __EXTREME_RESOURCE_VOLUMETEXTURE_INC__
#define __EXTREME_RESOURCE_VOLUMETEXTURE_INC__

#include "x3m_texture.h"

namespace Extreme {

	class VolumeTexture : public Texture
	{


	};
}

#endif