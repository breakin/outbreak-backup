#ifndef __EXTREME_RESOURCE_PLAINTEXTURE_INC__
#define __EXTREME_RESOURCE_PLAINTEXTURE_INC__

#include "x3m_texture.h"

namespace Extreme {

	/**
	 * @class	Texture
	 * @brief	Represent a texture object within the Extreme engine
	 * @author	Peter Nordlander
	 * @date	2002-01-07
	 */

	class Texture : public Resource
	{		
	public:

		/**
		 * Supported texturetypes
		 */
		enum eTextureType
		{
			TYPE_PLAIN,
			TYPE_VOLUME,
			TYPE_CUBE,
			TYPE_DEFAULT = TYPE_PLAIN,
		};

		/**
		 * Virtual destructor
		 */
		virtual ~Texture();

		/** 
		 * create a new texture object
		 */
		void create(const std::string &name) = 0;
		
		/** 
		 * Create a new texture
		 */
		void create(const std::string &name, const int32 width, const int32 height);

		/** 
		 * Release the texture object, full deallocation
		 */
		void release();

		/** 
		 * Reallocate the resource with the parameters it was created with
		 */
		void realloc();
		
		/** 
		 * Temporarily dispose the resource, swap it out
		 */
		void dispose();

		/** 
		 * Check if texture is valid, and not swapped
		 * @see Resource::isDisposed
		 */
		const bool isDisposed() const;

		/** 
		 * Returns the size of the texture in bytes
		 * @see Resouce::getDataSize
		 */
		const int32 getDataSize() const;

		/** 
		 * Get the texture's with in pixels
		 * @return The width of the texture, in pixels
		 */
		const int32 getWidth() const;

		/**
		 * Get the texture's height in pixels
		 * @return The height of the texture, in pixels
		 */
		const int32 getHeight() const;

		
		/** 
		 * Get the texture's bitdepth/count
		 * @return The texture's bitdepth 
		 */
		const int32 getBitDepth() const;

		/** 
		 * Return the direct3d texture interface
		 * @return The texture's corresponding D3D COM-interface
		 */
		IDirect3DTexture * getD3DTexture() const;

	private:
	
		/** 
		 * Initialize members to their default
		 */
		void init();

		/** 
		 * Default contructor
		 */
		Texture();

		/** 
		 * Copy contructor
		 */
		Texture(const Texture &other);

	protected:

		IDirect3DTexture *	mD3DTexture;	///< Direct3D Texture interface
		int32				mWidth;			///< Width in pixels
		int32				mHeight;		///< Height in pixels
		int32				mBitDepth;		///< Texture bitdepth
		int32				mMipLevels;		///< Number of MIP levels used for this texture
		bool				mDisposed;		///< True if texture is disposed
	};
	
	/**
	 * Typedef texturehandle
	 */
	typedef TSmartPtr<Texture, TRefCountResource<Texture> > TextureHandle;
}


#endif
