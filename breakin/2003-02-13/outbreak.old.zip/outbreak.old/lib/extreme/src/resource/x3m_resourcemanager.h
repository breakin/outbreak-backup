#ifndef __EXTREME_RESOURCE_MANAGER_INC__
#define __EXTREME_RESOURCE_MANAGER_INC__

#include "..\debug\x3m_debug.h"
#include "..\template\x3m_singleton.h"
#include "..\x3m_typedef.h"
#include "x3m_resource.h"

/// stl includes
#include <string>
#include <list>

namespace Extreme {

	/**
	 * @class	ResourceManager
	 * @brief	Basic resource managment functionallity, base for Texture/Material managers
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */
	class ResourceManager
	{
	public:

		/**
		 * Constructor
		 */
		ResourceManager() {
			X3M_DEBUG ("ResourceManager", "Constructing...");
		};

		/**
		 * Destructor
		 */
		virtual ~ResourceManager() {
			X3M_DEBUG ("ResourceManager", "Desstructing...");
		};
			
		/**
		 * Add search paths, common to all resource managers
		 * @param path A valid path in which all managers are able to search for their object's
		 */
		static void addCommonPath(const std::string &path);
	
		/**
		 * Add a resourcetype specific path
		 * @param path A valid path 
		 */
		void addPath(const std::string &path);

		/**
		 * Flushes all videomemory resources, used internally by RenderSystem when it detects a lost device
		 * @remarks Flush doesn't remove the resources from the repository, just release them until restore is invoked
		 */
		static void flush();

		/**
		 * Restore all flushed resources
		 * @remarks Must have been preceeded by a call to ResourceManager::flush
		 */
		static void restore();

		/**
		 * Method which ALL resourcemanager derived classes must implement, releases all resources currently resident within the managers
		 * @remarks It does NOT remove them from the repository - just invokes each resource's release method
		 */
		virtual void releaseAll() { };

		/**
		 * Brute force remove - totally removes resources from repository
		 * @param resouce Resouce to release
		 * @return The amount of references left of this resource
		 * @remarks This should never be
		 */
		virtual const uint32 remove(const std::string &name) = 0;

	protected:
		
		typedef std::list<Resource*> ResourceList;
		typedef std::list<std::string> PathList;
		
		static uint32		sVidMemUsage;		///< Total amount of bytes allocated for resources in vidememory
		static uint32		sSysMemUsage;		///< Total amount of bytes allocated for resources in systemmemory
		static uint32		sTotMemUsage;		///< Total amount of bytes allocated for all resources
		static ResourceList sVidMemResources;	///< Resources stored on deviceoptimal memory, and that must be reset on detection of a lost device
		static ResourceList sResources;			///< Storage for ALL resources in the database
		static PathList		sCommonPaths;		///< Common paths for all resources/managers
		PathList			mPaths;				///< Specific paths for a certain type of resource. Manager specific
	};
}

#endif
