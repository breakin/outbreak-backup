#ifndef __EXTREME_RESOURCE_MATERIAL_INC__
#define __EXTREME_RESOURCE_MATERIAL_INC__

#include "x3m_texturemanager.h"
#include "..\rendersystem\x3m_renderstates.h"
#include "..\rendersystem\x3m_blendmode.h"
#include "..\rendersystem\x3m_texturelayer.h"
#include "..\x3m_typedef.h"
#include "..\x3m_color.h"

namespace Extreme {

	/**
	 * @class	Material
	 * @brief	Representing all renderingstates and texturelayers for Mesh object
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */
	class Material : public Resource
	{
	public:
		
		enum eStencilOp
		{
			STENCILOP_KEEP		= D3DSTENCILOP_KEEP,
			STENCILOP_ZERO		= D3DSTENCILOP_ZERO,
			STENCILOP_REPLACE	= D3DSTENCILOP_REPLACE,
			STENCILOP_INCRSAT	= D3DSTENCILOP_INCRSAT,
			STENCILOP_DECRSAT	= D3DSTENCILOP_DECRSAT,
			STENCILOP_INVERT	= D3DSTENCILOP_INVERT,
			STENCILOP_INCR		= D3DSTENCILOP_INCR,
			STENCILOP_DECR		= D3DSTENCILOP_DECR,
		};

		/** 
		 * Pixel compare functions
		 */
		enum eAcceptFunc
		{
			ACCEPT_NEVER		= D3DCMP_NEVER,			///< Always fail the test. 
			ACCEPT_ALWAYS		= D3DCMP_ALWAYS,		///< Always pass the test. 
			ACCEPT_LESS			= D3DCMP_LESS,			///< Accept the new pixel if its value is less than the value of the current pixel. 
			ACCEPT_EQUAL		= D3DCMP_EQUAL,			///< Accept the new pixel if its value equals the value of the current pixel. 
			ACCEPT_LESSEQUAL	= D3DCMP_LESSEQUAL,		///< Accept the new pixel if its value is less than or equal to the value of the current pixel. 
			ACCEPT_GREATER      = D3DCMP_GREATER,		///< Accept the new pixel if its value is greater than the value of the current pixel. 
			ACCEPT_NOTEQUAL     = D3DCMP_NOTEQUAL,		///< Accept the new pixel if its value does not equal the value of the current pixel. 
			ACCEPT_GREATEREQUAL = D3DCMP_GREATEREQUAL,	///< Accept the new pixel if its value is greater than or equal to the value of the current pixel. 
		};

		/**
		 * Rendersystem backface culling modes
		 */
		enum eCullMode
		{
			CULL_CW				= D3DCULL_CW,			///< Cull faces with vertices in clockwise ordering
			CULL_CCW			= D3DCULL_CCW,			///< Cull faces with vertices in counter clocwise ordering
			CULL_NONE			= D3DCULL_NONE,			///< Cull none, disabled
		};

		/**
		 * RenderSystem Fill Modes
		 */
		enum eFillMode
		{	
			FILL_POINT			= D3DFILL_POINT,		///< Point fillmode, draw points, no filling
			FILL_WIREFRAME		= D3DFILL_WIREFRAME,	///< WireFrame fillmode, draw face without filling, only its contours
			FILL_SOLID			= D3DFILL_SOLID,		///< Solid fillmode
		};

		/**
		 * RenderSystem shade modes
		 */
		enum eShadeMode
		{
			SHADE_FLAT			= D3DSHADE_FLAT,		///< Flat shading
			SHADE_GOURAUD		= D3DSHADE_GOURAUD,		///< Gouraud shading
			SHADE_PHONG			= D3DSHADE_PHONG,		///< Phong shading
		};
			
		/**
		 * Color source, from where the rendersysem should fetch its color data
		 */
		enum eColorSource
		{
			COLORSRC_SURFACE		= D3DMCS_MATERIAL,	///< Fetch color from surface
			COLORSRC_VERTEXDIFFUSE  = D3DMCS_COLOR1,	///< Fetch color from vertice's diffuse component
			COLORSRC_VERTEXSPECULAR = D3DMCS_COLOR2,	///< Fetch color from vertice's specular component
		};
		
		/**
		 * Destructor
		 */
		~Material();
		
		/**
		 * Returns the total size of the material structure
		 * @return The total size in bytes
		 */
		const int32 getDataSize() const;
		
		/**
		 * Create a material with default values and an arbitrary amount of texturelayers
		 * @param name Name of material
		 * @param textureLayers Initial amount of texturelayers
		 */
		void create(const std::string &name, const int32 numTextureLayers);

		/**
		 * Release material
		 */
		void release();
		
		/**
		 * Get textureLayer for a given stage
		 * @param stage The stage to retrieve the texturelayer for
		 */
		TextureLayerHandle getTextureLayer(const int32 stage);

		/**
		 * Increase list of texturelayers
		 * @return The stagenumber for the new texturelayer
		 */
		TextureLayerHandle addTextureLayer();

		/** 
		 * Remove the last texturelayer
		 * @return The amount of texturelayers attached to this material after removal
		 */
		const int32 removeTextureLayer();

		/** 
		 * Remove all texturelayers
		 */
		void removeAllTextureLayers();

		/**
		 * Check weither this material is transparent
		 * @return True if transparent, false otherwise
		 */
		const bool isTransparent() const;


		/* Material color properties */
		ColorValue			mDiffuse;				///< Material's diffuse color
		ColorValue			mSpecular;				///< Material's specular color
		ColorValue			mAmbient;				///< Material's ambient color		
		
		/* Alpha Scene blend parameters */
		BlendMode			mBlendMode;				///< Material's blending parameters
		bool				mBlendEnable;			///< Material's blending enable flag
		
		/* Render properties */
		eFillMode			mFillMode;				///< Material's RenderSystem fillmode used for this material
		eShadeMode			mShadeMode;				///< Material's RenderSystem shademode used for this material
		eCullMode			mCullMode;				///< Material's cullmode, desides weihter material is twosided or not
		
		/* Color sources */
		eColorSource		mAmbientColorSource;	///< Material's ambient colorsource
		eColorSource		mDiffuseColorSource;	///< Material's diffuse colorsource
		eColorSource		mSpecularColorSource;	///< Material'a specular colorsource
		eColorSource        mEmmisiveColorSource;
		
		/* Light parameters */
		bool				mLightingEnable;		///< Indicates weihter lighting should be enabled during rendering with this material
		
		/* Depth buffer parameters */
		bool				mDepthWriteEnable;		///< Flag indicating weither zbuffer writes should be enabled
		bool				mDepthBufferEnable;		///< Flag indicating weither depthbuffering should be turned on during rendering 
		eAcceptFunc			mDepthCompareFunc;		///< Compare function to control how the pixels are accepted when tested with zbuffer
		
		/* Stencil buffer parameters */	
		bool				mStencilBufferEnable;
		eStencilOp			mStencilOpFail;
		eStencilOp			mStencilOpZFail;
		eStencilOp			mStencilOpPass;
		eAcceptFunc			mStencilFunc;
		uint32				mStencilRef;
		uint32				mStencilMask;
		uint32				mStencilWriteMask;
    													
		/**
		 * Friend system classes, needs instant access to material data construction and managment 
		 */
		friend class MaterialManager;
		friend class RenderSystem;
	
	protected:

		/* Texturelayers */
		TextureLayerList	mTextureLayers;			///< Materials texturelayers
		int32				mNumTextureLayers;		///< Number of texturelayers in this material
		/** 
		 * Constructor
		 */
		Material(MaterialManager * creator = NULL);
		
		/**
		 * Initialize materialdata to their default value
		 */
		void init();
	};

	/**
	 * Material handle
	 */ 
	typedef TSmartPtr<Material, TRefCountResource<Material> > MaterialHandle;

//=============================================================================================================


}

#endif