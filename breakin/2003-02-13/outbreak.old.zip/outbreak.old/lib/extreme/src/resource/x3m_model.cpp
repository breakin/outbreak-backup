//==========================================================================================
// Include files
//==========================================================================================
#include "..\debug\x3m_debug.h"
#include "..\debug\x3m_assert.h"
#include "x3m_model.h"
#include "x3m_modelmanager.h"

//==========================================================================================
// Used namespaces
//==========================================================================================
using namespace Extreme;
//==========================================================================================
// Method implementation
//==========================================================================================

Model::Model(ModelManager * creator) : Resource(creator) {
	X3M_DEBUG ("Model", "Constructing..");
	init();
}

//==========================================================================================

Model::~Model() {
	X3M_DEBUG ("Model", "Destructing..");
}

//==========================================================================================

void Model::release() {
	
	removeAllSubModels();
	init();
}

//==========================================================================================

void Model::init() {
	mName = "";
	mVertexBuffer = NULL;
	mIndexBuffer = NULL;

}

//==========================================================================================

void Model::create(const std::string &name, const int32 numVertices, const uint32 FVF, VertexBuffer::ePrimitiveType primType, const int32 numIndices) {
	
	// set name
	mName = name;
	
	// create vertexbuffer(s)
	mVertexBuffer = ModelManager::getInstance().createVertexBuffer(name + "_vb", FVF, numVertices, VertexBuffer::USAGE_STATIC);
	mSysVertexBuffer = ModelManager::getInstance().createVertexBuffer(name + "_vb_sys", FVF, numVertices, VertexBuffer::USAGE_STATIC);
	mVertexBuffer->setPrimitiveType(primType);
	mSysVertexBuffer->setPrimitiveType(primType);

	// create indexbuffer(s)
	if (numIndices) {
		mIndexBuffer = ModelManager::getInstance().createIndexBuffer(name + "_ib",  numIndices, IndexBuffer::INDEX_16, IndexBuffer::USAGE_STATIC);
		mSysIndexBuffer = ModelManager::getInstance().createIndexBuffer(name + "_ib_sys",  numIndices, IndexBuffer::INDEX_16, IndexBuffer::USAGE_STATIC);
	}

	// create all submodels
	for (int i = 0 ;i < 0; i++)
		createSubModel();
}

//==========================================================================================

SubModelHandle Model::createSubModel()  {

	int32 newIndex = mSubModels.size();

	X3M_DEBUG ("Model", "Model (%s) - create new submodel (%d)", mName, newIndex);
	SubModelHandle handle = new SubModel(this);
	mSubModels.push_back(handle);
	return handle;
}

//==========================================================================================

const int32 Model::getNumSubModels() const {
	return mSubModels.size();
}

//==========================================================================================

void Model::removeSubModel(const int32 index) {
	SubModelList::iterator i = mSubModels.begin();
	mSubModels.erase(i + index);
}

//==========================================================================================

void Model::removeSubModel(const SubModelHandle handle) {
	int32 index;
	
	for (index = 0; index < mSubModels.size(); index++)
		if (mSubModels[index].getObject() == handle.getObject())
			break;

	mSubModels.erase(mSubModels.begin() + index);
}

//==========================================================================================

SubModelHandle Model::getSubModel(const int32 index) {
	return mSubModels[index];	
}

//==========================================================================================

const SubModelHandle Model::getSubModel(const int32 index) const {
	return mSubModels[index];	
}

//==========================================================================================

void Model::removeAllSubModels() {
	mSubModels.clear();
}

//==========================================================================================

void Model::getRenderUnits(RenderUnits &renderUnits) {
	
	renderUnits.clear();
	renderUnits.resize(mSubModels.size());

	for (int iUnit = 0; iUnit < mSubModels.size(); iUnit++) {
		renderUnits[iUnit] = mSubModels[iUnit]->createInstance();
	}
}

//==========================================================================================

VertexBufferHandle Model::getVertexBuffer(){
	return mVertexBuffer;
}


const VertexBufferHandle Model::getVertexBuffer() const {
	return mVertexBuffer;
}

IndexBufferHandle Model::getIndexBuffer() {
	return mIndexBuffer;
}


const IndexBufferHandle Model::getIndexBuffer() const {
	return mIndexBuffer;
}