#ifndef __EXTREME_RESOURCE_TEXTURE_INC__
#define __EXTREME_RESOURCE_TEXTURE_INC__

#include "..\rendersystem\x3m_d3dversion.h"
#include "..\x3m_typedef.h"
#include "..\x3m_area.h"
#include "..\template\x3m_smartptr.h"
#include "..\template\x3m_refcount_resource.h"
#include "x3m_resource.h"

namespace Extreme {
		
	// forw. declaration of texturemanager
	class TextureManager;

	/**
	 * @class	Texture
	 * @brief	Represent a texture object within the Extreme engine
	 * @author	Peter Nordlander
	 * @date	2002-01-07
	 */
	class Texture : public Resource
	{		
	public:
		
		/**
		 * Texture usage properties
		 */
		enum eUsage
		{
			USAGE_TEXTURE		= 0x00,						///< Texture will be used as an ordinary texture,
			USAGE_RENDERTARGET	= D3DUSAGE_RENDERTARGET,	///< Texture will be used as a rendertarget
			USAGE_DEPTHSTENCIL	= D3DUSAGE_DEPTHSTENCIL,	///< Texture will be used as a depth/stencil buffer
			USAGE_DEFAULT		= USAGE_TEXTURE,			///< Texture default usage
		};

		/**
		 * Texture description
		 */
		struct Desc
		{
			int32	mWidth;			///< Width in pixels
			int32	mHeight;		///< Height in pixels
			int32	mBitDepth;		///< Texture bitdepth
			int32	mMipLevels;		///< Number of MIP levels used for this texture (0 if desc if associated with a MIPmap)
			eUsage  mUsage;			///< Texture usage
		};

		/**
		 * Virtual destructor
		 */
		virtual ~Texture();

		/** 
		 * Resize an already created texture
		 * @param desc New description of texture
		 * @remarks The texture will still have the same name as before 
		 */
		void resize(const Texture::Desc & desc);

		/** 
		 * Release the texture object, full deallocation
		 */
		virtual void release();
		
		/** 
		 * Temporarily dispose the resource, swap it out
		 */
		virtual void dispose();

		/** 
		 * Restore a temporarily disposed texture
		 */
		virtual void restore();

		/** 
		 * Returns the size of the texture in bytes
		 * @see Resouce::getDataSize
		 */
		const int32 getDataSize() const;

		/**
		 * Return desciption of this texture object
		 * @return TextureDesc object describing this texture's properties
		 */
		const Texture::Desc & getDesc(const int32 level = 0) const;

		/** 
		 * Return the direct3d texture interface
		 * @return The texture's corresponding D3D COM-interface
		 */
		IDirect3DBaseTexture * getD3DTexture() const;

		/**
		 * Lock a certain texture level 
		 * @param level MIP level to lock
		 * @param level [out] pitch, in bytes
		 * @param levelArea [out] Size of the locked level, returned by function
		 * @return Pointer to the surface data
		 */
		const uint32 * lock(const int32 level, int32 &pitch, Texture::Desc & levelArea) const;

		/**
		 * Lock a certain texture level 
		 * @param level MIP level to lock
		 * @param level [out] pitch, in bytes
		 * @param levelArea [out] Size of the locked level, returned by function
		 * @return Pointer to the surface data
		 */
		uint32 * lock(const int32 level, int32 & pitch, Texture::Desc & levelArea);

		/**
		 * Unlock texture
		 */
		void unlock() const;
	
	private:
	
		/** 
		 * Initialize members to their default
		 */
		void init();
		
		/** 
		 * create a new texture object
		 * @param name Name of this texture
		 * @param desc Texture description holding this textures creation parameters
		 */
		void create(const std::string &name, const Texture::Desc &desc);

		/** 
		 * create a new texture object and load from file
		 * @param filename Name of imagefile containsing the texturedata
		 */
		void create(const std::string &filename);

		/** 
		 * Default contructor
		 */
		Texture(TextureManager * creator);

		/** 
		 * Copy contructor
		 */
		Texture(const Texture &other);

	protected:
		
		IDirect3DTexture *		mSysTexture;	///< Texture i SYSRAM, for rendertarget reads and updates
		IDirect3DTexture *		mD3DTexture;	///< Texture - Direct3D COM interface
		Texture::Desc			mDesc;			///< Texture - descrption
		mutable Texture::Desc	mLockedDesc;	///< Description of locked texture surface level
		mutable int32			mLockedLevel;	///< Which texture level that is currently locked
		friend TextureManager;
	};
	
	/**
	 * Typedef texturehandle
	 */
	typedef TSmartPtr<Texture, TRefCountResource<Texture> > TextureHandle;
}

#endif