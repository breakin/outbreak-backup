#ifndef __EXTREME_TEXTURE_MANAGER_INC__
#define __EXTREME_TEXTURE_MANAGER_INC__

#include "..\x3m_typedef.h"
#include "x3m_resourcemanager.h"
#include "x3m_texture.h"

#pragma warning (disable : 4786)

/// stl includes
#include <map>

namespace Extreme {

	/**
	 * @class	TextureManager
	 * @brief	Texture resource manager within the Extreme engine
	 * @author	Peter Nordlander
	 * @date	2002-01-07
	 */
	class TextureManager :  public ResourceManager, public TSingleton<TextureManager>
	{
	public:

		/**
		 * Contructor
		 */
		TextureManager();

		/**
		 * Destructor
		 */
		~TextureManager();

		/**
		 * Create a new Texture from file
		 * @param name Name of texture to create/filename containing the texturedata
		 * @return The handle for the texture with name @name
		 * @remarks Will return an existing object if such exist with an equal name
		 */
		TextureHandle createTexture(const std::string &filename);

		/**
		 * Create a new empty texture
		 * @param name Name of texture to create
		 * @return The handle for the texture with name @name
		 * @remarks Will return an existing object if such exist with an equal name
		 */
		TextureHandle createTexture(const std::string &name, const int32 width, const int32 height, const int32 bitDepth = 32, const int32 mipLevels = 0); 

		/**
		 * Remove a resource from repository
		 * @param resouce Resouce to release
		 * @return The amount of references left of this resource
		 * @remarks This should never be
		 */
		const uint32 remove(const std::string &name);

		/**
		 * Get available texturememory onboard
		 * @return The total available amount of texturememory, rounded to nearest MB
		 */
		const uint32 getAvailableTextureMemory();

		/**
		 * Release all textures stored within the texturemanager
		 */
		void releaseAll();


	protected:

		friend class TSingleton<TextureManager>;
		
		typedef std::map<std::string, TextureHandle> TextureMap;
		TextureMap mTextures;		///< Map of texture handles paired with there corresponding name
	};
}

#endif