//=============================================================================
// Include files
//=============================================================================
#include "x3m_modelmanager.h"
#include "x3m_model.h"

//=============================================================================
// Used namespaces
//=============================================================================
using namespace Extreme;

//=============================================================================
// Static data definition
//=============================================================================
ModelManager * TSingleton<ModelManager>::sSingletonObject = NULL;

//=============================================================================

ModelManager::ModelManager() {
	X3M_DEBUG("ModelManager", "Constructing...");
}

//=============================================================================

ModelManager::~ModelManager() {
	X3M_DEBUG ("ModelManager", "Destructing...");
}

//=============================================================================

ModelHandle ModelManager::createModel(const std::string &name, const int32 numVertices, const uint32 FVF, VertexBuffer::ePrimitiveType primType, const int32 numIndices) {
	
	ModelMap::iterator i = mModels.find (name);

	if (i == mModels.end()) {

		X3M_DEBUG ("ModelManager", "Create Model (%s)..", name.c_str());
		ModelHandle handle;
		handle = new Model(this);
		handle->create(name, numVertices, FVF, primType, numIndices);
		mModels[name] = handle;
		return handle;
	}
	else {
		
		X3M_DEBUG ("ModelManager", "Model (%s) already exist (%d refs), return existing object...", name.c_str(), i->second.getRefCount());
		return i->second;
	}
}

//=============================================================================

VertexBufferHandle ModelManager::createVertexBuffer(std::string &name, const uint32 FVF, const int32 size, const VertexBuffer::eUsage usage) {

	VertexBufferMap::iterator i = mVertexBuffers.find(name);
	
	if (i == mVertexBuffers.end()) {

		X3M_DEBUG ("VertexBufferManager", "Create VertexBuffer (%s)..", name.c_str());
		VertexBufferHandle handle;
		handle = new VertexBuffer(this);
		handle->create(size, FVF, usage);
		handle->setName(name);
		mVertexBuffers[name] = handle;
		return handle;
	}
	else {
		
		X3M_DEBUG ("VertexBufferManager", "VertexBuffer (%s) already exist (%d refs), return existing object...", name.c_str(), i->second.getRefCount());
		return i->second;
	}
}

//=============================================================================

IndexBufferHandle ModelManager::createIndexBuffer(std::string &name, const int32 size , const IndexBuffer::eIndexType type, const IndexBuffer::eUsage usage) {

	IndexBufferMap::iterator i = mIndexBuffers.find(name);
	
	if (i == mIndexBuffers.end()) {

		X3M_DEBUG ("IndexBufferManager", "Create IndexBuffer (%s)..", name.c_str());
		IndexBufferHandle handle;
		handle = new IndexBuffer(this);
		handle->create(size, type, usage);
		handle->setName(name);
		mIndexBuffers[name] = handle;
		return handle;
	}
	else {
		
		X3M_DEBUG ("IndexBufferManager", "IndexBuffer (%s) already exist (%d refs), return existing object...", name.c_str(), i->second.getRefCount());
		return i->second;
	}
}

//=============================================================================

void ModelManager::releaseAll() {
	
	ModelMap::iterator i = mModels.begin();

	while(i!=mModels.end()) {
		i->second->release();
		++i;
	}
}

//=============================================================================

const uint32 ModelManager::remove(const std::string &name) {
	
	if (mModels.find(name) != mModels.end()) {
		mModels.erase(name);
		return 0;
	}
	if (mVertexBuffers.find(name) != mVertexBuffers.end()) {
		mVertexBuffers.erase(name);
		return 0;
	}
	if (mIndexBuffers.find(name) != mIndexBuffers.end()) {
		mIndexBuffers.erase(name);
		return 0;
	}

	X3M_ERROR ("ModelManager", "Resource with name (%s) was not found and could not be removed!!", name.c_str());
	return 0;
}

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

//=============================================================================

