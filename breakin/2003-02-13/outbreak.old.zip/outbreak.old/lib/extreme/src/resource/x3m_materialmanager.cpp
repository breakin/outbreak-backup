//==========================================================================================
// Include files
//==========================================================================================

#include "x3m_materialmanager.h"
#include "x3m_material.h"
#include "..\debug\x3m_assert.h"
#include "..\rendersystem\x3m_rendersystem.h"
#include "..\rendersystem\x3m_d3dutil.h"

//==========================================================================================
// Namespace usage
//==========================================================================================

using namespace Extreme;

//==========================================================================================

MaterialManager * TSingleton<MaterialManager>::sSingletonObject = NULL;

//==========================================================================================
// Method definitions
//==========================================================================================
		
MaterialManager::MaterialManager() {
	Debug::debug ("MaterialManager", "Constructing...");
	mMaterials.clear();
}
//==========================================================================================

MaterialManager::~MaterialManager() {
	Debug::debug ("MaterialManager", "Desstructing...");
	releaseAll();
}

//==========================================================================================

MaterialHandle MaterialManager::createMaterial(const std::string &name, const int32 numTextureLayers) {

	MaterialMap::iterator itorHandle;
	MaterialHandle handle;

	// search for an already existing material with this name
	itorHandle = mMaterials.find(name);

	// check if this material does not exist
	if (itorHandle == mMaterials.end()) {
		
		X3M_DEBUG ("MaterialManager", "Create a new material (%s)", name.c_str());

		// craeate a new entry in handledatabase
		handle.attach(new Material(this));
		
		// create/init material
		handle->create(name, numTextureLayers);

		// insert in namelookup table
		mMaterials[name] = handle;
		
		// return new material
		return handle;
	}
	// already exist 
	else {

		X3M_DEBUG ("MaterialManager", "Material [%s] already exists, increase reference count", name.c_str());	
		return itorHandle->second;
	}
}

//==========================================================================================

const uint32 MaterialManager::remove(const std::string &name) {

	X3M_DEBUG ("MaterialManager", "Remove material (%s)...", name.c_str());
	MaterialMap::iterator handleItor = mMaterials.find(name);

	if (handleItor != mMaterials.end()) {
		// remove material's name from table
		mMaterials.erase(name);
		return 0;
	}
	
	X3M_ERROR ("MaterialManager", "Attempt to remove an invalid handle!");
	return 0;
}

//==========================================================================================

void MaterialManager::releaseAll() {

	if (mMaterials.size() > 0) {
		MaterialMap::iterator handleItor = mMaterials.begin();
		
		while (handleItor != mMaterials.end()) {
			
			handleItor->second->release();
			handleItor++;
		}
	}
}

//==========================================================================================
