#ifndef __EXTREME_RESOURCE_MODELMANAGER_INC__
#define __EXTREME_RESOURCE_MODELMANAGER_INC__

#include "x3m_resourcemanager.h"
#include "x3m_model.h"
#include "..\template\x3m_singleton.h"

namespace Extreme {

	/**
	 * @class	ModelManager
	 * @brief	
	 * @author	Peter Nordlander
	 * @date	2002-04-28
	 */
	class ModelManager : public ResourceManager, public TSingleton<ModelManager>
	{
	public:

		/** 
		 * Constructor
		 */
		ModelManager();

		/** 
		 * Destructor
		 */
		~ModelManager();

		/**
		 * Create a new model object
		 * @name Name of model to create
		 * @return The new model-object / or an already existant object if such already had been created
		 */
		ModelHandle createModel(const std::string &name, const int32 numVertices, const uint32 FVF, VertexBuffer::ePrimitiveType primType, const int32 numIndices = 0);

		ModelHandle createDynamicModel();

		/**
		 * Create a new vertexbuffer
		 * @param name Name of vertexbuffer to create
		 * @return New VertexBuffer, or entry if already exist
		 */
		VertexBufferHandle createVertexBuffer(std::string &name, const uint32 FVF, const int32 size, const VertexBuffer::eUsage usage);

		/**
		 * Create a new indexbuffer or retrieve access to an already existing one
		 * @param Name Name of vertexbuffer to create
		 */
		IndexBufferHandle createIndexBuffer(std::string &name, const int32 size, const IndexBuffer::eIndexType type, const IndexBuffer::eUsage usage);

		/**
		 * Release all model's
		 * @remarks Model resource's aren't actually removed from manager
		 * that will only occur when all modelhandles has been released. 
		 */
		void releaseAll();

		/**
		 * Remove an modelentry in the ModelManager database, should NOT be
		 * invoked explicitly as it is used from within the handleclass when it detects
		 * that no more references are available within the system to a certain model object.
		 * @param name Name of model to remove 
		 */
		const uint32 remove(const std::string &name);

	protected:

		typedef std::map<std::string, ModelHandle> ModelMap;
		typedef std::map<std::string, VertexBufferHandle> VertexBufferMap;
		typedef std::map<std::string, IndexBufferHandle> IndexBufferMap;

		ModelMap		mModels;		///< Model repository
		VertexBufferMap mVertexBuffers;	///< VertexBuffer repository
		IndexBufferMap	mIndexBuffers;	///< IndexBuffer repository
		
	};

	//======================================================================================

}

#endif