//==========================================================================================
// Include files
//==========================================================================================

#include "x3m_indexbuffer.h"
#include "x3m_modelmanager.h"
#include "..\debug\x3m_assert.h"
#include "..\rendersystem\x3m_rendersystem.h"
#include "..\rendersystem\x3m_d3dutil.h"

//==========================================================================================
// Namespace usage
//==========================================================================================

using namespace Extreme;

//==========================================================================================
// Method definitions
//==========================================================================================
		
IndexBuffer::IndexBuffer(ModelManager * creator) : Resource(creator) {
	init();
}

//==========================================================================================

IndexBuffer::~IndexBuffer() {
	release();
}

//==========================================================================================

void IndexBuffer::create(const int32 length, const eIndexType indexType, const IndexBuffer::eUsage usage) {

	Debug::debug ("IndexBuffer::create", "Create a new vertexbuffer");

	// initilize members
	init();

	// fill in indexbuffer format description
	mDesc.Format = (indexType == IndexBuffer::INDEX_16) ? D3DFMT_INDEX16 : D3DFMT_INDEX32;
    mDesc.Type   = D3DRTYPE_INDEXBUFFER;
    mDesc.Usage  = (usage == IndexBuffer::USAGE_DYNAMIC) ? D3DUSAGE_DYNAMIC : 0;
	mDesc.Usage |= D3DUSAGE_WRITEONLY;
    mDesc.Pool   = (usage == IndexBuffer::USAGE_DYNAMIC) ? D3DPOOL_DEFAULT : D3DPOOL_MANAGED;
	mDesc.Size   = length * ((indexType == IndexBuffer::INDEX_16) ? 2 : 4);

	// set size of of buffer (in indices)
	mSize = length;

	// get our d3ddevice from rendersystem
	IDirect3DDevice * d3dDevice = RenderSystem::getInstance().getD3DDevice();

	if (d3dDevice) {

		// create the indexbuffer
		HRESULT res = d3dDevice->CreateIndexBuffer(mDesc.Size, mDesc.Usage, mDesc.Format, mDesc.Pool, &mD3DIndexBuffer);
		
		// check for errors
		if (res != D3D_OK)
			throw Exception ("Cannot create indexbuffer, reason (%s)", Direct3DUtil::getInstance().resultToString(res));
	}
	else
		throw Exception ("Cannot create indexbuffer, device not ready!");
}

//==========================================================================================

void IndexBuffer::release() {

	// unlock indexbuffer, just in case
	unlock();

	// release com-interface
	COM_SAFE_RELEASE(mD3DIndexBuffer);
	
	// reinitialize members
	init();
}

//==========================================================================================

void IndexBuffer::init() {
	
	mD3DIndexBuffer = NULL;
	mLocked = false;
	memset(&mDesc, 0, sizeof (mDesc));
}

//==========================================================================================

const void * IndexBuffer::lock(const int32 lockStart, const int32 lockSize, const bool discardContents) const {
	return const_cast<IndexBuffer*>(this)->lock(lockStart, lockSize, discardContents);
}

//==========================================================================================

void * IndexBuffer::lock(const int32 lockStart, const int32 lockSize, const bool discardContents) {
	
	DWORD lockFlags = D3DLOCK_NOSYSLOCK;

	if (mDesc.Usage & D3DUSAGE_DYNAMIC)
		lockFlags |= (discardContents) ? D3DLOCK_DISCARD : D3DLOCK_NOOVERWRITE;

	// only attempt to lock if not already locked
	if (!mLocked) {

		BYTE * indexData;
		HRESULT result = mD3DIndexBuffer->Lock(lockStart, lockSize * (mDesc.Format == D3DFMT_INDEX16 ? 2 : 4), &indexData, lockFlags); 

		// check so that lock went ok
		if (result != D3D_OK) {

			Debug::error ("IndexBuffer::lock", "Could not lock indexbuffer, reason (%s)", Direct3DUtil::getInstance().resultToString(result));
			return NULL;
		}

		mLocked = true;
		return (void*)indexData;
	}

	Debug::debug ("IndexBuffer::lock", "Indexbuffer already locked!");
	return NULL;
}

//==========================================================================================

void IndexBuffer::unlock() {

	if (mLocked) {

		mD3DIndexBuffer->Unlock();
		mLocked = false;
	}
}

//==========================================================================================

const bool IndexBuffer::isLocked() const {
	return mLocked;
}

//==========================================================================================

const IndexBuffer::eUsage IndexBuffer::getUsage() const {
	return (mDesc.Usage & D3DUSAGE_DYNAMIC) ? IndexBuffer::USAGE_DYNAMIC : USAGE_STATIC; 
}

//==========================================================================================

const IndexBuffer::eIndexType IndexBuffer::getIndexType() const {
	return (mDesc.Format == D3DFMT_INDEX16) ? IndexBuffer::INDEX_16 : IndexBuffer::INDEX_32;
}

//==========================================================================================

const int32 IndexBuffer::getSize() const {
	return mSize;
}

//==========================================================================================
