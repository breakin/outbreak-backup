#ifndef __EXTREME_RESOURCE_INC__
#define __EXTREME_RESOURCE_INC__

#include "..\x3m_typedef.h"
#include "..\rendersystem\x3m_d3dversion.h"

/// stl includes
#include <string>
#include <memory>

namespace Extreme {

	class ResourceManager;

	/**
	 * @class	Resource
	 * @brief	Common resource data and functionality
	 * @author	Peter Nordlander
	 * @date	2002-01-07
	 * @todo	Implement some sort of allocator/dealloctor class which can be used
	 *			for holding a pool of free objects.
	 */
	class Resource
	{
	public:
		
		/**
		 * Resource management 
		 */
		enum ePool
		{	
			POOL_VRAM,					///< Resource resides in system RAM memory, 
			POOL_SRAM,					///< Resource resides in onboard videomemory, 
			POOL_AUTO,					///< Resource resided in most appropriate available memorypool, automaticallt managed 
		};
		
		/**
		 * Resouce share levels
		 */
		enum eShareLevel
		{
			SL_UNIQE,					///< Resource is uniqe, only one copy can reside within the system
			SL_SHARED,					///< Resource is shared
			SL_DUPLICATE,				///< Resource is uniqe, but CAN be copied on request
		};

		/**
		 * Resource accesslevel
		 */
		enum eAccessLevel
		{
			AL_READ		 = 0,			///< The reousrce can be read from
			AL_WRITE	 = 1,			///< The resource can be written to
			AL_READWRITE = 2,			///< The resource can both be read from and written to
			AL_DEFAULT   = 2,			///< Default accesslevel
		};
		
		/**
		 * Resource priority
		 */
		enum ePriority
		{
			PRIO_HIGH,					///< High priority resource, stays in cache as long as possible
			PRIO_MEDIUM,				///< Medium priority, will get cached out before any highprio resources 
			PRIO_LOW,					///< Low priority, only in cache as long as no other resource needs to be there
			PRIO_DEFAULT = PRIO_MEDIUM, ///< Priority default
		};

		/**
		 * Temporarily dispose the resource, basically tell the resource to save its state and release itself
		 * @remarks This method will be called from the ResourceManager almost extensivly on VRAM resources,
		 * If overridden, the mDisposedflag MUST be set in the overridden method!
		 */
		virtual void dispose();

		/**
		 * Restore a temporarily disposed resource from its saved settins and states
		 * @remarks This method is internal-only and must only be called from ResourceManager.
		 */
		virtual void restore();


		/**
		 * Create the resource, to be overridden by derived classes
		 * @param name Name of resource 
		 * @remarks Must be overidden by derived classes
		 */
		virtual void create(const std::string &name);
	
		/**
		 * Release the resource 
		 * @remarks Must be overidden by derived classes
		 */
		virtual void release() = 0;

		/**
		 * Check weither resource is disposed
		 * @return True if the resouce is disposed, false otherwise
		 */
		virtual const bool isDisposed() const;

		/**
		 * Retrieve the size of the resource in bytes
		 * @return Total allocated memory for this resource
		 * @remarks Must be overidden by derived classes
		 */
		virtual const int32 getDataSize() const = 0;
		
		/**
		 * Retrieve the resource's name
		 * @return The name of the resource
		 */
		virtual const std::string & getName() const;

		/**
		 * Set the resource's name
		 * @param name Name of resource
		 */
		void setName(const std::string &name);

		/**
		 * Get the resource's priority
		 * @return This resources managed priority, 
		 * @see Resource::ePriority
		 */
		virtual const ePriority getPriority() const;

		/**
		 * Set the resource's priority
		 * @param priority A Value of Resource::ePriority, 
		 * @see Resource::ePriority
		 */
		virtual void setPriority(const ePriority priority);

		/**
		 * Set resource's access level
		 * @param accessLevel A value of Resource::eAccessLevel
		 * @see Resource::eAccessLevel
		 */
		virtual void setAccessLevel (const eAccessLevel accessLevel);

		/**
		 * Get current access level
		 * @return The resource's accesslevel
		 * @see Resource::eAccessLevel
		 */
		virtual const eAccessLevel getAccessLevel() const;

		/**
		 * Get current access level
		 * @return The resource's accesslevel
		 * @see Resource::eAccessLevel
		 */
		virtual ResourceManager * getCreator() const;

		/**
		 * Virtual destructor
		 */
		virtual ~Resource();

	protected:

		/**
		 * Constructor
		 * @param name Initial name of resource
		 */
		Resource (ResourceManager * creator, const std::string &name = "") :	
			
			mCreator(creator),
			mName(name),
			mPriority(PRIO_DEFAULT),
			mDisposed(true)
			{}

		/**
		 * Deep copy construcion and assigment
		 */
		Resource(const Resource &r) {}

		/**
	     * Make operator new and delete friend, with these are the only allowed
		 * way to allocate a resource object
		 */
		friend void * ::operator new (size_t size);
		friend void ::operator delete (void *);

		ResourceManager * mCreator;				///< ResourceManager which created this resource
		bool			  mDisposed;			///< Resource disposed flag, indicates weihter this resource needs to be reallocated
		std::string		  mName;				///< Resouces name
		ePriority	 	  mPriority;			///< Resource priority
		eAccessLevel	  mAccessLevel;			///< Resources access level (SHARED/UNIQUE)
		static uint32	  mResourceCount;		///< Amount of resources currently avaliable in system
	};
}

#endif