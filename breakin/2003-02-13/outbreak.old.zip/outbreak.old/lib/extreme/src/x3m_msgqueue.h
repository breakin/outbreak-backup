#ifndef __EXTREME_MESSAGE_QUEUE_INC__
#define __EXTREME_MESSAGE_QUEUE_INC__

#include "win32\x3m_mutex.h"
#include "win32\x3m_event.h"
#include "x3m_point.h"

#include <queue>

namespace Extreme {

	/**
	 * Message types
	 */
	enum eMsgType 
	{
		MSG_QUIT,
		MSG_CLOSE,
		MSG_PAINT,
		MSG_GOTFOCUS,
		MSG_LOSTFOCUS,
		MSG_ACTIVATE,

		MSG_KEYDOWN,
		MSG_KEYUP,
		
		MSG_MOUSEMOVE,
		MSG_LEFTMOUSE,
		MSG_RIGHTMOUSE,
	};
		
	/**
	 * Message groups
	 */
	enum eMsgGroup 
	{
		MSGGROUP_SYS	= 0x01,
		MSGGROUP_MOUSE	= 0x02,
		MSGGROUP_KEYB	= 0x04, 
		MSGGROUP_ALL	= 0xff,
	};

	/**
	 * @struct	Msg
	 * @brief	Message structure, holding message data as well as group and param info.
	 * @author	Peter Nordlander
	 * @date	2001-10-29
	 */
	struct Msg 
	{	
		eMsgGroup	mGroup;		///< Message Group
		eMsgType	mMsg;		///< Message ID
		uint32		mParam;		///< Message Parameter data
		uint32		mExtra;		///< Message extra parameter data
		Point		mMousePos;	///< Message mouse position at arrival
	};


	/**
	 * @class	MsgQueue
	 * @brief	Thread-safe message queue, takes and queues messages 
	 * @author	Peter Nordlander
	 * @date	2001-10-29
	 */
	class MsgQueue : public CopyProtected
	{
	public:

		/**
		 * Constructor
		 */
		MsgQueue();

		/** 
		 * Destructor
		 */
		~MsgQueue();

		/** 
		 * Add message to queue
		 * @param group Group message belong to @see eMsgGroup
		 * @param msg Type of message @see eMsgType
		 * @param param Extra parameter
		 * @param extra Another extra parameter
		 * @return Boolean value indicating if the message was succesfully queued(true) or not (false)
		 */
		bool addMessage(eMsgGroup group, eMsgType msg, uint32  param, uint32 extra);
		
		/**
		 * GetMessage, checks queue and returns if no messages are present
		 * @param msg Reference to a message struct in where to copy the received message from queue
		 * @param waitIfBusy Set to false if you want the functioncall to return emedialtely if another thread was working with the queue
		 * @return A value of (true) if a message was retrieved, (false) otherwise
		 */
		bool getMessage(Msg &msg, bool waitIfBusy = true);
		
		/** 
		 * Wait of a message to arrive on queue - blocks calling thread
		 * @param msg Where to copy the retrieved message data
		 * @return True if a message was retrievd, false otherwise
		 */
		bool waitMessage(Msg &msg);

		/**
	     * Check if queue is empty
		 * @return (true) if queue was empty, (false) if containing messages
		 */
		bool isEmpty();
		
		/**
		 * Flushs all messages in queue
		 * @return (true) if call was successful, (false) on failure
		 */
		bool flush();

		/**
		 * Set msg group filter
		 * @param filter New message group filter @see eMsgGroup
		 */
		void setFilter(const uint32 filter);

		/**
		 * Get msg group filter
		 * @return Currently set message group filter @see eMsgGroup
		 */
		const uint32 getFilter() const;

	protected:

		std::deque<Msg>		mQueue;		///< Queue messages
		Mutex				mMutex;		///< Queue thread synchronization mutex
		Event				mEvent;		///< Queue event, used to signal a waiting thread that messages has arrived
		uint32				mFilter;	///< Queue filter, accepts GROUP_ALL, GROUP_SYS... etc
	};

}

#endif
