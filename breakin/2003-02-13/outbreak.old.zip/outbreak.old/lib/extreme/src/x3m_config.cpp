//================================================================================
// Include files
//================================================================================

#include "x3m_config.h"
#include "x3m_exception.h"
#include <string.h>

//================================================================================
// Namespace usage
//================================================================================

using namespace Extreme;

//================================================================================
// Method implenetation
//================================================================================

ConfigMap::ConfigMap() {
	X3M_DEBUG ("ConfigMap", "Constructing...");
}

//================================================================================

ConfigMap::~ConfigMap() {
	X3M_DEBUG ("ConfigMap", "Destructing...");
}

//================================================================================

void ConfigMap::registerParam(const std::string &name, const ConfigValue initVal) {

	// only register if not already exist
	if (!hasParam(name))
		mConfigMap[convertParam(name)] = initVal;
}

//================================================================================

const bool ConfigMap::setParam(const std::string &name, const ConfigValue &value) {
	std::string param = convertParam(name);
	
	// check if it exist in the record
	if (!hasParam(param))
		return false;

	// set value for this parameter
	mConfigMap[param] = value;
	return true;		
}

//================================================================================

const bool ConfigMap::hasParam(const std::string &name) {
	std::map<std::string, ConfigValue>::iterator i = mConfigMap.find(name);
	if (i == mConfigMap.end())
		return false;
	return true;
}

//================================================================================

ConfigValue & ConfigMap::getParam(const std::string &name) {
	if (!hasParam(convertParam(name)))
		throw Exception ("Parameter %s does not exist in record!", name.c_str());

	return mConfigMap[convertParam(name)];
}

//================================================================================

void ConfigMap::clear() {
	mConfigMap.clear();
}

//================================================================================

std::string ConfigMap::convertParam(const std::string &param) {
	std::string fmtParam;
	fmtParam = _strlwr(strdup(param.c_str()));
	return fmtParam;
}

//================================================================================

const int32 ConfigValue::getIntVal() const {
				
	int32 intVal;
	
	if (sscanf(mVal.c_str(), "%d", &intVal) != 1)
		throw Exception ("Invalid format, value %s is not numeric!", mVal.c_str());

	return intVal;
}

//================================================================================

const bool ConfigValue::getBoolVal() const {

	if ((mVal == "true") || (mVal == "false")) 
		return bool(mVal == "true");
		
	throw Exception ("Invalid configparameter format, parameter is not of type bool!");
}

//================================================================================

const std::string ConfigValue::getVal() const{
	return mVal;
}

//================================================================================
//================================================================================
//================================================================================
