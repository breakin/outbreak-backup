#ifndef __EXTREME_CLOCK_INC__
#define __EXTREME_CLOCK_INC__

#include "x3m_timerinterface.h"
#include "x3m_typedef.h"

namespace Extreme {

	/**
	 * @class	Clock 
	 * @brief	Timer sync. through CPU clock 
	 * @author	Peter Nordlander
	 * @date	2001-12-26
	 */

	class Clock : public TimerInterface
	{
	public:

		/// Constructor
		Clock();

		/// Destructor
		virtual ~Clock();

		/// Start clock
		virtual void start();

		/// Stop clock
		virtual void stop();

		/// Pause clock
		virtual void pause() { stop(); }

		/**
		 * Receive current time in seconds
		 * @return Current time in seconds as a float64
		 */
		virtual const float64 getTime() const;
	
	protected:

		float64	mStart;			///< Start time
		float64 mStop;			///< Stop time
		float64 mFrequency;		///< Clock frequency, counts / second
		bool	mRunning;		///< State flag indicating weither clock is running
	};	
}

#endif
