#ifndef __EXTREME_AREA_INC__
#define __EXTREME_AREA_INC__

#include <windows.h>
#include "x3m_typedef.h"

namespace Extreme {

	/**
	 * @class	Area
	 * @brief	Class representing a 2 dim. area consisint of x,y, width and height.
	 * @author	Peter Nordlander
	 * @date	2001-11-12
	 */	
	class Area
	{
	public:

		/**
		 * Constructor
		 */
		Area(int32 x = 0, int32 y = 0, int32 width = 0, int32 height = 0) 
			: mLeft(x), mTop(y), mWidth(width), mHeight(height) {}

		/**
		 * Logical AND operator
		 * @param other Other operand
		 * @return Result of operation
		 */
		const Area& operator & (const Area &other);

		/**
		 * Logical OR operator
		 * @param other Other operand
		 * @return Result of operation
		 */
		const Area& operator | (const Area &other);

		/**
		 * Logical equal operator
		 * @param other Other operand
		 * @return Result of operation
		 */
		const Area& operator == (const Area &other);

		/**
		 * Clear area
		 */
		void clear() { mTop = 0; mLeft = 0; mWidth = 0; mHeight = 0; }

		/**
		 * Conversion operator to a Win32 RECT struct
		 */
		operator RECT();

		int32	mTop;		///< Top of are
		int32	mLeft;		///< Lef of area
		int32	mWidth;		///< Area width
		int32	mHeight;	///< Area height
	};
}

#endif
