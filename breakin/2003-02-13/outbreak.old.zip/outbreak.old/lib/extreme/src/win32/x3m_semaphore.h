#ifndef __EXTREME_WIN32_SYNC_SEMAPHORE_INC__
#define __EXTREME_WIN32_SYNC_SEMAPHORE_INC__

#include <windows.h>

namespace Extreme {

	/**
	 * @class  Semaphore
	 * @brief  Semaphore synchronization object that allows more than 1 thread to sync with it.
	 * @author Peter Nordlander
	 * @date   2002-03-23
	 */
	class Semaphore : public SignalObject
	{
	public:

		/**
		 * Constructor
		 * @param name The name to provide this semaphore with - also its ID when sharing the object across processes
		 * @param maxCnt Maximum amount of callers allowed to lock this object
		 * @param initCnt Initially free slots in semaphore (usually set to the same value as maxCnt)
		 */
		Semaphore (const std::string &name = "", const int32 maxCnt = 1, const int32 initCnt = 1);
	
		/**
		 * Destructor
		 */
		virtual ~Semaphore ();

		/**
		 * Explicitly create a new semaphore 
		 * @param name The name to provide this semaphore with - also its ID when sharing the object across processes
		 * @param maxCnt Maximum amount of callers allowed to lock this object
		 * @param initCnt Initially free slots in semaphore (usually set to the same value as maxCnt)
		 */
		const bool create (const std::string &name = "", const int32 maxCnt = 1, const int32 initCnt = 1);
		
		/**
		 * Lock mutex, gain exclusive ownership if not the maximum amounts of syncs has been reached
		 * @param milliSecs Amount of milliseconds to wait before giving up
		 * @return true on gain of access, false on timeout
		 * @remarks Equal to SignalObject::wait
		 */
		const bool lock(const int32 milliSecs = SignalObject::WAIT_INFINITE);

		/**
		 * Give up ownership
		 * @return True on success, false on failure
		 */
		const bool unlock();

	protected:

		/**
		 * Cleanup, initialize and set default values etc.
		 */
		void init();
		
		std::string mName;		///< Semaphore's name
		int32		mCount;		///< Semaphore's current counter
		int32		mMaxCount;	///< Semaphore's maximum counter
	};

}

#endif
