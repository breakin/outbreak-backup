//================================================================================
// Include files
//================================================================================

#include "x3m_thread.h"
#include "..\debug\x3m_debug.h"

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Method implementations
//================================================================================

Thread::Thread() {
	
	mStartupEvent.create();
	mShutdownEvent.create();

	// clear and set default values
	Debug::debug ("Thread", "Constructing...");
	init();
}

//===============================================================================

Thread::~Thread() {

	// terminate thread if running
	Debug::debug ("Thread", "Destructing...");
	if (mRunning)
		stop();
}
			  
//===============================================================================

const bool Thread::stop() {
	
	Debug::debug ("Thread", "Killing thread!");

	// if already suspended, just return
	if (!mRunning) {

		Debug::debug ("Thread", "Thread is not running, stop failed!");
		return true;
	}
	
	/** 
	 * wait for 0.1 sec, and check if thread has already 
	 * exited, if wait returned false, it did not detect
	 * the thread object to be signalled
	 */
	if (!mShutdownEvent.wait(100)) {
		
		// terminate thread
		TerminateThread(mHandle, 0);
	}

	SignalObject::release();
	mRunning = false;
	init();
	return true;
}

//===============================================================================

const bool Thread::start() {
	// if already running, return
	if (mRunning) {

		Debug::debug ("Thread", "Cant start thread, yhread is already running!");
		return false;
	}

	// create thread
	mHandle = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)threadInstanceRouter, (LPVOID)this, 0, &mThreadID);

	// wait until thread has started
	mStartupEvent.wait();

	// update state flag 
	mRunning = true;
	return true;
}

//===============================================================================

int32 Thread::threadInstanceRouter(LPVOID instance) {

	Thread *threadObject = (Thread*)(instance);
	
	// pulse startupevent to notify startup of thread
	threadObject->mStartupEvent.pulse();

	// call threads run method
	threadObject->main();

	// set shutdownevent to indicate that thread has finished
	threadObject->mShutdownEvent.set();

	return 0;
}

//===============================================================================

void Thread::setPriority(const eThreadPriority priority) {
	mPriority = priority;
	::SetThreadPriority(mHandle, (uint32)priority);
}

//===============================================================================

const Thread::eThreadPriority Thread::getPriority() const {
	return mPriority;
}

//===============================================================================

const uint32 Thread::getID() const {
	return mThreadID;
}

//===============================================================================

const HANDLE Thread::getHandle() const {
	return mHandle;
}

//===============================================================================

const uint32 Thread::getState() const {
	return mRunning ? STATE_RUNNING : STATE_SUSPENDED;
}

//===============================================================================

void Thread::init() {
	mPriority	= PRIO_NORMAL;
	mRunning	= false;
	mHandle	= NULL;
	mThreadID	= 0;
	mStartupEvent.reset();
	mShutdownEvent.reset();
}

//===============================================================================
