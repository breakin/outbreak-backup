//================================================================================
// Include files
//================================================================================

#include "x3m_mutex.h"
#include "..\x3m_exception.h"

//================================================================================
// Used Namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Method implementations
//================================================================================

Mutex::Mutex(const std::string &name) {
	// clear data members, init to default
	Debug::debug ("Mutex", "Constructing...");
	init();
}

//=============================================================================

Mutex::~Mutex() {
	Debug::debug ("Mutex", "Destructing...");
}

//=============================================================================

const bool Mutex::create (const std::string & name) {

	X3M_ASSERT(mHandle == NULL);

	// check if we need to deallocate mName 
	init();

	// check if named and allocate char. space
	mName = name;

	// create mutex
	mHandle = CreateMutex(NULL, FALSE, (mName == "") ? NULL : mName.c_str());
	
	// if creation failed, throw exception
	if (!mHandle) {
		
		DWORD errCode = ::GetLastError();
		std::string errMsg = "Fatal failure!";

		if (errCode == ERROR_INVALID_HANDLE)
			errMsg = "Object with name already exist";
	
		throw Exception("Failed to create Mutex(%s)! reason [%s]!", mName.c_str(), errMsg.c_str());
	}

	return true;
}

//=============================================================================

void Mutex::unlock() {
	
	// check if the mutex object is valid
	if (!mHandle) {
		Debug::error ("Mutex", "Attempt to unlock an invalid object [%s]!", mName.c_str());
		return;
	}
	
	// release the mutex
	ReleaseMutex(mHandle);
}

//=============================================================================

void Mutex::init() {	
	mName = "";
	mHandle = NULL;
}

//=============================================================================

const bool Mutex::lock(const int32 milliSecs) {
	return SignalObject::wait(milliSecs);
}
