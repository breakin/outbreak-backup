//================================================================================
// Include files
//================================================================================

#include "x3m_event.h"
#include "..\x3m_exception.h"
#include "..\debug\x3m_assert.h"

//================================================================================
// Used Namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Method implementations
//================================================================================

Event::Event(const Event::eEventType eventType, const std::string &name) {
	Debug::debug ("Event", "Constructing...");
	init();
}

//================================================================================

Event::~Event() {
	Debug::debug ("Event", "Destructing...");
}

//================================================================================

const bool Event::create(eEventType type, const std::string &name) {

	X3M_ASSERT (mHandle == NULL);
	BOOL manualReset = (type == EVENT_AUTO_RESET) ? FALSE : TRUE;

	mType = type;
	mName = name;
	mHandle = CreateEvent(NULL, manualReset, FALSE, (mName == "") ? NULL : mName.c_str());

	if (!mHandle)
		throw Exception("Could not create EVENT kernel object!");

	return true;
}

//================================================================================

const bool Event::isAutoReset() const {
	return mType == Event::EVENT_AUTO_RESET ? true : false;
}

//================================================================================

const bool Event::isManualReset() const {
	return mType == Event::EVENT_MANUAL_RESET ? true : false;
}

//================================================================================

void Event::set() {
	X3M_ASSERT (mHandle != NULL);
	SetEvent(mHandle);
}

//================================================================================

void Event::reset() {
	X3M_ASSERT (mHandle != NULL);
	ResetEvent(mHandle);
}

//================================================================================

void Event::pulse() {
	X3M_ASSERT (mHandle != NULL);
	PulseEvent(mHandle);
}

//================================================================================

void Event::init() {
	mHandle = NULL;
	mName = "";
}

//================================================================================
