//====================================================================================
// Include files
//====================================================================================

#include "x3m_threadwindow.h"
#include "..\debug\x3m_assert.h"
#include "..\debug\x3m_debug.h"

//====================================================================================
// Used namespaces
//====================================================================================

using namespace Extreme;

//====================================================================================
// method implementations
//====================================================================================

ThreadWindow::ThreadWindow() : Thread() {

	Debug::debug ("ThreadWindow", "constructing...");
};

//====================================================================================

ThreadWindow::~ThreadWindow() {

	Debug::debug ("ThreadWindow", "destructing...");
};

//====================================================================================

const bool ThreadWindow::open(const int32 windowStyle, const int32 initWidth, const int32 initHeight, const bool visible) {

	Debug::log ("ThreadWindow", "Open multithreaded window");
	mWidth		= initWidth;
	mHeight		= initHeight;
	mVisible	= visible;
	mType		= windowStyle;
	
	/// start thread
	start();

	/// sleep for 0.1 sec, to let window be created
	Sleep(100);

	return true;
}

//=================================================================================

void ThreadWindow::close() {

	Debug::debug ("ThreadWindow", "Close window");

	// post a quit message to the thread's messagequeue
	Debug::debug ("ThreadWindow", "Post Quit message to thread[%d]", this->getID());
	PostThreadMessage(GetWindowThreadProcessId(mHwnd,NULL), WM_QUIT, 0, 0);
	
	// wait for window thread to stop 
	Debug::debug ("ThreadWindow", "Wait at lease 1000ms to let thread cleanup...");
	
	if (!this->wait(1000)) {

		// mHandle might have been released(handle set to NULL), so that could have been the reason that wait failed
		if (mHandle) {
			Debug::debug ("ThreadWindow", "Thread did not die, kill him!");
			TerminateThread(mHandle,0);
		}
	}
		
	// close window
	this->Window::close();
}

//=================================================================================

void ThreadWindow::main() {

	// create window in this thread
	Window::createWindow();
	
	// call infinite dispatch loop
	dispatch();
}

//=================================================================================

void ThreadWindow::dispatch() {

	MSG msg;
	
	Debug::log ("ThreadWindow", "Entering threaded dispatch loop...");

	while (1) {
	
		if (GetMessage(&msg, NULL, 0,0)) {
			
			if (msg.message == WM_QUIT)
				break;

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else {
			
			Debug::debug ("ThreadWindow", "Window received a quit message!...");
			// case thread to die, return
			break;
		}
	}
	
	mRunning = false;
	
	Debug::log ("ThreadWindow", "Received QUIT message, stop execution!");
	mHandle = NULL;
}

//=================================================================================
