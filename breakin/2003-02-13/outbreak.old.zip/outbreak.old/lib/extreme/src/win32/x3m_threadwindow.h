#ifndef __EXTREME_SYS_WINDOW_MT_INC__
#define __EXTREME_SYS_WINDOW_MT_INC__

#include "x3m_window.h"
#include "x3m_thread.h"
#include "..\x3m_typedef.h"
#include "..\x3m_msgqueue.h"
#include <windows.h>
#include <string>

namespace Extreme {

	/**
	 * @class	ThreadWindow
	 * @brief	Win32 window management class which run its dispatching loop in an own thread
	 * @author	Peter Nordlander
	 * @date	2001-10-15
	 */

	class ThreadWindow : public Window, protected Thread
	{
	public:

		/**
		 * Constuctor
		 */
		ThreadWindow();

		/**
		 * Destructor
		 */
		virtual ~ThreadWindow();

		/**
		 * Open a new window
		 * @param style A predefined window style @see Window::eWindowStyle
		 * @param initWidth Initial width of clientarea in pixels
		 * @param initHeight Initial height of clientarea in pixels
		 * @param visible Indicating weither the window should be shown directly implicitly
		 * @return true on success, false on failure
		 */
		const bool open(const int32 style, const int32 initWidth, const int32 initHeight, const bool visible = true);
		
		/**
		 * Close window
		 */
		void close();

		/**
		 * Dispath messages, differs from Window's dispatch
		 * in that it is kept in a continues loop and do only consume CPU when 
		 * @remarks The dispath method do run in an own thread
		 */
		void dispatch();
		
	protected:

		/**
		 * Overloaded thread main, thread execution initial point
		 */
		void main();	
	};
}

#endif
