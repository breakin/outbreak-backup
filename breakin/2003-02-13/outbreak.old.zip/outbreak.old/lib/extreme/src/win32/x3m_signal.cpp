//================================================================================
// Include files
//================================================================================

#include "x3m_signal.h"
#include "..\debug\x3m_debug.h"
#include <windows.h>

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Method implementations
//================================================================================

SignalObject::SignalObject() : mHandle(NULL) {
	Debug::debug ("SignalObject", "Constructing...");
}

//================================================================================

SignalObject::~SignalObject() {
	Debug::debug ("SignalObject", "Destructing...");
	release();
}

// =============================================================================

void SignalObject::release() {

	if (mHandle)
		CloseHandle(mHandle);

	mHandle = NULL;

	// data members
	Debug::debug ("SignalObject", "Calling init on inherited class");
}
// =============================================================================

const bool SignalObject::wait(const int32 milliSecs) {

	if (!mHandle) {
		Debug::error ("SignalObject", "Object not valid!");
		return false;
	}

	// wait until object is in signalled state
	int ret = WaitForSingleObject(mHandle, milliSecs);
	
	if ((ret != WAIT_OBJECT_0) && (ret != WAIT_ABANDONED)) {
		Debug::log ("SignalObject", "Wait timeout/or not released!");
		
		// timeout or error
		return false;
	}

	return true;
}

//=============================================================================

const bool SignalObject::isValid() const {
	return mHandle == NULL ? false : true;
}

//=============================================================================
