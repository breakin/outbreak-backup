#ifndef __EXTREME_SYS_EVENT_INC__
#define __EXTREME_SYS_EVENT_INC__

#include "x3m_signal.h"
#include <string>

namespace Extreme {

	/**
	 * @class	Event
	 * @brief	Win32 Event synch object
	 * @author	Peter Nordlander
	 * @date	2001-10-15
	 * @remarks Events differs slightly from other synchronization objects
	 *			It rarely get locked for a cetain amount of time, its often
	 *			Pulsed
	 */

	class Event : public SignalObject
	{
	public:

		/**
		 * Event types
		 */
		enum eEventType {

			EVENT_MANUAL_RESET = 0x01, ///< Needs to be reset manually through ::reset
			EVENT_AUTO_RESET   = 0x02, ///< Automatically reset when pulsed through ::pulse
		};

		/** 
		 * Constructor
		 * @param eventType Type of event @see eEventType
		 * @param eventName Optional name identifier of this Event
		 */
		Event(const eEventType eventType = EVENT_AUTO_RESET, const std::string & eventName = "");
		
		/**
		 * Destructor
		 */
		virtual ~Event();

		/**
		 * Create event
		 * @param type Type of event @see eEventType
		 * @param name Optional name identifier of this Event
		 * @return Boolean <true> on success, <false> on failure
		 */ 
		const bool create(eEventType type = EVENT_AUTO_RESET, const std::string &name = "");

		/**
		 * Check if event must be manually reset on signalling
		 * @return true if manual reset, false otherwise
		 */
		const bool isAutoReset() const;
		
		/**
		 * Check if event is auto reset on signalling
		 * @return true if auto reset, false otherwise
		 */
		const bool isManualReset() const;

		/**
		 * Get event type
		 * @return Currently set type for this event @see eEventType
		 */
		const eEventType getType() const { return mType; }
		
		/**
		 * Pulse Event
		 */
		void pulse();

		/**
		 * Set Event
		 */
		void set();

		/**
		 * Reset Event
		 */
		void reset();

		/**
		 * Clear data members
		 */
		void init();

	private:

		eEventType	mType;	///< Event type (MANUAL or AUTO_RESET)
		std::string	mName;	///< Event name
	};
}

#endif