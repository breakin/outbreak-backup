//************************************************************************************
// Include files
//************************************************************************************

#include "x3m_window.h"
#include "..\debug\x3m_assert.h"
#include "..\debug\x3m_debug.h"

//************************************************************************************
// Used namespaces
//************************************************************************************

using namespace Extreme;

//************************************************************************************
// static member definition
//************************************************************************************

char *		Window::sWindowClassName = "X3MWNDCLASS";
WNDCLASSEX	Window::sWindowClass;
uint32		Window::sRefCounter = 0;

//************************************************************************************
// method implementations
//************************************************************************************

Window::Window() {

	Debug::debug ("Window", "Constructing reference[%d]...", sRefCounter);

	// only create windowclass if first instance of window
	if (sRefCounter == 0)
		createWindowClass();

	// increase reference counter
	sRefCounter++;

	// set default values
	init();
}

//************************************************************************************

Window::~Window() {

	Debug::debug ("Window", "Destructing reference[%d]...", sRefCounter-1);

	sRefCounter--;

	if (mOpened)
		close();

	if (sRefCounter == 0)
		releaseWindowClass();
}

//************************************************************************************

bool Window::open(int32 style, int32 initWidth, int32 initHeight, bool visible) {

	X3M_ASSERT(!mOpened);
	X3M_ASSERT(mMsgQueue);

	Debug::log ("Window", "Opening window[%s (%d,%d)]", mCaption.c_str(), mWidth, mHeight);
	
	// set properties
	mType		= style;
	mVisible	= visible;
	mWidth		= initWidth;
	mHeight	= initHeight;

	// create the window
	return createWindow();

}

//************************************************************************************

void Window::init() {

	/// set default values
	mCaption	= "X3M 3D Application";
	mWidth		= 640;
	mHeight		= 480;
	mFocus		= false;
	mValidRect	= false;
	mOpened		= false;
	mType		= Window::STYLE_WINDOW;
	mHwnd		= NULL;
	mHdc		= NULL;
	mMsgQueue	= NULL;
}

//************************************************************************************

void Window::close() {

	Debug::debug ("Window", "Destroying window");

	if (mOpened) {

		// destroy window
		destroyWindow();

		// flush message queue
		mMsgQueue->flush();
	}

	// initialize default values
	init();
}

//************************************************************************************

void Window::setMsgQueue(MsgQueue * queue) {

	mMsgQueue = queue;
}

//************************************************************************************

const MsgQueue * Window::getMsgQueue() const {

	return mMsgQueue;
}

//************************************************************************************

const std::string& Window::getCaption() const {

	return mCaption;
}

//************************************************************************************

void Window::setCaption(const std::string &caption) {

	mCaption = caption;

	// update opened window only if opened
	if (mOpened)
		SetWindowText(mHwnd, caption.c_str());
}

//************************************************************************************

const int32 Window::getWidth() const {

	return mWidth;
}

//************************************************************************************

const int32 Window::getHeight() const {
	
	return mHeight;
}

//************************************************************************************

const HWND Window::getHWND() const {

	return mHwnd;
}

//************************************************************************************

HDC Window::getDC() {

	if (!mHdc)
		mHdc = ::GetDC(mHwnd);
	return mHdc;
}

//************************************************************************************

void Window::releaseDC() {

	if (mHdc)
		ReleaseDC(mHwnd, mHdc);
	
	mHdc = NULL;
}

//************************************************************************************

void Window::show() {

	X3M_ASSERT (mOpened);

	// check if widow is visible, and only show it if its not
	if (!mVisible) {

		ShowWindow(mHwnd, SW_SHOW);
		mVisible = true;
	}
}

//************************************************************************************

void Window::hide() {

	X3M_ASSERT (mOpened);

	if (mVisible) {

		ShowWindow(mHwnd, SW_HIDE);
	}
}

//************************************************************************************

bool Window::resize(int x, int y, int width, int height, bool keepPosition) {

	X3M_ASSERT(mOpened);

	RECT rect;

	// obtain current position if we should keep it as is
	if (keepPosition) {

		GetWindowRect (mHwnd, &rect);
		x = rect.left;
		y = rect.top;
	}
	
	// update client area
	mWidth	 = width;
	mHeight = height;

	// new window position/dimensions
	rect.left	= x;
	rect.top	= y;
	rect.right	= x + width;
	rect.bottom = y + height;

	// adjust window area so we get a by pixel precice cleint area
	AdjustWindowRectEx(&rect, convertStyle(), FALSE, 0);
	
	// move window
	if (!MoveWindow(mHwnd,rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, TRUE))
		return false;

	return true;
}

//************************************************************************************

void Window::center() {

	// retrieve desktop dimensions
	int32 mid_x = (GetSystemMetrics (SM_CXSCREEN) >> 1) - (mWidth >> 1);
	int32 mid_y = (GetSystemMetrics (SM_CYSCREEN) >> 1) - (mHeight >> 1);
	
	this->resize(mid_x, mid_y, mWidth, mHeight, false);
}

//************************************************************************************

void Window::setStyle(eWindowStyle windowStyle) {

	// check if already using this style
	if (mType == windowStyle)
		return;

	mType = windowStyle;

	// if opened, update window visually
	if (mOpened) {

		// change style
		SetWindowLong(mHwnd, GWL_STYLE, convertStyle());
		
		// call SetWindowPos for making the changes affect
		SetWindowPos(mHwnd, HWND_NOTOPMOST, 0,0,mWidth,mHeight, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED | SWP_SHOWWINDOW); 
	}
}

//************************************************************************************

void Window::showMouse() {

	ShowCursor(TRUE);
}

//************************************************************************************

void Window::hideMouse() {

	ShowCursor(FALSE);
}

//************************************************************************************

const int32 Window::getStyle() const {

	return mType;
}

//************************************************************************************

void Window::invalidateRect() {

	mValidRect = false;
}

//************************************************************************************

void Window::validateRect() {

	mValidRect = true;
}

//************************************************************************************

bool Window::isWindow() const {

	return (IsWindow(mHwnd) == TRUE);
}

//************************************************************************************

bool Window::needsRepaint() const {

	return mValidRect;
}

//************************************************************************************

int32 Window::convertStyle() const {

	switch (mType) {

	case Window::STYLE_WINDOW:
		return WS_POPUP|WS_BORDER|WS_SYSMENU|WS_CAPTION;
	case Window::STYLE_FRAME:
		return WS_POPUP|WS_BORDER;
	case Window::STYLE_PLAIN:
		return WS_POPUP;
	}

	return 0;
}

//************************************************************************************

void Window::dispatch() {

	MSG msg;

	if (mFocus) {

		if (GetMessage(&msg, mHwnd, 0,0)) {

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	else {

		if (PeekMessage(&msg, mHwnd, 0,0, PM_REMOVE)) {

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
}

//************************************************************************************

bool Window::createWindow() {

	Debug::log ("Window", "Create window");

	RECT	rect;

	// set up and adjust rect
	rect.left	= 0;
	rect.top	= 0;
	rect.right	= rect.left + mWidth;
	rect.bottom = rect.top + mHeight;
	AdjustWindowRect(&rect, convertStyle(), FALSE);

	// check if we should show the window on immidialtely
	DWORD visible = mVisible ? WS_VISIBLE : 0;

	// create window
	mHwnd = CreateWindowEx(0, 
							sWindowClassName, 
							mCaption.c_str(), 
							convertStyle() | visible,
							CW_USEDEFAULT, CW_USEDEFAULT,
							rect.right - rect.left, rect.bottom - rect.top,
							NULL,
							NULL,
							GetModuleHandle(NULL),
							NULL);
	
	Debug::log ("Window", "Window created...");

	// check result, and return false on error
	if (!mHwnd) {

		Debug::error ("Window", "Window [%s] failed to open!");
		return false;
	}

	/**
	 * Store object instance in allocated extra storage for <this> window
	 */ 
	Debug::log ("Window", "Store object instance in window extra space...");
	SetWindowLong (mHwnd, 0, (LONG)this);
	
	/// Give window focus at startup
	SetFocus(mHwnd);

	mOpened = true;
	mFocus = true;

	return true;
}

//************************************************************************************

bool Window::destroyWindow() {

	Debug::debug ("Window", "Destroying window!");

	if (mOpened) {
		
		// check so that the window still is valid,
		// and destroy in that case
		if (IsWindow(mHwnd)) {

			Debug::debug ("Window", "Window was not a valid win32-window object!");
			DestroyWindow(mHwnd);
		}

		mOpened = false;
	
		return true;
	}

	return false;
}

//************************************************************************************
// Wim32Window static members
//************************************************************************************

LRESULT CALLBACK Window::windowProcedure(HWND hwnd , UINT msg, WPARAM lparam, LPARAM wparam) {
	
	// get object instance
	Window * pWinObj = (Window*)GetWindowLong(hwnd, 0);
	
	// check for safety, if not created already, pass to DefWindowProc
	if (pWinObj) {

		// check message
		switch (msg) {
		
		case WM_PAINT:
			pWinObj->mMsgQueue->addMessage(MSGGROUP_SYS, MSG_PAINT, 0 , 0); 
			pWinObj->invalidateRect();
		break;

		case WM_DESTROY:
		return 0;

		case WM_CLOSE:
			pWinObj->mMsgQueue->addMessage(MSGGROUP_SYS, MSG_CLOSE, 0 , 0); 
		return 0;

		case WM_KEYDOWN:
			pWinObj->mMsgQueue->addMessage(MSGGROUP_KEYB, MSG_KEYDOWN, lparam, wparam);
		return 0;

		case WM_KEYUP:
			pWinObj->mMsgQueue->addMessage(MSGGROUP_KEYB, MSG_KEYUP, lparam, wparam);
		return 0;
		
		}	
	}
	// return default window procedure
	return DefWindowProc(hwnd, msg, lparam, wparam);
}

//************************************************************************************

void Window::createWindowClass() {
	
	Debug::log ("Window", "Register windowclass...");

	// set class config
	sWindowClass.cbClsExtra = 0;
	sWindowClass.cbSize = sizeof (WNDCLASSEX);
	sWindowClass.cbWndExtra = sizeof (Window*);
	sWindowClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	sWindowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	sWindowClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	sWindowClass.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	sWindowClass.hInstance = GetModuleHandle(00);
	sWindowClass.lpfnWndProc = windowProcedure;
	sWindowClass.lpszClassName = sWindowClassName;
	sWindowClass.style = CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
	sWindowClass.lpszMenuName = NULL;

	// register class with windows
	if (!RegisterClassEx(&sWindowClass))
		Debug::error("Window", "Unable to create windowclass!");


}

//************************************************************************************

void Window::releaseWindowClass() {

	Debug::log ("Window", "Unregister windowclass...");

	UnregisterClass(sWindowClassName, GetModuleHandle(0));
}

//************************************************************************************

