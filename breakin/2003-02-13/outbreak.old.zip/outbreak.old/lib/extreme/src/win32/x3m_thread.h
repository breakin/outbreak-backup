#ifndef __EXTREME_SYS_THREAD_INC__
#define __EXTREME_SYS_THREAD_INC__

#include "x3m_signal.h"
#include "x3m_event.h"
#include "..\x3m_typedef.h"
#include "..\x3m_copyprotect.h"
#include <windows.h>

namespace Extreme {

	/**
	 * @class	Thread
	 * @brief	Win32 threaded object interface
	 *			Classes implementing the Thread interface are able to run in an own threaded enviroment.
	 * @author	Peter Nordlander
	 * @date	2001-10-15
	 */

	class Thread : public SignalObject
	{
	public:
		
		/**
		 * Thread state enumerations
		 */
		enum eThreadState  {

			STATE_SUSPENDED,	///< Thread is suspended
			STATE_RUNNING,		///< Thread is running
		};

		/**
		 * Thread priorities
		 */
		enum eThreadPriority {

			PRIO_LOW	  = THREAD_PRIORITY_BELOW_NORMAL,	///< Below normal scheduling priority
			PRIO_NORMAL   = THREAD_PRIORITY_NORMAL,			///< Normal scheduling priority
			PRIO_HIGH	  = THREAD_PRIORITY_ABOVE_NORMAL,	///< Low normal scheduling priority
			PRIO_CRITIVAL = THREAD_PRIORITY_TIME_CRITICAL,	///< Time critical/maximum scheduling priority
		};

		/**
		 * Constructor
		 */
		Thread();

		/**
		 * Destructor
		 */
		virtual ~Thread();
	
		/**
		 * Start Thread
		 * @return true on success, false on failure
		 */
		const bool start();

		/**
		 * Stop Thread
		 * @return true on success, false on failure
		 */
		const bool stop();

		/**
		 * Set a threads priority runtime
		 * @param priority @see eThreadPriority
		 */
		void setPriority(const eThreadPriority priority);
		
		/**
		 * Get a threads current priority
		 * @return Current priority @see eThreadPriority
		 */		
		const eThreadPriority getPriority() const;

		/**
		 * Get a threads current state
		 * @return Current priority @see eThreadState
		 */		
		const uint32 getState() const;		

		/**
		 * Get a threads current ID
		 * @return Current numeric identifier
		 */		
		const uint32 getID() const;

		/**
		 * Get a threads Win32 Object Handle
		 * @return Thread's Win32 Handle
		 */		
		const HANDLE getHandle() const;

		/**
		 * Virtual method, to be overloaded. startup routine for each thread
		 */
		virtual void main() = 0;
	
	protected:

		/**
		 * Clear data members
		 */
		void init();

		/**
		 * Static thread router, routs run() to proper instance of thread
		 * @param instance Thread object invoked the call to threadInstanceRouter
		 */
		static int32 threadInstanceRouter(LPVOID instance);
		
		Event			mStartupEvent;	///< Thread's startup event
		Event			mShutdownEvent; ///< Thread's shutdown event, signalled when thread dies
		eThreadPriority mPriority;		///< Thread's current priority
		uint32			mThreadID;		///< Thread's ID
		bool			mRunning;		///< Thread is running(true)/ stopped(false)
	};
}

#endif