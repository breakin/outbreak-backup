#ifndef __EXTREME_SYS_WINDOW_INC__
#define __EXTREME_SYS_WINDOW_INC__

#include "..\x3m_typedef.h"
#include "..\x3m_msgqueue.h"
#include <windows.h>
#include <string>

namespace Extreme {

	/**
	 * @class	Window
	 * @brief	Win32 window management class
	 * @author	Peter Nordlander
	 * @date	2001-10-15
	 */
	class Window : public CopyProtected
	{
	public:

		/** 
		 * Window's predefined styles
		 */
		enum eWindowStyle {

			STYLE_PLAIN	 = 0x00,	///< Plain window area
			STYLE_FRAME	 = 0x01,	///< Frame window with border
			STYLE_WINDOW = 0x02,	///< Common window with border and captionbar
		};
	
		/**
		 * Constuctor
		 */
		Window();

		/**
		 * Destructor
		 */
		virtual ~Window();

		/**
		 * Open a new window
		 * @param style A predefined window style @see Window::eWindowStyle
		 * @param initWidth Initial width of clientarea in pixels
		 * @param initHeight Initial height of clientarea in pixels
		 * @param visible Indicating weither the window should be shown directly implicitly
		 * @return true on success, false on failure
		 * @remarks Method open should always be called AFTER a MsgQueue has been set on
		 *			the Window object. A MsgQueue is attached through the setMsgQueue method.
		 */
		virtual bool open(int32 windowStyle, int32 initWidth, int32 initHeight, bool visible = true);

		/**
		 * Close Window
		 */
		virtual void close();

		/**
		 * Set Message queue to which the window will pass its incoming messages from MSWindows
		 * @param Pointer to a valid MsgQueue object
		 */
		void setMsgQueue(MsgQueue * queue);
		
		/**
		 * Retreve currently attached msgqueue
		 * @return The currently attached msgqueue, NULL if there is no attached
		 */
		const MsgQueue * getMsgQueue() const;

		/**
		 * Get window caption
		 * @return The windows caption/titlebar title
		 */
		const std::string& getCaption() const;

		/**
		 * Set window caption
		 * @param caption A std::string which will be used as caption on this Window
		 */
		void setCaption(const std::string &caption);

		/**
		 * Get Window's client area width		
		 * @return Width of Window's client area in pixels
		 */
		const int32 getWidth() const;
		
		/**
		 * Get Window's client area height		
		 * @return Width of Window's client area in pixels
		 */
		const int32 getHeight() const;	
		
		/**
		 * Get window's Win32 HWND
		 * @return Handle for this Window object, its HWND
		 */
		const HWND getHWND() const;

		/**
		 * Show window
		 */
		void show();

		/**
		 * Hide window
		 */
		void hide();
	
		/**
		 * Show mouse
		 */
		void showMouse();

		/**
		 * Hide mouse
		 */
		void hideMouse();

		/**
		 * Retrieve current mouse position
		 * @return A Point object holding the mouse's current position in screen coordinates
		 */ 
		const Point& getMousePosition() const;

		/**
		 * Convert from screen to relative window cordinates
		 * @param point A reference to a point object which is used both as src and dst of conversion
		 */
		void screenToWindow(Point &point);
		
		/**
		 * Convert from window to screen cordinates
		 * @param point A reference to a point object which is used both as src and dst of conversion
		 */
		void windowToScreen(Point &point);

		/**
		 * Resize window
		 */
		bool resize(int x, int y, int width, int height, bool keepPosition);

		/**
		 * Center window
		 */
		void center();

		/**
		 * Set or change window style
		 * @param windowStyle The new style to be applicated on this Window @see eWindowStyle
		 */
		void setStyle(eWindowStyle windowStyle);

		/**
		 * Retrieve current window style
		 * @return A constant representing any of the Window's predefined styles @see wWindowStyle
		 */ 
		const int32 getStyle() const;
		
		/**
		 * Invalidate the whole client area
		 */ 
		void invalidateRect();
		
		/**
		 * Explicitly validate clientarea
		 */ 
		void validateRect();

		/**
		 * Check if client area is updated or needs to be repainted
		 * @return true if the window needs to be repainted, false otherwise
		 */ 
		bool needsRepaint() const;

		/**
		 * Check if window is a valid window
		 * @return true if windows is valud, false otherwise
		 */ 
		bool isWindow() const;

		/**
		 * Dispath messages
		 * @remarks Must be called each frame as it polls messages from window's
		 */ 
		void dispatch();
		
		/**
		 * Get Window's Device Context
		 * @return Handle to the window's device context
		 */ 
		HDC	getDC();
		
		/**
		 * Release Window's device context
		 */ 
		void releaseDC();

	protected:
		
		/**
		 * Set default and initialize all members
		 */
		void init();

		/// convert window highlerlevel types to WS_ window styles
		int32 convertStyle() const;

		/// Create win32 window
		bool createWindow();

		/// Destroy win32 window
		bool destroyWindow();

		/// Static message router
		static LRESULT CALLBACK windowProcedure(HWND, UINT, WPARAM, LPARAM);

		/// Create Window class
		static void createWindowClass();
		
		/// Release Window class
		static void releaseWindowClass();

		MsgQueue*		mMsgQueue;		///< Queue to receive window messages
		int32			mWidth;			///< Window's client area width 
		int32			mHeight;		///< Window's client area height
		bool			mOpened;		///< True if window has been opened
		bool			mHasCaption;	///< True if window has a caption bar, else false
		bool			mVisible;		///< True if window is visible
		int32			mType;			///< Window style
		bool			mFocus;			///< Window has focus
		bool			mValidRect;		///< Windows client area needs to be repainted
		HWND			mHwnd;			///< Window's handle
		HDC				mHdc;			///< Window's device context handle
		std::string		mCaption;		///< The Window's caption
			
		/// static members
		static  char *		sWindowClassName;	///< Window class name
		static	WNDCLASSEX	sWindowClass;		///< Window class		
		static	uint32		sRefCounter;		///< Window object referece counter
	
	};
}

#endif
