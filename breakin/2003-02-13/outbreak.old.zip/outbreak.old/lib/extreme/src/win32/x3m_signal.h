#ifndef __EXTREME_SYS_SYNCOBJECT_INC__
#define __EXTREME_SYS_SYNCOBJECT_INC__

#include "..\x3m_typedef.h"
#include "..\x3m_copyprotect.h"

#include <windows.h>

namespace Extreme {

	/**
	 * @class	SignalObject
	 *			Win32 Synchronization waitable/signalled object interface
	 *			Must be subclassed by other synchronization objects such as Mutexes/Threads etc
	 * @author	Peter Nordlander
	 * @date	2001-10-15
	 */

	class SignalObject : public CopyProtected
	{
	public:
		
		/**
		 * Lock timeout constant
		 */
		enum 
		{
			WAIT_INFINITE = INFINITE,	///< Wait forever to obtain access to object
		};

		/**
		 * Constructor
		 */
		SignalObject();
		
		/**
		 * Destructor
		 */
		virtual ~SignalObject();

		/**
		 * Request and wait for access to object
		 * @param milliSecs Amount of milliseconds to wait before giving up attempt
		 * @return Boolean <true> if access was gained, <false> on failure/timeout
		 */
		virtual const bool wait(const int32 milliSecs = WAIT_INFINITE);
		
		/**
		 * Release SignalObject
		 */
		virtual void release();
		
		/**
		 * Check weither this object is valid
		 * @return true if the object is active, false otherwise
		 * @remarks On return of false, the object has to be activated through a 
		 * call to the specific object's create method.
		 */
		const bool isValid() const;

		/**
		 * Initialize objects default values
		 */
		virtual void init() = 0;

	protected:

		HANDLE	mHandle;	///< Synchronization object's handle
	};

}

#endif
