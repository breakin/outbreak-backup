#ifndef __EXTREME_SYS_MUTEX_INC__
#define __EXTREME_SYS_MUTEX_INC__

#include "..\x3m_typedef.h"
#include "x3m_signal.h"
#include <windows.h>
#include <string>

namespace Extreme {

	/**
	 * @class	Mutex
	 * @brief	Win32 Mutex synch object
	 * @author	Peter Nordlander
	 * @date	2001-10-15
	 */

	class Mutex : public SignalObject
	{
	public:
		
		/**
		 * Constructor
		 */
		Mutex(const std::string &name = "");

		/**
		 * Destructor
		 */
		virtual ~Mutex();

		/**
		 * Create Mutex
		 * @param name Optinal character string name for this Mutex
		 * @return Boolean <true> on success, <false> on failure
		 */
		const bool create(const std::string &name = "");		
		
		/**
		 * Lock mutex, gain exclusive ownership
		 * @param milliSecs Amount of milliseconds to wait before giving up
		 * @return true on gain of access, false on timeout
		 * @remarks Equal to SignalObject::wait
		 */
		const bool lock(const int32 milliSecs = SignalObject::WAIT_INFINITE);

		/**
		 * Unlock Mutex - give up exclusive ownership
		 */
		void unlock();
			
	protected:

		/**
		 * Set default value on data members
		 */
		void init();

		std::string	mName;	///< Mutex object name
	};
}

#endif

