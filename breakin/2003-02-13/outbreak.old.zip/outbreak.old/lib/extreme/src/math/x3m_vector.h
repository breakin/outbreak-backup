#ifndef __EXTREME_MATH_VECTOR_INC__
#define __EXTREME_MATH_VECTOR_INC__

#include "..\x3m_typedef.h"
#include "..\debug\x3m_assert.h"
#include <math.h>
#include <d3d8.h>

namespace Extreme {

	/**
	 * @class	Vector3
	 * @brief	3 component vector class
	 * @author	Peter Nordlander
	 * @date	2001-10-17
	 */

	class Vector3
	{
	public:

		/**
		 * Default constructor
		 */
		Vector3();
		
		/**
		 * Constructor
		 * param x X axis component of vectof
		 * param y Y axis component of vectof
		 * param x Z axis component of vectof
		 */
		explicit Vector3(const float32 x, const float32 y, const float32 z);
		
		/**
		 * Default constructor
		 * @param other The vector to intialze the new vector with
		 */
		Vector3(const Vector3 &other);

		/**
		 * Constructor
		 * @param init Initial vector starting point
		 * @param term Vector termination point		 
		 */
		Vector3(const Vector3 &init, const Vector3 &term);
	
		/**
		 * Operator overload for addition
		 * @param other The other vector, to perform addition with
		 * @return The result of this + other
		 */
		Vector3  operator + (const Vector3 &other) const;
		
		/**
		 * Operator overload for subtraction
		 * @param other The other vector, to perform subtraction with
		 * @return The result of this - other
		 */
		Vector3  operator - (const Vector3 &other) const;
		
		/**
		 * Operator overload for a vector crossproduct
		 * @param other The other vector, to perform crossproduct with
		 * @return The result of a crossproduct between this and @a other
		 */
		Vector3  operator % (const Vector3 &other) const;

		/**
		 * Operator overload for vector multiply with a scalar
		 * @param scale The factor to scale the vector with
		 * @return The result of this * scale
		 */
		Vector3  operator * (const float32 scale)  const;		
		
		/**
		 * Operator overload for vector dotproduct
		 * @param other The vector to perform dotproduct with
		 * @return The result of a dotproduct between this and other
		 */
		float32	 operator * (const Vector3 &other) const;

		/**
		 * Operator overload for adding another vector on this
		 * @param other The vector to add to this
		 */
		void operator += (const Vector3 &other);

		/**
		 * Operator overload for subtracting another vector on this
		 * @param other The vector to subtract from this
		 */
		void operator -= (const Vector3 &other);
		
		/**
		 * Operator overload for applying a crossproduct of another vector on this
		 * @param other The other vector
		 */
		void operator %= (const Vector3 &other);

		/**
		 * Operator overload for applying a scalar on this
		 * @param other The vector to perform scalar mul. with
		 */
		void operator *= (const float32 scalar);

		/**
		 * Vector addition of this and another vector object
		 * @param other The other operand of an addition
		 * @param result The resulting vector of this operation
		 * @remarks Operation (result = this + other)
		 */
		void add (const Vector3 &other, Vector3 & result) const;

		/**
		 * Vector subtraction of this and another vector object
		 * @param other The other operand of an addition
		 * @param result The resulting vector of this operation
		 * @remarks Operation (result = this - other)
		 */
		void sub (const Vector3 &other, Vector3 & result) const;

		/**
		 * Vector multiplication of this and a scalar value
		 * @param other The other operand of an multiplication
		 * @param result The resulting vector of this operation
		 * @remarks Operation (result = this * scalar)
		 */
		void mul (const float32 scalar, Vector3 & result) const;
		
		/**
		 * Vector dotproduct between this and another vector object
		 * @param other The other operand of a dotproduct
		 * @param result The resulting vector of this operation
		 * @remarks Operation (result = this * other)
		 */
		void dot (const Vector3 &other, float32 & result) const;

		/**
		 * Vector crossproduct between this and another vector object
		 * @param other The other operand of a vector crossproduct
		 * @param result The resulting vector of this operation
		 * @remarks Operation (result = this X other)
		 */
		void cross (const Vector3 & other, Vector3 & result) const;

		/**
		 * Operator[], use vector as an array of 3 floats
		 * @param index 0 - X, 1 - Y, 2 - Z
		 * @return A reference to the component corresponding to the given index
		 */
		float32& operator[] (const int32 index);
		
		/**
		 * Operator[], use vector as an array of 3 floats
		 * @param index 0 - X, 1 - Y, 2 - Z
		 * @return A reference to the component corresponding to the given index
		 */
		const float32& operator[] (const int32 i) const;

		/**
		 * Conversion to d3d vector
		 * @return A D3DVECTOR derived from this
		 */
		operator D3DVECTOR () { return *this; }

		/**
		 * Get vector magnitude
		 * @return The length of the vector
		 */
		const float32 getLength() const;

		/**
		 * Get vector magnitude - squared
		 * @return The length of the vector squared
		 */
		const float32 getLengthSquared() const;

		/**
		 * Get vector's reflection vector
		 * @param normal The normal of the plane to get the corresponding reflection to
		 * @return The reflection vector of this and @a normal
		 */
		const Vector3 getReflection(const Vector3 &normal) const;

		/**
		 * Get a the vector, normalized to a length of 1.0
		 * @return A Normalized vector with the same direction as <this>
		 */
		const Vector3 getNormalized() const;
		/**
		 * Normalize vector, scale components to a total magnitude of 1,0
		 */
		void normalize();
		
		/**
		 * Friend function
		 */
		friend Vector3 operator * (const float32 scalar, const Vector3 &);		
	
		/// vector data
		union {
		
			struct {
				
				float32	x; ///< X axis
				float32 y; ///< Y axis
				float32 z; ///< Z axis
			};
			struct {

				float32 r; ///< Red
				float32 g; ///< Green
				float32 b; ///< Blue
			};
		};
	};


//==================================================================================================================================
	
X3M_INLINE Vector3::Vector3() : x(0.0f), y(0.0f), z(0.0f) {}

//==================================================================================================================================

X3M_INLINE Vector3::Vector3(float32 px, float32 py, float32 pz) : x(px), y(py), z(pz) {}

//==================================================================================================================================

X3M_INLINE Vector3::Vector3(const Vector3 &other) : x(other.x), y(other.y), z(other.z) {}

//==================================================================================================================================

X3M_INLINE Vector3::Vector3(const Vector3 &init, const Vector3 &term) : x(term.x - init.x), y(term.y - init.y), z(term.z - init.z) {}

//==================================================================================================================================

X3M_INLINE float32& Vector3::operator[] (const int32 i) {

	return *((float32*)this + i);
}

//==================================================================================================================================

X3M_INLINE const float32& Vector3::operator[] (const int32 i) const {

	return *((float32*)this + i);
}

//==================================================================================================================================

X3M_INLINE Vector3 Vector3::operator + (const Vector3 &other) const {

	return Vector3 (other.x + x, other.y + y, other.z + z);
}

//==================================================================================================================================

X3M_INLINE Vector3 Vector3::operator - (const Vector3 &other) const {

	return Vector3 (x - other.x, y - other.y , z - other.z);
}

//==================================================================================================================================

X3M_INLINE Vector3 Vector3::operator % (const Vector3 &other) const {

	return Vector3 (y * other.z - z * other.y, z * other.x - x * other.z, x * other.y - y * other.x);
}

//==================================================================================================================================

X3M_INLINE Vector3 Vector3::operator * (const float32 scalar) const {

	return Vector3 (x * scalar, y * scalar, z * scalar);
}

//==================================================================================================================================

X3M_INLINE float32 Vector3::operator * (const Vector3 &other) const {

	return x * other.x + y * other.y + z * other.z;
}

//==================================================================================================================================

X3M_INLINE void Vector3::add(const Vector3 & other, Vector3 & result) const {
	result.x = x + other.x;
	result.y = y + other.y;
	result.z = z + other.z;
}

//==================================================================================================================================

X3M_INLINE void Vector3::sub(const Vector3 & other, Vector3 & result) const {
	result.x = x - other.x;
	result.y = y - other.y;
	result.z = z - other.z;
}

//==================================================================================================================================

X3M_INLINE void Vector3::mul(const float32 scalar, Vector3 & result) const {
	result.x = x * scalar;
	result.y = y * scalar;
	result.z = z * scalar;
}

//==================================================================================================================================

X3M_INLINE void Vector3::dot(const Vector3 & other, float32 & result) const {
	result = (this->x * other.x + this->y * other.y + this->z * other.z);
}
	
//==================================================================================================================================

X3M_INLINE void Vector3::cross(const Vector3 & other, Vector3 & result) const {
	result.x = (this->y * other.z - this->z * other.y);
	result.y = (this->z * other.x - this->x * other.z);
	result.z = (this->x * other.y - this->y * other.x);
}

//==================================================================================================================================

X3M_INLINE void Vector3::operator += (const Vector3 &other) {
	*this = *this + other;
}

//==================================================================================================================================

X3M_INLINE void Vector3::operator -= (const Vector3 &other) {
	*this = *this - other;
}

//==================================================================================================================================

X3M_INLINE void Vector3::operator %= (const Vector3 &other) {

	*this = *this % other;
}

//==================================================================================================================================

X3M_INLINE void Vector3::operator *= (const float32 scalar) {

	x *= scalar;
	y *= scalar;
	z *= scalar;
}

//==================================================================================================================================

X3M_INLINE const float32 Vector3::getLength() const {

	return sqrtf(getLengthSquared());
}

//==================================================================================================================================

X3M_INLINE const float32 Vector3::getLengthSquared() const {

	return (x * x + y * y + z * z);
}

//==================================================================================================================================

X3M_INLINE void Vector3::normalize() {
	
	float32 length = this->getLength();
	
	X3M_ASSERT (length != 0);

	x /= length;
	y /= length;
	z /= length;
}

//==================================================================================================================================

X3M_INLINE const Vector3 Vector3::getReflection(const Vector3 &normal) const {

	return ((-2 * (*this * normal)) * normal) + *this;
}

//==================================================================================================================================

X3M_INLINE Vector3 operator * (const float32 scalar, const Vector3 &other) {

	return other * scalar;
}

//==================================================================================================================================

X3M_INLINE const Vector3 Vector3::getNormalized() const {
	Vector3 n(this->x, this->y, this->z);
	n.normalize();
	return n;
}

//==================================================================================================================================


} // end namespace

#endif
