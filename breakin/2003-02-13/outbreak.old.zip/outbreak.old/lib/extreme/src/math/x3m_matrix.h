#ifndef __ETERNITY_MATRIX4X4_INC__
#define __ETERNITY_MATRIX4X4_INC__

#include "..\template\x3m_smartptr.h"
#include "..\x3m_typedef.h"
#include "x3m_vector.h"
#include <cstring>
#include <d3d8.h>
#include <d3dx8math.h>

namespace Extreme{

	/**
	 * @class	Matrix4x4
	 * @brief	Linear algebra matrix class of a 4x4 dimension
	 * @author	Peter Nordlander
	 * @date	2001-05-23
	 */
		
	class Matrix4x4
	{
	private:
		
		static Matrix4x4	sRetMatrix[8];	///< matrices used for returned data
		static Vector3		sRetVector;		///< vector used for referential return values
		static int			sRetCurrent;	///< currently "free" matrix to use as return value
		
		union 
		{
			struct 
			{
				float32 _11,_12,_13,_14;
				float32 _21,_22,_23,_24;
				float32 _31,_32,_33,_34;
				float32 _41,_42,_43,_44;
			};
					
			float32 mRows[4][4];
			float32 mData[16];
		};

	public:

		/**
		 * Constructor
		 */
		Matrix4x4();			
	
		/**
		 * Zero matrix data
		 */
		void zero();
		
		/**
		 * Make predefined matrix transformations
		 */
		void makeIdentity();
		void makeTranslation(const Vector3 &pos);
		void makeScale(float32 sx, float32 sy, float32 sz);
		void makeRotX(float32 ang);
		void makeRotY(float32 ang);
		void makeRotZ(float32 ang);
		void makeViewLookAt(const Vector3 &pos, const Vector3 &lookAt, float32 roll);
		void makeViewDirection(const Vector3 &pos, const Vector3 &direction, float32 roll);		
		void makeRotXYZ(float32 xang, float32 yang, float32 zang);
		void makeProjection(const float32 fov, const float32 xnear, float32 zfar); 
		void makeProjection(const float32 fov, const float32 znear, const float32 zfar, const aspectRatio);
		
		/**
		 * Assignment overload
		 * @param other Matrix to assign to this
		 * @return Reference to this
		 */
		Matrix4x4& operator = (const Matrix4x4 &other);
		
		/**
		 * Get matrix inverse
		 * @return The inverse of this matrixobject
		 */
		const Matrix4x4& operator - () const;
		
		/**
		 * Aritmethic overloads vector mul matrix
		 * @parama other Vector to me multiplied with this matrix
		 * @return The resultant vector
		 */
		const Vector3&  operator * (const Vector3  &other) const;
		
		/**
		 * Aritmethic overloads
		 * @param other Matrix to perform the operation with 
		 * @return Result matrix from operation
		 */
		const Matrix4x4& operator * (const Matrix4x4 &other) const;
		const Matrix4x4& operator - (const Matrix4x4 &other) const;
		const Matrix4x4& operator + (const Matrix4x4 &other) const;
		const Matrix4x4& operator / (const Matrix4x4 &other) const;
		
		/**
		 * Indexation operator
		 * @param indexRow Row to retrieve
		 * @return a pointer to the first column of row specified by @a indexRow
		 */
		const float32 * const operator [] (int indexRow) const;
		float32 * operator [] (int indexRow);

		/**
		 * Self modifying operators
		 * @param other Matrix to perform operation with
		 */
		void operator *= (const Matrix4x4 &other);
		void operator += (const Matrix4x4 &other);
		void operator -= (const Matrix4x4 &other);
		void operator /= (const Matrix4x4 &other);
		
		/**
		 * Conversion to D3DMATRIX
		 * @return D3DMATRIX, basically the same
		 */
		operator D3DMATRIX () { return *this; }
		operator D3DMATRIX * () { return (D3DMATRIX*)this; }
		operator const D3DMATRIX * () const { return (const D3DMATRIX*)this; }

		/**
		 * Get the transpose and inverse of matrix
		 * @return The inverse of this matrix
		 */
		const Matrix4x4& getTranspose() const;
		const Matrix4x4& getGaussInverse() const {};

		/**
		 * Get row vector[n]
		 * @param row The row vector to retrieve
		 * @return The vector specified by row @a row
		 */
		const Vector3& getRow(const int32 row) const;
		Vector3& getRow(const int32 row);
		
		// friend functions
		friend Vector3& operator*(const Vector3 &vector, const Matrix4x4 &matrix);

	private:

		/**
		 * Return index of current free matrix and sets index to next 
		 * @return Current free matrix to use as return/result of matrix operation
		 */
		const int32 getReturnIndex() const {
			
			int32 current = sRetCurrent;
			sRetCurrent = ((sRetCurrent + 1) % 8);
			return current;
		}
	};


// ======================================================================================================

X3M_INLINE Matrix4x4::Matrix4x4() {

	zero();
	makeIdentity();
}

// ======================================================================================================

X3M_INLINE void Matrix4x4::zero () {
	
	uint8 *dst = (uint8*)mData;
	
	_asm {
	
		pxor mm0,mm0
		mov edi, dst
		movq [edi   ], mm0
		movq [edi+ 8], mm0
		movq [edi+16], mm0
		movq [edi+24], mm0
		movq [edi+32], mm0
		movq [edi+40], mm0
		movq [edi+48], mm0
		movq [edi+56], mm0
		emms
	}
}

// ======================================================================================================

X3M_INLINE void Matrix4x4::makeIdentity() {

	_11 = _22 = _33 = _44 = 1.0;
}

//======================================================================================================

X3M_INLINE void Matrix4x4::makeScale(float32 sx, float32 sy, float32 sz) {

	_11 = sx;
	_22 = sy;
	_33 = sz;
}

//======================================================================================================

X3M_INLINE void Matrix4x4::makeTranslation(const Vector3 &pos) {
	
	_41 = pos.x;
	_42 = pos.y;
	_43 = pos.z;
}

//======================================================================================================

X3M_INLINE void Matrix4x4::makeRotX(float32 pitch) {

	_22 = cosf(pitch); 
	_32 = sinf(pitch);
	_23 = -sinf(pitch);
	_33 = cosf(pitch);
}

//======================================================================================================

X3M_INLINE void Matrix4x4::makeRotY(float32 yaw) {

	_11 = cosf(yaw);
	_31 = -sinf(yaw);
	_13 = sinf(yaw);
	_33 = cosf(yaw);
}

//======================================================================================================

X3M_INLINE void Matrix4x4::makeRotZ(float32 roll) {

	_11 = cosf(roll);
	_21 = -sinf(roll);
	_12 = sinf(roll);
	_22 = cosf(roll);
}

//======================================================================================================

X3M_INLINE void Matrix4x4::makeRotXYZ(float32 pitch, float32 yaw, float32 roll) {

	Matrix4x4 a;
	Matrix4x4 b;
	Matrix4x4 c;
	
	a.makeRotX(pitch);
	b.makeRotY(yaw);
	c.makeRotZ(roll);

	*this = a * b * c;
}

//======================================================================================================

X3M_INLINE void Matrix4x4::makeProjection(const float32 fov, const float32 znear, const float32 zfar, const aspectRatio) {
	D3DXMatrixPerspectiveFovLH((D3DXMATRIX*)this, fov, aspectRatio, znear, zfar);
}

//======================================================================================================


X3M_INLINE void Matrix4x4::makeProjection(const float32 fov, const float32 znear, const float32 zfar) {

	float32 focalLength = 1.0 / tanf(fov * 0.5);
	float32 Q = zfar / (zfar - znear);

	makeIdentity();

	_11 = -focalLength;
    _22 = focalLength;
	_33 = Q;
	_43 = 1.0f;
	_34 = -Q * znear;
}

//======================================================================================================

X3M_INLINE void Matrix4x4::makeViewLookAt(const Vector3 &pos, const Vector3 &target, float32 rollAng) {
	
	Matrix4x4 a,b;

	// genereate y vector by rotating 0,1 round the z axis by roll deg.
	makeIdentity();

	// y rotated round z axis (roll)
	Vector3 y(sinf(rollAng),cosf(rollAng),0);
	
	// calculate look at
	Vector3 z = (target - pos);
	
	// z normalized
	z.normalize();

	// create x vector by taking the cross produkt betw. y and z
	Vector3 x = (y % z);
	
	// normalize x vector
	x.normalize();

	// correct the y vector to get mor accurat result
	y = (x % z);

	// normalize y vector, just in case
	y.normalize();
	
	// create matrix, free transpose by just setting the row vectors
	_11 = x.x;
	_21 = x.y;
	_31 = x.z;

	_12 = y.x;
	_22 = y.y;
	_32 = y.z;
	
	_13 = z.x;
	_23 = z.y;
	_33 = z.z;

	// zero translation 
	_41 = _42 = _43 = 0;
	_44 = 1.0;

	// negate translation
	b._41 = -pos.x;
	b._42 = -pos.y;
	b._43 = -pos.z;
	b._44 = 1.0f;

	
	// mlutiply negated translation with camera rotation
	(*this) = b  * (*this);
}

//======================================================================================================

X3M_INLINE void Matrix4x4::makeViewDirection(const Vector3 &pos, const Vector3 &target, float32 rollAng) {
	
	Matrix4x4 a,b;

	// genereate y vector by rotating 0,1 round the z axis by roll deg.
	makeIdentity();

	// y rotated round z axis (roll)
	Vector3 y(sinf(rollAng),cosf(rollAng),0);
	
	// calculate direction vector
	Vector3 z = target;
	
	// z normalized
	z.normalize();

	// create x vector by taking the cross produkt betw. y and z
	Vector3 x = (y % z);
	
	// normalize x vector
	x.normalize();

	// correct the y vector to get mor accurat result
	y = (x % z);

	// normalize y vector, just in case
	y.normalize();
	
	// create matrix, free transpose by just setting the row vectors
	_11 = x.x;
	_21 = x.y;
	_31 = x.z;
	_12 = y.x;
	_22 = y.y;
	_32 = y.z;
	_13 = z.x;
	_23 = z.y;
	_33 = z.z;
	
	// zero translation 
	_41 = _42 = _43 = _44 = 0;

	// negate translation
	b._41 = -pos.x;
	b._42 = -pos.y;
	b._43 = -pos.z;
	b._44 = 1.0f;
	
	// mlutiply negated translation with camera rotation
	(*this) = b * (*this);
}

//======================================================================================================

X3M_INLINE const Matrix4x4& Matrix4x4::operator * (const Matrix4x4 &m) const {

	int32 returnIndex = getReturnIndex();

	// multiply all rows and cols.
	sRetMatrix[returnIndex]._11 = (_11 * m._11) + (_12 * m._21) + (_13 * m._31) + (_14 * m._41); 
	sRetMatrix[returnIndex]._12 = (_11 * m._12) + (_12 * m._22) + (_13 * m._32) + (_14 * m._42); 
	sRetMatrix[returnIndex]._13 = (_11 * m._13) + (_12 * m._23) + (_13 * m._33) + (_14 * m._43); 
	sRetMatrix[returnIndex]._14 = (_11 * m._14) + (_12 * m._24) + (_13 * m._34) + (_14 * m._44); 

	sRetMatrix[returnIndex]._21 = (_21 * m._11) + (_22 * m._21) + (_23 * m._31) + (_24 * m._41);
	sRetMatrix[returnIndex]._22 = (_21 * m._12) + (_22 * m._22) + (_23 * m._32) + (_24 * m._42); 
	sRetMatrix[returnIndex]._23 = (_21 * m._13) + (_22 * m._23) + (_23 * m._33) + (_24 * m._43); 
	sRetMatrix[returnIndex]._24 = (_21 * m._14) + (_22 * m._24) + (_23 * m._34) + (_24 * m._44);

	sRetMatrix[returnIndex]._31 = (_31 * m._11) + (_32 * m._21) + (_33 * m._31) + (_34 * m._41);
	sRetMatrix[returnIndex]._32 = (_31 * m._12) + (_32 * m._22) + (_33 * m._32) + (_34 * m._42); 
	sRetMatrix[returnIndex]._33 = (_31 * m._13) + (_32 * m._23) + (_33 * m._33) + (_34 * m._43); 
	sRetMatrix[returnIndex]._34 = (_31 * m._14) + (_32 * m._24) + (_33 * m._34) + (_34 * m._44);

	sRetMatrix[returnIndex]._41 = (_41 * m._11) + (_42 * m._21) + (_43 * m._31) + (_44 * m._41);
	sRetMatrix[returnIndex]._42 = (_41 * m._12) + (_42 * m._22) + (_43 * m._32) + (_44 * m._42); 
	sRetMatrix[returnIndex]._43 = (_41 * m._13) + (_42 * m._23) + (_43 * m._33) + (_44 * m._43); 
	sRetMatrix[returnIndex]._44 = (_41 * m._14) + (_42 * m._24) + (_43 * m._34) + (_44 * m._44);
	
	// return matrix and update retCnt
	return sRetMatrix[returnIndex];
}

//======================================================================================================

X3M_INLINE const Matrix4x4& Matrix4x4::operator + (const Matrix4x4 &m) const {
	
	int32 returnIndex = getReturnIndex();

	for (int c=0; c < 16; c++)
		sRetMatrix[returnIndex].mData[c]= mData[c] + m.mData[c]; 	
	
	return sRetMatrix[returnIndex];
}

//======================================================================================================

X3M_INLINE const Matrix4x4& Matrix4x4::operator - (const Matrix4x4 &m) const {

	int32 returnIndex = getReturnIndex();

	for (int c=0; c < 16; c++)
		sRetMatrix[returnIndex].mData[c]= mData[c] - m.mData[c]; 	
	
	return sRetMatrix[returnIndex];
}

// ======================================================================================================

X3M_INLINE const Matrix4x4& Matrix4x4::operator / (const Matrix4x4 &other) const {

	return sRetMatrix[getReturnIndex()];
}

//======================================================================================================

X3M_INLINE const Matrix4x4& Matrix4x4::operator - () const {

	return getTranspose();
}

//======================================================================================================

X3M_INLINE void Matrix4x4::operator *= (const Matrix4x4 &m) {

	*this = *this * m;
}

//======================================================================================================

X3M_INLINE void Matrix4x4::operator += (const Matrix4x4 &m) {

	*this = *this * m;
}

//======================================================================================================

X3M_INLINE void Matrix4x4::operator -= (const Matrix4x4 &m) {

	*this = *this * m;
}

//======================================================================================================

X3M_INLINE void Matrix4x4::operator /= (const Matrix4x4 &m) {

	*this = *this * m;
}

//======================================================================================================

X3M_INLINE const Matrix4x4& Matrix4x4::getTranspose() const {
	
	int32 index = getReturnIndex();
	int32 index2 = getReturnIndex();
	
	sRetMatrix[index].zero();
	sRetMatrix[index2].zero();

	// copy diagonal
	sRetMatrix[index]._11 = _11;
	sRetMatrix[index]._22 = _22;
	sRetMatrix[index]._33 = _33;

	// mirror matrix
	sRetMatrix[index]._13 = _31;
	sRetMatrix[index]._31 = _13;
	sRetMatrix[index]._12 = _21;
	sRetMatrix[index]._21 = _12;
	sRetMatrix[index]._32 = _23;
	sRetMatrix[index]._23 = _32;

	// inverse translation
	sRetMatrix[index2]._41 = -_41;
	sRetMatrix[index2]._42 = -_42;
	sRetMatrix[index2]._43 = -_43;
	sRetMatrix[index2]._44 = 1;
	
	return sRetMatrix[index2] * sRetMatrix[index];
}

//======================================================================================================

X3M_INLINE const Vector3&  Matrix4x4::operator * (const Vector3  &vector) const {

	sRetVector.x = vector.x * _11 + vector.y * _21 + vector.z * _31 + _41;
	sRetVector.y = vector.x * _12 + vector.y * _22 + vector.z * _32 + _42;
	sRetVector.z = vector.x * _13 + vector.y * _23 + vector.z * _33 + _43;

	return sRetVector;
}

//======================================================================================================

X3M_INLINE Vector3& operator * (const Vector3 &vector, const Matrix4x4 &matrix) {

	static Vector3 retVector;
//	return Vector3(
	retVector.x = vector.x * matrix._11 + vector.y * matrix._21 + vector.z * matrix._31 + matrix._41;
	retVector.y = vector.x * matrix._12 + vector.y * matrix._22 + vector.z * matrix._32 + matrix._42;
	retVector.z = vector.x * matrix._13 + vector.y * matrix._23 + vector.z * matrix._33 + matrix._43;
//		);
	return retVector;
}

//======================================================================================================

X3M_INLINE const float32 * const Matrix4x4::operator [] (int indexRow) const {

	return mData + indexRow * 4;
}


//======================================================================================================

X3M_INLINE float32 * Matrix4x4::operator [] (int indexRow) {

	return mData + indexRow * 4;
}

//======================================================================================================

X3M_INLINE const Vector3& Matrix4x4::getRow(const int32 n) const {

	return (Vector3&)(mData[n * 4]);	
}

//======================================================================================================

X3M_INLINE Vector3& Matrix4x4::getRow(const int32 n) {

	return (Vector3&)(mData[n * 4]);	
}

//======================================================================================================

X3M_INLINE Matrix4x4& Matrix4x4::operator = (const Matrix4x4 &other) {

	void *dst = (void*)mData;
	void *src = (void*)other.mData;

	_asm {
		
		mov		esi, src
		mov		edi, dst
		movq	mm0,[esi     ]
		movq	mm1,[esi +  8]
		movq	mm2,[esi + 16]
		movq	mm3,[esi + 24]
		movq	mm4,[esi + 32]
		movq	mm5,[esi + 40]
		movq	mm6,[esi + 48]		
		movq	mm7,[esi + 56]
		movq	[edi	 ], mm0
		movq	[edi +  8], mm1
		movq	[edi + 16], mm2 
		movq	[edi + 24], mm3
		movq	[edi + 32], mm4
		movq	[edi + 40], mm5
		movq	[edi + 48],	mm6	
		movq	[edi + 56], mm7	
		emms
	}
	
	return *this;
}

//======================================================================================================

} // end namsspace

#endif
