#ifndef __EXTREME_MATH_QUATERNION_INC__
#define __EXTREME_MATH_QUATERNION_INC__

#include "..\x3m_typedef.h"
#include "x3m_vector.h"

namespace Extreme {
	
	/**
	 * @class	Quaternion	
	 *			Repr. an quaternion, In our case a more convenient way
	 *			of storing a rotation around an arbitary axis
	 * @author	Peter Nordlander
	 * @date	2001-10-17
	 */
	
	class Quaternion 
	{
	public:

		/// create from axis and angle
		Quaternion(const Vector3 &axis, const float32 angle);

		/// constructor with component args
		Quaternion(float32 x, float32 y, float32 z, float32 w);
		
		/// deafult constructor
		Quaternion();
				
		/// operator overloads
		const Quaternion operator + (const Quaternion & other) const;
		const Quaternion operator - (const Quaternion & other) const;
		const Quaternion operator * (const Quaternion & other) const;
		const Quaternion operator * (const float32 s) const;
		const Quaternion operator / (const float32 s) const;

		/// dot product/treating quat as a 4d vector
		const float32 dotProduct(const Quaternion &other) const;

		/// operator overloads, apply on this
		Quaternion & operator += (const Quaternion &other);
		Quaternion & operator -= (const Quaternion &other);
		Quaternion & operator *= (const Quaternion &other);
		Quaternion & operator *= (const float32 s);

		/// get angle/axix of rotation
		const float32 getAngleOfRotation() const;
		const Vector3 getAxisOfRotation() const;
	
		// get N(q) / N(q)^2
		const float32 getNorm() const;
		const float32 getNormSquared() const;

		// get conjugate
		const Quaternion operator ~ () const;

		/// negate
		const Quaternion operator - () const;

		/// get invertse
		const Quaternion getInverse() const;

		/// get invertse, assume quat in normalized to a length of 1.0
		const Quaternion getInverseUnit() const;

		/// interpolation methods with q2 with respect of (t)
		const Quaternion lerp  (const Quaternion &other, const float32 t) const;	///< Linear interpolation
		const Quaternion slerp (const Quaternion &other, const float32 t) const;	///< Spherical linear interpolation
		const Quaternion squad (const Quaternion &other, const float32 t) const;	///< Sphercial quadratic interpolation

		/// friend methods
		friend const Quaternion operator * (const float32 s, const Quaternion &q);
		
		union {
			
			/// 4D float notation
			struct {

				float32 x;		///< Quaternion x component
				float32 y;		///< Quaternion y component
				float32 z;		///< Quaternion z component
				float32 w;		///< Quaternion w component
			};

			/// vect/float notation
			struct {
				
				Vector3	mV;	///< Quaternion vector axis
				float32 mW;	///< Quaterntion w component
			};

			/// 4D float notation 
			struct {

				float32 i;	
				float32 j;
				float32	k;
				float32 l;
			};		
		};
	};

//==============================================================================

X3M_INLINE Quaternion::Quaternion(float32 x, float32 y, float32 z, float32 w) 
: mV(x,y,z), mW(w) {}

//==============================================================================

X3M_INLINE Quaternion::Quaternion() 
: mV(0.0f,0.0f,0.0f), mW(0.0f) {}

//==============================================================================

X3M_INLINE Quaternion::Quaternion(const Vector3 &axis, const float32 angle) {

	float32 angle2 = angle/2;
	mW = cosf(angle2);
	mV = axis * sinf(angle2);
}

//==============================================================================

X3M_INLINE const float32 Quaternion::dotProduct(const Quaternion &other) const {

	return (i * other.i + j * other.j + k * other.k + l * other.l);
}

//==============================================================================

X3M_INLINE const Quaternion Quaternion::operator + (const Quaternion & other) const {

	return Quaternion(i + other.i, j + other.j, k + other.k, l + other.l);
}

//==============================================================================

X3M_INLINE const Quaternion Quaternion::operator - (const Quaternion & other) const {

	return Quaternion(i - other.i, j - other.j, k - other.k, l - other.l);
}

//==============================================================================

X3M_INLINE const Quaternion Quaternion::operator * (const Quaternion & other) const {
	
	Vector3 vect = (mV % other.mV) + (mW * other.mV) + (other.mW * mV);
	return Quaternion(vect.x, vect.y, vect.z, mW * other.mW);
}

//==============================================================================

X3M_INLINE const Quaternion Quaternion::operator * (const float32 s) const {

	return Quaternion (i * s, j * s, k * s, mW * s);
}

//==============================================================================

X3M_INLINE const Quaternion Quaternion::operator / (const float32 s) const {

	float32 rpr = 1.0f / s;
	return (*this).operator * (rpr);
}

//==============================================================================
// friend method
X3M_INLINE  const Quaternion operator * (const float32 s, const Quaternion &q) {

	return q.operator * (s);
}

//==============================================================================

X3M_INLINE const Quaternion Quaternion:: operator ~ () const {

	return Quaternion (-i, -j, -k, mW);
}


//==============================================================================

X3M_INLINE const Quaternion Quaternion::operator - () const {

	return Quaternion(-i, -j, -k, -mW);
}

//==============================================================================

X3M_INLINE Quaternion & Quaternion::operator += (const Quaternion &other) {

	*this = *this + other;
	return *this;
}

//==============================================================================

X3M_INLINE Quaternion & Quaternion::operator -= (const Quaternion &other) {

	*this = *this - other;
	return *this;
}

//==============================================================================

X3M_INLINE Quaternion & Quaternion::operator *= (const Quaternion &other) {

	*this = *this * other;
	return *this;
}

//==============================================================================

X3M_INLINE Quaternion & Quaternion::operator *= (const float32 s) {

	*this = *this * s;
	return *this;
}

//==============================================================================

X3M_INLINE const float32 Quaternion::getNormSquared() const {

	return mV.getLengthSquared() + mW * mW;
}

//==============================================================================

X3M_INLINE const float32 Quaternion::getNorm() const {

	return sqrtf(getNormSquared());
}

//==============================================================================

X3M_INLINE const Quaternion Quaternion::getInverse() const {

	// divide (this) conjugate by its Norm
	return ~(*this) / getNorm();
}

//==============================================================================

X3M_INLINE const Quaternion Quaternion::getInverseUnit() const {

	// divide (this) conjugate by its Norm
	return ~(*this);
}

//==============================================================================

X3M_INLINE const Quaternion Quaternion::lerp(const Quaternion &other, const float32 t) const {

	return (*this * (1.0f - t)) + (other * t);
}

//==============================================================================

X3M_INLINE const Quaternion Quaternion::slerp(const Quaternion &other, const float32 t) const {

	float32 angle = acosf(other.dotProduct(other));
	return	((sinf((1.0 - t) * angle) / sinf(angle)) * (*this)) +
			((sinf(t * angle) / sinf(angle)) * other);
}

//==============================================================================

X3M_INLINE const float32 Quaternion::getAngleOfRotation() const {

	return acos(mW) * 2;
}

//==============================================================================

X3M_INLINE const Vector3 Quaternion::getAxisOfRotation() const {

	float recip = 1.0f / sinf(getAngleOfRotation());
	return mV * recip;
}

//==============================================================================

}

#endif
