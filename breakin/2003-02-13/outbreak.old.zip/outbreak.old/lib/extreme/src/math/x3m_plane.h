#ifndef __EXTREME_MATH_PLANE_INC__
#define __EXTREME_MATH_PLANE_INC__

#include "x3m_typedef.h"
#include "x3m_vector.h"
#include <math.h>

namespace Extreme {

	/**
	 * @class	Plane
	 * @brief	Repr. an infinite plane in 3d space
	 * @author	Peter Nordlander
	 * @date	2001-10-17
	 */

	class Plane
	{
	public:

		/**
		 * Default constructor
		 */
		Plane();

		/**
		 * Constructor
		 * @param vector Plane's normal
		 * @param distance Nearest distance to origo from plane
		 */
		Plane(const Vector3 &vector, const float32 distance);

		/**
		 * Constructor
		 * @param point1 A point on the plane
		 * @param point2 A point on the plane
		 * @param point3 A point on the plane
		 */
		Plane(const Vector3 &point1, const Vector3 &point2, const Vector3 &point3);

		/**
		 * Get plane's A component
		 * @return The X component of the planes normal
		 */
		const float32 getA() const;

		/**
		 * Get plane's B component
		 * @return The Y component of the planes normal
		 */
		const float32 getB() const;
		
		/**
		 * Get plane's C component
		 * @return The Z component of the planes normal
		 */
		const float32 getC() const;
		
		/**
		 * Get plane's D component
		 * @return The plane's nearest distance to origo
		 */
		const float32 getD() const;

		/**
		 * Set plane's A components explicitly
		 * @param A the plane's new A component
		 */
		void setA(const float32 A);

		/**
		 * Set plane's B components explicitly
		 * @param B the plane's new B component
		 */
		void setB(const float32 B);

		/**
		 * Set plane's C components explicitly
		 * @param C the plane's new C component
		 */
		void setC(const float32 C);

		/**
		 * Set plane's D components explicitly
		 * @param D the plane's new D component
		 */
		void setD(const float32 D);

		/**
		 * Get plane's normal vector
		 * @return The plane's normal
		 */
		const Vector3& getNormal() const;

		/**
		 * Calculate equation (Ax + By + Cz - D = 0) from 3 points
		 * @param point1 A point on the plane
		 * @param point2 A point on the plane
		 * @param point3 A point on the plane
		 */
		void calculate(const Vector3 &point1, const Vector3 &point2, const Vector3 &point3);

		/**
		 * Get the factor when a ray intersects with this plane 
		 * @param init The ray initial point
		 * @param dir The ray direction
		 * @return -1 = no collide, > 0 time at collition (t)
		 */
		const float32 getRayIntersection(const Vector3 &init, const Vector3 &dir) const;

		/**
		 * Get the nearest distance from a point to this plane
		 * @param p The point to test
		 * @return 0 = on plane, < 0 = back, > 0 = in front
		 */
		const float32 getPointDistance(const Vector3 &p) const;

	private:

		Vector3	mNormal;		///< Planes normal
		float32	mDistance;		///< Distance on normal from ORIGO
	};

//========================================================================================================================

X3M_INLINE Plane::Plane() : mNormal(0.0f, 0.0f, 0.0f), mDistance(0.0f) {}

//========================================================================================================================

X3M_INLINE Plane::Plane(const Vector3 &normal, const float32 distance) : mNormal(normal), mDistance(distance) {}

//========================================================================================================================

X3M_INLINE Plane::Plane(const Vector3 &p1, const Vector3 &p2, const Vector3 &p3) {

	/// send parameter data directly to calculate
	calculate(p1,p2,p3);
}

//========================================================================================================================

X3M_INLINE void Plane::calculate(const Vector3 &p1, const Vector3 &p2, const Vector3 &p3) {

	Vector3 base1(p1,p2);
	Vector3 base2(p1,p3);

	// calculate normal vector
	mNormal = base1 % base2;
	mNormal.normalize();

	/// calculate plane distance by inserting a point into p.eq
	mDistance = mNormal * p1;
}

//========================================================================================================================

X3M_INLINE void Plane::setA(const float32 a) {
	mNormal.x = a;
}

//========================================================================================================================

X3M_INLINE void Plane::setB(const float32 b) {
	mNormal.y = b;
}

//========================================================================================================================

X3M_INLINE void Plane::setC(const float32 c) {
	mNormal.z = c;
}

//========================================================================================================================

X3M_INLINE void Plane::setD(const float32 d) {
	mDistance  = d;
}

//========================================================================================================================

X3M_INLINE const float32 Plane::getA() const {
	return mNormal.x;
}

//========================================================================================================================

X3M_INLINE const float32 Plane::getB() const {
	return mNormal.y;
}

//========================================================================================================================

X3M_INLINE const float32 Plane::getC() const {
	return mNormal.z;
}

//========================================================================================================================

X3M_INLINE const float32 Plane::getD() const {
	return mDistance;
}

//========================================================================================================================

X3M_INLINE const Vector3& Plane::getNormal() const {
	return mNormal;
}

//========================================================================================================================

X3M_INLINE const float32 Plane::getRayIntersection(const Vector3 &init, const Vector3 &dir) const {

	/// calculate t, time of intersection along distance (dir)
	return -((mNormal * init) - mDistance) / (dir * mNormal);
}

//========================================================================================================================

X3M_INLINE const float32 Plane::getPointDistance(const Vector3 &p) const {

	// insert point into plane equation
	return (mNormal * p) - mDistance;
}

}

#endif
