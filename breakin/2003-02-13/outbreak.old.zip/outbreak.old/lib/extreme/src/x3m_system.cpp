//==========================================================================================
// Include files
//==========================================================================================
#include "x3m_system.h"
#include "resource\x3m_modelmanager.h"

//==========================================================================================
// Namespace usage
//==========================================================================================

using namespace Extreme;

//==========================================================================================
// Method definitions
//==========================================================================================

System * TSingleton<System>::sSingletonObject = NULL;

//==========================================================================================

System::System() {

	X3M_LOG ("System", "System startup...");
	X3M_LOG ("System", "Starting subsystems...");
	mTextureManager = new TextureManager;
	mModelManager = new ModelManager;
	mMaterialManager = new MaterialManager;
	mRenderSystem = new RenderSystem;
	mSoundSystem = new SoundSystem;
	X3M_LOG ("System", "SubSystems started...");
}

//==========================================================================================

System::~System() {

	X3M_LOG ("System", "System shutdown...");
	X3M_LOG ("System", "Shutting down SubSystems...");
}

//==========================================================================================

