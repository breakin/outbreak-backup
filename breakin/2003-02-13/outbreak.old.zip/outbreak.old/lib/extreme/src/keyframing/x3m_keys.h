#ifndef __ETERNITY_KEYFRAMING_KEYS_INC__
#define __ETERNITY_KEYFRAMING_KEYS_INC__

#include "..\x3m_typedef.h"
#include "..\math\x3m_vector.h"
#include "..\template\x3m_key.h"
#include "..\math\x3m_quaternion.h"

namespace Extreme {

	typedef TKey<float32>		KeyFloat;	///< Key with float data
	typedef TKey<Vector3>		KeyVector;	///< Key with vector3d data
	typedef TKey<Quaternion>	KeyQuat;	///< Key with quaternion data
}

#endif