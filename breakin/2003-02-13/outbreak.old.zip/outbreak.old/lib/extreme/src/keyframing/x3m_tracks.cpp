//================================================================================
// Include files
//================================================================================

#include "x3m_tracks.h"

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Methods implementation
//================================================================================

TrackFloat::TrackFloat(const TrackFloat &other) {

	*this = other;
}

//================================================================================

TrackFloat& TrackFloat::operator = (const TrackFloat &other) {
	
	mKeyCount = other.mKeyCount;
	mFrameCount = other.mFrameCount;
	mTrackMode = other.mTrackMode;

	/// resize and allocate
	resize(mKeyCount);

	/// copy keys
	memcpy (mKeys, other.mKeys, mKeyCount * sizeof (KeyFloat));
	
	return *this;
}

//================================================================================

TrackVector::TrackVector(const TrackVector &other) {

	*this = other;
}

//================================================================================

TrackVector& TrackVector::operator = (const TrackVector &other) {
	
	mKeyCount = other.mKeyCount;
	mFrameCount = other.mFrameCount;
	mTrackMode = other.mTrackMode;

	/// resize and allocate
	resize(mKeyCount);

	/// copy keys
	memcpy (mKeys, other.mKeys, mKeyCount * sizeof (KeyVector));
	
	return *this;
}

//================================================================================

TrackQuat::TrackQuat(const TrackQuat &other) {

	*this = other;
}

//================================================================================

TrackQuat& TrackQuat::operator = (const TrackQuat &other) {
	
	mKeyCount = other.mKeyCount;
	mFrameCount = other.mFrameCount;
	mTrackMode = other.mTrackMode;

	/// resize and allocate
	resize(mKeyCount);

	/// copy keys
	memcpy (mKeys, other.mKeys, mKeyCount * sizeof (KeyQuat));
	
	return *this;
}

//================================================================================


void TrackFloat::resize(int n) {

	release();

	mKeys = new KeyFloat[n];
	mKeyCount = n;
}

//===================================================================================

void TrackFloat::release() {

	if (mKeys != NULL) {

		mKeyCount = 0;
		delete[] mKeys;
		mKeys = NULL;
	}
}

//===================================================================================

void TrackVector::resize(int n) {

	release();

	mKeys = new KeyVector[n];
	mKeyCount = n;
}

//===================================================================================

void TrackVector::release() {

	if (mKeys != NULL) {

		delete[] mKeys;
		mKeyCount = 0;
		mKeys = NULL;
	}	
}

//===================================================================================

void TrackQuat::resize(int n) {

	release();

	mKeys = new KeyQuat[n];
	mKeyCount = n;
}

//===================================================================================

void TrackQuat::release() {

	if (mKeys != NULL) {

		delete[] mKeys;
		mKeyCount = 0;
		mKeys = NULL;
	}
}

//===================================================================================

KeyFloat* TrackFloat::getKeys() {

	return mKeys;
}

//===================================================================================

KeyVector* TrackVector::getKeys() {

	return mKeys;
}

//===================================================================================

KeyQuat* TrackQuat::getKeys() {

	return mKeys;
}

//===================================================================================
// HERMIT SPLINE (TCB) INTERPOLATION CODE 
//===================================================================================

__forceinline float Ease( float t, float a, float b) {
	float32 k;
	float32 s = a+b;

	if (s == 0.0f) return t;
	if (s > 1.0f) {
		a = a/s;
		b = b/s;
	}
	k = 1.0f/(2.0f-a-b);
	if (t < a) return ((k/a)*t*t);
	else	{
		if (t < 1.0f-b)	{
			return (k*(2.0f * t - a));
		}	else {
			t = 1.0f -t;
			return (1.0f-(k/b)*t*t);
		}
	}
}

//===================================================================================

Vector3 TrackVector::getKey(float32 frameIndex) {

	int p1Index;	/// index of first point
	int p2Index;	/// index of second point

	// check if higher that last frame or track only has 1 frame
	// return last (locked) in that case
	if (frameIndex >= mKeys[mKeyCount-1].frameNumber)
		return mKeys[mKeyCount-1].data;

	// special case 2, only 2 keys in track
	if (mKeyCount == 2) {
		
		p1Index = 0;
		p2Index = 1;
	}
	else {

		/// find first frame
		for (int n=0; n < (int)mKeyCount; n++) {
			
			if (mKeys[n].frameNumber >= frameIndex) {
				
				// if exact position found, return data
				if (mKeys[n].frameNumber == frameIndex)
					return mKeys[n].data;

				// set from index
				p1Index = n-1;
				p2Index = n;
				break;
			}
		}
	}
	
	// fromIndex, and toIndex contains data to be interpolated
	float32 total = mKeys[p2Index].frameNumber - mKeys[p1Index].frameNumber;
	float32 t  = (frameIndex - mKeys[p1Index].frameNumber) / total;

	t = Ease(t,mKeys[p1Index].easeFrom,mKeys[p2Index].easeTo);
	
	// precalc. t^2 , t^3 and other known scalar values
	float32 t2	 = t * t;
	float32 t3	 = t2 * t;
	float32 t2_3 = 3 * t2;
	float32 t3_2 = 2 * t3;
	
	// get points
	Vector3 p1 = mKeys[p1Index].data;
	Vector3 p2 = mKeys[p2Index].data;

	// fet incoming and outgoing tangents
	Vector3 r1 = mKeys[p1Index].tangentIn;
	Vector3 r2 = mKeys[p1Index].tangentOut;

	
	return ((p1*(t3_2 - t2_3 + 1)) + (r1*(t3 - 2*t2 + t)) + 
			(p2*(-t3_2 + t2_3)) + (r2*(t3 - t2)));
}

//===================================================================================

float32 TrackFloat::getKey(float32 frameIndex) {

	int p1Index;	/// index of first point
	int p2Index;	/// index of second point
	int t1Index;	/// index of p1 - 1 
	int t2Index;	/// index of p2 + 1 

	// check if higher that last frame or track only has 1 frame
	// return last (locked) in that case
	if (frameIndex >= mKeys[mKeyCount-1].frameNumber) {

		// check for verymuch higher (2 * larger thatn frameMax ti)

		// check trackmode single
		if (mTrackMode == Track::TRACK_SINGLE)
			return mKeys[mKeyCount-1].data;
		
		// handle ROLL and REPEAT case
		if (mTrackMode == Track::TRACK_ROLL)
			frameIndex = mKeys[mKeyCount - 1].frameNumber - (frameIndex - mKeys[mKeyCount-1].frameNumber);
		else {
			// (mTrackMode == Track::TRACK_REPEAT)
			frameIndex = (frameIndex - mKeys[mKeyCount-1].frameNumber);
		}
	}

	// special case 2, only 2 keys in track
	if (mKeyCount == 2) {
		
		t1Index = 0;
		t2Index = 1;
	}
	else {

		/// find first frame
		for (int n=0; n < (int)mKeyCount; n++) {

			if (mKeys[n].frameNumber >= frameIndex) {

				// if exact position found, return data
				if (mKeys[n].frameNumber == frameIndex)
					return mKeys[n].data;
				
				// set from index
				p1Index = n-1;
				p2Index = n;
				break;
			}
		}
	}
	
	// fromIndex, and toIndex contains data to be interpolated
	float32 total = mKeys[p2Index].frameNumber - mKeys[p1Index].frameNumber;
	float32 t  = (frameIndex - mKeys[p1Index].frameNumber) / total;

	t = Ease(t,mKeys[p1Index].easeFrom,mKeys[p2Index].easeTo);
	
	// precalc. t^2 , t^3 and other known scalar values
	float32 t2	 = t * t;
	float32 t3	 = t2 * t;
	float32 t2_3 = 3.0f * t2;
	float32 t3_2 = 2.0f * t3;
	
	// get points
	float32 p1 = mKeys[p1Index].data;
	float32 p2 = mKeys[p2Index].data;

	// fet incoming and outgoing tangents
	float32 r1 = mKeys[p1Index].tangentIn;
	float32 r2 = mKeys[p1Index].tangentOut;

	return (p1*(t3_2 - t2_3 + 1.0f) + r1*(t3 - 2*t2 + t) + p2*(-t3_2 + t2_3) + r2*(t3 - t2));
}

//===================================================================================

void TrackFloat::calculateTangents() {

	float32		g1,g2,g3;
	float32		p1,p2;
	float32		T,C,B;
	int			t1Index, t2Index;
	int			p1Index, p2Index;

	// handle if only 1 key in track
	if (mKeyCount == 1)
		return;

	for (uint32 n=0; n < mKeyCount; n++) {

		p1Index = n;
		p2Index = n + 1;
		t1Index = p1Index - 1;
		t2Index = p2Index + 1;

		if (p1Index < 0)
			p2Index = 0;

		if (p2Index > int(mKeyCount - 1)) 
			p2Index = (mKeyCount - 1);

		if (t1Index < 0)
			t1Index = 0;

		if (t2Index > int(mKeyCount - 1)) 
			t2Index = int(mKeyCount - 1);
			
		// get T, C and B parameters
		T = mKeys[n].tension;
		C = mKeys[n].continuity;
		B = mKeys[n].bias;

		p1 = mKeys[p1Index].data;
		p2 = mKeys[p2Index].data;

		// calc inc. tangent
		g1 = (p1 - mKeys[t1Index].data) * (1.0f + B);
		g2 = (p2 - p1) * (1.0f - B);
		g3 = (p2 - p1);

		mKeys[p1Index].tangentIn = (g1 + g3 * (0.5f + 0.5f * C)) * (1.0f - T);

		// calc out. tangent
		g1 = (p2 - p1) * (1.0f + B);
		g2 = (mKeys[t2Index].data - p2) * (1.0f - B);
		g3 = (p2 - p1);

		mKeys[p1Index].tangentOut = (g1 + g3 * (0.5f - 0.5f * C)) * (1.0f - T);
	}
}

//===================================================================================

void TrackVector::calculateTangents() {

	Vector3	g1,g2,g3;
	Vector3	p1,p2;
	float32		T,C,B;
	int			t1Index, t2Index;
	int			p1Index, p2Index;

	// handle if only 1 key in track
	if (mKeyCount == 1)
		return;

	for (uint32 n=0; n < mKeyCount; n++) {

		p1Index = n;
		p2Index = n + 1;
		t1Index = p1Index - 1;
		t2Index = p2Index + 1;

		if (p1Index < 0)
			p2Index = 0;

		if (p2Index > int(mKeyCount - 1)) 
			p2Index = (mKeyCount - 1);
		
		if (t1Index < 0)
			t1Index = 0;

		if (t2Index > int(mKeyCount - 1)) 
			t2Index = (mKeyCount - 1);
			
		// get T, C and B parameters
		T = mKeys[n].tension;
		C = mKeys[n].continuity;
		B = mKeys[n].bias;

		p1 = mKeys[p1Index].data;
		p2 = mKeys[p2Index].data;

		// calc inc. tangent
		g1 = (p1 - mKeys[t1Index].data) * (1.0f + B);
		g2 = (p2 - p1) * (1.0f - B);
		g3 = (p2 - p1);

		mKeys[p1Index].tangentIn = (g1 + (g3 * (0.5f + 0.5f * C))) * (1.0f - T);

		// calc out. tangent
		g1 = (p2 - p1) * (1.0f + B);
		g2 = (mKeys[t2Index].data - p2) * (1.0f - B);
		g3 = (p2 - p1);

		mKeys[p1Index].tangentOut = (g1 + (g3 * (0.5f - 0.5f * C))) * (1.0f - T);
	}
}

//===================================================================================

Quaternion TrackQuat::getKey(float32 frameIndex) {

	int p1Index;	/// index of first point
	int p2Index;	/// index of second point

	// check if higher that last frame or track only has 1 frame
	// return last (locked) in that case
	if (frameIndex >= mKeys[mKeyCount-1].frameNumber)
		return mKeys[mKeyCount-1].data;

	// special case 2, only 2 keys in track
	if (mKeyCount == 2) {
		
		p1Index = 0;
		p2Index = 1;
	}
	else {

		/// find first frame
		for (int n=0; n < (int)mKeyCount; n++) {
			
			if (mKeys[n].frameNumber >= frameIndex) {
				
				// if exact position found, return data
				if (mKeys[n].frameNumber == frameIndex)
					return mKeys[n].data;

				// set from index
				p1Index = n-1;
				p2Index = n;
				break;
			}
		}
	}
	
	// fromIndex, and toIndex contains data to be interpolated
	float32 total = mKeys[p2Index].frameNumber - mKeys[p1Index].frameNumber;
	float32 t  = (frameIndex - mKeys[p1Index].frameNumber) / total;

	t = Ease(t,mKeys[p1Index].easeFrom,mKeys[p2Index].easeTo);
	
	// precalc. t^2 , t^3 and other known scalar values
	float32 t2	 = t * t;
	float32 t3	 = t2 * t;
	float32 t2_3 = 3 * t2;
	float32 t3_2 = 2 * t3;
	
	// get points
	Quaternion p1 = mKeys[p1Index].data;
	Quaternion p2 = mKeys[p2Index].data;

	// fet incoming and outgoing tangents
/*	Quaternion r1 = mKeys[p1Index].tangentIn;
	Quaternion r2 = mKeys[p1Index].tangentOut;

	return ((p1*(t3_2 - t2_3 + 1)) + (r1*(t3 - 2*t2 + t)) + 
			(p2*(-t3_2 + t2_3)) + (r2*(t3 - t2))); */

	return Quaternion();
}

//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
