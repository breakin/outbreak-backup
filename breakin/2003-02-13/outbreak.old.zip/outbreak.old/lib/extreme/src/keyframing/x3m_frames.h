#ifndef __ETERNITY_KEYFRAMING_FRAMES_INC__
#define __ETERNITY_KEYFRAMING_FRAMES_INC__

#include "..\x3m_typedef.h"

namespace Extreme {

	class Animation
	{
	public:

		Animation(uint32 start = 0, uint32 end = 0, float32 time = 0);
		
		void setStartFrame(uint32 start);
		const uint32 getStartFrame() const;

		void setEndFrame(uint32 start);
		const uint32 getEndFrame() const;

		void setTime(float32 time);
		const float32 getTime() const;

		uint32 getFrame(float32 t);
		
	private:

		uint32	mStart;		///< Frame start
		uint32	mEnd;		///< Frame end	
		float32 mTime;		///< Animation time
	};
}


#endif