#ifndef __ETERNITY_KEYFRAMING_TRACKS_INC__
#define __ETERNITY_KEYFRAMING_TRACKS_INC__

#include "x3m_keys.h"
//#include "..\math\e3d_quat.h"

namespace Extreme {
	
	/**
	 * @class	Track
	 * @brief	Common track data and functionality
	 * @author	Peter Nordlander
	 * @date	2001-07-01
	 */
	
	class Track
	{
	public:
		
		enum {

			TRACK_ROLL	= 0x03,
			TRACK_REPEAT= 0x02,
			TRACK_SINGLE= 0x00,
		};

		Track() : mFrameCount(0), mKeyCount(0) {}
		virtual ~Track() {};
				
		/// get number of keys in track
		const uint32 getKeyCount() const {
			
			return mKeyCount;
		}
		
		/// get total frames in an�mation
		const uint32 getFrameCount() const {
		
			return mFrameCount;
		}

		/// get total frames in an�mation
		void setFrameCount(uint32 frameCount) {

			mFrameCount = frameCount;
		}

		/// set track mode TRACK_ROLL, TRACK_SINGLE or TRACK_REPEAT
		void setTrackMode(uint32 mode) {

			mTrackMode = mode;
		}

		/// get track mode TRACK_ROLL, TRACK_SINGLE or TRACK_REPEAT
		const uint32 getTrackMode() const {
		
			return mTrackMode;
		}


	protected:
		
		uint32	mFrameCount;		///< Frames in animation
		uint32	mKeyCount;			///< Amount of keys in track
		uint32	mTrackMode;		///< Track mode, roll, single, repeat
	};


	/**
	 * @class	TrackFloat
	 * @brief	Keyframing track of floats
	 * @author	Peter Nordlander
	 * @date	2001-07-01
	 */
	
	class TrackFloat : public Track
	{
	public:
		
		TrackFloat() : mKeys(NULL) {}

		/// copy constructor
		TrackFloat(const TrackFloat &other);

		/// destructor
		~TrackFloat() {release();}

		/// assignent operator
		TrackFloat& operator = (const TrackFloat &other);

		/// resize array of keys
		void resize(int n);

		/// release arrary of keys, delete data
		void release();

		/// get access to keys
		KeyFloat* getKeys();

		/// operator[], get float val at frame <index>
		float operator[](int index);
		
		/// returns a float repr. the current value at frameIndex
		float getKey(float32 frameIndex);

		/// calculate inc/outg. TCB spline tangents
		void calculateTangents();
	
	protected:
		
		KeyFloat*	mKeys;		///< Track key data
	};
	
	/**
	 * @class	TrackQuat
	 * @brief	Keyframing track of quaternions.
	 * @author	Peter Nordlander
	 * @date	2001-07-01
	 */
	
	class TrackQuat : public Track
	{
	public:
		
		/// contructor
		TrackQuat() : mKeys(NULL) {}

		/// copy constructor
		TrackQuat(const TrackQuat &other);

		/// destructor
		~TrackQuat() { release(); }

		/// assignent operator
		TrackQuat& operator = (const TrackQuat &other);

		/// resize array of keys
		void resize(int n);

		/// release arrary of keys, delete data
		void release();

		/// get access to keys
		KeyQuat* getKeys();

		/// operator[] get quat at frame <index>
		Quaternion operator[] (int index);

		/// returns a float repr. the current value at frameIndex
		Quaternion getKey(float32 frameIndex);

		/// calculate inc/outg. TCB spline tangents
		void calculateTangents(){};

	private:
		
		KeyQuat*	mKeys;	///< Track of quaternion keys
	};

	/**
	 * @class	TrackVector
	 * @brief	Keyframing track of vectors
	 * @author	Peter Nordlander
	 * @date	2001-07-01
	 */
	
	class TrackVector : public Track
	{
	public:
		
		/// contructor
		TrackVector() : mKeys(NULL) {}

		/// copy contructor
		TrackVector(const TrackVector &other);

		/// destructor
		~TrackVector() { release();}

		/// assignent operator
		TrackVector& operator = (const TrackVector &other);

		/// resize array of keys
		void resize(int n);
		
		/// release arrary of keys, delete data
		void release();

		/// get arrary of vector keys
		KeyVector* getKeys();

		/// operator[] get vector at frame <index>
		Vector3 operator[] (int index);
	
		/// returns a vector repr. the current value at frameIndex
		Vector3 getKey(float32 frameIndex);

		/// calculate incoming/outgoing. TCB spline tangents
		void calculateTangents();

	private:

		KeyVector*	mKeys;	///< Track of vector keys
	};
}



#endif