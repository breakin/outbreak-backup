#ifndef __EXTREME_DETAULT_REFERENCE_COUNT_INC__
#define __EXTREME_DEFAULT_REFERENCE_COUNT_INC__

namespace Extreme {

	/**
	 * @class  TRefCount
	 * @brief  Default referencecount manager for autoptr objects
	 * @author Peter Nordlander
	 */
	template <typename T>
	class TRefCount
	{
	public:

		/** 
		 * Constructor
		 */
		TRefCount() : mRefCount(0) {}

		/** 
		 * Increase reference count for the given object
		 * @param pointer Ptr to object to increase the reference count for
		 */
		void addRef(T * pointer);
		
		/** 
		 * Decrease/release reference count for the given object
		 * @param pointer Ptr to object to increase the reference count for
		 * @remarks The object will be deleted/released if the counter 
		 * has reached a value of 0.
		 */
		const uint32 release(T * pointer);

		/**
		 * Get the current reference count value
		 * @return The current reference count value
		 */
		const uint32 getRef(T * pointer) const;
		
	protected:

		uint32 mRefCount;	///< Reference counter
	};


//========================================================================================

template <typename T> 
	void TRefCount<T>::addRef(T * pointer) {
	mRefCount++;
}

//========================================================================================

template <typename T> 
	const uint32 TRefCount<T>::release(T * pointer) {
	mRefCount--;
	if (mRefCount == 0)
		delete pointer;

	return mRefCount;
}

//========================================================================================

template <typename T> 
	const uint32 TRefCount<T>::getRef(T * pointer) const {
	return mRefCount;
}

//========================================================================================

}

#endif