#ifndef __EXTREME_TEMPLATE_ALLOCATOR_INC__
#define __EXTREME_TEMPLATE_ALLOCATOR_INC__

template <typename _OBJ>
class TPoolAllocator
{
	public:
	
		TPoolAllocator(const uint32 maxPoolSize);
		
		_OBJ * alloc();
		
		free(_OBJ *);

		const uint32 getMaxPoolSize();

		void setMaxPoolSize(const uint32 maxAlloc); 

		void resize(const int32 maxAlloc);

		void flush();

	protected:
		
		uint32	mMaxLimit;	///< Limit, Maximum queue size before is stops to queue deallocated object
};

#endif
