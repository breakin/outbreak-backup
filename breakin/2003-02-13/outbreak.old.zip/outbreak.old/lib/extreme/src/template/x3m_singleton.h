#ifndef __EXTREME_TEMPLATE_SINGLETON_INC__
#define __EXTREME_TEMPLATE_SINGLETON_INC__

#include "..\debug\x3m_debug.h"
#include "..\x3m_exception.h"

namespace Extreme {

	/**
	 * @class	TSingleton
	 * @brief	Singleton Pattern object template, only to be derived from
	 * @author	Peter Nordlander
	 * @date	2001-11-14
	 */

	template <typename T> 
	class TSingleton
	{	
	public:
		
		/**
		 * Hidden constructor
		 */
		TSingleton();

		/**
		 * Destructor
		 */
		~TSingleton();

		/**
		 * Get single instance of object with type T
		 * @return Reference to a single instance of an object with type T
		 */
		static T& getInstance();

	protected:
		
		static T * sSingletonObject;
	};


//================================================================================

template <typename T>
TSingleton<T>::TSingleton() {	
	X3M_DEBUG("TSingleton", "Constructing...");
	
	if (sSingletonObject) 
		X3M_ERROR ("TSingleton","Attempt to construct two instances of a singleton object!");
	else 		
		sSingletonObject = (T*)((int)this + ((int)(T*)1 - (int)(TSingleton<T>*)(T*)1));
}

//================================================================================

template <typename T>
TSingleton<T>::~TSingleton() {
	sSingletonObject = NULL;
}

//================================================================================

template <typename T>
T& TSingleton<T>::getInstance() {
	if (sSingletonObject)
		return *sSingletonObject;	

	throw Exception ("Singlton object has not yet been created!");
}

}

#endif
