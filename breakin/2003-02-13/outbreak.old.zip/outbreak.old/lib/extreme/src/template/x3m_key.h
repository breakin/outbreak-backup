#ifndef __ETERNITY_TEMPLATE_KEYFRAME_KEY_INC__
#define __ETERNITY_TEMPLATE_KEYFRAME_KEY_INC__

namespace Extreme {

	/**
	 * @class	TKey
	 * @brief	A Template for keyframing KEY data.
	 * @author	Peter Nordlander
	 * @date	2001-06-19
	 */

	template <typename T>
	struct TKey 
	{
		float32	frameNumber;	///< key frame number
		float32	easeTo;			///< Key ease to value
		float32 easeFrom;		///< Key ease from value
		float32 tension;		///< Key tension
		float32 continuity;		///< Key coninuity
		float32 bias;			///< Key bias
		T		data;			///< Key data
		T		tangentIn;		///< Key tangent In
		T		tangentOut;		///< Key tangent Out
	
		/**
		 * Constructor, init all members to 0.0f
		 */
		TKey() :easeTo		(0.0f),
				easeFrom	(0.0f),
				tension		(0.0f),
				continuity	(0.0f),
				bias		(0.0f) {}

	};
}

#endif

