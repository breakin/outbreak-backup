#ifndef __EXTREME_TEMPLATE_HANDLE_INC__
#define __EXTREME_TEMPLATE_HANDLE_INC__

#include "..\x3m_typedef.h"

namespace Extreme {

#define HANDLE_INDEX_PACKED_BITS 16
#define HANDLE_MAGIC_PACKED_BITS 32 - HANDLE_INDEX_PACKED_BITS

	/**
	 * @class	THandle
	 * @brief	A resource handle, a sort of identification key for a certain resource type
	 * @author	Peter Nordlander
	 * @date	2002-01-06
	 */

	template <typename T>
	class THandle 
	{
	private:

		union {
			
			struct {
				
				uint32 mIndex	: HANDLE_INDEX_PACKED_BITS;	///< Handle index
				uint32 mMagic	: HANDLE_MAGIC_PACKED_BITS;	///< Handle magic number, ensure that handle i valid
			};
			uint32 mHandle;		///< Handle's ID, build from index and magic
		};

	public:

		/**
		 * Contructor
		 */
		THandle();

		/**
		 * Destructor
		 */
		~THandle();

		/**
		 * Comparision operator
		 * @param other Other handle to perform comapision with
		 * @return Boolean <true> if equal, <false> otherwise
		 */
		const bool operator == (const THandle &other) const;

		/**
		 * Create a hadle, initialize with (index)
		 * @param index Index to associate with this handle
		 */
		void create(const uint32 index);

		/**
		 * Check if handle is invalud,ie) a NULL handle
		 * @return Boolean <true> if NULL, <false> if valid
		 */
		bool isNull() const;

		/**
		 * Get handle's index
		 * @return Handle's numeric index
		 */
		const uint32 getIndex() const;
		
		/**
		 * Get handle's magic number
		 * @return Handle's numeric index
		 */
		const uint32 getMagic() const;

		/**
		 * Get handle's numerical represetation of both its magic and its index
		 * @return Handle's numeric index
		 */
		const uint32 getHandle() const;
	
		/**
		 * Indirect accessing of the handle's corresponding object 
		 * @return A pointer to the object corresponding to this handle
		 * @remarks A check for isNull must be preceeding any operation 
		 *          with this operator! @see THandle::isNull
		 */
		T * operator->();	

	private:

		T * object;
	};

//===================================================================================================================


template <typename T>
X3M_INLINE THandle<T>::THandle() : mHandle(0) {
}

//===================================================================================================================

template <typename T>
X3M_INLINE THandle<T>::~THandle() {
}

//===================================================================================================================

template <typename T>
X3M_INLINE void THandle<T>::create(const uint32 index) {

	static uint32 sMagic = 1;

	// make sure we do not exceed maximum value allowed
	if (!(sMagic & 0xffff))
		sMagic = 1;

	mIndex = index;
	mMagic = sMagic++;
}

//===================================================================================================================
template <typename T>
X3M_INLINE bool THandle<T>::isNull() const {

	return mHandle == 0 ? true : false;
}

//===================================================================================================================
template <typename T>
X3M_INLINE const uint32 THandle<T>::getIndex() const {
	
	return mIndex;
}
		
//===================================================================================================================
template <typename T>
X3M_INLINE const uint32 THandle<T>::getMagic() const {

	return mMagic;
}

//==================================================================================================================
template <typename T>
X3M_INLINE const uint32 THandle<T>::getHandle() const {

	return mHandle;
}

//===================================================================================================================
template <typename T>
X3M_INLINE const bool THandle<T>::operator == (const THandle<T> &other) const {

	return mHandle == other.mHandle;
}

//===================================================================================================================
//===================================================================================================================


}

#endif