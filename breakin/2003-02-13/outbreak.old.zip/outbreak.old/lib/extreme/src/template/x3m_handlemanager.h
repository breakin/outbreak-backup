#ifndef __EXTREME_TEMPLATE_HANDLEMANAGER_INC__
#define __EXTREME_TEMPLATE_HANDLEMANAGER_INC__

#include "..\x3m_typedef.h"
#include "..\debug\x3m_assert.h"
#include <vector>

namespace Extreme {

#define HANDLE_INDEX_PACKED_BITS 16
#define HANDLE_MAGIC_PACKED_BITS 32 - HANDLE_INDEX_PACKED_BITS

	/**
	 * @class	THandleManager
	 * @brief	Template HandleManager 
	 *			The HandleManager stores and allocates objects and associates them
	 *			with handle identifiers.
	 * @author	Peter Nordlander
	 * @date	2002-01-06
	 */

	template <typename DATATYPE, typename HANDLETYPE>
	class THandleManager 
	{
	public:

		/**
		 * Constructor
		 */
		THandleManager();

		/**
		 * Destructor
		 */
		~THandleManager();

		/**
		 * Request a new handle and allocata a new data object
		 * @param handle A reference to a handle object where to store the new objects handle identifier
		 * @return Pointer to a new dynamically allocated object.
		 * @remarks The handle manager does not always create new objects, 
		 *			it will reuse releasead and unused objects previously created.
		 */
		DATATYPE * create(HANDLETYPE &handle);

		/**
		 * Release a handle in manager and the object associtated with it
		 * @param handle Handle to a valid object
		 */
		void release(HANDLETYPE handle);

		/**
		 * Get a constant reference of the dataobject represented by <handle>
		 * @param handle Handle to a valid object
		 * @return The object associated with @handle
		 */
		const DATATYPE * getData(const HANDLETYPE handle) const;
		
		/**
		 * Get a reference of the managed dataobject represented by <handle>
		 * @param handle Handle to a valid object
		 * @return The object associated with @handle
		 */
		DATATYPE * getData(const HANDLETYPE handle);

		/**
		 * Flush,destroy and deallocate all data within the handle manager
		 */
		void flush();


	protected:

		std::vector<DATATYPE*>	mData;	///< Managed data store
		std::vector<uint32>		mMagic;	///< Validation magic numbers
		std::vector<uint32>		mFree;	///< Free indexes store
	};

//====================================================================================================

template <typename DATATYPE, typename HANDLETYPE>
X3M_INLINE THandleManager<DATATYPE,HANDLETYPE>::THandleManager() {

}

//====================================================================================================

template <typename DATATYPE, typename HANDLETYPE>
X3M_INLINE THandleManager<DATATYPE,HANDLETYPE>::~THandleManager() {

}

//====================================================================================================

template <typename DATATYPE, typename HANDLETYPE>
X3M_INLINE DATATYPE * THandleManager<DATATYPE,HANDLETYPE>::create(HANDLETYPE &handle) {

	X3M_ASSERT (handle.isNull());

	uint32 index;

	// check if there are free indexes available
	if (mFree.size() > 0) {

		// obtain free index
		index = mFree.back();
		mFree.pop_back();

		// create the handle
		handle.create(index);

		// store the handle's magic number in magic numer stor
		mMagic[index] = handle.getMagic();
		
		// return data at index (index)
		return mData[index];
	}
	else {

		index = mData.size();

		// create a new handle
		handle.create(mData.size());
		
		DATATYPE * dt = new DATATYPE;

		// increase size of data vector with an empty data object
		mData.push_back(dt);

		// add handle's magic number to magic vector
		mMagic.push_back(handle.getMagic());
	}

	return *(mData.begin() + index);
}

//====================================================================================================

template <typename DATATYPE, typename HANDLETYPE>
X3M_INLINE void THandleManager<DATATYPE,HANDLETYPE>::release(HANDLETYPE handle) {

	uint32 index = handle.getIndex();

	X3M_ASSERT (!handle.isNull());
	X3M_ASSERT (index < mData.size());
	X3M_ASSERT (mMagic[index] == handle.getMagic());

	// set magic to 0 to invalidate handle and add its index to free store
	mMagic[handle.getIndex()] = 0;	
	mFree.push_back(handle.getIndex());	
}

//====================================================================================================

template <typename DATATYPE, typename HANDLETYPE>
X3M_INLINE DATATYPE * THandleManager<DATATYPE,HANDLETYPE>::getData(HANDLETYPE handle) {

	uint32 index = handle.getIndex();

	X3M_ASSERT (!handle.isNull());
	X3M_ASSERT (mMagic[index] == handle.getMagic());
	X3M_ASSERT (index < mData.size());

	if (mMagic[index] != handle.getMagic())
		return NULL;

	return *(mData.begin() + index);
}

//====================================================================================================

template <typename DATATYPE, typename HANDLETYPE>
X3M_INLINE const DATATYPE * THandleManager<DATATYPE,HANDLETYPE>::getData(HANDLETYPE handle) const {

	return (const_cast<THandleManager<DATATYPE,HANDLETYPE>*> (this)->getData(handle));
}

//====================================================================================================

template <typename DATATYPE, typename HANDLETYPE>
X3M_INLINE void THandleManager<DATATYPE, HANDLETYPE>::flush() {

	for (int iData = 0; iData < mData.size(); iData++) {
		
		DATATYPE * data = mData.back();
		mData.pop_back();
		delete data;
	}

	// delete magic and free tables aswell
	mFree.erase(mFree.begin(), mFree.end());
	mMagic.erase(mMagic.begin(), mMagic.end());
}

//====================================================================================================

}

#endif
