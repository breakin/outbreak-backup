#ifndef __EXTREME_DETAULT_REFERENCE_COUNT_INC__
#define __EXTREME_DEFAULT_REFERENCE_COUNT_INC__

namespace Extreme {

	/**
	 * @class  TRefCountCOM
	 * @brief  Default referencecount manager for COM interfaces
	 * @author Peter Nordlander
	 */
	template <typename _COMOBJ>
	class TRefCountCOM
	{
	public:

		/** 
		 * Constructor
		 */
		TRefCountCOM() : mRefCount(0) {}

		/** 
		 * Increase reference count for the given object
		 * @param pointer Ptr to object to increase the reference count for
		 */
		void addRef(_COMOBJ * pointer);
		
		/** 
		 * Decrease/release reference count for the given object
		 * @param pointer Ptr to object to increase the reference count for
		 * @remarks The object will be deleted/released if the counter 
		 * has reached a value of 0.
		 */
		const uint32 release(_COMOBJ * pointer);

		/**
		 * Get the current reference count value
		 * @return The current reference count value
		 */
		const uint32 getRef(_COMOBJ * pointer) const;
		
	protected:

		uint32 mRefCount;	///< Reference counter
	};


//========================================================================================

template <typename _COMOBJ> 
	void TRefCountCOM<_COMOBJ>::addRef(_COMOBJ * comobj) {
	mRefCount = comobj->AddRef();
}

//========================================================================================

template <typename _COMOBJ> 
	const uint32 TRefCountCOM<_COMOBJ>::release(_COMOBJ * comobj) {
	mRefCount = comobj->Release();
	return mRefCount;
}

//========================================================================================

template <typename _COMOBJ> 
	const uint32 TRefCountCOM<_COMOBJ>::getRef(_COMOBJ * comobj) const {
	return mRefCount;
}

//========================================================================================

}

#endif
