#ifndef __EXTREME_RESOURCE_REFERENCE_COUNT_INC__
#define __EXTREME_RESOURCE_REFERENCE_COUNT_INC__

#pragma warning (disable : 4786)

#include "..\debug\x3m_debug.h"
#include "x3m_resourcemanager.h"

namespace Extreme {

	template <typename _RES>
	class TRefCountResource
	{
	public:
		
		/**
		 * Constructor
		 */
		TRefCountResource() : mRefCount(0) {}

		/**
		 * Increase referencecount
		 * @param resource Resource to increase referencecount for
		 */
		void addRef(_RES * resource);

		/**
		 * Decrease referencecount
		 * @param resource Resource to decrease referencecount for
		 * @return References left, after decreament
		 */
		const uint32 release(_RES * resource);
		
		/**
		 * Retrieve the current referencecounter
		 * @return The current value of the reference counter
		 */
		const uint32 getRef(_RES * resource) const;

	protected:

		uint32  mRefCount;	///< Resource reference counter
		bool	mRefLock;	///< Resource refcount lock, prevent destruction of refcountobject's counter to be decreamented
	};

//================================================================================
	
template <typename _RES>
X3M_INLINE void TRefCountResource<_RES>::addRef(_RES * res) {

	// increase copy of referencecounter
	mRefCount++;
}

//================================================================================
template <typename _RES>
X3M_INLINE const uint32 TRefCountResource<_RES>::release(_RES * res) {

	// check if this resource was created throgh at resourcemanager
	if (res->getCreator() == NULL)
		return --mRefCount;

	/**
	 * SPECIAL CODE BLOCK:
	 * Check if one - as resourcemanager also holds a reference to this resource
	 * After the resource has been released through the resourcemanager
	 * mRefCount will actually be 0 as the ResourceManager has decreased it.
	 */
//	mRefCount--;
	
	if (mRefCount == 2) {
		
		// increase refcount to any value, we do not want the resman to delete the reference as this method would crasg that way ;)
		// actually a quite ugly solution, but what the heck - It works ! ;D
		mRefCount++;

		// we do not delete anything here, leave that responsibilty to the manager
		res->getCreator()->remove(res->getName());
			
		// HERE referencecounter (mRecCount is 0)
		X3M_DEBUG ("ResCountResource", "Reference counter is %ld after manager destruction (res (%s)", mRefCount, res->getName().c_str());

		// set refcount to 0, force object to delete itself and the shared reference aswell
		mRefCount = 0;

		// also delete the resource managed by this smartptr
		delete res;
		
		// and finally return 0 to force reference to be deleted
		return 0;
	}
	
	mRefCount--;

	// return refcount to calling object 
	return mRefCount;
}

//================================================================================

template <typename _RES>
X3M_INLINE const uint32 TRefCountResource<_RES>::getRef(_RES * resource) const {
	return mRefCount;
}

//================================================================================

}

#endif