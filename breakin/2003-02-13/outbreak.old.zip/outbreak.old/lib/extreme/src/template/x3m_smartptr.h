#ifndef __EXTREME_TEMPLATE_SMARTPTR_INC__
#define __EXTREME_TEMPLATE_SMARTPTR_INC__

#pragma warning (disable : 4786)

#include "..\x3m_typedef.h"
#include "..\debug\x3m_assert.h"
#include "x3m_refcount_default.h"

namespace Extreme {


	/**
	 * @class TSmartPtr
	 * @brief Smart pointer class, used automatic ownership and management of dynamically allocated objects 
	 * @author Peter Nordlander
	 */
	template <typename T, typename C = TRefCount<T> >
	class TSmartPtr
	{
	public:
		
		/**
		 * Constructor
		 * @param pointer Pointer to the object that this AutoPtr should track
		 */
		TSmartPtr(T * ptr = NULL);
		
		/**
		 * Copy Constructor
		 * @param other An AutoPtr object (derived from the same type)
		 * @remarks This object will, after assignment, referecnce to the same object
		 * as @a other - only their internal reference count will be increased.
		 */
		TSmartPtr(const TSmartPtr<T, C> &other);

		/**
		 * Destructor
		 * @remarks Only performs a deallocation if the internal reference count is zero.
		 */
		~TSmartPtr();

		/**
		 * Explicitly give up ownership of this autoptr
		 * @remarks May deallocate object if the reference count i equal to 0.
		 */
		void release();
		
		/**
		 * Explicitly increase the object's reference count
		 */
		void addRef();

		/**
		 * Explicitly attach a pointer, release its old managed ptr
		 * @param ptr The new object to manage
		 */
		void attach(const T * ptr);

		/**
		 * Retrieve the current reference count on the ptr's corresponding object
		 */
		const int32 getRefCount() const;

		/**
		 * Check weither this autoptr is invalud, 
		 * @return True if this autoptr doesn't reference to an object, false otherwise
		 */
		const bool isNull() const;

		/**
		 * Pointer notation operator
		 * @return The object that this autoptr contains
		 */
		T * operator->();
		
		/**
		 * Pointer notation operator
		 * @return The object that this autoptr contains
		 */
		const T * operator->() const;

		/**
		 * Deference notation operator
		 * @return A reference to the object that this autoptr contains
		 */
		T & operator * ();

		/**
		 * Deference notation operator
		 * @return A reference to the object that this autoptr contains
		 */
		const T & operator * () const;
			
		/**
		 * Assignment operator
		 * @param other The object to assign this object with
		 * @return A reference the object from which this operator was invoked
		 */
		TSmartPtr<T, C> & operator = (const TSmartPtr<T, C> &other);

		/**
		 * Assignment operator
		 * @param ptr The object to be managed by this smartprt
		 * @return A reference to this
		 */
		TSmartPtr<T, C> & operator = (const T * ptr);

		/**
		 * Compare smartptr object operator
		 * @param ptr The pointer to compare this smartptr with
		 * @return True if the object that this smartpr contain is equal to @a ptr
		 */
		int operator == (const T * ptr) { if (!mObjectRef) return 0; return (mObjectRef->mObject == ptr);}

		/**
		 * Cast operator to uint32
		 * @return Integer representation of this object
		 */
		operator uint32 () const;

		/**
		 * Cast operator to it pointertype
		 * @return The actual supervised object
		 */
		operator T * () const { if (!mObjectRef) return NULL; return mObjectRef->mObject;}

		/** 
		 * Retrieve access to the object managed by this smartptr, 
		 * @return The object managed by this smartptr
		 * @remarks This method should be carefully used as no referencecounting and
		 * other detections are involved. 
		 */
		const T * getObject() const { if (mObjectRef == NULL) return NULL; return mObjectRef->mObject; }
 
		/** 
		 * Retrieve access to the object managed by this smartptr, 
		 * @return The object managed by this smartptr
		 * @remarks This method should be carefully used as no referencecounting and
		 * other detections are involved. 
		 */		
		T * getObject() { if (mObjectRef == NULL) return NULL; return mObjectRef->mObject; }

	protected:

		/**
		 * Hidden operator new
		 */
		// void * operator new (size_t size) { return NULL; }

		/**
		 * Hidden operator delete
		 */
		// void operator delete (void * p) {}
	
		/**
		 * @class  PtrRef
		 * @brief  The object reference, shared between autoptr objects
		 * @author Peter Nordlander
		 */
		struct PtrRef
		{
			T * mObject;		///< Object reference
			C  mCounter;		///< Object reference counter, usage count
		};
		
		union 
		{
			PtrRef* mObjectRef;	///< Object reference
			uint32  mObjectID;	///< Integer object ID
		};
	};

	//========================================================================================
	
	//========================================================================================
	
	template <typename T, typename C  >
		TSmartPtr<T, C>::TSmartPtr(T * pointer) : mObjectRef(NULL) {
		// attach pointer
		attach(pointer);		
	}
	
	//========================================================================================
	template <typename T, typename C >
	const int32 TSmartPtr<T, C>::getRefCount() const {
		if (mObjectRef)
			return mObjectRef->mCounter.getRef(mObjectRef->mObject);
		return 0;
	}

	//========================================================================================

	template <typename T, typename C  >
	TSmartPtr<T, C>::TSmartPtr(const TSmartPtr<T, C> & other) {
		
		// get other object's pointer-reference
		mObjectRef = other.mObjectRef;
		
		// explicitly increase referencecounter
		if (mObjectRef)
			addRef();
	}
	
	//========================================================================================
	
	template <typename T, typename C  >
	TSmartPtr<T, C>::~TSmartPtr() {

		// release object on destruction
		release();
	}
	
	//========================================================================================
	
	template <typename T, typename C  >
	void TSmartPtr<T, C>::release() {
		
		// check if we're valid
		if (mObjectRef) {

			// decerase reference counter, and check if no refs are left
			if (mObjectRef->mCounter.release(mObjectRef->mObject) == 0)		
				delete mObjectRef;

			// set objectreference to NULL, not used anymore
			mObjectRef = NULL;
		}
	}
	
	//========================================================================================
	
	template <typename T, typename C>
	TSmartPtr<T, C> & TSmartPtr<T, C>::operator = (const T * ptr) {
		
		// release current 
		release();
		
		// check for NULL, attach if valid object
		if (ptr)
			attach(ptr);
		
		return *this;
	}

	//========================================================================================

	template <typename T, typename C  >
	const bool TSmartPtr<T, C>::isNull() const {
		return (mObjectRef == NULL) ? true : false;
	}

	//========================================================================================

	template <typename T, typename C  >
	void TSmartPtr<T, C>::attach(const T * pointer) {

		// release old pointer
		release();

		// attach new pointer - only if not NULL
		if (pointer) {

			T * ptr = const_cast<T *>(pointer);
			
			mObjectRef = new PtrRef;
			mObjectRef->mObject = ptr;
			mObjectRef->mCounter.addRef(ptr);
		}
	}
	
	//========================================================================================
	
	template <typename T, typename C  >
	void TSmartPtr<T, C>::addRef() {
		X3M_ASSERT (!this->isNull())

		// increase referncecounter for managed object
		mObjectRef->mCounter.addRef(mObjectRef->mObject);
	}
	
	//========================================================================================

	template <typename T, typename C  >
	T * TSmartPtr<T, C>::operator-> () {
		X3M_ASSERT (mObjectRef != NULL);

		// return the object pointed to
		return mObjectRef->mObject;
	}
	
	//========================================================================================

	template <typename T, typename C  >
	const T * TSmartPtr<T, C>::operator-> () const {
		X3M_ASSERT (mObjectRef != NULL);
		
		// return a const reference to the object pointed to
		return mObjectRef->mObject;
	}
	
	//========================================================================================

	template <typename T, typename C  >
	T & TSmartPtr<T, C>::operator * () {
		X3M_ASSERT (mObjectRef != NULL);

		// derefence pointed object
		return *(mObjectRef->mObject);
	}
	

	//========================================================================================
	
	template <typename T, typename C  >
	const T & TSmartPtr<T, C>::operator * () const {
		X3M_ASSERT (mObjectRef != NULL);
		return *(mObjectRef->mObject);
	}

	//========================================================================================

	template <typename T, typename C  >
	TSmartPtr<T, C>::operator uint32 () const {
		return mObjectID;		
	}

	//========================================================================================
	
	//template <typename T, typename C  >
	//int TSmartPtr<T, C>::operator == (const TSmartPtr & other) {
	//	return (mObjectRef == other.mObjectRef) ? 1 : 0;		
	//}

	//========================================================================================

	template <typename T, typename C  >
	TSmartPtr<T, C> & TSmartPtr<T, C>::operator = (const TSmartPtr<T, C> & other) {

		// prevent assignment of itself
		if (other.mObjectRef == mObjectRef)
			if (mObjectRef != NULL)
				throw Exception("Cannot assign an autoptr to itself!");

		// release if this autoptr reference to another object
		if (!isNull())
			release();

		mObjectRef = other.mObjectRef;
		
		if (mObjectRef)
			mObjectRef->mCounter.addRef(mObjectRef->mObject);
		
		return *this;
	}


	//========================================================================================
	//========================================================================================
	//========================================================================================
	//========================================================================================
	//========================================================================================
	//========================================================================================
}

#endif