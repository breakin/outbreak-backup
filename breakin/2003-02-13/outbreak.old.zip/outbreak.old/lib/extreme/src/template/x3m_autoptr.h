#ifndef __EXTREME_TEMPLATE_AUTOPTR_INC__
#define __EXTREME_TEMPLATE_AUTOPTR_INC__

namespace Extreme {

	/**
	 * @class  TDefaultRefCount
	 * @brief  Default referencecount manager for autoptr objects
	 * @author Peter Nordlander
	 */
	template <typedef _OBJ>
	class TDefaultRefCount
	{
	public:

		/** 
		 * Constructor
		 */
		TDefaultRefCount() : mRefCount(0) {}

		/** 
		 * Increase reference count for the given object
		 * @param pointer Ptr to object to increase the reference count for
		 */
		void addRef(_OBJ * pointer);
		
		/** 
		 * Decrease/release reference count for the given object
		 * @param pointer Ptr to object to increase the reference count for
		 * @remarks The object will be deleted/released if the counter 
		 * has reached a value of 0.
		 */
		void release(_OBJ * pointer);

		/**
		 * Get the current reference count value
		 * @return The current reference count value
		 */
		const uint32 getRef() const;
		
	protected:

		uint32 mRefCount;	///< Reference counter
	};

	/**
	 * @class TAutoPtr
	 * @brief Auto pointer class, used automatic ownership and management of dynamically allocated objects 
	 * @author Peter Nordlander
	 */
	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	class TAutoPtr
	{
	public:
		
		/**
		 * Constructor
		 * @param pointer Pointer to the object that this AutoPtr should track
		 */
		TAutoPtr(_OBJ * pointer = NULL);
		
		/**
		 * Copy Constructor
		 * @param other An AutoPtr object (derived from the same type)
		 * @remarks This object will, after assignment, referecnce to the same object
		 * as @a other - only their internal reference count will be increased.
		 */
		TAutoPtr(const TAutoPtr<_OBJ, _CNTR> &other);

		/**
		 * Destructor
		 * @remarks Only performs a deallocation if the internal reference count is zero.
		 */
		~TAutoPtr();

		/**
		 * Explicitly give up ownership of this autoptr
		 * @remarks May deallocate object if the reference count i equal to 0.
		 */
		void release();
		
		/**
		 * Explicitly increase the object's reference count
		 */
		void addRef();

		/**
		 * Check weither this autoptr is invalud, 
		 * @return True if this autoptr doesn't reference to an object, false otherwise
		 */
		const bool isNull() const;

		/**
		 * Pointer notation operator
		 * @return The object that this autoptr contains
		 */
		_OBJ * operator->();
		
		/**
		 * Pointer notation operator
		 * @return The object that this autoptr contains
		 */
		const _OBJ * operator->() const;

		/**
		 * Deference notation operator
		 * @return A reference to the object that this autoptr contains
		 */
		_OBJ & operator * ();

		/**
		 * Deference notation operator
		 * @return A reference to the object that this autoptr contains
		 */
		const _OBJ & operator * () const;
			
		/**
		 * Assignment operator
		 * @param other The object to assign this object with
		 * @return A reference the object from which this operator was invoked
		 */
		TAutoPtr<_OBJ, _CNTR> & operator = (const TAutoPtr<_OBJ, _CNTR> &other);

	protected:

		/**
		 * Hidden operator new
		 */
		void * operator new (size_t size) { return NULL; }

		/**
		 * Hidden operator delete
		 */
		void operator delete (void * p) {}
	
		/**
		 * @class  PtrRef
		 * @brief  The object reference, shared between autoptr objects
		 * @author Peter Nordlander
		 */
		struct PtrRef
		{
			_OBJ * mObject;		///< Object reference
			_CNTR  mCounter;	///< Object reference counter, usage count
		};
	
		PtrRef* mObjectRef;	///< Object reference
	};

	//========================================================================================
	
	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
		TAutoPtr<_OBJ, _CNTR>::TAutoPtr(_OBJ * pointer) : mObjectRef(NULL) {
		if (pointer) {
			mObjectRef = new PtrRef;
			mObjectRef->mObject = pointer;
			mObjectRef->mCounter.addRef(pointer);
		}
	}
	
	//========================================================================================

	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	TAutoPtr<_OBJ, _CNTR>::TAutoPtr(const TAutoPtr<_OBJ, _CNTR> & other) {
		mObjectRef = other.mObjectRef;
		mObjectRef->mCounter.addRef(mObjectRef->mObject);
	}
	
	//========================================================================================
	
	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	TAutoPtr<_OBJ, _CNTR>::~TAutoPtr {
		release();
	}
	
	//========================================================================================
	
	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	void TAutoPtr<_OBJ, _CNTR>::release() {
		
		if (mObjectRef) {
			mObjectRef->mCounter.release(mObjectRef->mObject);
		
			if (mObjectRef->mCounter.getRef() == 0)
				delete mObjectRef;
			
			mObjectRef = NULL;
		}
	}
	
	//========================================================================================

	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	const bool TAutoPtr<_OBJ, _CNTR>::isNull() const {
		return (mObjectRef == NULL) ? true : false;
	}

	//========================================================================================
	
	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	void TAutoPtr<_OBJ, _CNTR>::addRef() {
		if (!isNull())
			mObjectRef->mCounter.addRef(mObjectRef->mObject);
	}
	
	//========================================================================================

	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	_OBJ * TAutoPtr<_OBJ, _CNTR>::operator-> () {
		X3M_ASSERT (mObjectRef != NULL);
		return mObjectRef->mObject;
	}
	
	//========================================================================================

	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	const _OBJ * TAutoPtr<_OBJ, _CNTR>::operator-> () const {
		X3M_ASSERT (mObjectRef != NULL);
		return mObjectRef->mObject;
	}
	
	//========================================================================================

	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	_OBJ & TAutoPtr<_OBJ, _CNTR>::operator * () {
		X3M_ASSERT (mObjectRef != NULL);
		return *(mObjectRef->mObject);
	}
	

	//========================================================================================
	
	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	const _OBJ & TAutoPtr<_OBJ, _CNTR>::operator * () const {
		X3M_ASSERT (mObjectRef != NULL);
		return *(mObjectRef->mObject);
	}

	//========================================================================================
	
	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	const bool TAutoPtr<_OBJ, _CNTR>::operator == (const TAutoPtr<_OBJ, _CNTR> & other) const {
		return (mObjectRef == other.mObjectRef) ? : true : false;		
	}

	//========================================================================================

	template <typename _OBJ, typename _CNTR = TDefaultRefCount<_OBJ> >
	TAutoPtr<_OBJ, _CNTR> & TAutoPtr<_OBJ, _CNTR>::operator = (const TAutoPtr<_OBJ, _CNTR> & other) {

		// prevent assignment of itself
		if (other == *this)
			throw Exception("Cannot assign an autoptr to itself!");

		// release if this autoptr reference to another object
		if (!isNull())
			release();

		mObjectRef = other.mObjectRef;
		
		if (mObjectRef)
			mObjectRef->mCounter.addRef(mObjectRef->mObject);
	}

	//========================================================================================

	template <typename _OBJ> 
		void TDefaultRefCount<_OBJ>::addRef(_OBJ * pointer) {
		mRefCount++;
	}

	//========================================================================================

	template <typename _OBJ> 
		void TDefaultRefCount<_OBJ>::release(_OBJ * pointer) {
		mRefCount--;
		if (mRefCount == 0)
			delete pointer;
	}
	
	//========================================================================================
	
	template <typename _OBJ> 
		const uint32 TDefaultRefCount<_OBJ>::getRef() const  {
		return mRefCount;
	}
	
	//========================================================================================
	//========================================================================================
	//========================================================================================
	//========================================================================================
	//========================================================================================
	//========================================================================================
	//========================================================================================


}

#endif