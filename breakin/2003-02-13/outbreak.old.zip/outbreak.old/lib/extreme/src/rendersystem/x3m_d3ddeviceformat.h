/*=======================================================================================*
 
	Extreme 3D Engine

	Responsible: Peter Nordlander (tooon@home.se)
 
	Copyright 2000-2002 Peter Nordlander, all rights reserved.
	Any modification of the source code is strictly forbidden without permission
	from the author(s) and/or the file responsible.
	
	Please visit:
	www.planetzeus.net
	www.outbreak.nu

*=======================================================================================*/

#ifndef __EXTREME_DEVICE_D3D_DEVICEFORMAT_INC__
#define __EXTREME_DEVICE_D3D_DEVICEFORMAT_INC__

#include "..\x3m_typedef.h"
#include "x3m_displaymode.h"

namespace Extreme {

	/**
	 * @class	D3DDeviceFormat
	 * @brief	Represents a d3d device's capabilities for a specific bitdepth/format
	 * @author	Peter Nordlander
	 * @date	2001-12-25
	 */

	class D3DDeviceFormat
	{	
	public:

		/**
		 * Retrieve maximum amount of samples when using this format
		 * @return Maximum amount of samples
		 */
		const int32 getMaxMultiSamples();
		
		/**
		 * Confirms that this format support a certain multisample rate
		 * @return true if rate is supported, false otherwise
		 */
		const bool confirmMultiSampleRate(const int32 rate) const;

		int32				mBitdepth;			///< Formats bitdepth
		uint32				mBehaviour;			///< Formats supported behaviours
		bool				mSupportFSAA;		///< Full Scene Antialiasing is supported on this format
		D3DFORMAT			mFormat;			///< Formats D3D packed identifier
		D3DFORMAT			mFormatDepthStencil;///< Formats D3D depth stencil format
		std::vector<int32>	mMultiSamples;		///< Formats Supported multi sample types (Full Scene AntiAliasing)
	};

	/// typedef std::vector, more trivial access and usage
	typedef std::vector<D3DDeviceFormat> D3DDeviceFormatList;

//====================================================================================================================

X3M_INLINE const int32 D3DDeviceFormat::getMaxMultiSamples() {

	int32 max = 0;

	for (int iSamples = 0; iSamples < mMultiSamples.size(); iSamples++) 
		if (mMultiSamples[iSamples] > max)
			max = mMultiSamples[iSamples];

	return max;
}

//====================================================================================================================

X3M_INLINE const bool D3DDeviceFormat::confirmMultiSampleRate(const int32 rate) const {

	for (int iSamples = 0; iSamples < mMultiSamples.size(); iSamples++) 
		if (mMultiSamples[iSamples] == rate)
			return true;

	return false;
}

}


#endif