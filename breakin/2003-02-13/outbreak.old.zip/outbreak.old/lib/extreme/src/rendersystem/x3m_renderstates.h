#ifndef __EXTREME_RENDERSYSTEM_RENDERSTATES_INC__
#define __EXTREME_RENDERSYSTEM_RENDERSTATES_INC__

namespace Extreme {
	
	class RenderState
	{
	public:

		bool mEnabled;
	};

	class FillMode : public RenderState
	{	
	public:
		enum eMode
		{
			SOLID,
			WIREFAME,
			POINT,
		};
		
		eMode mMode;
	};
	
	class ShadeMode : public RenderState
	{
	public:
		enum eMode
		{
			GOURAUD,
			PHONG,
			FLAT,
		};

		eMode mMode;
	};

	class LightState : public RenderState
	{
	public:
		bool mLightEnable;
	};
	
	class CullMode : public RenderState
	{
		enum 
		{
			CCW,
			CW,
			NONE,
		};
	};

	class DepthBufferMode : public RenderState
	{
	public:
		
		bool mDepthWriteEnable;
		bool mDepthEnable;
	};
	
	class ColorSource : public RenderState
	{
		enum 
		{
			VERTEXDIFFUSE,
			VERTEXSPECULAR,
			SURFACE,
		};

		int32 mDiffuse;
		int32 mSpecular;
		int32 mAmbient;
	};


	namespace RState 
	{
		/**
		 * Rendersystem backface culling modes
		 */
		enum eCullMode
		{
			CULL_CW,				///< Cull faces with vertices in clockwise ordering
			CULL_CCW,				///< Cull faces with vertices in counter clocwise ordering
			CULL_NONE,				///< Cull none, disabled
		};

		/**
		 * RenderSystem Fill Modes
		 */
		enum eFillMode
		{	
			FILL_POINT		= 0x01,			///< Point fillmode, draw points, no filling
			FILL_WIREFRAME	= 0x02,			///< WireFrame fillmode, draw face without filling, only its contours
			FILL_SOLID		= 0x03,			///< Solid fillmode
			FILL_DEFAULT	= FILL_SOLID,	///< Default fillmode
		};

		/**
		 * RenderSystem shade modes
		 */
		enum eShadeMode
		{
			SHADE_FLAT		= 0x01,		///< Flat shading
			SHADE_GOURAUD	= 0x02,		///< Gouraud shading
			SHADE_PHONG		= 0x03,		///< Phong shading
		};
		
		/**
		 * Primitive types
		 */
		enum ePrimitiveType 
		{
			PT_POINTLIST,		///< Point list
			PT_LINELIST,		///< Line list
			PT_TRISTRIP,		///< Triangle strip
			PT_TRILIST,			///< Triangle list
		};
		
		/**
		 * Color source, from where the rendersysem should fetch its color data
		 */
		enum eColorSource
		{
			COLORSRC_SURFACE,
			COLORSRC_VERTEXDIFFUSE,
			COLORSRC_VERTEXSPECULAR,
		};
	}
}

#endif
