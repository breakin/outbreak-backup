#ifndef __EXTREME_RENDERSYSTEM_CONFIG_INC__
#define __EXTREME_RENDERSYSTEM_CONFIG_INC__

#include <string>

namespace Extreme {



}

#endif