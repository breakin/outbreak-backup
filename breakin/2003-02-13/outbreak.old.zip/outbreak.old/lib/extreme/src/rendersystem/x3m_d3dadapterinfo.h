/*=======================================================================================*
 
	_..::>Extreme 3D Engine<::.._ 

	File responsible: Peter Nordlander (tooon@home.se)
 
	Copyright 2000-2002 Peter Nordlander, all rights reserved.
	Any modification of the source code is strictly forbidden without permission
	from the author(s) and/or the file responsible.
	
	Hangouts:
	www.planetzeus.net
	www.outbreak.nu

*=======================================================================================*/

#ifndef __EXTREME_D3D_ADAPTER_INFO_INC__
#define __EXTREME_D3D_ADAPTER_INFO_INC__

#include "x3m_d3ddeviceinfo.h"
#include "x3m_d3dversion.h"

namespace Extreme {

	/**
	 * AdapterInfo constants
	 */
	const uint32 ADAPTERINFO_MAX_DEVICETYPES = 2;
	const uint32 ADAPTERINFO_DEVICETYPE_HAL  = 0;
	const uint32 ADAPTERINFO_DEVICETYPE_REF  = 1;

	/**
	 * @class	D3DAdapterInfo
	 * @brief	Describes a d3d compatible adapter and its supported devices
	 * @author	Peter Nordlander
	 * @date	2001-12-19
	 */
	
	struct D3DAdapterInfo 
	{
		/**
		 * Constructor
		 */
		D3DAdapterInfo() : mSupportHAL(true) {}

		/**
		 * Indexing operator for devicetypes
		 */
		D3DDeviceInfo& operator[] (D3DDEVTYPE deviceType);

		/**
		 * Get reference to deviceInfo for a certain device typ of D3DDEVTYPE_HAL/REF
		 * @param deviceType D3DDEVTYPE specifing for which devicetype you want defive information
		 * @return Pointer to the D3DDeviceInfo associated with the passed deviceType
		 */
		D3DDeviceInfo * getD3DDeviceInfo(D3DDEVTYPE deviceType);

		/**
		 * Confirm that a displaymode exists on this adapter
		 * @param mode DisplayMode to be confirmed
		 */
		const bool confirmDisplayMode(const DisplayMode &mode);

		/// Adapterinfo data
		D3DDeviceInfo			 mDevices[2];	///< Adapter's supported device types (CD3DDeviceInfo::TYPE_HAL/REF)
		std::string				 mDriver;		///< Adapter driver description
		std::string				 mDescription;	///< Adapter description
		D3DDISPLAYMODE			 mDesktopMode;	///< Adapter's desktop displaymode
		std::vector<DisplayMode> mDisplayModes;	///< Adapter's supported displaymodes
		bool					 mSupportHAL;	///< Adapter support a HAL device
		bool					 mSupportFSAA;	///< Adapter support FullSceneAntiAliasing
		
		int32					 mAdapterIndex;///< Adapter index, how it is reffered to by direct 3d
	};

	typedef std::vector<D3DAdapterInfo> D3DAdapterInfoList;

//========================================================================================================================

X3M_INLINE const bool D3DAdapterInfo::confirmDisplayMode(const DisplayMode &mode) {

	for (int iAdapterMode = 0; iAdapterMode < mDisplayModes.size(); iAdapterMode++)
		if (mDisplayModes[iAdapterMode] == mode)
			return true;
	return false;
}

//========================================================================================================================

X3M_INLINE D3DDeviceInfo& D3DAdapterInfo::operator[] (D3DDEVTYPE deviceType) {

	if (mDevices[0].mDeviceCaps.DeviceType == deviceType)
		return mDevices[0];

	return mDevices[1];
}

//========================================================================================================================

X3M_INLINE D3DDeviceInfo * D3DAdapterInfo::getD3DDeviceInfo(D3DDEVTYPE deviceType) {

	if (mDevices[0].mDeviceCaps.DeviceType == deviceType)
		return &mDevices[0];

	return &mDevices[1];
}

//========================================================================================================================
}


#endif