//==========================================================================================
// Include files
//==========================================================================================

#include "x3m_rendersystem.h"
#include "x3m_rendersystem_cfg.h"
#include "x3m_d3dversion.h"
#include "x3m_d3dutil.h"
#include "..\resource\x3m_material.h"
#include "..\resource\x3m_materialmanager.h"
#include "..\resource\x3m_texturemanager.h"
#include "..\resource\x3m_modelmanager.h"



/// d3d includes
#include <d3d8.h>

/// stl include
#include <string>

//==========================================================================================
// Namespace usage
//==========================================================================================

using namespace Extreme;

//==========================================================================================
// Static/Global Module data/types
//==========================================================================================

RenderSystem * TSingleton<RenderSystem>::sSingletonObject = NULL;

//==========================================================================================

// typedef of a stdcall d3d create function
typedef IDirect3D8 * (__stdcall *D3DCREATEFUNC) (UINT);

// direct3D create function ptr
D3DCREATEFUNC gDirect3DCreate;

//==========================================================================================
// Method implenetation
//==========================================================================================

RenderSystem::RenderSystem() {

	X3M_DEBUG ("RenderSystem", "Constructing...");
	
	// map DLL in application address space
	d3d_loadDLL();
	
	// cretate Hardware interface
	d3d_create();

	// initilize data to default
	init();

	// init default configuration, register paremeters
	initConfig();

	// init capabilities
	initCaps();
}

//==========================================================================================

RenderSystem::~RenderSystem() {

	X3M_DEBUG ("RenderSystem", "Destructing...");
	
	// check if started, and then shut down
	if (mStateRunning)
		shutdown();

	// release d3d
	d3d_release();

	// unload dll
	d3d_unloadDLL();
}

//==========================================================================================

const RenderSystemCaps & RenderSystem::getCaps() const {
	return mCaps;
}

//==========================================================================================

void RenderSystem::initCaps()
{
	// clear caps data
	mCaps.clear();

	// set default devicetype to HAL
	D3DDEVTYPE usedDevType = D3DDEVTYPE_HAL;
	
	// copy description of gfx-board
	mCaps.mAdapterDesc = mD3DAdapterInfo[ADAPTER_DEFAULT].mDescription;

	// check HAL support
	mCaps.mSupportHAL  = mD3DAdapterInfo[ADAPTER_DEFAULT].mSupportHAL;

	// check supportHAL, and continue using referencerasterizer if not supported
	if (!mCaps.mSupportHAL)
		usedDevType = D3DDEVTYPE_REF;

	// get device format for 32 bit using the most optimal devicetype availbale
	D3DDeviceFormat * pDeviceFormat = mD3DAdapterInfo[ADAPTER_DEFAULT].getD3DDeviceInfo(usedDevType)->getD3DDeviceFormat(32);

	// if not ok, try 16 bit format
	if (!pDeviceFormat)
		pDeviceFormat = mD3DAdapterInfo[ADAPTER_DEFAULT].getD3DDeviceInfo(usedDevType)->getD3DDeviceFormat(16);

	// check again for safety, if neihter 16 nor 32 where found, give up man!!
	if (!pDeviceFormat)
		throw Exception ("No supported bitdepths on device, hw/driver error!");

	D3DCAPS8 d3dCaps = mD3DAdapterInfo[ADAPTER_DEFAULT].getD3DDeviceInfo(usedDevType)->mDeviceCaps;

	mCaps.mSupportWindowed = mD3DAdapterInfo[ADAPTER_DEFAULT].getD3DDeviceInfo(usedDevType)->mCanRenderWindowed;
	mCaps.mSupportFSAA = pDeviceFormat->mSupportFSAA;
	mCaps.mMultiSampleRateList = pDeviceFormat->mMultiSamples;
	mCaps.mDisplayModes = mD3DAdapterInfo[ADAPTER_DEFAULT].mDisplayModes;

	// set limits and other device-capabilites
	mCaps.mMaxActiveLights = d3dCaps.MaxActiveLights;
	mCaps.mMaxStreams = d3dCaps.MaxStreams;
	mCaps.mMaxStreamStride = d3dCaps.MaxStreamStride;
	mCaps.mMaxVertexIndex = d3dCaps.MaxVertexIndex;
	mCaps.mMaxTextureStages = d3dCaps.MaxSimultaneousTextures;
	mCaps.mMaxPrimitiveCount = d3dCaps.MaxPrimitiveCount;
	mCaps.mMaxTextureWidth = d3dCaps.MaxTextureWidth;
	mCaps.mMaxTextureHeight = d3dCaps.MaxTextureHeight;

	X3M_DEBUG ("RenderSystem", "Max active lights     %d", mCaps.mMaxActiveLights);
	X3M_DEBUG ("RenderSystem", "Max streams           %d", mCaps.mMaxStreams);
	X3M_DEBUG ("RenderSystem", "Max stream stride     %d", mCaps.mMaxStreamStride);
	X3M_DEBUG ("RenderSystem", "Max vertex index      %d", mCaps.mMaxVertexIndex);
	X3M_DEBUG ("RenderSystem", "Max texture stages    %d", mCaps.mMaxTextureStages);
	X3M_DEBUG ("RenderSystem", "Max primitives/batch  %d", mCaps.mMaxPrimitiveCount);
	X3M_DEBUG ("RenderSystem", "Max texture width     %d", mCaps.mMaxTextureWidth);
	X3M_DEBUG ("RenderSystem", "Max texture height    %d", mCaps.mMaxTextureHeight);

}

//==========================================================================================

void RenderSystem::startup() {

	X3M_ASSERT (mDirect3d);
	X3M_ASSERT (!mStateRunning);
		
	X3M_LOG ("RenderSystem", "Startup...");

	// convert configuration 
	d3d_buildPresentParameters();

	// create a new window
	int32 windowStyle = mD3Dpp.Windowed == TRUE ? Window::STYLE_WINDOW : Window::STYLE_PLAIN;
	mWindow.open(windowStyle, mD3Dpp.BackBufferWidth, mD3Dpp.BackBufferHeight, false);
	mWindow.setMsgQueue(this);
	mWindow.setCaption(mConfig.getParam(CFG_TITLE).getVal());
	mWindow.center();
	mWindow.show();

	// explicitly set d3dpp's windowhandle at startup as the hwnd where not valid before creation of mWindow
	mD3Dpp.hDeviceWindow = mWindow.getHWND();

	// create the direct 3d device
	d3d_createDevice();
	
	// create material
	mCurrentMaterial.create("", mCaps.mMaxTextureStages);

	// set is-active state
	mStateRunning = true;

	// set default renderstates
	initRenderStates();
}	

//==========================================================================================

void RenderSystem::shutdown() {

	if (mStateRunning) {
		
		X3M_DEBUG ("RenderSystem","Shutting down...");

		// flush resources
		flushUsedResources();

		// release device
		d3d_releaseDevice();

		// close target window
		mWindow.close();

		// init data to default
		init();

		// init default configuration
		initConfig();

		// reset running state
		mStateRunning = false;

		// null resource handles
		mCurrentVertexBuffer = NULL;
		mCurrentIndexBuffer = NULL;
	}
}

//==========================================================================================

void RenderSystem::flushUsedResources() {

	X3M_ASSERT (mD3DDevice);

	// flush all textures from vram
	for (int i =0; i < 8; i++)
		mD3DDevice->SetTexture(i ,NULL);

	// reset indexbuffer stream source
	mD3DDevice->SetIndices(NULL,0);

	// flush streamsource
	mD3DDevice->SetStreamSource(0, NULL, 0);
}

//==========================================================================================

void RenderSystem::setTitle(const std::string &title) {
	mWindow.setCaption(title);
}

//==========================================================================================

const bool RenderSystem::isStarted() const {
	return mStateRunning;
}

//==========================================================================================

const std::string & RenderSystem::getTitle() const {
	return mWindow.getCaption();
}

//==========================================================================================

void RenderSystem::setViewMatrix (const Matrix4x4 & matrix) {

	X3M_ASSERT (mDirect3d);
	X3M_ASSERT (mD3DDevice);
	
	mD3DDevice->SetTransform (D3DTS_VIEW, (D3DMATRIX*)&matrix);
}

//==========================================================================================

void RenderSystem::setWorldMatrix (const Matrix4x4 & matrix) {

	X3M_ASSERT (mDirect3d);
	X3M_ASSERT (mD3DDevice);
	
	mD3DDevice->SetTransform (D3DTS_WORLD, (D3DMATRIX*)&matrix);
}

//==========================================================================================

void RenderSystem::setProjectionMatrix (const Matrix4x4 & matrix) {

	X3M_ASSERT (mDirect3d);
	X3M_ASSERT (mD3DDevice);
	
	mD3DDevice->SetTransform (D3DTS_PROJECTION, (D3DMATRIX*)&matrix);
}

//==========================================================================================

IDirect3DDevice * RenderSystem::getD3DDevice() const {
	
	X3M_ASSERT (mD3DDevice);
	return mD3DDevice;
}

//==========================================================================================

void RenderSystem::setRenderTarget(const TextureHandle handle) {
	X3M_ASSERT (mD3DDevice);
}

//==========================================================================================

X3M_INLINE void RenderSystem::setFillMode(const Material::eFillMode fillMode) {

	if (!mForceMaterialUpdate && (fillMode == mCurrentMaterial.mFillMode))
		return;
	
	X3M_DEBUG ("RenderSystem", "SETTING FILLMODE!");
	mD3DDevice->SetRenderState(D3DRS_FILLMODE, fillMode);
	mCurrentMaterial.mFillMode = fillMode;
}


//==========================================================================================

X3M_INLINE void RenderSystem::setShadeMode(const Material::eShadeMode shadeMode) {

	if (!mForceMaterialUpdate && (shadeMode == mCurrentMaterial.mShadeMode))
		return;
	
	X3M_DEBUG ("RenderSystem", "SETTING SHADEMODE!");
	mD3DDevice->SetRenderState(D3DRS_SHADEMODE, shadeMode);
	mCurrentMaterial.mShadeMode = shadeMode;
}

//==========================================================================================

X3M_INLINE void RenderSystem::setColorSource(const Material::eColorSource ambient, const Material::eColorSource diffuse, const Material::eColorSource specular) {

	if ((mCurrentMaterial.mDiffuseColorSource != diffuse) || (mForceMaterialUpdate)) {
		X3M_DEBUG ("RenderSystem", "SETTING COLORSRC!");
		mD3DDevice->SetRenderState(D3DRS_DIFFUSEMATERIALSOURCE, D3DMATERIALCOLORSOURCE(diffuse));
		mCurrentMaterial.mDiffuseColorSource = diffuse;
	}

	if ((mCurrentMaterial.mSpecularColorSource != specular) || (mForceMaterialUpdate)){
		X3M_DEBUG ("RenderSystem", "SETTING COLORSRC!");
		mD3DDevice->SetRenderState(D3DRS_SPECULARMATERIALSOURCE, D3DMATERIALCOLORSOURCE(specular));
		mCurrentMaterial.mSpecularColorSource = specular;
	}

	if ((mCurrentMaterial.mAmbientColorSource != ambient)|| (mForceMaterialUpdate)) {
		X3M_DEBUG ("RenderSystem", "SETTING COLORSRC!");
		mD3DDevice->SetRenderState(D3DRS_AMBIENTMATERIALSOURCE , D3DMATERIALCOLORSOURCE(ambient));    
		mCurrentMaterial.mSpecularColorSource = ambient;	
	}
}

//==========================================================================================

X3M_INLINE void RenderSystem::setLighting(const bool lightEnable) {

	if ((mCurrentMaterial.mLightingEnable != lightEnable) || (mForceMaterialUpdate)) {
			
		X3M_DEBUG ("RenderSystem", "SETTING LIGHTING!");
		mD3DDevice->SetRenderState(D3DRS_LIGHTING, lightEnable ? TRUE : FALSE);
		mCurrentMaterial.mLightingEnable = lightEnable;
	}
}

//==========================================================================================

X3M_INLINE void RenderSystem::setSurfaceColor(const ColorValue &ambient, const ColorValue &diffuse, const ColorValue &specular) {

	static D3DMATERIAL8 d3dMaterial;
	
	// set surface/material attributes
	d3dMaterial.Ambient.r = ambient.mR;
	d3dMaterial.Ambient.g = ambient.mG;
	d3dMaterial.Ambient.b = ambient.mB;
	d3dMaterial.Ambient.a = diffuse.mA;

	d3dMaterial.Diffuse.r = diffuse.mR;
	d3dMaterial.Diffuse.g = diffuse.mG;
	d3dMaterial.Diffuse.b = diffuse.mB;
	d3dMaterial.Diffuse.a = diffuse.mA;

	d3dMaterial.Specular.r = specular.mR;
	d3dMaterial.Specular.g = specular.mG;
	d3dMaterial.Specular.b = specular.mB;
	d3dMaterial.Specular.a = specular.mA;
	

	// enable this material 
	mD3DDevice->SetMaterial(&d3dMaterial);
}

//==========================================================================================

X3M_INLINE void RenderSystem::setCullMode(const Material::eCullMode cullMode) {

	if ((mCurrentMaterial.mCullMode != cullMode) || (mForceMaterialUpdate)) {

		X3M_DEBUG ("RenderSystem", "SETTING CULLMODE!");
		mD3DDevice->SetRenderState(D3DRS_CULLMODE, cullMode);
		mCurrentMaterial.mCullMode = cullMode;
	}
}

//==========================================================================================

X3M_INLINE void RenderSystem::setTexture(const int32 stage, const TextureHandle handle) {
	
	// check if we should disable this texture on this stage
	if (handle.isNull()) {

		mD3DDevice->SetTexture(stage, NULL);
		mCurrentMaterial.mTextureLayers[stage].mTexture = NULL;
		mCurrentMaterial.mTextureLayers[stage].mEnabled = false;
		return;
	}
	
	// check if this texture already is activated on this stage
	if ((mCurrentMaterial.mTextureLayers[stage].mTexture == handle.getObject()) || (mForceMaterialUpdate)) {
		return;
	}
	
	// update current stage
	mCurrentMaterial.mTextureLayers[stage].mTexture = handle;

	// upload texture to device
	mD3DDevice->SetTexture(stage, handle->getD3DTexture());	
}

//==========================================================================================

X3M_INLINE void RenderSystem::setTextureCoordIndex(const int32 stage, const TextureLayer::eCoordIndex texCoordIndex) {

	// only change if needed
	if ((!mForceMaterialUpdate) && (texCoordIndex == mCurrentMaterial.mTextureLayers[stage].mCoordIndex))
		return;

	mD3DDevice->SetTextureStageState(stage, D3DTSS_TEXCOORDINDEX, texCoordIndex);
	mCurrentMaterial.mTextureLayers[stage].mCoordIndex = texCoordIndex;
}

//==========================================================================================

X3M_INLINE void RenderSystem::unsetTextureLayer(const int32 stage) {
	
	if (mCurrentMaterial.mTextureLayers[stage].mEnabled) {

		mCurrentMaterial.mTextureLayers[stage].mEnabled = false;
		mCurrentMaterial.mTextureLayers[stage].mTexture = NULL;
		mD3DDevice->SetTexture(stage, NULL);
	}

	X3M_DEBUG ("RenderSystem", "TextureLayer (%d) deactivated...", stage);
}

//==========================================================================================

X3M_INLINE void RenderSystem::setTextureLayer(const int32 stage, const TextureLayer * textureLayer) {
		
	X3M_ASSERT (textureLayer);

	if (!textureLayer->mEnabled) {
		unsetTextureLayer(stage);
		return;
	} 
	
	mCurrentMaterial.mTextureLayers[stage].mEnabled = true;

	/*** Check if we must force update of texturestage states */
	if (mForceMaterialUpdate) {

		mD3DDevice->SetTextureStageState(stage, D3DTSS_MINFILTER, textureLayer->mFilter);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_MAGFILTER, textureLayer->mFilter);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_MIPFILTER, textureLayer->mFilter);
		mCurrentMaterial.mTextureLayers[stage].mFilter = textureLayer->mFilter;
		
		// set texturea addressing mode
		mD3DDevice->SetTextureStageState(stage, D3DTSS_ADDRESSU, textureLayer->mAddressMode);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_ADDRESSV, textureLayer->mAddressMode);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_ADDRESSW, textureLayer->mAddressMode);
		mCurrentMaterial.mTextureLayers[stage].mAddressMode = textureLayer->mAddressMode;

		mD3DDevice->SetTextureStageState(stage, D3DTSS_TEXCOORDINDEX, textureLayer->mCoordIndex);
		mCurrentMaterial.mTextureLayers[stage].mCoordIndex = textureLayer->mCoordIndex;
	
		mD3DDevice->SetTexture (stage, textureLayer->mTexture->getD3DTexture());
		mCurrentMaterial.mTextureLayers[stage].mTexture = textureLayer->mTexture;

		mD3DDevice->SetTextureStageState(stage, D3DTSS_ALPHAOP		, D3DTOP_MODULATE);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_ALPHAARG1	, D3DTA_TFACTOR);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_ALPHAARG2	, D3DTA_TFACTOR);

		mD3DDevice->SetTextureStageState(stage, D3DTSS_COLORARG1	, D3DTA_TEXTURE);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_COLORARG2	, D3DTA_CURRENT);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_COLOROP		, D3DTOP_BLENDFACTORALPHA);

		return;
	}

	// check texture filtering
	if (mCurrentMaterial.mTextureLayers[stage].mFilter != textureLayer->mFilter) {
		mD3DDevice->SetTextureStageState(stage, D3DTSS_MINFILTER, textureLayer->mFilter);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_MAGFILTER, textureLayer->mFilter);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_MIPFILTER, textureLayer->mFilter);
		mCurrentMaterial.mTextureLayers[stage].mFilter = textureLayer->mFilter;
	}

	// check texture U/V/W addressmode
	if (mCurrentMaterial.mTextureLayers[stage].mAddressMode != textureLayer->mAddressMode) {
		mD3DDevice->SetTextureStageState(stage, D3DTSS_ADDRESSU, textureLayer->mAddressMode);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_ADDRESSV, textureLayer->mAddressMode);
		mD3DDevice->SetTextureStageState(stage, D3DTSS_ADDRESSW, textureLayer->mAddressMode);
		mCurrentMaterial.mTextureLayers[stage].mAddressMode = textureLayer->mAddressMode;
	}
	
	// check texture-coordinate index
	if (mCurrentMaterial.mTextureLayers[stage].mCoordIndex != textureLayer->mCoordIndex) {
		mD3DDevice->SetTextureStageState(stage, D3DTSS_TEXCOORDINDEX, textureLayer->mCoordIndex);
		mCurrentMaterial.mTextureLayers[stage].mCoordIndex = textureLayer->mCoordIndex;
	}

	// check texture data
	if (mCurrentMaterial.mTextureLayers[stage].mTexture != textureLayer->mTexture.getObject()) {
		mD3DDevice->SetTexture (stage, textureLayer->mTexture->getD3DTexture());
		mCurrentMaterial.mTextureLayers[stage].mTexture = textureLayer->mTexture;
	}
	
	// check layer blendmodex
/*	
	mD3DDevice->SetTextureStageState(stage, D3DTSS_ALPHAOP		, D3DTOP_MODULATE);
	mD3DDevice->SetTextureStageState(stage, D3DTSS_ALPHAARG1	, D3DTA_TFACTOR);
	mD3DDevice->SetTextureStageState(stage, D3DTSS_ALPHAARG2	, D3DTA_TFACTOR);

	mD3DDevice->SetTextureStageState(stage, D3DTSS_COLORARG1	, D3DTA_TEXTURE);
	mD3DDevice->SetTextureStageState(stage, D3DTSS_COLORARG2	, D3DTA_CURRENT);
	mD3DDevice->SetTextureStageState(stage, D3DTSS_COLOROP		, D3DTOP_BLENDFACTORALPHA);
*/

	
}

//==========================================================================================

X3M_INLINE void RenderSystem::setTextureFilter(const int32 stage, const TextureLayer::eFilter textureFilter) {

	// only change if needed
//	if ((!mForceMaterialUpdate) && (textureFilter == mCurrentMaterial.mTextureLayers[stage].mFilter))
//		return;

	// update d3d device
//	mD3DDevice->SetTextureStageState(stage, D3DTSS_MINFILTER, textureFilter);
	mD3DDevice->SetTextureStageState(stage, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);//textureFilter);
//	mD3DDevice->SetTextureStageState(stage, D3DTSS_MIPFILTER, textureFilter);

	mCurrentMaterial.mTextureLayers[stage].mFilter = textureFilter;

}

//==========================================================================================

X3M_INLINE void RenderSystem::setTextureAddressMode(const int32 stage, const TextureLayer::eAddressMode textureAddressing) {

	if ((!mForceMaterialUpdate) && (textureAddressing == mCurrentMaterial.mTextureLayers[stage].mAddressMode))
		return;
		
	// set addressing mode i corrent stage
	mD3DDevice->SetTextureStageState(stage, D3DTSS_ADDRESSU, textureAddressing);
	mD3DDevice->SetTextureStageState(stage, D3DTSS_ADDRESSV, textureAddressing);
	mD3DDevice->SetTextureStageState(stage, D3DTSS_ADDRESSW, textureAddressing);

	mCurrentMaterial.mTextureLayers[stage].mAddressMode = textureAddressing;
}

//==========================================================================================

X3M_INLINE void RenderSystem::setDepthBufferMode(const bool depthEnable, const bool depthWriteEnable) {
	
	// set depthbuffering enabled
	if (mForceMaterialUpdate || (mCurrentMaterial.mDepthBufferEnable != depthEnable)) {
		mD3DDevice->SetRenderState(D3DRS_ZENABLE, depthEnable ? D3DZB_TRUE : D3DZB_FALSE);
		mCurrentMaterial.mDepthBufferEnable = depthEnable;
	}

	// set depthbuffer writes enabled
	if (mForceMaterialUpdate || (mCurrentMaterial.mDepthWriteEnable != depthWriteEnable)) {
		mD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE, depthWriteEnable ? TRUE : FALSE);
		mCurrentMaterial.mDepthWriteEnable = depthWriteEnable;
	}
}

//==========================================================================================

X3M_INLINE void RenderSystem::setSceneBlendMode(const bool blendEnable, const BlendMode &blendMode) {
	
	if (!blendEnable) {

		if (mCurrentMaterial.mBlendEnable == false)
			return;

		X3M_DEBUG ("RenderSystem", "Deactivate alphablending!");
		mD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
		mCurrentMaterial.mBlendEnable = false;
		return;
	}
	
	mD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	mCurrentMaterial.mBlendEnable = true;
	X3M_DEBUG ("RenderSystem", "Activate alphablending!");

	// set source-blending factor
	if ((mCurrentMaterial.mBlendMode.mSrcFactor != blendMode.mSrcFactor) || mForceMaterialUpdate) {
		
		X3M_DEBUG ("RenderSystem", "Set material blend.srcfactor!");
		mD3DDevice->SetRenderState(D3DRS_SRCBLEND, (D3DBLEND)blendMode.mSrcFactor);
		mCurrentMaterial.mBlendMode.mSrcFactor = blendMode.mSrcFactor;
	}

	// set dest-blending factor
	if ((mCurrentMaterial.mBlendMode.mDstFactor != blendMode.mDstFactor) || mForceMaterialUpdate) {
		
		X3M_DEBUG ("RenderSystem", "Set material blend.dstfactor!");
		mD3DDevice->SetRenderState(D3DRS_DESTBLEND, (D3DBLEND)blendMode.mDstFactor);
		mCurrentMaterial.mBlendMode.mDstFactor = blendMode.mDstFactor;
	}

	// set blending operation
	if ((mCurrentMaterial.mBlendMode.mOp != blendMode.mOp) || mForceMaterialUpdate) {
		
		X3M_DEBUG ("RenderSystem", "Set material blend.op!");
		mD3DDevice->SetRenderState(D3DRS_BLENDOP, (D3DBLEND)blendMode.mOp);
		mCurrentMaterial.mBlendMode.mOp = blendMode.mOp;
	}
}

//==========================================================================================

void RenderSystem::setMaterial(const Material * pMaterial) {
	
	X3M_ASSERT (mD3DDevice);
	X3M_ASSERT (pMaterial);

	// set renderstates
	setSurfaceColor(pMaterial->mAmbient, pMaterial->mDiffuse, pMaterial->mSpecular);
	setFillMode(pMaterial->mFillMode);
	setShadeMode(pMaterial->mShadeMode);
	setCullMode(pMaterial->mCullMode);
	setColorSource(pMaterial->mAmbientColorSource, pMaterial->mDiffuseColorSource, pMaterial->mSpecularColorSource);
	setLighting(pMaterial->mLightingEnable);
	setDepthBufferMode(pMaterial->mDepthBufferEnable, pMaterial->mDepthWriteEnable);
	setSceneBlendMode(pMaterial->mBlendEnable, pMaterial->mBlendMode);

	// deactivate unused texturelayers	
	int32 inactiveLayers = mCaps.mMaxTextureStages - pMaterial->mTextureLayers.size();

	X3M_DEBUG ("RenderSystem", "Material contained (%d) unused layers, deactive their corresponding layers",inactiveLayers);	

	for (int iTextureLayer = mCaps.mMaxTextureStages-1; iTextureLayer >= pMaterial->mTextureLayers.size(); iTextureLayer--) 
		unsetTextureLayer(iTextureLayer);

	for (iTextureLayer=0; iTextureLayer < pMaterial->mTextureLayers.size(); iTextureLayer++)
		setTextureLayer(iTextureLayer, &(pMaterial->mTextureLayers[iTextureLayer]));

	//for (int i = 2; i >= pMaterial->mTextureLayers.size(); i--) 
	//	unsetTextureLayer(i);
}

//==========================================================================================

const DisplayMode & RenderSystem::getDisplayMode() const {
	return mCurrentDeviceMode;
}

//==========================================================================================

void RenderSystem::beginScene() {

	X3M_ASSERT (mD3DDevice!=NULL);
	X3M_ASSERT (!mD3DDeviceInScene);
	
	// clear rendertarget and depthbuffer and initialize a new scene
	HRESULT res = mD3DDevice->BeginScene();
	if (res != D3D_OK)
		throw Exception ("Unable to begin scene, reason (%s)", mD3DUtil.resultToString(res));

	mD3DDeviceInScene = true;
}

//==========================================================================================

void RenderSystem::clear(const uint32 flags, const ColorValue &clearColor,
	const float32 z, const uint32 stencil) {

	 X3M_ASSERT (mD3DDevice!=NULL);
	 DWORD d3dFlags = 0;

	 // check target buffers
	 if (flags & RenderSystem::CLEAR_STENCIL)
	  d3dFlags |= D3DCLEAR_STENCIL;
	 if (flags & RenderSystem::CLEAR_DEPTH)
	  d3dFlags |= D3DCLEAR_ZBUFFER;
	 if (flags & RenderSystem::CLEAR_TARGET)
	  d3dFlags |= D3DCLEAR_TARGET;

	 if (mD3DDevice->Clear(0,NULL,d3dFlags,clearColor.toIntARGB(), z, stencil)
	!= D3D_OK)
	  throw Exception ("Unable to clear depth/stencil or target buffer!");
}

//==========================================================================================

void RenderSystem::present() {

	// check for a lost device
	HRESULT res = mD3DDevice->Present(NULL, NULL, 0 , NULL);
	
	if (res != D3D_OK) {

		// reset the lost device
		if (res == D3DERR_DEVICELOST) {
			Debug::error ("RenderSystem", "Lost device detected, attempt to reset...");
			d3d_resetDevice();
			return;
		}

		throw Exception ("Failed to present rendered image, reason (%s)", mD3DUtil.resultToString(res));
	}
}

//==========================================================================================

void RenderSystem::endScene() {

	X3M_ASSERT (mD3DDevice!=NULL);
	X3M_ASSERT (mD3DDeviceInScene);
	
	// end scene
	mD3DDevice->EndScene();

	// reset flag
	mD3DDeviceInScene = false;
}

//==========================================================================================

void RenderSystem::reset() {

	X3M_ASSERT (mDirect3d);
	X3M_ASSERT (mD3DDevice);

	// build present parameters and reset device
	d3d_buildPresentParameters();
	d3d_resetDevice();

	// check if we should change the apperenace of the window
	int32 windowStyle = mD3Dpp.Windowed == TRUE ? Window::STYLE_WINDOW : Window::STYLE_PLAIN;
	mWindow.setStyle(Window::eWindowStyle(windowStyle));

	/** 
	 * Resize window - we might have changed resolution 
	 * the reason wy this is done "after" the reset, is that we might have been in a 
	 * fullscreen 640,480 format and changed to Windowed with 800,600. Window's doesnt 
	 * allow a window to have larger dimensions than the actual current displaymode.
	 */
	mWindow.resize(0,0, mD3Dpp.BackBufferWidth, mD3Dpp.BackBufferHeight, true);
}

//==========================================================================================

void RenderSystem::init() {

	X3M_LOG ("RenderSystem", "Initiating members to default values");

	// reset system states
	mStateRunning = false;
	mD3DDevice	= NULL;
	mD3DDeviceLost = false;
	mD3DDeviceInScene = false;
	mCurrentDeviceType = D3DDEVTYPE_HAL;

	// set default d3dpp
	memset(&mD3Dpp, 0, sizeof (mD3Dpp));
}

//==========================================================================================

void RenderSystem::initConfig() {

	// clear configuration map
	mConfig.clear();
	
	// register default parameters and set their corresponding defaultvalues
	mConfig.registerParam(CFG_TITLE				, "Extreme 3D Engine");
	mConfig.registerParam(CFG_WINDOWED			, "true");
	mConfig.registerParam(CFG_WIDTH				, "640");
	mConfig.registerParam(CFG_HEIGHT			, "480");
	mConfig.registerParam(CFG_BITDEPTH			, "32");

	mConfig.registerParam(CFG_BACKBUFFER_COUNT	, "1");
	mConfig.registerParam(CFG_VSYNC				, "true");
	mConfig.registerParam(CFG_LAYER				, "hal");	

	mConfig.registerParam(CFG_FSAA_SAMPLES		, "0");
	mConfig.registerParam(CFG_FSAA_ENABLE		, "false");
}

//==========================================================================================

void RenderSystem::initRenderStates() {
	
	// set flag to force stateupdates to be flushed to gfxboard
	mForceMaterialUpdate = true;

	// set current material, and force to flush states to board
	setMaterial(&mCurrentMaterial);

	// done updating, reset flag
	mForceMaterialUpdate = false;
	// create default material 
}

//==========================================================================================

const bool RenderSystem::config(const std::string &parameter, const ConfigValue value) {

	// check if parameter exist
	return mConfig.setParam(parameter, value);
}

//==========================================================================================

void RenderSystem::setViewPort(const ViewPort &viewPort) {

	X3M_ASSERT (mD3DDevice);

	// get viewport from device
	D3DVIEWPORT d3dViewPort;

	d3dViewPort.X		= viewPort.getLeft();
	d3dViewPort.Y		= viewPort.getTop();
	d3dViewPort.Width	= viewPort.getWidth();
	d3dViewPort.Height	= viewPort.getHeight();
	d3dViewPort.MinZ	= viewPort.getMinZDepth();
	d3dViewPort.MaxZ	= viewPort.getMaxZDepth();
	
	// apply viewport on device
	HRESULT res = mD3DDevice->SetViewport(&d3dViewPort);
	
	if (res != D3D_OK)
		throw Exception ("RenderSystem could not set viewport on device! reson(%s)", mD3DUtil.resultToString(res));
}

//==========================================================================================

const ViewPort & RenderSystem::getViewPort() const {
	
	X3M_ASSERT (mD3DDevice);
	
	static D3DVIEWPORT d3dViewPort;
	static ViewPort viewPort;

	// get viewport from device
	HRESULT res = mD3DDevice->GetViewport(&d3dViewPort);

	// check result
	if (res != D3D_OK)
		throw Exception ("RenderSystem could not get viewport from device, reason (%s)", mD3DUtil.resultToString(res));

	// convert to extreme viewport
	viewPort.setWidth (d3dViewPort.Width);
	viewPort.setHeight (d3dViewPort.Height);
	viewPort.setLeft (d3dViewPort.X);
	viewPort.setTop (d3dViewPort.Y);
	viewPort.setMaxZDepth (d3dViewPort.MaxZ);
	viewPort.setMinZDepth (d3dViewPort.MinZ);
	
	return viewPort;
}

//==========================================================================================

void RenderSystem::setIndexBuffer(IndexBufferHandle indexBuffer, const int32 baseIndexOffs) {

	// check if we should deactivate streamsource
	if (indexBuffer.isNull()) {

		mD3DDevice->SetIndices(NULL, 0);
		mCurrentIndexBuffer = NULL;
		return;
	}

	// only set vertexbuffer if differs from what is already set
	if (!(indexBuffer == mCurrentIndexBuffer.getObject())) {

		mD3DDevice->SetIndices(indexBuffer->getD3DIndexBuffer(), baseIndexOffs);
		mCurrentIndexBuffer = indexBuffer;
	}
}

//==========================================================================================

void RenderSystem::setVertexBuffer(VertexBufferHandle vertexBuffer) {
	
	// check if we should deactivate streamsource
	if (vertexBuffer.isNull()) {

		mD3DDevice->SetStreamSource(0, NULL, 0);
		mCurrentVertexBuffer = NULL;
		return;
	}

	// only set vertexbuffer if differs from what is already set
	if (!(vertexBuffer == mCurrentVertexBuffer.getObject())) {

		X3M_DEBUG ("RenderSystem", "vertexbuffer numverts(%d), stride(%d), format (%d)", vertexBuffer->getSize(), vertexBuffer->getStride(), vertexBuffer->getFormat);
		
		if (mD3DDevice->SetVertexShader(vertexBuffer->getFormat()) != D3D_OK)
			throw Exception ("SetShader!");

		if (vertexBuffer->getD3DVertexBuffer() == NULL)
			throw Exception ("SetStreamSource!");

		if (mD3DDevice->SetStreamSource(0, vertexBuffer->getD3DVertexBuffer(), vertexBuffer->getStride()) != D3D_OK)
			throw Exception ("SetStreamSource!");

		mCurrentVertexBuffer = vertexBuffer;
	}
}

//==========================================================================================

void RenderSystem::renderPrimitive(const VertexBuffer::ePrimitiveType pType, const int32 numPrimitives, const int32 startVertex) {

	X3M_ASSERT (mD3DDevice);
	HRESULT res = mD3DDevice->DrawPrimitive((D3DPRIMITIVETYPE)pType, startVertex, numPrimitives);
	if (res != D3D_OK)
		throw Exception ("RenderSystem, DrawPrimitive failed, reason(%s)", mD3DUtil.resultToString(res));
}

//==========================================================================================

void RenderSystem::renderIndexedPrimitive(const VertexBuffer::ePrimitiveType pType, const int32 numPrimitives, const int32 startIndex) {

	X3M_ASSERT (mD3DDevice);
	X3M_ASSERT (!mCurrentIndexBuffer.isNull());
	uint32 numVertices = mCurrentIndexBuffer->getSize();
	mD3DDevice->DrawIndexedPrimitive((D3DPRIMITIVETYPE)pType, 0, numVertices, startIndex, numPrimitives);
}

//==========================================================================================
// RenderSystem lowlevel D3D routines
//==========================================================================================

void RenderSystem::d3d_loadDLL() {

	X3M_LOG ("RenderSystem", "Loading Direct3D DLL [%s]", X3M_D3D_DLL);

	// load d3d.dll in address soace
	mD3DModule = LoadLibrary(X3M_D3D_DLL);

	if (!mD3DModule)
		throw Exception("RenderSystem::d3d_loadDLL", "Could not find d3d8.dll!");

	// export top create COM object metod
	X3M_LOG ("RenderSystem", "Export Direct3DCreate8");
	gDirect3DCreate = (D3DCREATEFUNC)GetProcAddress(mD3DModule, "Direct3DCreate8");

	if (!gDirect3DCreate)
		throw Exception("RenderSystem::d3d_loadDLL", "Could not export Direct3DCreate8 from DLL");
}

//==========================================================================================

void RenderSystem::d3d_unloadDLL() {

	X3M_LOG ("RenderSystem", "Unloading Direct3D DLL");
	
	// unload DLL
	if (mD3DModule) {

		FreeLibrary (mD3DModule);
		mD3DModule = NULL;
	}
}

//==========================================================================================


void RenderSystem::d3d_create() {
	
	X3M_ASSERT(gDirect3DCreate);

	X3M_LOG ("RenderSystem", "Intializing Hardware (D3D) Sub System...");

	mDirect3d = gDirect3DCreate(D3D_SDK_VERSION);	

	if (!mDirect3d) 
		throw Exception("RenderSystem::d3d_create", "Could not create IDirect3D8 interface");

	d3d_enumerateAdapters();
}

//==========================================================================================

void RenderSystem::d3d_release() {

	X3M_LOG ("RenderSystem", "Shutting down hardware (D3D) Sub System...");
	
	// release direct3d interface
	COM_SAFE_RELEASE(mD3DDevice);
	COM_SAFE_RELEASE(mDirect3d);

	// destroy, delete adapterinfo informatation
	mD3DAdapterInfo.clear();

	// clear members
	init();
}

//==========================================================================================

D3DFORMAT RenderSystem::d3d_getCompatibleDepthStencilFormat(const int32 adapter, D3DDEVTYPE devType, D3DFORMAT renderTarget) {

	/// check rendertarget and return best available depth/stencil buffer format
	switch (mD3DUtil.formatToBitDepth(renderTarget)) {

	/**
	 * Check 32/24 bit depth/stencil formats
	 */
	case 32:
	case 24:	
		if (d3d_confirmDepthStencilFormat(adapter, devType, renderTarget, D3DFMT_D24S8))
			return D3DFMT_D24S8;
		if (d3d_confirmDepthStencilFormat(adapter, devType, renderTarget, D3DFMT_D24X4S4))
			return D3DFMT_D24X4S4;
		if (d3d_confirmDepthStencilFormat(adapter, devType, renderTarget, D3DFMT_D32))
			return D3DFMT_D32;
		if (d3d_confirmDepthStencilFormat(adapter, devType, renderTarget, D3DFMT_D24X8))
			return D3DFMT_D24X8;
	
	/**
	 * Fall through, if no 32/24 depth/stencil bitformats exists for a 32/24 rendertarget
	 * continue looking for a 15/16 bitmode
	 */
	case 16:

		/// check 15/16 bit modes
		if (d3d_confirmDepthStencilFormat(adapter, devType, renderTarget, D3DFMT_D15S1))
			return D3DFMT_D15S1;
		if (d3d_confirmDepthStencilFormat(adapter, devType, renderTarget, D3DFMT_D16))
			return D3DFMT_D16;
		if (d3d_confirmDepthStencilFormat(adapter, devType, renderTarget, D3DFMT_D16_LOCKABLE))
			return D3DFMT_D16_LOCKABLE;
	}

	return D3DFMT_UNKNOWN;
}

//==========================================================================================

void RenderSystem::d3d_resetDevice() {

	HRESULT res;

	// set device lost indicator to true
	mD3DDeviceLost = true;

	// flush all resources currently used as targets/streamsource and so on
	flushUsedResources();

	// flush all hardware/loose resources allocated in VRAM
	ResourceManager::flush();

	// continue attempts until we successfully manage to reset the device
	while (mD3DDeviceLost) {

		// test cooperative level of device
		res = mD3DDevice->TestCooperativeLevel();
	
		switch (res) 
		{	
		// device is lost, sleep for a while and continue testing until success
		case D3DERR_DEVICELOST:
			Sleep(50);
			X3M_DEBUG ("RenderSystem", "Device still lost, sleep another 50ms");
		break;
		
		// device is not reset, reset device and continue execution of application
		case D3D_OK:
		case D3DERR_DEVICENOTRESET:
		
			// reset d3d-device
			if (mD3DDevice->Reset(&mD3Dpp) != D3D_OK)
				throw Exception ("RenderSystem where not able to reset the current device!");

			// reset state
			mD3DDeviceLost = false;

			// restore all hw resources
			ResourceManager::restore();
			
			// set all current renderstates when device is restored
			initRenderStates();

		break;
		}
	}
}

//==========================================================================================

const bool RenderSystem::d3d_confirmDepthStencilFormat(const int32 adapter, D3DDEVTYPE devType, D3DFORMAT renderTarget, D3DFORMAT dsFormat) {

	/// first check so that the format is ok as rendertarget
	if (mDirect3d->CheckDeviceFormat(adapter, devType, renderTarget, D3DUSAGE_DEPTHSTENCIL, D3DRTYPE_SURFACE, dsFormat) == D3D_OK) {

		// then check the depth/stencil format
		if (mDirect3d->CheckDepthStencilMatch(adapter, devType, renderTarget, renderTarget, dsFormat) == D3D_OK) {

			/// yes, found a compatible depth/stencil format
			return true;
		}
	}

	// format not confirmed, return false
	return false;
}

//==========================================================================================

void RenderSystem::d3d_enumerateAdapters() {

	X3M_ASSERT(mDirect3d);

	/// parse through all adapters
	int32						adapterCount = mDirect3d->GetAdapterCount();
	std::vector<D3DFORMAT>		formats;
	std::vector<bool>			formatsConfirmed;
	std::vector<D3DFORMAT>		depthStencilFormats;
	std::vector<D3DDISPLAYMODE> displayModes;
	D3DDEVTYPE					deviceTypes[] = {D3DDEVTYPE_HAL, D3DDEVTYPE_REF};
	char *						deviceTypeDescr[] = {"HAL", "REF"};
	
	
	// clear mD3DAdapterInfo
	mD3DAdapterInfo.clear();

	/// resize list
	mD3DAdapterInfo.resize(adapterCount);
	X3M_DEBUG ("RenderSystem","Found [%d] adapters on host", adapterCount); 

	/**
	 * Parse through all adaptern on host
	 * ==================================
	 */	
	
	/// parse through all displaymodes
	for (int indexAdapter=0; indexAdapter < adapterCount; indexAdapter++) {
		
		D3DAdapterInfo * pAdapterInfo = &mD3DAdapterInfo[indexAdapter];
		D3DADAPTER_IDENTIFIER adapterIdentifier;
		
		/// save direct3d's index, which it use to reffer to this adapter later on
		pAdapterInfo->mAdapterIndex = indexAdapter;

		/// retrieve adapterinfo
		mDirect3d->GetAdapterIdentifier(indexAdapter, 0, &adapterIdentifier);

		// retrive nescessary information from AdapterIdentifier
		pAdapterInfo->mDriver = adapterIdentifier.Driver;
		pAdapterInfo->mDescription = adapterIdentifier.Description;


		// print debug info about description/driver
		X3M_DEBUG ("hardware", "Adapter [%d] Descr. : [%s]", indexAdapter, pAdapterInfo->mDescription.c_str());
		X3M_DEBUG ("Hardware", "Adapter [%d] Driver : [%s]", indexAdapter, pAdapterInfo->mDriver.c_str());
		
		// get desktop displaymode
		mDirect3d->GetAdapterDisplayMode(indexAdapter, &pAdapterInfo->mDesktopMode);

		/**
		 * 1.	Check all displaymodes supported on adapter
		 *		Only save those of interest (w>640, h>400, bpp>8)
		 * ======================================================== 
		 */
		for (int indexMode = 0; indexMode < mDirect3d->GetAdapterModeCount(indexAdapter); indexMode++) {


			D3DDISPLAYMODE mode;
			mDirect3d->EnumAdapterModes(indexAdapter, indexMode, &mode);
			
			bool newMode = true;
		
			// skip modes with less resolutuion that 640x400
			if ((mode.Width < 640) || (mode.Height < 400) || (mD3DUtil.formatToBitDepth(mode.Format) == 0))
				continue;

			// remove duplicate modes with just an equal refreshrate
			for (int iMode = 0; iMode < displayModes.size(); iMode++) {

				// check mode already exist, only different refresh reate
				if ((displayModes[iMode].Width  == mode.Width) &&
				    (displayModes[iMode].Height == mode.Height) &&
				    (displayModes[iMode].Format == mode.Format))					
					newMode = false;
			}
			
			// insert mode in list
			if (newMode) {
			
				// convert mode to Extreme::DisplayMode
				uint32 r,g,b,a;
				DisplayMode displayMode (mode.Width, mode.Height, mD3DUtil.formatToBitDepth(mode.Format));				
				mD3DUtil.formatToBitMasks(mode.Format, r,g,b,a);
				displayMode.setBitMasks(r,g,b,a);

				// add to adapters displaymode list
				pAdapterInfo->mDisplayModes.push_back(displayMode);
				
				// store mode in d3d displaymode list aswell
				displayModes.push_back(mode);				
			}

			// check for formats, add to list if new
			bool newFormat = true;
			for (int iFormat = 0; iFormat < formats.size(); iFormat++) {
			
				if (formats[iFormat] == mode.Format) {
					newFormat = false;
					break;
				}
			}
		
			// add to list if format was not located in list already
			if (newFormat)
				formats.push_back(mode.Format);
			
		}
		
		/**
		 * 2.	Confirm and enumerate devicetypes on adapter(s)
		 *		Check all formats for windowed support and which
		 *		formats that can be used as rendertargets.
		 * ========================================================
		 */
		for (int indexDeviceType = 0; indexDeviceType < 2; indexDeviceType++) {
			
			X3M_DEBUG ("", "");
			X3M_DEBUG (deviceTypeDescr[indexDeviceType], "%s", pAdapterInfo->mDescription.c_str());

			std::vector<uint32> behaviours;
			
			D3DDeviceInfo * pDeviceInfo = &mD3DAdapterInfo[indexAdapter].mDevices[indexDeviceType];
			
			/// resize behaviours to match size of gormats
			behaviours.resize(formats.size());

			// retrieve device capabilities
			if (mDirect3d->GetDeviceCaps(indexAdapter, deviceTypes[indexDeviceType], &pDeviceInfo->mDeviceCaps) != D3D_OK) {

				if (deviceTypes[indexDeviceType] == D3DDEVTYPE_HAL) {

					pAdapterInfo->mSupportHAL = false;
					X3M_LOG ("*","supports HAL [NO]");
					continue;
				}
				else {

					// throw exception, if device does not support a REF device, we give up... sorry
					Debug::error ("*","no supported devices!", pAdapterInfo->mDescription.c_str());
					throw Exception("Adapter [%s] has no supported D3D devices!", pAdapterInfo->mDescription.c_str());
				}
			}

			// HAL is supported on device
			if (deviceTypes[indexDeviceType] == D3DDEVTYPE_HAL)
				pAdapterInfo->mSupportHAL = true;
			
			// default windowmode compatible to true
			pDeviceInfo->mCanRenderWindowed = true;

			/// resize depth/stencil and formatsConfirmed - match size of formats
			depthStencilFormats.resize(formats.size());
			formatsConfirmed.resize(formats.size());

			// check which formats the device supports
			for (int indexFormat = 0; indexFormat < formats.size(); indexFormat++) {

				X3M_DEBUG ("*", "format %d bpp", formats[indexFormat]);

				/**
				 * Check for windowed rendering support on device
				 * by comparing the formats in list with the desktop's.
				 * if equal - call CheckDeviceType and invesitate result
				 */
				if (pAdapterInfo->mDesktopMode.Format == formats[indexFormat]) {

					// set last parameter to true(windowed)
					if (mDirect3d->CheckDeviceType(indexAdapter, deviceTypes[indexDeviceType], formats[indexFormat], formats[indexFormat], TRUE) != D3D_OK)
						pDeviceInfo->mCanRenderWindowed = false;
				}

				// check for overall support, ie) can the device render in this format (disregardless of fs/windowed) ?
				if (mDirect3d->CheckDeviceType(indexAdapter, deviceTypes[indexDeviceType], formats[indexFormat], formats[indexFormat], FALSE) != D3D_OK) {

					X3M_LOG("*", "no render support in %d bpp", 
						mD3DUtil.formatToBitDepth(formats[indexFormat]));
					
					// set to unknown, we will not use it from now on
					formatsConfirmed[indexFormat] = false;
				}

							
				/**
				 * Check for a suitable depth/Z buffer format				
				 */
				depthStencilFormats[indexFormat] = d3d_getCompatibleDepthStencilFormat(indexAdapter, deviceTypes[indexDeviceType], formats[indexFormat]);

				/// check if we found one
				if (depthStencilFormats[indexFormat] == D3DFMT_UNKNOWN) {

					formatsConfirmed[indexFormat] = false;
					X3M_LOG ("*", "no depth/stencil buffer format for %d bpp", mD3DUtil.formatToBitDepth(formats[indexFormat]));
					continue;
				}

				
				X3M_DEBUG ("*", "found a compatible depth/stencilformat!");
				/**
				 * Set behaviours for the device on this format
				 * by checking its caps. 
				 */
								
				X3M_DEBUG ("*", "Maximum texture blend stages [%d]", pDeviceInfo->mDeviceCaps.MaxTextureBlendStages);

				/// check if hw T&L is supported
				if (pDeviceInfo->mDeviceCaps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT) {

					X3M_DEBUG ("*", "supports hardware T&L [YES]");
					
					/// check for pure device
					if (pDeviceInfo->mDeviceCaps.DevCaps & D3DDEVCAPS_PUREDEVICE) {

						X3M_DEBUG ("*", "supports pure device  [YES]");
						behaviours[indexFormat] = D3DCREATE_HARDWARE_VERTEXPROCESSING | D3DCREATE_PUREDEVICE;
						formatsConfirmed[indexFormat] = true;
					}
					/// no support for pure device
					else {

						X3M_DEBUG ("*","supports pure device  [NO]");
						behaviours[indexFormat] = D3DCREATE_HARDWARE_VERTEXPROCESSING;
						formatsConfirmed[indexFormat] = true;
					}
				}
				// software vertexprocessing
				else {

					X3M_DEBUG ("*","supports hardware T&L [NO]");
					X3M_DEBUG ("*","supports pure device  [NO]");
					behaviours[indexFormat] = D3DCREATE_SOFTWARE_VERTEXPROCESSING;
					formatsConfirmed[indexFormat] = true;
				}
			}

			/// all formats are now parsed and checked, lets build the devices modelist
			pDeviceInfo->mDeviceFormats.clear();
			
			for (int iFormat = 0; iFormat < formats.size(); iFormat++) {
			
				if (formatsConfirmed[iFormat]) {
		
					D3DDeviceFormat deviceFormat;
					
					// build complete deviceformat with device caps and display format
					deviceFormat.mBitdepth				= mD3DUtil.formatToBitDepth(formats[iFormat]);
					deviceFormat.mFormat				= formats[iFormat];
					deviceFormat.mBehaviour				= behaviours[iFormat];
					deviceFormat.mFormatDepthStencil	= depthStencilFormats[iFormat];
					
					pDeviceInfo->mDeviceFormats.push_back(deviceFormat);
					
					D3DDeviceFormat * pDeviceFormat = & (pDeviceInfo->mDeviceFormats.back());
				
					// check multisample techniques supported on this deviceformat
					d3d_enumDeviceMultiSampleSupport(indexAdapter, deviceTypes[indexDeviceType], formats[iFormat], pDeviceFormat->mMultiSamples);
					
					if (pDeviceFormat->mMultiSamples.size() == 0)
						pDeviceFormat->mSupportFSAA = false;
				
					for (int i = 0; i < pDeviceFormat->mMultiSamples.size(); i++) 
						X3M_DEBUG ("*", "format %d bpp - %d samples supported.", pDeviceFormat->mBitdepth, pDeviceFormat->mMultiSamples[i]);
				
				}
			}		
		
		} // end indexDevice
	
	} // end indexAdapter
}

//==========================================================================================

const bool RenderSystem::d3d_enumDeviceMultiSampleSupport(const int32 adapter, D3DDEVTYPE devType, D3DFORMAT format, std::vector<int32> &msList) {

	X3M_ASSERT (mDirect3d);
	X3M_ASSERT (devType != D3DFMT_UNKNOWN);

	// clear list just in case it contains any garbage, 
	msList.clear();

	// always add supprt for 0 samples ;)
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_2_SAMPLES) == D3D_OK)
		msList.push_back(2);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_3_SAMPLES) == D3D_OK)
		msList.push_back(3);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_4_SAMPLES) == D3D_OK)
		msList.push_back(4);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_5_SAMPLES) == D3D_OK)
		msList.push_back(5);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_6_SAMPLES) == D3D_OK)
		msList.push_back(6);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_7_SAMPLES) == D3D_OK)
		msList.push_back(7);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_8_SAMPLES) == D3D_OK)
		msList.push_back(8);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_9_SAMPLES) == D3D_OK)
		msList.push_back(9);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_10_SAMPLES) == D3D_OK)
		msList.push_back(10);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_11_SAMPLES) == D3D_OK)
		msList.push_back(11);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_12_SAMPLES) == D3D_OK)
		msList.push_back(12);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_13_SAMPLES) == D3D_OK)
		msList.push_back(13);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_14_SAMPLES) == D3D_OK)
		msList.push_back(14);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_15_SAMPLES) == D3D_OK)
		msList.push_back(15);
	if (mDirect3d->CheckDeviceMultiSampleType(adapter, devType, format, FALSE, D3DMULTISAMPLE_16_SAMPLES) == D3D_OK)
		msList.push_back(16);

	// check if only 1 sample is supported
	if (msList.size() == 1)
		return false;
	
	return true;
}

//==========================================================================================

D3DFORMAT RenderSystem::d3d_getCompatibleDeviceFormat(const int32 adapter, const D3DDEVTYPE deviceType, const int32 bitdepth) {

	// check indexes
	int deviceIndex = 0;
	
	if (mD3DAdapterInfo[ADAPTER_DEFAULT].mDevices[1].mDeviceCaps.DeviceType == deviceType)
		deviceIndex = 1;

	// traverse device's format list 
	for (int iDeviceFormat=0; iDeviceFormat < mD3DAdapterInfo[ADAPTER_DEFAULT].mDevices[deviceIndex].mDeviceFormats.size(); iDeviceFormat++) {

		if (mD3DAdapterInfo[ADAPTER_DEFAULT].mDevices[deviceIndex].mDeviceFormats[iDeviceFormat].mBitdepth == bitdepth) {

			return mD3DAdapterInfo[ADAPTER_DEFAULT].mDevices[deviceIndex].mDeviceFormats[iDeviceFormat].mFormat;
		}
	}

	// ok, if we reached here, there is no support for this bitdepth on this devicetype
	return D3DFMT_UNKNOWN;
}

//==========================================================================================

void RenderSystem::d3d_buildPresentParameters() {

	int32 bitDepth;

	// set current device type
	mCurrentDeviceType = mConfig.getParam(CFG_LAYER).getVal() == "hal" ? D3DDEVTYPE_HAL : D3DDEVTYPE_REF;

	// set currentDevuceInfo to the deviceinfo for the layer to be used
	mCurrentDeviceInfo = mD3DAdapterInfo[ADAPTER_DEFAULT].getD3DDeviceInfo(mCurrentDeviceType);

	// check so that this layer is supported before doing anything else
	if (!mCurrentDeviceInfo)
		throw Exception ("RenderSystem - Configured device layer not supported in hardware!");

	// retrieve deviceinfo
	mCurrentDeviceFormat = mCurrentDeviceInfo->getD3DDeviceFormat(mConfig.getParam(CFG_BITDEPTH).getIntVal());
	if (!mCurrentDeviceFormat)
		throw Exception ("No such format (%d bpp) available on this devicetype!", mConfig.getParam("bitdepth").getIntVal());

	// clear present parameters
	memset (&mD3Dpp, 0, sizeof (mD3Dpp));

	// set d3d present parameters from configuration map
	mD3Dpp.Windowed			= mConfig.getParam(CFG_WINDOWED).getBoolVal();
	mD3Dpp.BackBufferWidth	= mConfig.getParam(CFG_WIDTH).getIntVal();
	mD3Dpp.BackBufferHeight	= mConfig.getParam(CFG_HEIGHT).getIntVal();
	mD3Dpp.BackBufferCount	= mConfig.getParam(CFG_BACKBUFFER_COUNT).getIntVal();

	// set device window and check its validity
	mD3Dpp.hDeviceWindow	= mWindow.getHWND();
		
	// set swap effect, not configurable at the moment
	mD3Dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	
	// check if windowed rendering and use desktop's bitdepth in that case
	if (mD3Dpp.Windowed == FALSE) {
		
		bitDepth = mCurrentDeviceFormat->mBitdepth;
		mD3Dpp.FullScreen_PresentationInterval = mConfig.getParam(CFG_VSYNC).getBoolVal() ? D3DPRESENT_INTERVAL_ONE  : D3DPRESENT_INTERVAL_IMMEDIATE;
		mD3Dpp.BackBufferFormat = mCurrentDeviceFormat->mFormat;
	}
	else {

		// check if windowed mode is supported
		if (!mCurrentDeviceInfo->mCanRenderWindowed)
			throw Exception ("RenderSystem failed to confirm device, Windowed rendering is not supported");

		// windowed modes needs the backbuffer format set to the same as the current desktop's
		mD3Dpp.BackBufferFormat = mD3DAdapterInfo[ADAPTER_DEFAULT].mDesktopMode.Format;
	}
	
	// set stencilbuffer format
	mD3Dpp.EnableAutoDepthStencil = TRUE;
	mD3Dpp.AutoDepthStencilFormat = mCurrentDeviceFormat->mFormatDepthStencil;
	
	// check if should activate FSAA
	bool useFSAA = mConfig.getParam(CFG_FSAA_ENABLE).getBoolVal();

	// setup FSAA
	if (useFSAA) {

		int32 multiSamples = mConfig.getParam(CFG_FSAA_SAMPLES).getIntVal();
		mD3Dpp.MultiSampleType = multiSamples == 0 ? D3DMULTISAMPLE_NONE : mD3DUtil.intToMultiSampleType(multiSamples);

		// check if FSAA i supported
		if (mCurrentDeviceFormat->mSupportFSAA == false)
			throw Exception ("Failed to confirm device - FSAA is not supported!");
	
		// ok, FSAA is supported but is the amount of samples available in this format?
		if (!mCurrentDeviceFormat->confirmMultiSampleRate(multiSamples))
			throw Exception ("Failed to confirm device - (%d) samples not supported!", multiSamples);
	}
	
	// check if devicetype is supported
	if ((!mD3DAdapterInfo[ADAPTER_DEFAULT].mSupportHAL) && (mCurrentDeviceType == D3DDEVTYPE_HAL))
		throw Exception("Failed to confirm device, HAL is not supported");
	
	// fill in the current displaymode in a D3DDISPLAYMODE structure
	D3DDISPLAYMODE d3dDisplayMode;
	d3dDisplayMode.Width  = mD3Dpp.BackBufferWidth;
	d3dDisplayMode.Height = mD3Dpp.BackBufferHeight;
	d3dDisplayMode.Format = mD3Dpp.BackBufferFormat;
	
	// convert to Extreme's format
	mD3DUtil.convertDisplayMode(d3dDisplayMode, mCurrentDeviceMode);

	// check if adapter support the displaymode
	if (!mD3DAdapterInfo[ADAPTER_DEFAULT].confirmDisplayMode(mCurrentDeviceMode))
		throw Exception("Failed to confirm device, Displaymode [%d,%d,%d] not supported on adapter",mCurrentDeviceMode.getWidth(),
																									mCurrentDeviceMode.getHeight(),
																									mCurrentDeviceMode.getBitDepth());
}

//==========================================================================================

void RenderSystem::d3d_releaseDevice() {

	if (mD3DDevice) {
		
		X3M_LOG ("RenderSystem", "Releaseing hardware(D3D) device");

		// release all resources created by this device... 
		MaterialManager::getInstance().releaseAll();
		TextureManager::getInstance().releaseAll();
		ModelManager::getInstance().releaseAll();

		// release device
		COM_SAFE_RELEASE(mD3DDevice);
	}
}

//==========================================================================================

void RenderSystem::d3d_createDevice() {

	X3M_ASSERT (mDirect3d);
	
	// check device window
	if ((mD3Dpp.hDeviceWindow == NULL) || (IsWindow(mD3Dpp.hDeviceWindow) == 0))
		throw Exception ("RenderSystem cannot initialize a device without a valid HWND!");

	X3M_LOG ("RenderSystem", "Create a new device :");
	X3M_LOG ("RenderSystem", " - Device Layer : %s		  ", mCurrentDeviceType == D3DDEVTYPE_HAL ? "[HAL]" : "[REF]");
	X3M_LOG ("RenderSystem", " - FSAA         : %d samples", mD3DUtil.multiSampleTypeToInt(mD3Dpp.MultiSampleType));
	X3M_LOG ("RenderSystem", " - DisplayMode  : %d, %d, %d", mD3Dpp.BackBufferWidth, mD3Dpp.BackBufferHeight, mCurrentDeviceMode.getBitDepth());
	X3M_LOG ("RenderSystem", " - Windowed     : %s		  ", mConfig.getParam(CFG_WINDOWED).getVal().c_str());
	X3M_LOG ("RenderSystem", " - Vert. sync   : %s		  ", mConfig.getParam(CFG_VSYNC).getVal().c_str());
	
	// create direct3d device
	HRESULT hres = mDirect3d->CreateDevice(ADAPTER_DEFAULT, mCurrentDeviceType, mD3Dpp.hDeviceWindow, 
											/*mCurrentDeviceFormat->mBehaviour*/D3DCREATE_SOFTWARE_VERTEXPROCESSING , &mD3Dpp,  &mD3DDevice);
	
	// check d3d result, if !ok - throw exception cause we cant fo ANYTHING if this device isn't fully functional
	if (hres != D3D_OK)		
		throw Exception ("RenderSystem could not create a %s device, reason(%s)", 
			mCurrentDeviceType == D3DDEVTYPE_HAL ? "HAL" : "REF", 
			mD3DUtil.resultToString(hres));
}

//==========================================================================================

//==========================================================================================

//==========================================================================================

//==========================================================================================

