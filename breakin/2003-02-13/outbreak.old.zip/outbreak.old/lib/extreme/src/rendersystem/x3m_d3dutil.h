/*=======================================================================================*
 
	_..::>Extreme 3D Engine<::.._ 

	Responsible: Peter Nordlander (tooon@home.se)
 
	Copyright 2000-2002 Peter Nordlander, all rights reserved.
	Any modification of the source code is strictly forbidden without permission
	from the author(s) and/or the file responsible.
	
	Please visit:
	www.planetzeus.net
	www.outbreak.nu

*========================================================================================*/

#ifndef __EXTREME_DEVICE_D3D_UTIL_INC__
#define __EXTREME_DEVICE_D3D_UTIL_INC__

#include "..\resource\x3m_vertexbuffer.h"
#include "..\x3m_typedef.h"
#include "..\template\x3m_singleton.h"
#include "x3m_displaymode.h"
#include <d3d8.h>

namespace Extreme {

	/**
	 * Safe COM-Interface release macro
	 */
	#define COM_SAFE_RELEASE(x) if (x!=NULL) {x->Release(); x = NULL;}

	/**
	 * @class Direct3DUtil
	 *
	 * D3D Utility/Helper methods,
	 * Exists as a singleton class an i mostly used internally to convert 
	 * back and forth to the D3D backend layer.
	 *
	 * @author	Peter Nordlander
	 * @date	2001-12-27
	 */
	
	class Direct3DUtil : public TSingleton<Direct3DUtil>
	{
	public:
		
		/**
		 * Converts a d3dformat to its corresponding bitdepth
		 * @param format A D3DFORMAT structure to be the source of conversion
		 * @return BitDepth as an int32 for the given D3DFORMAT
		 */
		const int32 formatToBitDepth(const D3DFORMAT &format) const;

		/**
		 * Converts a d3dformat to its corresponing r/g/b pixelformat
		 * @param format A D3DFORMAT structure to be the source of conversion
		 * @r Where to load RED   bitmask
		 * @g Where to load GREEN bitmask
		 * @b Where to load BLUE  bitmask
		 * @a Where to load ALPHA bitmask
		 */
		void formatToBitMasks(const D3DFORMAT &format, uint32 &r, uint32 &g, uint32 &b, uint32 &a) const;
		
		/**
		 * Converts a D3DDISPLAYMODe to an Extreme::DisplayMode object
		 * @param d3ddm D3DDISPLAYMODE structure, source of conversion
		 * @param displayMode DisplayMode object in which to store converted data
		 */
		void convertDisplayMode(const D3DDISPLAYMODE &d3ddm, DisplayMode &displayMode) const;

		/**
		 * Converts a d3dmultisample_type enumeration to an ordinal - representing the amount of samples
		 * @param d3dmst MultiSampleType as a D3DMULTISAMPLE_TYPE (D3D ENUM)
		 * @return Integer representing the actual amount of samples 
		 */
		const int32 multiSampleTypeToInt(const D3DMULTISAMPLE_TYPE d3dmst) const;

		/**
		 * Converts a ordinal to a d3dmultisample_type enumeration
		 * @param mscount Amount of mulisamples 
		 * @return A D3DMULTISAMPLE_TYPE represeneting the amount samples given
		 */	
		const D3DMULTISAMPLE_TYPE intToMultiSampleType(const int32 mscount) const;

		/**
		 * Get the amount of bits reserverd for stencilbuffer usage on a certain depth/stencil D3DFORMAT 
		 * @param depthStencilFormat The D3DFORMAT to be tested
		 * @return The amount of bits reserverd for the given D3DFORMAT 
		 */
		const int32 getStencilBitCount(D3DFORMAT depthStencilFormat) const;
	
		/**
		 * Get the amount of bits reserverd for stencilbuffer usage on a certain depth/stencil D3DFORMAT 
		 * @param depthStencilFormat Bit depth used as stencilbuffer
		 * @return The amount of bits reserverd as D3DFORMAT 
		 */
		const D3DFORMAT getDepthStencilFormat(const int32 stencilBits, const int32 depthDepth) const;

		/**
		 * Check weither a D3DFORMAT is lockable 
		 * @param format The D3DFORMAT to be tested
		 * @return true if format is lockable, false if not 
		 */
		const bool formatIsLockable(D3DFORMAT format) const;

		/**
		 * Converts a HRESULT from a Direct3d APICall to a character string
		 * @param result HRESULT to be converted
		 * @return A character string representation of the given HRESULT, NULL on error
		 */
		const char * resultToString(const HRESULT result) const;

		/**
		 * Retrieve the size of a single vertex with a given FVF format
		 * @param FVF The flexible vertex format 
		 * @return The size of a vertex with a FVF of @a FVF
		 */
		const uint32 getVertexSize(const DWORD FVF) const;

	};

// =========================================================================================

X3M_INLINE const uint32 Direct3DUtil::getVertexSize(const DWORD FVF) const {
	return D3DXGetFVFVertexSize(FVF);
}

// =========================================================================================

X3M_INLINE const bool Direct3DUtil::formatIsLockable(D3DFORMAT format) const {

	return format == D3DFMT_D16_LOCKABLE ? true : false;
}

// =========================================================================================

X3M_INLINE const int32 Direct3DUtil::getStencilBitCount(D3DFORMAT depthStencilFormat) const {

	// check if there is any stencil bits in depthbuffer format
	switch (depthStencilFormat) 
	{
	case D3DFMT_D24S8:
		return 8;
	case D3DFMT_D24X4S4:
		return 4;
	case D3DFMT_D15S1:
		return 1;
	}

	return 0;
}

// =========================================================================================

X3M_INLINE const D3DFORMAT Direct3DUtil::getDepthStencilFormat(const int32 stencilBitDepth, const int32 depthBitCount) const {

	switch (stencilBitDepth)
	{
		case 0:

			switch (depthBitCount)
			{
			case 16: return D3DFMT_D16_LOCKABLE;
			case 24: return D3DFMT_D24X8;
			case 32: return D3DFMT_D32;
			default : return D3DFMT_UNKNOWN;
			};
		
		case 1: return D3DFMT_D15S1;
		case 8: return D3DFMT_D24S8;
        case 4: return D3DFMT_D24X4S4;

		default:
			return D3DFMT_UNKNOWN;
	};

}

// =========================================================================================

X3M_INLINE void Direct3DUtil::convertDisplayMode(const D3DDISPLAYMODE &d3ddm, DisplayMode &displayMode) const {

	uint32 r,g,b,a;
	displayMode.set(d3ddm.Width, d3ddm.Height, formatToBitDepth(d3ddm.Format));
	formatToBitMasks(d3ddm.Format,r,g,b,a);
	displayMode.setBitMasks(r,g,b,a);
}

// =========================================================================================

X3M_INLINE const D3DMULTISAMPLE_TYPE Direct3DUtil::intToMultiSampleType(const int32 multiSampleCount) const {

	switch (multiSampleCount) 
	{
	case 0:
	return D3DMULTISAMPLE_NONE;
	case 2:
	return D3DMULTISAMPLE_2_SAMPLES;
	case 3:
	return D3DMULTISAMPLE_3_SAMPLES;
	case 4:
	return D3DMULTISAMPLE_4_SAMPLES;
	case 5:
	return D3DMULTISAMPLE_5_SAMPLES;
	case 6:
	return D3DMULTISAMPLE_6_SAMPLES;
	case 7:
	return D3DMULTISAMPLE_7_SAMPLES;
	case 8:
	return D3DMULTISAMPLE_8_SAMPLES;
	case 9:
	return D3DMULTISAMPLE_9_SAMPLES;
	case 10:
	return D3DMULTISAMPLE_10_SAMPLES;
	case 11:
	return D3DMULTISAMPLE_11_SAMPLES;
	case 12:
	return D3DMULTISAMPLE_12_SAMPLES;
	case 13:
	return D3DMULTISAMPLE_13_SAMPLES;
	case 14:
	return D3DMULTISAMPLE_14_SAMPLES;
	case 15:
	return D3DMULTISAMPLE_15_SAMPLES;
	case 16:
	return D3DMULTISAMPLE_16_SAMPLES;
	};

	return D3DMULTISAMPLE_NONE;
}

// =========================================================================================

X3M_INLINE const int32 Direct3DUtil::multiSampleTypeToInt(const D3DMULTISAMPLE_TYPE d3dmst) const {

	switch (d3dmst) 
	{
	case D3DMULTISAMPLE_NONE:
		return 0;
	case D3DMULTISAMPLE_2_SAMPLES:
		return 2;
	case D3DMULTISAMPLE_3_SAMPLES:
		return 3;
	case D3DMULTISAMPLE_4_SAMPLES:
		return 4;
	case D3DMULTISAMPLE_5_SAMPLES:
		return 5;
	case D3DMULTISAMPLE_6_SAMPLES:
		return 6;
	case D3DMULTISAMPLE_7_SAMPLES:
		return 7;
	case D3DMULTISAMPLE_8_SAMPLES:
		return 8;
	case D3DMULTISAMPLE_9_SAMPLES:
		return 9;
	case D3DMULTISAMPLE_10_SAMPLES:
		return 10;
	case D3DMULTISAMPLE_11_SAMPLES:
		return 11;
	case D3DMULTISAMPLE_12_SAMPLES:
		return 12;
	case D3DMULTISAMPLE_13_SAMPLES:
		return 13;
	case D3DMULTISAMPLE_14_SAMPLES:
		return 14;
	case D3DMULTISAMPLE_15_SAMPLES:
		return 15;
	case D3DMULTISAMPLE_16_SAMPLES:
		return 16;
	};

	return 0;
}

// =========================================================================================

X3M_INLINE const int32 Direct3DUtil::formatToBitDepth(const D3DFORMAT &d3dformat) const {

	// check d3d formats and convert them to an
	// appropriate bitcount
	switch (d3dformat) {

		/// 24 bitmodes
		case D3DFMT_R8G8B8: 
		case D3DFMT_D24X8:
			return 24;

		/// 32 bitmodes
		case D3DFMT_D24S8:
		case D3DFMT_D24X4S4:
		case D3DFMT_D32:
		case D3DFMT_A8R8G8B8:          
		case D3DFMT_X8R8G8B8:          
			return 32;

		/// 15/16 bit modes
		case D3DFMT_D15S1:
		case D3DFMT_D16:
		case D3DFMT_D16_LOCKABLE:
		case D3DFMT_A8R3G3B2:     
		case D3DFMT_X4R4G4B4: 
		case D3DFMT_R5G6B5:   
		case D3DFMT_X1R5G5B5:
		case D3DFMT_A1R5G5B5:          
		case D3DFMT_A4R4G4B4: 
			return 16;
	}
	
	return 0;
}

// =========================================================================================

X3M_INLINE void Direct3DUtil::formatToBitMasks(const D3DFORMAT &d3dformat, uint32 &r, uint32 &g, uint32 &b, uint32 &a) const {

	// clear bitmasks
	r = g = b = a = 0x000000;

	// find format and convert
	switch (d3dformat) {

		case D3DFMT_A8R8G8B8:          
		a = 0x000000;
		case D3DFMT_R8G8B8: 
		case D3DFMT_X8R8G8B8:          
		r = 0xff0000;
		g = 0x00ff00;
		b = 0x0000ff;
		break;
			
		/// 16 bit modes
		case D3DFMT_A8R3G3B2:     
		a = 0xff00;
		r = 0xe0;
		g = 0x1c;
		b = 0x03;
		break;
		case D3DFMT_A4R4G4B4: 
		a = 0xf000;
		case D3DFMT_X4R4G4B4: 
		r = 0x0f00;
		g = 0x00f0;
		b = 0x000f;
		break;

		/// 15 bit modes
		case D3DFMT_A1R5G5B5:          
		a = 0x01 << 15;
		case D3DFMT_X1R5G5B5:
		r = 0x1f << 10;
		g = 0x1f << 5;
		b = 0x1f;
		break;
		case D3DFMT_R5G6B5:  
		r = 0x1f << 11;
		g = 0x3f << 5;
		b = 0x1f;
		break;
	}
}


// =========================================================================================

X3M_INLINE const char * Direct3DUtil::resultToString(const HRESULT result) const {

	switch (result) {

	case D3DERR_WRONGTEXTUREFORMAT               : return "D3DERR_WRONGTEXTUREFORMAT";
	case D3DERR_UNSUPPORTEDCOLOROPERATION        : return "D3DERR_UNSUPPORTEDCOLOROPERATION";
	case D3DERR_UNSUPPORTEDCOLORARG              : return "D3DERR_UNSUPPORTEDCOLORARG";
	case D3DERR_UNSUPPORTEDALPHAOPERATION        : return "D3DERR_UNSUPPORTEDALPHAOPERATION";
	case D3DERR_UNSUPPORTEDALPHAARG              : return "D3DERR_UNSUPPORTEDALPHAARG";
	case D3DERR_TOOMANYOPERATIONS                : return "D3DERR_TOOMANYOPERATIONS";
	case D3DERR_CONFLICTINGTEXTUREFILTER         : return "D3DERR_CONFLICTINGTEXTUREFILTER";
	case D3DERR_UNSUPPORTEDFACTORVALUE           : return "D3DERR_UNSUPPORTEDFACTORVALUE";
	case D3DERR_CONFLICTINGRENDERSTATE           : return "D3DERR_CONFLICTINGRENDERSTATE";
	case D3DERR_UNSUPPORTEDTEXTUREFILTER         : return "D3DERR_UNSUPPORTEDTEXTUREFILTER";
	case D3DERR_CONFLICTINGTEXTUREPALETTE        : return "D3DERR_CONFLICTINGTEXTUREPALETTE";
	case D3DERR_DRIVERINTERNALERROR              : return "D3DERR_DRIVERINTERNALERROR";

	case D3DERR_NOTFOUND                         : return "D3DERR_NOTFOUND";
	case D3DERR_MOREDATA                         : return "D3DERR_MOREDATA";
	case D3DERR_DEVICELOST                       : return "D3DERR_DEVICELOST";
	case D3DERR_DEVICENOTRESET                   : return "D3DERR_DEVICENOTRESET";
	case D3DERR_NOTAVAILABLE                     : return "D3DERR_NOTAVAILABLE";
	case D3DERR_OUTOFVIDEOMEMORY                 : return "D3DERR_OUTOFVIDEOMEMORY";
	case D3DERR_INVALIDDEVICE                    : return "D3DERR_INVALIDDEVICE";
	case D3DERR_INVALIDCALL                      : return "D3DERR_INVALIDCALL";
	case D3DERR_DRIVERINVALIDCALL                : return "D3DERR_DRIVERINVALIDCALL";

	}

	return "D3DERR_UNSPECIFIED";
}


// =========================================================================================

}

#endif
