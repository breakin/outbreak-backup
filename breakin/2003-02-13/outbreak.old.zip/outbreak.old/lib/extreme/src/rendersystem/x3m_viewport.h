#ifndef __EXTREME_RENDERSYSTEM_VIEWPORT_INC__
#define __EXTREME_RENDERSYSTEM_VIREPORT_INC__

namespace Extreme {

	/**
	 * @class	ViewPort
	 * @brief	Viewport, defines how to project vertices onto the current rendering target
	 * @author	Peter Nordlander
	 * @date	2001-01-01
	 */
	class ViewPort 
	{
	public:
		
		/// constructor
		explicit ViewPort(const int32 x = 0, const int32 y = 0, const int32 width = 0, const int32 height = 0) :
			m_x (x),
			m_y (y),
			m_width (width),
			m_height(height) {
		}
	
		/// set viewport left
		void setLeft(const int32 x) { m_x = x; }
			
		/// set viewport width
		void setWidth(const int32 width) {m_width = width; }
	
		/// set viewport top
		void setTop(const int32 top) { m_y = top;}
		
		/// set viewport height
		void setHeight(const int32 height) { m_height = height; }

		/// set near/min z value for clipping purposes
		void setMinZDepth ( const float32 minZ ) { m_minZ = minZ; }

		/// set near/min z value for clipping purposes
		void setMaxZDepth ( const float32 maxZ ) { m_maxZ = maxZ; }

		/// get viewport top
		const int32 getTop() const { return m_y; }
		
		/// get viewport left
		const int32 getLeft() const  { return m_x; }
		
		/// get viewport width
		const int32 getWidth() const  { return m_width; }
		
		/// get viewport height
		const int32 getHeight() const { return m_height; }
		
		/// get viewport right
		const int32 getRight() const { return m_x + m_width; }

		/// get viewport bottom
		const int32 getBottom() const { return m_y + m_height; }

		/// get minimum z depth value, used for clipping
		const float32 getMinZDepth() const { return m_minZ; }

		/// get maximum z depth value, used for clipping
		const float32 getMaxZDepth() const { return m_maxZ; }



	protected:

		float32 m_minZ;		///< Minimum Z Value on viewport clipping
		float32 m_maxZ;		///< Maximum Z Value on viewport clipping
		int32	m_x;		///< Position (left) of viewport
		int32	m_y;		///< Position (top) of viewport
		int32	m_width;	///< Width of viewport in pixels
		int32	m_height;	///< Height of vireport in pixeles
	};
}

#endif
