#ifndef __EXTREME_RENDERSYSTEM_INC__
#define __EXTREME_RENDERSYSTEM_INC__

#include "..\x3m_config.h"
#include "x3m_viewport.h"
#include "x3m_d3dversion.h"
#include "x3m_d3dadapterinfo.h"
#include "x3m_d3dutil.h"
#include "x3m_rendersystem_caps.h"
#include "x3m_texturelayer.h"

#include "..\x3m_color.h"
#include "..\x3m_typedef.h"
#include "..\x3m_exception.h"
#include "..\x3m_msgqueue.h"
#include "..\debug\x3m_debug.h"
#include "..\template\x3m_singleton.h"
#include "..\win32\x3m_threadwindow.h"
#include "..\resource\x3m_texturemanager.h"
#include "..\resource\x3m_vertexbuffer.h"
#include "..\resource\x3m_indexbuffer.h"
#include "..\resource\x3m_material.h"

#pragma warning (disable:4786)
#include <map>

namespace Extreme {

	/**
	 * RenderSystem configuration parameters 
	 */
	const std::string CFG_FSAA_ENABLE		= "fsaa.enable";
	const std::string CFG_FSAA_SAMPLES		= "fsaa.samples";
	const std::string CFG_BACKBUFFER_COUNT	= "backbuffer.count";
	const std::string CFG_WIDTH				= "backbuffer.width";
	const std::string CFG_HEIGHT			= "backbuffer.height";
	const std::string CFG_BITDEPTH			= "backbuffer.bitdepth";
	const std::string CFG_VSYNC				= "device.vsync";
	const std::string CFG_LAYER				= "device.layer";
	const std::string CFG_WINDOWED			= "appl.windowed";
	const std::string CFG_TITLE				= "appl.title";

	/**
	 * @class  RenderSystem
	 * Extreme engine's rasterizer/display system unit
	 * Also, a quite low level wrapper to a D3D Hardware device
	 *
	 * @author Peter Nordlander
	 * @date   2001-12-30
	 *
	 * @todo    Make it possible to get information about the current 
	 * device's capabilities (Pure device, hw vertexproc. etc)
	 * @todo	Also make it possible to render in multiple passes if multitexturing isnt supported
	 *
	 */
	class RenderSystem : public MsgQueue, public TSingleton<RenderSystem>
	{
	public:
		
		/**
		 * Rendersystem hardware abstraction layers
		 */
		enum eLayer 
		{
			LAYER_HAL = 0x00,		///< RenderSystem Hardware Accelerated device
			LAYER_REF = 0x01,		///< RenderSystem Software Emulation device
		};
		
		/** 
		 * Contructor
		 */
		RenderSystem();
		
		/**
		 * Destructor
		 */
		~RenderSystem();
		
		/**
		 * Set a configuration parameter, returns false if not supported, true otherwise
		 * @param parameter Configuration parameter
		 * @param value Configuration parameter value
		 * @return true if parameter is supported, false otherwise
		 * @remarks If a parameter is changed after a rendersystem has been started, 
		 * a call to RenderSystem::reset must be invoked.
		 */
		const bool config(const std::string &parameter, const ConfigValue value);

		/**
		 * Set window's title
		 * @param title New title to set, only affect appls running in window mode
		 */
		void setTitle(const std::string & title);
		
		/**
		 * Retrieve window's title
		 * @return The current caption of the application's window
		 */
		const std::string & getTitle() const;

		/** 
		 * Startup & initialize rendersystem
		 */
		void startup();

		/**
		 * Release/shutdown rendersystem
		 */
		void shutdown();

		/**
		 * Reinitialize/reset rendersystem
		 */
		void reset();
		
		/**
		 * Start of frame notification to hardware
		 * @remarks Must be called each frame before any rendering
		 */
		void beginScene();

		/**
		 * End of frame notification to hardware
		 * @remarks Must be called before Present/Flip of the backbuffer
		 */
		void endScene();

		/**
		   * Clear flags specifying what buffers to involve during clear
		   */
		  enum eClearFlags
		  {
		   CLEAR_DEPTH   = 0x01, ///< Clear depthbuffer
		   CLEAR_STENCIL = 0x02, ///< Clear stencilbuffer
		   CLEAR_TARGET  = 0x04, ///< Clear targetbuffer, framebuffer
		   CLEAR_ALL   = 0xff,
		   FORCE_DWORD   = 0xffffffff,
		  };

		/**
		   * Clear the devices backbuffer
		   * @param flags One, or a combination of, eClearFlags @see eClearFlags
		   * @param clearColor Color to fill the targetbuffer with
		   * @param z Value used to fill the depthbuffer
		   * @param stencil Value used to fill the stencilbuffer
		   * @remarks Must NOT be called in between a begin/endScene pair
		   */
		  void clear(const uint32 flags, const ColorValue &clearColor, const float32
		z = 1.0f, const uint32 stencil = 0);

		/**
		 * Update/flips the backbuffer and present the scene on screen
		 * @remarks This method is used to present the final rendered image each frame
		 * and must always be invoked AFTER endScene.
		 */
		void present();

		/**
		 * Check if rendersystem is activated
		 * @return true if RenderSystem is started, false otherwise
		 */
		const bool isStarted() const;

		/**
		 * Set Rendering ViewPort
		 * @param viewPort ViewPort to use for clipping and rendering
		 */
		void setViewPort(const ViewPort &viewPort);

		/**
		 * Retrieve current viewport
		 * @return Currently set ViewPort
		 */
		const ViewPort & getViewPort() const;

		/**
		 * Retrieve current active DisplayMode
		 * @return Currently set DisplayMode
		 */
		const DisplayMode & getDisplayMode() const;

		/**
		 * Set Material to use for rendering of primitives
		 * @param handle Handle to material to activate
		 */
		void setMaterial(const Material * handle);

		/**
		 * Set view/camera matrix
		 * @param matrix Matrix to use for camera/view transformations
		 */
		void setViewMatrix (const Matrix4x4 & matrix);

		/**
		 * Set world transformation matrix
		 * @param Matrix to use for world transformation
		 */
		void setWorldMatrix (const Matrix4x4 & matrix);

		/**
		 * Set projection matrix, should never be done explicitly
		 * @param matrix Matrix to use for projections
		 */
		void setProjectionMatrix (const Matrix4x4 & matrix);

		/**
		 * Set/change rendertarget - NULL to switch to default backbuffer
		 * @param handle TextureHandle to use as rendertarget, NULL handle will switch to default backbuffer
		 */
		void setRenderTarget(const TextureHandle handle);

		/**
		 * Set VertexBuffer
		 * @param handle VertexBuffer to use as streamsource
		 */
		void setVertexBuffer(VertexBufferHandle handle);

		/**
		 * Set IndexBuffer
		 * @param handle IndexBuffer to use as source of indices
		 * @param streamBaseOffset Offset to be added to each index during rendering
		 */
		void setIndexBuffer(IndexBufferHandle indexBuffer, const int32 streamBaseOffset = 0);

		/**
		 * Render primitives accordning to prior set vertex/index/transform and state data
		 * @param pType The PrimitiveType that describes how we should treat the vertex data
		 * @param numPrims Number of primitives to render in this pass, 0 = render whole vertexbuffer
		 */
		void renderPrimitive(const VertexBuffer::ePrimitiveType pType, const int32 numPrims = 0, const int32 startVertex = 0);

		/** 
		 * Render indexed primitive
		 * @param pType The PrimitiveType that describes how we should treat the vertex data
		 * @param numPrims Number of primitives to render in this pass, 0 = render whole vertexbuffer
		 */
		void renderIndexedPrimitive(const VertexBuffer::ePrimitiveType pType, const int32 numPrims = 0, const int32 startOffs = 0);
	
		/**
		 * Get access to the topmost D3D COMInterface
		 * @return The D3DInterface used in this RenderSystem
		 */
		IDirect3D * getD3D() const;

		/**
		 * Get access to the internal D3DDdevice
		 * @return The D3DDevice used internally
		 */
		IDirect3DDevice * getD3DDevice() const;

		/**
		 * Get RenderSystem capablities
		 * @return A RenderSystem::Caps object, @see RenderSystem::Caps
		 */
		const RenderSystemCaps & getCaps() const;

	private:

		/// reset and clear member defaults
		void init();
		
		/// intialize rendersystem's capabilites
		void initCaps();

		/// initialize default confitation parameters and their corresponding values
		void initConfig();

		/// initialize default renderstates and texturestage states
		void initRenderStates();

		/// clear all states and used hw-resources (vbuffers/indices/textures and so on)
		void flushUsedResources();
		
		/**
		 * Set TextureStageStates from texturelayer
		 */
		void setTextureFilter(const int32 stage, const TextureLayer::eFilter textureFilter);
		void setTextureAddressMode(const int32 stage, const TextureLayer::eAddressMode textureAddressMode);
		void setTextureCoordIndex(const int32 stage, const TextureLayer::eCoordIndex texCoordIndex);
		void setTexture(const int32 stage, const TextureHandle handle);
		
		/**
		 * Set RenderStates from material
		 */
		void setCullMode(const Material::eCullMode cullMode);
		void setFillMode(const Material::eFillMode fillMode);
		void setShadeMode(const Material::eShadeMode shadeMode);
		void setDiffuseColorSource(const Material::eColorSource colorSource);
		void setSpecularColorSource(const Material::eColorSource colorSource);
		void setAmbientColorSource(const Material::eColorSource colorSource);
		void setSurfaceColor(const ColorValue &ambient, const ColorValue &diffuse, const ColorValue &specular);
		void setColorSource(const Material::eColorSource ambient, const Material::eColorSource diffuse, const Material::eColorSource specular);
		void setLighting(const bool enabled);
		void setDepthBufferMode(const bool depthEnabled, const bool depthWriteEnable);
		void setSceneBlendMode(const bool blendEnable, const BlendMode &blendMode);
		void setTextureLayer(const int32 stage, const TextureLayer * textureLayer);
		void unsetTextureLayer(const int32 stage);
		
		/**
		 * Default graphicschip adapter index
		 */
		enum { ADAPTER_DEFAULT = 0x00, };

		/**
		 * Direct3D lower level <private> methods which totally
		 * performs a d3d specific task
		 */
		/// load D3D.DLL
		void d3d_loadDLL();

		/// Unload D3D.DLL
		void d3d_unloadDLL();

		/// create Direct3D interface
		void d3d_create();

		/// release Direct3D interfaces
		void d3d_release();
	
		/// create device
		void d3d_createDevice();
		
		/// release device
		void d3d_releaseDevice();

		/// build present paramaters from configuration properties
		void d3d_buildPresentParameters();
		
		/// check device's current state
		void d3d_resetDevice();

		/// enumerat all devices/adapters and desplaymodes
		void d3d_enumerateAdapters();

		/// returns a d3d packed format for <bitdepth> on a given devicetype
		D3DFORMAT d3d_getCompatibleDeviceFormat(const int32 adapter, const D3DDEVTYPE, const int32 bitdepth);

		/// find a compatible (best available stencilformat)
		D3DFORMAT d3d_getCompatibleDepthStencilFormat(const int32 adapter, D3DDEVTYPE devType, D3DFORMAT renderTarget);
			
		// confirm depth/stencilformat
		const bool d3d_confirmDepthStencilFormat(const int32 adapter, D3DDEVTYPE devType, D3DFORMAT format, D3DFORMAT renderTarget);

		/// checks support for FSAA on a given devicetype and fills in the passed list with the supported amounts of samples
		const bool d3d_enumDeviceMultiSampleSupport(const int32 adapter, D3DDEVTYPE devType, D3DFORMAT format, std::vector<int32> &);
	
	private:

		/// RenderSystem capabilities & settings
		RenderSystemCaps			mCaps;				///< RenderSystem capabilites
		ConfigMap					mConfig;			///< Current Device configuration
		ThreadWindow				mWindow;			///< Win32 Render/focus window
		bool						mStateRunning;		///< Set to true if rendersystem is activated
		bool						mStateDeviceInScene;///< Indicates weither device in currently inbetween a begin/endScene 
		bool						mStateDeviceLost;	///< Incicates weither a device is lost and needs to be reset
		
		/// direct 3d stuff
		Direct3DUtil				mD3DUtil;
		D3DPRESENT_PARAMETERS		mD3Dpp;				///< D3D device present paramters
		IDirect3D *					mDirect3d;			///< D3D top API interface
		HMODULE						mD3DModule;			///< Direct3D DLL module handle
		IDirect3DDevice *			mD3DDevice;			///< D3D device pointer
		bool						mD3DDeviceLost;		///< Flag indicating weither a device must be reset internally
		bool						mD3DDeviceInScene;	///< Flag indicating weither a device is currently beeing open for rendering
		D3DAdapterInfoList			mD3DAdapterInfo;	///< Hardware adapterinfo
				
		/// current active resources
		VertexBufferHandle			mCurrentVertexBuffer;	///< Currently set vertexbuffer
		IndexBufferHandle			mCurrentIndexBuffer;	///< Currently set indexbuffer
		Material					mCurrentMaterial;		///< Material to keep track of current renderstates
		bool						mForceMaterialUpdate;	///< Forece material properties to set on hw
		
		/// device settings
		D3DDEVTYPE					mCurrentDeviceType;		///< Current devicetype (D3DDEVTYPE_HAL/REF)
		DisplayMode					mCurrentDeviceMode;		///< Current set displaymode		
		D3DDeviceInfo *				mCurrentDeviceInfo;		///< Current device info
		D3DDeviceFormat *			mCurrentDeviceFormat;	///< Current device format
	};
}

#endif
