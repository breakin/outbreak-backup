//==========================================================================================
// Include files
//==========================================================================================
#include "x3m_rendersystem_caps.h"

//==========================================================================================
// Used namespaces
//==========================================================================================
using namespace Extreme;

//==========================================================================================
// Method implementation
//==========================================================================================

RenderSystemCaps::RenderSystemCaps() {
	clear();
}

//==========================================================================================

RenderSystemCaps::~RenderSystemCaps() {
	clear();
}

//==========================================================================================

void RenderSystemCaps::clear() {
	
	mSupportWindowed	= false;
	mSupportHAL			= false;			
	mSupportFSAA		= false;			
	mMaxPrimitiveCount	= 0;		
	mMaxBlendMatrices	= 0;	
	mMaxTextureStages	= 0;	
	mMaxActiveLights	= 0;	
	mMaxVertexIndex		= 0;
	mMaxStreamStride	= 0;
	mMaxStreams			= 0;	
	mAdapterDesc		= "";
	mDisplayModes.clear();	
	mMultiSampleRateList.clear();
}
//==========================================================================================
