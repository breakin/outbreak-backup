#ifndef __EXTREME_DISPLAYMODE_INC__
#define __EXTREME_DISPLAYMODE_INC__

#include "..\x3m_typedef.h"
#include <d3d8.h>
#include <vector>

namespace Extreme {

	/**
	 * @class	DisplayMode
	 * @brief	Screen displaymode 
	 * @author	Peter Nordlander
	 * @date	2001-12-19
	 */
	
	struct DisplayMode
	{	
		/**
		 * Constructor
		 * @param width Default width
		 * @param height Default height
		 * @param bitdepth Default bit per pixel
		 */
		DisplayMode(const int32 width = 0, const int32 height = 0, const int32 bitdepth = 0);
		
		/**
		 * Set displaymode properties
		 * @param width Width
		 * @param height Height
		 * @param bitdepth Bit per pixel
		 */
		void set (const int32 width, const int32 height, const int32 bpp);

		/**
		 * Set width of displaymode
		 * @param width The width in pixels
		 */
		void setWidth (const int32 width) { mWidth = width;}
		
		/**
		 * Set height of displaymode
		 * @param height The height in pixels
		 */
		void setHeight (const int32 height) { mHeight = height;}

		/**
		 * Set bitdepth of displaymode
		 * @param bitdepth The bitdepth in bits/pixel (15/16/24/32)
		 */
		void setBitDepth (const int32 bitdepth) { mBitdepth = bitdepth;}

		/**
		 * Retrieve width of displaymode
		 * @return The displaymode's width, in pixels
		 */
		const int32 getWidth() const { return mWidth;}
		
		/**
		 * Retrieve height of displaymode
		 * @return The displaymode's height, in pixels
		 */
		const int32 getHeight() const { return mHeight;}
		
		/**
		 * Retrieve displaymode's bitdepth
		 * @return The displaymode's bitdepth
		 */
		const int32 getBitDepth() const { return mBitdepth;}
		
		/**
		 * Retrieve the displaymode's corresponding R,G,B and A bitmasks
		 * @param alpha Where to load the Alpha bitmask
		 * @param red   Where to load the Red bitmask
		 * @param green Where to load the Green bitmask
		 * @param blue  Where to load the Blue bitmask
		 * @return The format's packed bitmask as AARRGGBB
		 */
		const uint32 getBitMasks (uint32 &alpha, uint32 &red, uint32 &green, uint32 &blue);

		/**
		 * Set the displaymode's corresponding R,G,B and A bitmasks
		 * @param alpha The Alpha bitmask
		 * @param red   The Red bitmask
		 * @param green The Green bitmask
		 * @param blue  The Blue bitmask
		 */
		void setBitMasks (const uint32 alpha, const uint32 red, const uint32 green, const uint32 blue);
		
		/**
		 * Less than - operator overload
		 * @param other DisplayMode to compare with
		 * @return true on less, false otherwise
		 */
		bool operator <  (const DisplayMode &other) const;
		
		/**
		 * Larger than - operator overload
		 * @param other DisplayMode to compare with
		 * @return true on larger, false otherwise
		 */
		bool operator >  (const DisplayMode &other) const;

		/**
		 * Equal to - operator overload
		 * @param other DisplayMode to compare with
		 * @return true on equal, false otherwise
		 */
		bool operator == (const DisplayMode &other) const;

	private:

		/// DisplayMode data
		int32		mWidth;				///< Mode's Width
		int32		mHeight;			///< Mode's Height
		int32		mBitdepth;			///< Mode's bitdepth
		uint32		mBitmaskRed;		///< Bitmask for attribute RED
		uint32		mBitmaskGreen;		///< Bitmask for attribute GREEN
		uint32		mBitmaskBlue;		///< Bitmask for attribute BLUE
		uint32		mBitmaskAlpha;		///< Bitmask for attribute ALPHA
	};

	typedef std::vector<DisplayMode> DisplayModeList; 

//================================================================================================

X3M_INLINE void DisplayMode::set(const int32 width = 0, const int32 height = 0, const int32 bitdepth = 0) {
	mWidth = width;
	mHeight = height;
	mBitdepth = bitdepth;
}

//================================================================================================

X3M_INLINE bool DisplayMode::operator == (const DisplayMode &other) const {
	return ((mWidth == other.mWidth) && (mHeight == other.mHeight) && (mBitdepth == other.mBitdepth));
}

//================================================================================================

X3M_INLINE bool DisplayMode::operator < (const DisplayMode &other) const {
	if (mBitdepth > other.mBitdepth)
		return false;

	if (mWidth > other.mWidth)
		return false;
	
	if (mHeight > other.mHeight)
		return false;

	return true;
}

//================================================================================================

X3M_INLINE bool DisplayMode::operator > (const DisplayMode &other) const {

	if (mBitdepth < other.mBitdepth)
		return false;

	if (mWidth < other.mWidth)
		return false;

	if (mHeight < other.mHeight)
		return false;

	return true;
}

//================================================================================================

X3M_INLINE DisplayMode::DisplayMode(const int32 width, const int32 height, const int32 bitdepth) : 
	/// initialize datemembers
	mWidth(width), 
	mHeight(height),
	mBitdepth(bitdepth),
	mBitmaskRed(0),
	mBitmaskGreen(0),
	mBitmaskBlue(0),
	mBitmaskAlpha(0){
}

//================================================================================================

X3M_INLINE const uint32 DisplayMode::getBitMasks (uint32 &alpha, uint32 &red, uint32 &green, uint32 &blue) {
	alpha	= mBitmaskAlpha;
	green	= mBitmaskGreen;
	blue	= mBitmaskBlue;
	red		= mBitmaskRed;
	return uint32(mBitmaskAlpha | mBitmaskRed | mBitmaskGreen | mBitmaskBlue);
}

//================================================================================================

X3M_INLINE void DisplayMode::setBitMasks (const uint32 alpha, const uint32 red, const uint32 green, const uint32 blue) {
	mBitmaskAlpha	= alpha;
	mBitmaskRed		= red;
	mBitmaskGreen	= green;
	mBitmaskBlue	= blue;
}

//================================================================================================

}


#endif