#ifndef __EXTREME_RENDERSYSTEM_RENDERUNIT_INC__
#define __EXTREME_RENDERSYSTEM_REMDERUNIT_INC__

#include "..\math\x3m_matrix.h"
#include "..\resource\x3m_vertexbuffer.h"
#include "..\resource\x3m_indexbuffer.h"
#include "..\resource\x3m_material.h"
#include "x3m_rendersystem.h"

namespace Extreme {

	/**
	 * @class  RenderUnit
	 * @brief  Smallest unit that the extreme engine can draw
	 * @author Peter Nordlander
	 */ 
	class RenderUnit
	{
	public:

		/** 
		 * Constructor
		 */
		RenderUnit();

		/**
		 * Destructor
		 */
		~RenderUnit();

		/**
		 * Setup the renderiner, prepare it to render this renderunit
		 */
		void setupRender() const;

		/**
		 * Render this renderunit
		 */
		void render() const;
		
		/**
		 * Set the transformation matrix to use when drawing this unit
		 * @param handle The matrix to use
		 */
		void setMatrix(const Matrix4x4 * matrix);
		
		/**
		 * Set vertexbuffer 
		 * @param handle The vertexbuffer this unit uses as streamsource
		 */
		void setVertexBuffer(const VertexBufferHandle handle);
		
		/**
		 * Set indexbuffer
		 * @param handle The vertexbuffer this unit uses as indices, NULL for nonindexed data
		 */
		void setIndexBuffer(const IndexBufferHandle handle);

		/**
		 * Set material to use for this unit
		 * @param handle The material, describing HOW this unit shold be rendered
		 */
		void setMaterial(const MaterialHandle handle);

		/** 
		 * Get material settings for this unit
		 * @return Material used in this unit
		 */
		MaterialHandle getMaterial();

		/** 
		 * Get material settings for this unit
		 * @return Material used in this unit
		 */
		const MaterialHandle getMaterial() const;

		/** 
		 * Get the indexbuffer for this unit
		 * @return The indexbuffer used in this unit, NULL if not indexed
		 */
		IndexBufferHandle getIndexBuffer();

		/** 
		 * Get the indexbuffer for this unit
		 * @return The indexbuffer used in this unit, NULL if not indexed
		 */
		const IndexBufferHandle getIndexBuffer() const;

		/** 
		 * Get the vertexbuffer for this unit
		 * @return The vertexbuffer used in this unit, NULL if not indexed
		 */
		VertexBufferHandle getVertexBuffer();

		/** 
		 * Get the vertexbuffer for this unit
		 * @return The vertexbuffer used in this unit, NULL if not indexed
		 */
		const VertexBufferHandle getVertexBuffer() const;

		/** 
		 * Get the world transformation matrix for this unit
		 * @return The world transformation matrix used in this unit
		 */
		Matrix4x4 * getMatrix();

		/** 
		 * Get the world transformation matrix for this unit
		 * @return The world transformation matrix used in this unit
		 */
		const Matrix4x4 * getMatrix() const;

		/**
		 * Set number of primitives stored in this renderunit
		 * @param primCount Number of primitives stored in this renderunit
		 */
		void setPrimitiveCount(const int32 primCount) { mPrimCount = primCount; }
		 
		/**
		 * Set start offset
		 * @param startOffset If indexed, startOffset relates to the indexbuffer, otherwise to the vertexbuffer
		 */
		void setStartOffset(const int32 startOffset) { mPrimStart = startOffset;}

		/**
		 * Get amount of primitives stored in this renderunit
		 * @return Amount of primitives in this renderunit
		 */
		const int32 getPrimitiveCount() const { return mPrimCount; }

		/**
		 * Get start offset in vertexbuffer, or indexbuffer if used
		 * @return Amount of primitives in this renderunit
		 */
		const int32 getStartOffset() const { return mPrimStart; }

		/**
		 * Check if this renderunit contains indexed data
		 * @return True if unit is indexed, false otherwise
		 */
		const bool isIndexed() const { return (mIndexBuffer.getObject() == NULL); }
	
	protected:

		int32				mPrimStart;
		int32				mPrimCount;
		VertexBufferHandle	mVertexBuffer;
		IndexBufferHandle	mIndexBuffer;
		MaterialHandle		mMaterial;
		Matrix4x4 *			mMatrix;
	};

	typedef std::vector<RenderUnit> RenderUnits;


//===============================================================================================================

X3M_INLINE RenderUnit::RenderUnit() :
	mPrimStart(0),
	mPrimCount(0),
	mVertexBuffer(NULL),
	mIndexBuffer(NULL),
	mMaterial(NULL)
{ }

//===============================================================================================================

X3M_INLINE RenderUnit::~RenderUnit() {

	mPrimStart = 0;
	mPrimCount = 0;
	mVertexBuffer = NULL;
	mIndexBuffer = NULL;
	mMaterial = NULL;
}

//===============================================================================================================

X3M_INLINE void RenderUnit::setupRender() const {

	RenderSystem * rs = &RenderSystem::getInstance();
	
	// setup streamsources and material
	rs->setVertexBuffer(mVertexBuffer);
	rs->setIndexBuffer(mIndexBuffer);
	rs->setMaterial(mMaterial);
	rs->setWorldMatrix(*mMatrix);
}

//===============================================================================================================

X3M_INLINE void RenderUnit::render() const {
	RenderSystem * rs = &RenderSystem::getInstance();	
	
	// check if should draw nonindexed
	if (mIndexBuffer.getObject() == NULL) {
		rs->renderPrimitive(mVertexBuffer->getPrimitiveType(), mPrimCount, mPrimStart);
		return;
	}
	
	// draw indexed primitives
	rs->renderIndexedPrimitive(mVertexBuffer->getPrimitiveType(), mPrimCount, mPrimStart);
}
//===============================================================================================================

X3M_INLINE void RenderUnit::setMatrix(const Matrix4x4 * matrix) {
	mMatrix = (const_cast<Matrix4x4*>(matrix));
}

//===============================================================================================================

X3M_INLINE void RenderUnit::setVertexBuffer(const VertexBufferHandle handle) {
	mVertexBuffer = handle;
}

//===============================================================================================================

X3M_INLINE void RenderUnit::setIndexBuffer(const IndexBufferHandle handle) {
	mIndexBuffer = handle;
}

//===============================================================================================================

X3M_INLINE void RenderUnit::setMaterial(const MaterialHandle handle) {
	mMaterial = handle;
}

//===============================================================================================================

X3M_INLINE MaterialHandle RenderUnit::getMaterial() {
	return mMaterial;
}

//===============================================================================================================

X3M_INLINE const MaterialHandle RenderUnit::getMaterial() const {
	return mMaterial;
}

//===============================================================================================================

X3M_INLINE IndexBufferHandle RenderUnit::getIndexBuffer() {
	return mIndexBuffer;
}

//===============================================================================================================

X3M_INLINE const IndexBufferHandle RenderUnit::getIndexBuffer() const {
	return mIndexBuffer;
}

//===============================================================================================================

X3M_INLINE VertexBufferHandle RenderUnit::getVertexBuffer() {
	return mVertexBuffer;
}

//===============================================================================================================

X3M_INLINE const VertexBufferHandle RenderUnit::getVertexBuffer() const {
	return mVertexBuffer;
}

//===============================================================================================================

X3M_INLINE Matrix4x4 * RenderUnit::getMatrix() {
	X3M_ASSERT (mMatrix);
	return mMatrix;
}

//===============================================================================================================

X3M_INLINE const Matrix4x4 * RenderUnit::getMatrix() const {
	X3M_ASSERT (mMatrix);
	return mMatrix;
}

//===============================================================================================================

}

#endif
