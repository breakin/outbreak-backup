#ifndef __EXTREME_RENDERSYSTEM_CONFIG_INC__
#define __EXTREME_RENDERSYSTEM_CONFIG_INC__

#include "..\x3m_typedef.h"
#include "x3m_displaymode.h"

// stl includes
#include <string>
#include <map>

namespace Extreme {

	/**
	 * @class	ConfigParameter
	 * @brief	RenderSytem startup configuration parameter
	 * @author	Peter Nordlander
	 * @date	2002-01-12
	 */

	struct ConfigParameter 
	{
		/**
		 * Config value types
		 */
		enum eValueType {

			TYPE_INT	= 0x01,	///< Interger/numeric value
			TYPE_BOOL	= 0x02,	///< Boolean "true" or "false"
			TYPE_STRING = 0x03,	///< String value
		};

		/**
		 * Constructor
		 * @param name  Name of configuration parameters
		 * @param value Configuration parameter's value
		 * @param type  Configuration parameter's datatype
		 * @param const Configuration parameter's const modifier, true = configuration parameter can not be changed
		 */
		ConfigParameter(const std::string &name = "", const std::string &value = "", const eValueType type = TYPE_INT, const bool constant = true) :
			mName(name),
			mValue(value),
			mType(type),
			mConst(constant) {}
		
		/**
		 * Set string value
		 * @param value The new value
		 */
		void setValue(const std::string &value);
		
		/**
		 * Set bool value
		 * @param value The new value
		 */
		void setValue(const bool value);
		
		/**
		 * Set int value
		 * @param value The new value
		 */
		void setValue(const int32 value);

		/**
		 * Get the value of this parameter as string
		 * @return The paramter's value as string
		 */
		const std::string getValue() const;
		
		/**
		 * Get the name of this parameter
		 * @return The name of the paramter
		 */
		const std::string getName() const;
	
		/**
		 * Get parameter's datatype
		 * @return A value of eValueType indicating the datatype of this parameter
		 */
		const eValueType getType() const;
		
		/**
		 * Check if parameter is constant
		 * @return True if the parameter is constant, false otherwise
		 */
		const bool isConst() const;

		/**
		 * Check if parameter is an integer
		 * @return True if the parameter is an int, false otherwise
		 */
		const bool isInt() const;

		/**
		 * Check if parameter is a boolean
		 * @return True if the parameter is a boolean, false otherwise
		 */
		const bool isBool() const;

		/**
		 * Check if parameter is a string
		 * @return True if the parameter is a string, false otherwise
		 */
		const bool isString() const;

		/// data members
		std::string		mName;		///< Parameter name
		std::string		mValue;		///< Parameter value
		int32			mType;		///< Parameter value type
		bool			mConst;		///< Parameter mutable stat
	};
	
	/// typedef configuration database map
	typedef std::map<std::string, ConfigParameter> ConfigMap;
}

#endif
