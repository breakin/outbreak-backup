#ifndef __EXTREME_RENDERSYSTEM_CAPS_INC__
#define __EXTREME_RENDERSYSTEM_CAPS_INC__

#include "x3m_displaymode.h"
#include "x3m_d3dversion.h"
#include "x3m_d3dadapterinfo.h"
#include "x3m_d3dutil.h"

namespace Extreme {

	typedef std::vector<int32> MultiSampleRateList;
	
	/**
	 * @class  RenderSystemCaps
	 * @brief  RenderSystem feauters/limits and overall description
	 * @author Peter Nordlander
	 */
	struct RenderSystemCaps
	{			
		/**
		 * Constructor
		 */
		RenderSystemCaps();

		/**
		 * Destructor
		 */
		~RenderSystemCaps();
		
		/**
		 * Clear data
		 */
		void clear();

		/**
		 * RenderSystem capabilities
		 */
		bool				mSupportWindowed;		///< RenderSysten can render in windowed mode using the current desktop resolution
		bool				mSupportHAL;			///< RenderSystem can render using hw acceleration
		bool				mSupportFSAA;			///< RenderSystem can use FullSceneAntiAliasing
		int32				mMaxPrimitiveCount;		///< Maximum amount of primitives that can batched in a single call
		int32				mMaxBlendMatrices;		///< Maximum amount of blending matrices for bones animation per vertex
		int32				mMaxTextureStages;		///< Maximum amount of stages support in hardware
		int32				mMaxTextureWidth;		///< Maximum width of texture
		int32				mMaxTextureHeight;		///< Maximum height of a texture
		int32				mMaxActiveLights;		///< Maxumum amount of active light in rasterizer
		int32				mMaxVertexIndex;		///< Maximum bitdepth for indexes (0xffff == 16) (0xffffffff == 32)
		int32				mMaxStreamStride;		///< Maxumum bytesize/stride of a single vertex
		int32				mMaxStreams;			///< Maximum amount of streamsources supported in hw	
		std::string			mAdapterDesc;			///< Name of the current graphics adapter installed on computer
		DisplayModeList		mDisplayModes;			///< Supported displaymodes
		MultiSampleRateList	mMultiSampleRateList;	///< RenderSystem's max multisamples(only if FSAA is available)
	};
}
#endif