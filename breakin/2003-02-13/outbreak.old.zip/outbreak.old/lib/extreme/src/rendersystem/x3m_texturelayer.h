#ifndef __EXTREME_TEXTURELAYER_INC__
#define __EXTREME_TEXTURELAYER_INC__

#include "..\x3m_typedef.h"
#include "..\rendersystem\x3m_blendmode.h"
#include "..\resource\x3m_texture.h"
#include "..\template\x3m_smartptr.h"

#include <d3d8.h>

namespace Extreme {


	/**
	 * @class	TextureLayer
	 * @brief	Represent a description of how to map a texture onto a rendered primitive
	 * @author	Peter Nordlander
	 * @date	2002-01-07
	 */
	struct TextureLayer 
	{	
		/**
		 * Texture addressing modes
		 */
		enum eAddressMode
		{
			TEXADDRESS_WRAP		= D3DTADDRESS_WRAP,		///< Wrapped addressingmode	 / Tiled at every integer junction
			TEXADDRESS_CLAMP	= D3DTADDRESS_CLAMP,	///< Clamp addressingmode	 / Uses last texel at 1.0/0.0 at cords > 1 resp. < 0
			TEXADDRESS_MIRROR	= D3DTADDRESS_MIRROR,	///< Mirrored addressingmode / Flipped at every integer junction,
			TEXADDRESS_BORDER	= D3DTADDRESS_BORDER,	///< Bordered addressingmode 
			TEXADDRESS_DEFAULT  = D3DTADDRESS_WRAP,		///< Default textureaddressing
		};
		
		/**
		 * Texture filtering types
		 */
		enum eFilter
		{
			TEXFILTER_NONE		  = D3DTEXF_NONE,		///< No Texture filtering
			TEXFILTER_POINT		  = D3DTEXF_POINT,		///< Point filtering
			TEXFILTER_BILINEAR	  = D3DTEXF_LINEAR,		///< Bilinear filtering
			TEXFILTER_TRILINEAR	  = D3DTEXF_FLATCUBIC,	///< Trilinear filtering
			TEXFILTER_ANISOTROPIC = D3DTEXF_ANISOTROPIC,///< Anisotropic filtering
			TEXFILTER_DEFAULT	  = TEXFILTER_POINT,	///< Default texturefilter
		};

		/**
		 * Texture coordinate indexsources
		 */
		enum eCoordIndex 
		{
			TEXCOORDINDEX_VERTEX				= D3DTSS_TCI_PASSTHRU,					 ///< Use coordindex from vertex data
			TEXCOORDINDEX_CAMERASPACENORMAL		= D3DTSS_TCI_CAMERASPACENORMAL,			 ///< Use camera space normal of vertex as texel coord. index
			TEXCOORDINDEX_CAMERASPACEPOSITION	= D3DTSS_TCI_CAMERASPACEPOSITION,		 ///< Use camera space position of vertex as texel coord. index
			TEXCOORDINDEX_CAMERASPACEREFLECTION	= D3DTSS_TCI_CAMERASPACEREFLECTIONVECTOR,///< Use camera space reflection vector from vertex position and its normal 
			TEXCOORDINDEX_DEFAULT				= TEXCOORDINDEX_VERTEX,
		};

		/**
		 * Constructor
		 */
		TextureLayer();

		/**
		 * Destructor
		 */
		~TextureLayer();

		/**
		 * Create a new texturelayer
		 */
		void create();

		/**
		 * Release texturelayer
		 */
		void release();

		/**
		 * Initialize texturelayer
		 */
		void init();

		TextureHandle	mTexture;			///< Texture used in this stage
		BlendMode		mColorBlend;		///< Texture blend mode		
		bool			mColorBlendEnable;	///< Colorblend enable
		bool			mAlphaBlendEnable;	///< Colorblend enable
		eFilter			mFilter;			///< Texture filtering
		eAddressMode	mAddressMode;		///< Texture addressing
		int32			mCoordIndex;		///< Texture coordinate index
		bool			mEnabled;			///< Flag indicating weither this layer is enabled
	};

//=============================================================================================================

typedef TextureLayer * TextureLayerHandle;
typedef std::vector<TextureLayer> TextureLayerList;

//=============================================================================================================

}

#endif