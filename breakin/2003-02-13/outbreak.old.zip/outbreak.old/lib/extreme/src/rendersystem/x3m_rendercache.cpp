//==========================================================================================
// Include files
//==========================================================================================

#include "x3m_rendercache.h"
#include "x3m_rendersystem.h"

//==========================================================================================
// Namespace usage
//==========================================================================================

using namespace Extreme;

//==========================================================================================
// Method implenetation
//==========================================================================================

StateSorter::StateSorter() {
	mDisplayList.clear();
	mViewMatrix.zero();
	mViewMatrix.makeIdentity();
}

//==========================================================================================

StateSorter::~StateSorter() {
	mDisplayList.clear();
}

//==========================================================================================

void StateSorter::setViewMatrix(Matrix4x4 &viewMatrix) {
	mViewMatrix = viewMatrix;
}

//==========================================================================================

void StateSorter::render() {
	
	// get root unit, first in list
	SortedUnitList::iterator i = mDisplayList.begin();
	
	// set camera matrix
	RenderSystem::getInstance().setViewMatrix(mViewMatrix);

	// traverse list of object and render them all
	while (i!=mDisplayList.end()) {

		// setup render
		i->second->setupRender();

		// rasterize unit
		i->second->render();
	}
}

//==========================================================================================

void StateSorter::accumulate(const RenderUnit * unit) {
	mDisplayList[unit->getMaterial()] = unit;
}

//==========================================================================================

const bool StateSorter::MaterialLess::operator () (const MaterialHandle &x, const MaterialHandle &y) const {
	
	bool xBlend = x->isTransparent();
	bool yBlend = y->isTransparent();
	
	// always store blended units at end of list
	if (xBlend && !yBlend)
		return false;
		
	if (yBlend && !xBlend)
		return true;

	// compare textures
	if ((uint32)x < (uint32)y)
		return true;
	return false;
	// compera materials
}

//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
//==========================================================================================
