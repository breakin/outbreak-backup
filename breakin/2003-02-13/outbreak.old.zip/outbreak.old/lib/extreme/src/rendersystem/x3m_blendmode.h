#ifndef __EXTREME_RENDERSYSTEM_BLENDMODE_INC__
#define __EXTREME_RENDERSYSTEM_BLENDMODE_INC__

#include "..\x3m_typedef.h"
#include <d3d8.h>

namespace Extreme {
	
	/**
	 * @class	BlendMode
	 * @brief	BlendMode Renderstate container,
	 * @author	Peter Nordlander
	 * @date	2001-12-27
	 */
		
	class BlendMode 
	{
	public:
		
		/**
		 * Blend sources, only of interset during texturelayer blending
		 */
		enum eSource 
		{	
			BLEND_CURRENT			= 0x01,						///< Use current color in framebuffer
			BLEND_TEXTURE			= 0x02,						///< Use texture color as blend source
			BLEND_DIFFUSE			= 0x04,						///< Use diffuse color as blend source
			BLEND_SPECULAR			= 0x05,						///< Use specular color as blend source
			BLEND_CONSTANT			= 0x06,						///< Use constant color as blend source
			BLEND_DEFAULT			= 0x01,	
		};

		/**
		 * Blend src factors
		 */
		enum eFactor
		{
			FACTOR_ZERO				=  D3DBLEND_ZERO,			///<
			FACTOR_ONE				=  D3DBLEND_ONE,			///<
			FACTOR_SRCCOLOR			=  D3DBLEND_SRCCOLOR,		///<
			FACTOR_INVSRCCOLOR		=  D3DBLEND_INVSRCCOLOR,	///<
			FACTOR_SRCALPHA			=  D3DBLEND_SRCALPHA,		///<
			FACTOR_INVSRCALPHA		=  D3DBLEND_INVSRCALPHA,	///<
			FACTOR_DESTALPHA		=  D3DBLEND_DESTALPHA,		///<
			FACTOR_INVDESTALPHA		=  D3DBLEND_INVDESTALPHA,	///<
			FACTOR_DESTCOLOR		=  D3DBLEND_DESTCOLOR,		///<
			FACTOR_INVDESTCOLOR		=  D3DBLEND_INVDESTCOLOR,	///<
			FACTOR_SRCALPHASAT      =  D3DBLEND_SRCALPHASAT,	///<
			FACTOR_BOTHSRCALPHA     =  D3DBLEND_BOTHSRCALPHA,	///<
			FACTOR_BOTHINVSRCALPHA	=  D3DBLEND_BOTHINVSRCALPHA,///<   
		};
	
		/**
		 * Blend operatiorns (blendSourceSRC OP blendSrcDest)
		 */
		enum eOp
		{
			OP_DISABLE				= 0,						///< Disable blending
			OP_ADD					= D3DBLENDOP_ADD,			///< SrcBlend + DstBlend
			OP_SUB					= D3DBLENDOP_SUBTRACT,		///< SrcBlend - DstBlend
			OP_MUL					= D3DBLENDOP_REVSUBTRACT,	///< SrcBlend * DstBlend
			OP_MIN					= D3DBLENDOP_MIN,			///< min(SrcBlend,DstBlend)
			OP_MAX					= D3DBLENDOP_MAX,			///< max(SrcBlend,DstBlend)
		};

		eFactor mSrcFactor;	///< Source pixel blend factor
		eFactor mDstFactor;	///< Dest pixel blend factor
		eSource mSrcBlend;	///< Source pixel blend type / TextureLayerBlend only
		eSource mDstBlend;	///< Dest pixel blend type / TextureLayerBlend only
		uint32  mBlendVal;	///< Used as a constant factor for a whole texture if BLEND_CONSTANT is used
		eOp	    mOp;		///< Blendmode operation of operands
	
		BlendMode() :
			mSrcFactor(FACTOR_ONE),
			mDstFactor(FACTOR_ZERO),
			mOp(OP_ADD) {}
	};

}
#endif