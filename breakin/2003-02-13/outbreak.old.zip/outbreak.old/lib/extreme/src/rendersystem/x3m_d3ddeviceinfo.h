/*=======================================================================================*
 
	_..::>Extreme 3D Engine<::.._ 

	Responsible: Peter Nordlander (tooon@home.se)
 
	Copyright 2000-2002 Peter Nordlander, all rights reserved.
	Any modification of the source code is strictly forbidden without permission
	from the author(s) and/or the file responsible.
	
	Please visit:
	www.planetzeus.net
	www.outbreak.nu

*=======================================================================================*/

#ifndef __EXTREME_DEVICE_D3D_DEVICEINFO_INC__
#define __EXTREME_DEVICE_D3D_DEVICEINFO_INC__

#include "..\x3m_typedef.h"
#include "x3m_d3ddeviceformat.h"
#include <d3d8.h>

namespace Extreme {

	/**
	 * @class	D3DDeviceInfo
	 * @brief	Describes a devicetype aswell as its supported displaymodes/formats and capabilities.
	 * @author	Peter Nordlander
	 * @date	2001-12-19
	 */
	
	struct D3DDeviceInfo
	{
		/**
		 * Constructor
		 */ 
		D3DDeviceInfo();
		
		/**
		 * Confirm that a given bitdepth is supported on device
		 * @param bitdepth BitDepth to be tested on device
		 * @return true if supported, false if not
		 */
		const bool confirmBitDepth(const int32 bitdepth);

		/**
		 * Confirm that a given format is supported on device
		 * @param format D3DFORMAT to be checked with device
		 * @return true if supported, false if not
		 */
		const bool confirmFormat(const D3DFORMAT format);

		/**
		 * Get D3DDeviceFormatInfo struct for a given bitdepth
		 * @param bitdepth BitDepth to match against a certain device format
		 * @return the associated D3DDeviceFormat for the given bitdepth on sucesss, NULL on failure
		 */
		D3DDeviceFormat * getD3DDeviceFormat(const int32 bitdepth);

		/// D3DDeviceInfo properties
		D3DCAPS8			mDeviceCaps;		///< Device capabilities
		D3DDeviceFormatList mDeviceFormats;	///< Deviceformats supported on this device
		bool				mCanRenderWindowed;///< Device support rendering in windowed mode
	};

	/**
	 * Typedef of std::vector, more trivial access
	 */
	typedef std::vector<D3DDeviceInfo> D3DDeviceInfoList;

// ====================================================================================================

X3M_INLINE D3DDeviceInfo::D3DDeviceInfo() :	mCanRenderWindowed(true) {} 

// ====================================================================================================

X3M_INLINE D3DDeviceFormat * D3DDeviceInfo::getD3DDeviceFormat(const int32 bitdepth) {
	for (int iFormat = 0; iFormat < mDeviceFormats.size(); iFormat++) 
		if (mDeviceFormats[iFormat].mBitdepth == bitdepth)
			return &mDeviceFormats[iFormat];

	return NULL;
}

// ====================================================================================================

X3M_INLINE const bool D3DDeviceInfo::confirmBitDepth(const int32 bitdepth) {
	for (int iFormat = 0; iFormat < mDeviceFormats.size(); iFormat++) 
		if (mDeviceFormats[iFormat].mBitdepth == bitdepth)
			return true;
	
	return false;
}

// ====================================================================================================

X3M_INLINE const bool D3DDeviceInfo::confirmFormat(const D3DFORMAT format) {
	for (int iFormat = 0; iFormat < mDeviceFormats.size(); iFormat++) 
		if (mDeviceFormats[iFormat].mFormat == format)
			return true;
	
	return false;
}

// ====================================================================================================

}

#endif