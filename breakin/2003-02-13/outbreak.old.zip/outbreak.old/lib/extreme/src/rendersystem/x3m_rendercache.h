#ifndef __EXTREME_RENDERSYSTEM_RENDERSET_INC__
#define __EXTREME_RENDERSYSTEM_RENDERSET_INC__

#include "..\math\x3m_matrix.h"
#include "x3m_renderunit.h"

namespace Extreme {

	class Accumulator
	{
		virtual void accumulate(RenderUnit * unit) = 0;
		virtual void render() = 0;
	};

	class BackToFrontSorter : public Accumulator
	{

	};

	class StateSorter : public Accumulator
	{
	public:
		
		StateSorter();
		
		~StateSorter();

		void setViewMatrix(Matrix4x4 &viewMatrix);
		
		void render();

		void accumulate(const RenderUnit * unit);

	protected:

		struct MaterialLess {
			const bool operator() (const MaterialHandle &x, const MaterialHandle &y) const;
		};
		
		typedef std::map<MaterialHandle, const RenderUnit *, MaterialLess> SortedUnitList;

		SortedUnitList	mDisplayList;
		Matrix4x4		mViewMatrix;
	};	
}

#endif
