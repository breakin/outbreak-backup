/*=======================================================================================*
 
	_..::>Extreme 3D Engine<::.._ 

	Responsible: Peter Nordlander (tooon@home.se)
 
	Copyright 2000-2002 Peter Nordlander, all rights reserved.
	Any modification of the source code is strictly forbidden without permission
	from the author(s) and/or the file responsible.
	
	Please visit:
	www.planetzeus.net
	www.outbreak.nu

*=======================================================================================*/

#ifndef __EXTREME_DIRECT3D_DEFS_INC__
#define __EXTREME_DIRECT3D_DEFS_INC__

#include <d3d8.h>

namespace Extreme {

	/// Direct3D version defines	
	typedef LPDIRECT3D8				LPDIRECT3D;				///< Direct3d top interface
	typedef LPDIRECT3DDEVICE8		LPDIRECT3DDEVICE;		///< Direct3d device interface
	typedef D3DCAPS8				D3DCAPS;				///< Direct3d device capabilities
	typedef D3DADAPTER_IDENTIFIER8	D3DADAPTER_IDENTIFIER;	///< Direct3d adapter identifier
	typedef D3DMATERIAL8			D3DMATERIAL;			///< Direct3d material 
	typedef D3DLIGHT8				D3DLIGHT;				///< Direct3d light
	typedef D3DVIEWPORT8			D3DVIEWPORT;			///< Direct3d viewport

	typedef IDirect3DSurface8		IDirect3DSurface;
	typedef IDirect3DVertexBuffer8	IDirect3DVertexBuffer;	///< Direct3d VertexBuffer interface without version mangling
	typedef IDirect3DIndexBuffer8	IDirect3DIndexBuffer;	///< Direct3d IndexBuffer interface without version mangling
	typedef IDirect3DBaseTexture8	IDirect3DBaseTexture;	///< Direct3d Texture interface without version mangling
	typedef IDirect3DVolumeTexture8	IDirect3DVolumeTexture;	///< Direct3d Texture interface without version mangling
	typedef IDirect3DCubeTexture8	IDirect3DCubeTexture;	///< Direct3d Texture interface without version mangling
	typedef IDirect3DTexture8		IDirect3DTexture;		///< Direct3d Texture interface without version mangling
	typedef IDirect3DDevice8		IDirect3DDevice;		///< Direct3d Device interface without version mangling
	typedef IDirect3D8				IDirect3D;				///< Direct3d Interface without version mangling

//	typedef TSmartPtr<IDirect3DVertexBuffer, TRefCountCOM<IDirect3DVertexBuffer> > D3DVertexBufferPtr;

	// other useful constants for future upgrades
	#define X3M_D3D_DLL		"d3d8.dll"

}

#endif
