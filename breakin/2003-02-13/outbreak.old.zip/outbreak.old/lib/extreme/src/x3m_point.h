#ifndef __EXTREME_POINT_INC__
#define __EXTREME_POINT_INC__

namespace Extreme {

	/**
	 * @class	:	Point
	 * @brief	:	2D Screen cordinate
	 * @author	:	Peter Nordlander
	 * @date	:	2001-10-29
	 */

	struct Point : public POINT
	{
		int32 mX;
		int32 mY;

		Point(int32 x = 0, int32 y = 0) { this->x = x; this->y = y;} 
		
		/// operator overloads
		Point operator + (const Point &other) const;
		Point operator - (const Point &otger) const;
		
		void operator += (const Point &other);
		void operator -= (const Point &other);
		bool operator == (const Point &other) const;
		bool operator != (const Point &other) const;
	};

//==============================================================================

X3M_INLINE Point Point::operator + (const Point &other) const {
		
	return Point(x + other.x, y + other.y);
}

//==============================================================================

X3M_INLINE Point Point::operator - (const Point &other) const {
		
	return Point(x + other.x, y + other.y);
}

//==============================================================================

X3M_INLINE bool Point::operator == (const Point &other) const {
		
	return ((x == other.x) && (y == other.y));
}

//==============================================================================

X3M_INLINE bool Point::operator != (const Point &other) const {

	return ((x != other.x) || (y != other.y));
}

//==============================================================================

X3M_INLINE void Point::operator += (const Point &other) {

	x += other.x;
	y += other.y;
}

//==============================================================================

X3M_INLINE void Point::operator -= (const Point &other) {

	x -= other.x;
	y -= other.y;
}
	
//==============================================================================

}

#endif
