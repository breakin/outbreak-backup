#ifndef __EXTREME_INTERFACE_TIMER_INC__
#define __EXTREME_INTERFACE_TIMER_INC__

#include "x3m_typedef.h"

namespace Extreme {

	/**
	 * @class	TimerInterface
	 * @brief	Timer synchronization interface 
	 * @author	Peter Nordlander
	 * @date	2001-11-08
	 */

	struct TimerInterface
	{
		/// Destructor
		virtual ~TimerInterface() {}

		/// Start timer
		virtual void start() = 0;
		
		/// Stop timer
		virtual void stop()	 = 0;
		
		/// Pause timer
		virtual void pause() = 0;

		/**
		 * Receive current time in seconds
		 * @return Current time in seconds as a float64
		 */
		virtual const float64 getTime() const = 0;
	};
}


#endif