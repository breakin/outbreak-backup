#ifndef __EXTREME_COLOR_RGBA_INC__
#define __EXTREME_COLOR_RGBA_INC__

#include "x3m_typedef.h"
#include <d3d8.h>

namespace Extreme {

	/**
	 * @class	ColorValue
	 * @brief	Representing a colorvalue of red,green,blue and alpha attributes 
	 * @author	Peter Nordlander
	 * @date	2001-12-20
	 */

	class ColorValue
	{
	public:

		/// constructor
		ColorValue (const float32 r = 0.0f, const float32 g = 0.0f, const float32 b = 0.0f, const float32 a = 0.0f) :
			mRed   (r),
			mGreen (g),
			mBlue  (b),
			mAlpha (a) {}

		/**
		 * Convertes a packed uint32/dword color into ColorValue float components
		 * @param rgba Packed DWORD RGBA color
		 */
		void fromIntRGBA(const uint32 rgba);

		/**
		 * Convertes a packed uint32/dword color into ColorValue float components
		 * @param argb Packed DWORD ARGB color
		 */
		void fromIntARGB(const uint32 argb);

		/**
		 * Converts colorvalue components into a packed dword in order RGBA
		 * @return A packed DWORD RGBA color representation of ColorValue
		 */
		const uint32 toIntRGBA() const;

		/**
		 * Converts colorvalue components into a packed dword in order RGBA
		 * @return A packed DWORD ARGB color representation of ColorValue
		 */
		const uint32 toIntARGB() const;
		
		/**
		 * Operator overloads for implicit conversion to packed RGBA data
		 * @return Packed 32bit color
		 */
		operator uint32();

		/**
		 * Operator for convering to a D3DCOLORVALUE
		 */
		operator D3DCOLORVALUE ();

		union {

			struct {
				float32 mR;	///< Red component	 (0..1)
				float32 mG;	///< Green component (0..1)
				float32 mB;	///< Blue component  (0..1)
				float32 mA;	///< Alpha component (0..1)
			};

			struct {
				float32 mRed;	///< Red component	 (0..1)
				float32 mGreen;	///< Green component (0..1)
				float32 mBlue;	///< Blue component	 (0..1)
				float32 mAlpha;	///< Alpha component (0..1)
			};
		};
	};

//======================================================================================

X3M_INLINE ColorValue::operator D3DCOLORVALUE() {
	static D3DCOLORVALUE col;
	col.r = mR;
	col.g = mG;
	col.b = mB;
	col.a = mA;
	return col;
}

//======================================================================================

X3M_INLINE void ColorValue::fromIntRGBA(const uint32 rgba) {
	mRed   = (float32)((rgba >> 24) & 0xff);
	mGreen = (float32)((rgba >> 16) & 0xff);
	mBlue  = (float32)((rgba >>  8) & 0xff);
	mAlpha = (float32)((rgba	   ) & 0xff);
}

//======================================================================================

X3M_INLINE void ColorValue::fromIntARGB(const uint32 rgba) {
	mAlpha = (float32)((rgba >> 24) & 0xff);
	mRed   = (float32)((rgba >> 16) & 0xff);
	mGreen = (float32)((rgba >>  8) & 0xff);
	mBlue  = (float32)((rgba	   ) & 0xff);
}
//======================================================================================

X3M_INLINE const uint32 ColorValue::toIntRGBA() const {
	return ((uint32)(mRed   * 255.0f) << 24) |
		   ((uint32)(mGreen * 255.0f) << 16) |
		   ((uint32)(mBlue  * 255.0f) << 8 ) |
		   ((uint32)(mAlpha * 255.0f));
}

//======================================================================================

X3M_INLINE const uint32 ColorValue::toIntARGB() const {
	return ((uint32)(mAlpha * 255.0f) << 24) |
		   ((uint32)(mRed   * 255.0f) << 16) |
		   ((uint32)(mGreen * 255.0f) << 8 ) |
		   ((uint32)(mBlue  * 255.0f));
}
//======================================================================================

};

#endif
