//================================================================================
// Include files
//================================================================================

#include "x3m_assert.h"
#include <windows.h>
#include <stdio.h>

// ==============================================================================
// Descr	: handles assert calls, and decides weither to ignore, retry or break.
// <file>	: In which module the assertion failure occured
// <line>	: On which line in <module> the assertion occured
// <expr>	: Expression which triggered the assert
// <ignore>	: Set to true if user always want to ignore this assert
// Returns	: Boolean <true> if user chosed to break the application, <false> if retry or ignore
  
bool Extreme::x3m_handle_assert(const std::string &file, const int line, const char expr[], bool &ignore) {

	static char assertMsg[1024];
	int	result;

	// build message
	sprintf (assertMsg,"Assert failed [%s]\nFile : %s\nLine : %04d\n", expr, &(file[file.find_last_of('\\')]) + 1, line);

	// execute messagebox 
	result = MessageBox (NULL, assertMsg, "Extreme Assert", MB_ABORTRETRYIGNORE);

	// evalutate result
	switch (result) {

	case IDIGNORE:
		ignore = true;
		return false;
	break;
	case IDABORT:
		return true;
	break;
	case IDRETRY:
		return false;
	break;
	}
	
	return true;
}

// ==============================================================================
