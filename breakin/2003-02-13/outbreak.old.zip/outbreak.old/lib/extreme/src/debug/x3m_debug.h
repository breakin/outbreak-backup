#ifndef __EXTREME_DEBUG_INC__
#define __EXTREME_DEBUG_INC__

#include "..\math\x3m_matrix.h"
#include "x3m_monitor.h"
#include "x3m_filemonitor.h"
#include "x3m_consolemonitor.h"
#include "..\x3m_typedef.h"
#include <vector>

/** Convenice macros for logging and debugging */
#define X3M_LOG   Extreme::Debug::log
#define X3M_DEBUG Extreme::Debug::debug
#define X3M_ERROR Extreme::Debug::error

/// check if we are forced to log message, even in release builds
#ifndef X3M_FORCEDEBUG
 #ifdef _DEBUG
	#define X3M_DEBUG_BUILD
 #endif
#else
 #define X3M_DEBUG_BUILD
#endif

/// check which default monitor to use
#ifdef X3M_DEBUG_DEFAULT_FILE
#define X3M_DEBUG_MONITOR DebugMonitorFile
#else
#define X3M_DEBUG_MONITOR DebugMonitorConsole
#endif

namespace Extreme {

	/**
	 * @class	Debug
	 *			Debug log manager, handling all debug and error logging
	 *			Also extendable by beein able to accept attachments of debugmonitors
	 * @author	Peter Nordlander
	 * @date	2001-10-16
	 */
	
	class Debug
	{
	public:
		
		/**
		 * Debug message priority classes
		 */
		enum eFilter {

			FILTER_LOG		= 0x02,		///< Log	- Medium priority, common log information
			FILTER_ERROR	= 0x01,		///< Error	- Highest priority, error notifications
			FILTER_DEBUG	= 0x04,		///< Debug	- Low priority, only debugging information
			FILTER_ALL		= 0xff,		///< All	- All priorities
		};

		/**
		 * Log with priority [ERR]
		 * @param meth method which invoked this call
		 * @param msg log message
		 */
		static void error(const char meth[], const char msg[], ...);
		
		/**
		 * Log with priority [DBG]
		 * @param meth method which invoked this call
		 * @param msg log message
		 */
		static void debug(const char meth[], const char msg[], ...);

		/**
		 * Log with priority [LOG]
		 * @param meth method which invoked this call
		 * @param msg log message
		 */
		static void log(const char meth[], const char msg[], ...);
		
		/**
		 * Set/Update default monitor's message group filter
		 * @param meth method which invoked this call
		 * @param msg log message
		 */
		static void setFilter(const uint32 filter) { sDefaultMonitor.setFilter(filter); }

		/**
		 * Set/Update default monitor's message group filter
		 * @return Currently set message group filter
		 */
		static const uint32 getFilter() { return sDefaultMonitor.getFilter(); }
		
		/**
		 * Attach a monitor, which Debug will distrubute its retrieved log message to
		 * @param monitor Any object derived from DebugMonitor
		 */
		static void attachMonitor(DebugMonitor &monitor);
		
		/**
		 * Removes a monitor, which Debug will distrubute its retrieved log message to
		 * @param monitor Any object derived from DebugMonitor
		 */
		static void removeMonitor(DebugMonitor &monitor);

		/**
		 * Switch timestamp marking on/off, disabling tsm will force Debug to exclude timestamp in logs
		 * @param enable Boolean indicating weiher to enable<true> or disable<false> tsm
		 */
		static void enableTimeStampMarking(const bool enable);
		
	protected:
		
		/**
		 * Initalize logging, attach default monitor and open approprite file channels
		 */
		static void initialize();

		/**
		 * Accept a default monitor by sending it a greeting message
		 * @param monitor Reference to a monitor currently attached
		 */
		static void acceptMonitor(DebugMonitor &monitor);

		/**
		 * Accept a default monitor by sending it a greeting message
		 * @param prio Message group priority @see eFilter
		 * @param meth Method invoked the log
		 * @param msg The actual log message
		 */
		static void updateMonitors(int32 prio, const char meth[], const char msg[]);


	private:

		static bool							sTimeStampMarking;	///< State indicating weither to add timestamps on logs
		static bool							sInitialized;		///< Initialization flag
		static X3M_DEBUG_MONITOR			sDefaultMonitor;	///< Default debug monitor, <extreme.log>
		static std::vector<DebugMonitor*>	sMonitors;			///< Linked list of monitors
	};
	
//================================================================================

X3M_INLINE void Debug::error (const char meth[], const char msg[], ...) {

#ifdef X3M_DEBUG_BUILD
	va_list	args;
	char argMsg[1024];

	// build message
	va_start (args, msg);
	vsprintf (argMsg, msg, args);
	
	// update monitors
	updateMonitors(Debug::FILTER_ERROR, meth, argMsg);

#endif
}

//================================================================================

X3M_INLINE void Debug::log (const char meth[], const char msg[], ...) {

#ifdef X3M_DEBUG_BUILD

	va_list	args;
	char argMsg[1024];

	// build message
	va_start (args, msg);
	vsprintf (argMsg, msg, args);
	
	// update monitors
	updateMonitors(Debug::FILTER_LOG, meth, argMsg);

#endif

}

//================================================================================

X3M_INLINE void Debug::debug (const char meth[], const char msg[], ...) {
	
#ifdef X3M_DEBUG_BUILD

	va_list	args;
	char argMsg[1024];

	// build message
	va_start (args, msg);
	vsprintf (argMsg, msg, args);
	
	// update monitors
	updateMonitors(Debug::FILTER_DEBUG, meth, argMsg);

#endif

}

}

#endif
