//================================================================================
// Include files
//================================================================================

#include "x3m_debug.h"
#include <stdarg.h>
#include <time.h>
#include <windows.h>

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Global variables and constants
//================================================================================

static const char g_attachMsg[] = { /// monitor accept message

"====================================================\n"
"  Ooo  ooO  _Oooo   Ooo   ooO		\n"
"  . o  o         O ..ooo ooo	.	\n"
"     oo   ..    oo.  oo o oo..		\n"
"   oO  Oo   O     O  oo   oo   .	\n"
"  oOO  OOo _ ooooo  Ooo   ooO  X3M Logging System(c)\n"
"====================================================\n"
};

//================================================================================
// Static member definitions
//================================================================================

bool						Debug::sTimeStampMarking = false;		///< Timestamp marking
bool						Debug::sInitialized = false;			///< Initialization flag
X3M_DEBUG_MONITOR			Debug::sDefaultMonitor("extreme.log");	///< Default debug monitor, <extreme.log>
std::vector<DebugMonitor*>	Debug::sMonitors;						///< Linked list of monitors


//================================================================================
// Method implementations
//================================================================================

void Debug::initialize() {
	attachMonitor(sDefaultMonitor);
	sInitialized = true;
}

//================================================================================

//================================================================================

void Debug::updateMonitors(int32 prio, const char meth[], const char msg[]) {

	static char message[1024];
	static char type[16];

	// check if initialized
	if (!sInitialized) {
		initialize();
	}

	// print message class in message
	switch (prio) {

	case Debug::FILTER_ERROR:
		strcpy (type, "ERR");
	break;
	
	case Debug::FILTER_LOG:
		strcpy (type, "LOG");
	break;

	case Debug::FILTER_DEBUG:
		strcpy (type, "DBG");
	break;
	}

	// treat empty messages as a newline
	if (msg[0] == '\0')
		sprintf (message,"\n");
	else {

		// set timestamp and add meth
		if (sTimeStampMarking)
			sprintf (message, "%4d : %s : [%s] : %s", time(NULL), type, meth, msg);
		else
			sprintf (message, "%s : [%s] : %s", type, meth, msg);
	}

	// update monitors
	for (int C = 0; C < sMonitors.size(); C++) {

		if (sMonitors[C]->onDebugMessage(prio, message) == false)
			removeMonitor(*sMonitors[C]);
	}
}

//================================================================================

void Debug::enableTimeStampMarking(const bool enable) {

	sTimeStampMarking = enable;
}

//================================================================================

void Debug::attachMonitor(DebugMonitor &dbgMon) {

	sMonitors.push_back(&dbgMon);
	acceptMonitor(dbgMon);
}

//================================================================================

void Debug::removeMonitor(DebugMonitor &dbgMon) {

	for (int C=0; C < sMonitors.size(); C++)
		if (sMonitors[C] == &dbgMon) {

			sMonitors.erase(sMonitors.begin() + C);
			return;
		}
}

//================================================================================

void Debug::acceptMonitor(DebugMonitor &dgbMon) {

	dgbMon.onDebugMessage(Debug::FILTER_LOG, g_attachMsg);
}

//================================================================================

//================================================================================

//================================================================================

//================================================================================

//================================================================================

//================================================================================

//================================================================================

//================================================================================

//================================================================================

//================================================================================

//================================================================================

//================================================================================

//================================================================================

//================================================================================

//================================================================================

