//================================================================================
// Include files
//================================================================================

#include "x3m_filemonitor.h"
#include <windows.h>

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

// ==========================================================================
// Descr	: DebugMonitorFile constructor
// <name>	: File name to write log messages to
// Returns	: -

DebugMonitorFile::DebugMonitorFile(const std::string& name) : mFileName(name), mInitialized(false), mFile(NULL) {
}

// ==========================================================================
// Descr	: DebugMonitorFile destructor
// Returns	: -

DebugMonitorFile::~DebugMonitorFile() {
}

// ==========================================================================
// Descr	: Opens the log file for writing
// Returns	: -

void DebugMonitorFile::open() {

	char fmt[4] = "a+";

	if (!mInitialized) {

		strcpy(fmt, "w+");
		mInitialized = true;
	}
	
	if (!mFile)
		mFile = fopen (mFileName.c_str(), fmt);
}

// ==========================================================================
// Descr	: Closes the file
// Returns	: -

void DebugMonitorFile::close() {
	
	if (mFile) {
		fclose(mFile);
		mFile = NULL;
	}
}

// ==========================================================================
// Descr	: Callback method called by DebugMangager each time it reveivs a message
// Returns	: Boolean <true> if message was handled properly, <false> otherwise

bool DebugMonitorFile::onDebugMessage(int32 priority, const char msg[]) {

	if (!(priority & mFilter)) 
		return true;

	this->open();
	
	/// check filepointer
	if (mFile) {

		fprintf (mFile, "%s\n", msg);
		this->close();
		return true;
	}

	// notify debug manager that object not 
	// where able to succefully print the message
	return false;
}

// ==========================================================================
