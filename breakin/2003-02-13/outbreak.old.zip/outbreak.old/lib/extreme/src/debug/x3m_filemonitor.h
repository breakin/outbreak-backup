#ifndef __EXTREME_DEBUG_FILEMONITOR_INC__
#define __EXTREME_DEBUG_FILEMONITOR_INC__

#include "x3m_monitor.h"
#include <cstdio>
#include <string>

namespace Extreme {

	/**
	 * @class	:	DebugMonitorFile
	 * @brief	:	File DebugMonitor, routs log messages to file
	 * @author	:	Peter Nordlander
	 * @date	:	2001-10-16
	 */
	
	class DebugMonitorFile : public DebugMonitor
	{
	public:

		/**
		 * Constructor
		 * @param filename A valid filename, will be created if not exist otherwise overwritten
		 */
		DebugMonitorFile(const std::string &filename);
		
		/**
		 * Destructor
		 */
		~DebugMonitorFile();
	
		/**
		 * Callback invoked by Debug log manager if an instance of this class is attached
		 * @param priorityClass @see Debug::eFilter
		 * @param msg The message sent from Debug manager 
		 * @return A boolean value indicating if Debug should keep sending this monitor messages (true) or not (false)
		 */
		virtual bool onDebugMessage(int32 priorityClass, const char msg[]);

	protected:

		/**
		 * Open file for writing
		 */
		void open();
		
		/**
		 * Close file
		 */		
		void close();

		bool		mInitialized;	///< Monitor initalized, set to true when first message is received
		FILE*		mFile;			///< Monitor file pointer
		std::string	mFileName;		///< Monitor file name
	};
}


#endif