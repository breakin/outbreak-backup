#ifndef __EXTREME_DEBUG_MONITOR_INC__
#define __EXTREME_DEBUG_MONITOR_INC__

#include "..\x3m_typedef.h"

namespace Extreme {

	/**
	 * @class	DebugMonitor
	 * @brief	DebugMonitor interface
	 * @author	Peter Nordlander
	 * @date	2001-10-16
	 */
	
	class DebugMonitor 
	{	
	public:
		
		/// constructor
		DebugMonitor() : 
		  mFilter (0xffffffff) {}

		/// virtual destructor
		virtual ~DebugMonitor() {}

		/// virtual callback methord called by Debug. 
		virtual bool onDebugMessage(int32 priorityClass, const char msg[]) = 0;

		/// set filter, for which messages the monitor will accept
		void setFilter(const uint32 filter) { mFilter = filter; }

		/// retrieve current message priority filter
		const uint32 getFilter() const { return mFilter; }

	protected:

		uint32	mFilter;	///< Message priority filter
	
	};
}

#endif
