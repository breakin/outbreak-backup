#ifndef __EXTREME_CONSOLE_MONITOR_INC__
#define __EXTREME_CONSOLE_MONITOR_INC__

#include "x3m_monitor.h"
#include <windows.h>

namespace Extreme {

	/**
	 * @class	DebugMonitorConsole
	 * @brief	Outputs log messages onto a console window
	 * @author	Peter Nordlander
	 * @date	2002-01-04
	 */

	class DebugMonitorConsole : public DebugMonitor
	{
	public:
		
		/**
		 * Constructor
		 * @param title Title used on console window
		 */
		DebugMonitorConsole(const char title[]);

		/// Destructor
		virtual ~DebugMonitorConsole();

		/**
		 * Callback invoked by Debug log manager if an instance of this class is attached
		 * @param priorityClass @see Debug::eFilter
		 * @param msg The message sent from Debug manager 
		 * @return A boolean value indicating if Debug should keep sending this monitor messages (true) or not (false)
		 */
		virtual bool onDebugMessage(int32 priorityClass, const char msg[]);

	protected:

		/// open a console window
		void openConsole();

		/// close a console window
		void closeConsole();

		static HANDLE mConsoleHandle;	///< Win32 Console handle
		static bool	  mAppHasConsole;	///< True if the application process already has a console on startup
		static uint32 mReferenceCount;	///< Instances of DebugMonitorConsole objects
	};

}

#endif