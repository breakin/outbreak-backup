#ifndef __EXTREME_DEBUG_ASSERT_INC__
#define __EXTREME_DEBUG_ASSERT_INC__

#include <string>

namespace Extreme {

/**
 * @module	X3M_ASSERT, X3M_BREAK
 *			System assertion handlers
 * @author	Peter Nordlander
 * @date	2001-10-20
 */
	
//====================================================================
// Debug version of assert
//====================================================================

/// assert message hander
bool x3m_handle_assert (const std::string& file,  const int line, const char expr[], bool &ignore);

#ifdef _DEBUG

/// debug assert breakpoint
#define X3M_BREAK __asm { int 3 }

/// debug assert
#define X3M_ASSERT(expr) {				\
	static bool assertIgnore = false;	\
										\
	if ((!(expr)) && (!assertIgnore))		\
		if (Extreme::x3m_handle_assert(__FILE__, __LINE__, #expr, assertIgnore))	\
			X3M_BREAK;	\
}						\

#else

//====================================================================
// Release versions, (do nothing)
//====================================================================

#define X3M_ASSERT(expr) 
#define X3M_BREAK 

#endif

} ///< End namespace Extreme

#endif
