//================================================================================
// Include files
//================================================================================

#include "x3m_consolemonitor.h"

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Static data definitions
//================================================================================

HANDLE	DebugMonitorConsole::mConsoleHandle = NULL;
bool	DebugMonitorConsole::mAppHasConsole = false;
uint32	DebugMonitorConsole::mReferenceCount= 0;

//================================================================================
// Metod implementation
//================================================================================

DebugMonitorConsole::DebugMonitorConsole(const char title[])  {

	if (mReferenceCount == 0) {

		openConsole();
		
		if (mConsoleHandle)
			SetConsoleTitle(title);
	}

	mReferenceCount++;
}

//================================================================================

DebugMonitorConsole::~DebugMonitorConsole() {

	mReferenceCount--;

	if (mReferenceCount == 0) 
		closeConsole();
}

//================================================================================

bool DebugMonitorConsole::onDebugMessage(int32 priorityClass, const char msg[])  {

	if (!mConsoleHandle)
		return false;

	static char consoleMsg[1024];
	strcpy (consoleMsg, msg);
	strcat (consoleMsg, "\n");
	
	// write message to console
	DWORD charsWritten;
	WriteConsole(mConsoleHandle, consoleMsg, strlen(consoleMsg), &charsWritten, NULL);
	return true;
}

//================================================================================

void DebugMonitorConsole::openConsole() {

	// allocate and test if the application already has a console
	if (AllocConsole() == FALSE) {

		mAppHasConsole = true;
	}

	// retrive stdout handle for this process's console
	mConsoleHandle = GetStdHandle (STD_OUTPUT_HANDLE); 
}

//================================================================================

void DebugMonitorConsole::closeConsole() {

	// only free console if we are the one created it
	if (!mAppHasConsole)
		FreeConsole();
	
	mConsoleHandle = NULL;
}

//================================================================================

