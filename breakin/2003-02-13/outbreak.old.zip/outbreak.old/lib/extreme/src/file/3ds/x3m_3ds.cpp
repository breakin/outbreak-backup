#include "x3m_3ds.h"
#include "x3m_3dsscene.h"
#include "..\..\x3m_exception.h"
#include "..\..\x3m_typedef.h"
#include "..\..\math\x3m_vector.h"
#include "..\..\keyframing\x3m_tracks.h"
#include "..\..\debug\x3m_debug.h"

using namespace Extreme;

//================================================================

Loader_3DS::Loader_3DS() {

	Debug::debug ("Loader_3DS::Loader_3DS", "constructing...");
}

//================================================================

Loader_3DS::~Loader_3DS() {

	Debug::debug ("Loader_3DS::~Loader_3DS", "destructing...");
}

//================================================================

void Loader_3DS::readChunk(Loader_3DS::Chunk &chunk) const {

	readData(chunk.m_id);
	readData(chunk.m_length);
}

//================================================================

void Loader_3DS::read(void *data, int n) {

	fread(data,1,n,m_fptr);
}

//================================================================

void Loader_3DS::readString(char str[]) const {

	int ch;
	int C =0;

	ch = fgetc(m_fptr);
	
	while (ch != '\0' && ch != EOF) {
		
		str[C++] = ch;
		ch = fgetc(m_fptr);	
	}
	
	str[C] = '\0';
}

//================================================================

void Loader_3DS::readIntPercent(float32 &dst) {

	uint16 intPercent;

	readData(intPercent);

	// convert intval of 1..100 to float 0.0..1.0
	dst = (float32)intPercent / 100.0f;
}


//================================================================

void Loader_3DS::loadScene(const char filename[]) {//, IScene &sceneInterface) {

	m_fptr = fopen(filename,"rb");

	if (m_fptr == NULL)
		throw IOException("Loader_3DS::Could not load %s",filename);

	/// temprarily scene in 3ds format 
	Scene_3DS scene;

	/// chunk to use for data reading
	Chunk chunk;
	
	// read main chunk
	readChunk(chunk);
	if (chunk.m_id != 0x4D4D) {
		
		throw Exception("Loader_3DS::%s in not a valid .3ds file!",filename);
	}

	// set C to 6 (sizof chunk)
	long C = 6;

	// L is Limit - size of 3ds data
	long L = chunk.m_length;
	
	// read version
	readChunk(chunk);
	
	uint32 version;
	readData(version);

	C += chunk.m_length;

	while (C < L) {
		
		readChunk(chunk);
			
		switch (chunk.m_id) {
			
		case CHUNK_EDIT:
			Debug::debug ("Loader_3DS::loadScene", "loading scene edit chunk!");
			loadEditScene(scene, chunk.m_length - 6);
		break;

		case CHUNK_KEYFRAME:
			Debug::debug("Loader_3DS::loadScene","loading keyframing!");
			loadKeyFraming(scene, chunk.m_length - 6);
		break;
		
		default:
			fseek(m_fptr,chunk.m_length - 6,SEEK_CUR);
		}

		C+= chunk.m_length;
	}
	
	// update initial matrices
	// convert to X3M IScene format
	//scene.updateKeyFraming(0.0f);

	// print debug information
	Debug::log ("","Scene [%s]", filename);
	Debug::log ("","======================");
	Debug::log ("","Meshes    [%d]", scene.m_listMesh.size());
	Debug::log ("","Lights    [%d]", scene.m_listLight.size());
	Debug::log ("","Cameras   [%d]", scene.m_listCamera.size());
	Debug::log ("","Materials [%d]", scene.m_listMaterial.size());
	Debug::log ("","");
	
	Debug::log ("","Material Info");
	Debug::log ("","======================");

	for (int iMaterial = 0; iMaterial < scene.m_listMaterial.size(); iMaterial++) {

		Debug::log("","MATERIAL [%02d] - NAME : [%s]", iMaterial, scene.m_listMaterial[iMaterial].m_name);	
	}

	Debug::log ("","");
	Debug::log ("","Texture Info");
	Debug::log ("","======================");
	Debug::log ("","Textures  [%d]", scene.m_textureManager.size());

	for (int iTexture = 0; iTexture < scene.m_textureManager.size(); iTexture++)
		Debug::log("","ID : [%04d] REF : [%02d] - NAME : [%s]", 
			scene.m_textureManager[iTexture].m_id,
			scene.m_textureManager[iTexture].m_refCount,
			scene.m_textureManager[iTexture].m_name.c_str());
			


	
	fclose (m_fptr);
}

//================================================================

void Loader_3DS::loadTriMesh(TriMesh_3DS &object, long chunkLength) {

	long	C=0;
	Chunk	chunk;
	int		extra;
	
	while (C < chunkLength) {
	
		readChunk(chunk);
		
		extra = 0;
		switch (chunk.m_id) {

		// case vertexlist
		case CHUNK_TRIMESH_VLIST:
		//extra = 2;
		loadTriMeshVertices(object);
		break;
		
		// case facelist
		case CHUNK_TRIMESH_FLIST:
		loadTriMeshFaces(object);
		break;
		
		case CHUNK_TRIMESH_MLIST:
		loadTriMeshMapping(object);
		break;
		// case local object matrix
		case CHUNK_TRIMESH_LOCAL:
		loadTriMeshMatrix(object);
		break;

		default:
		C+=chunk.m_length;
		fseek(m_fptr,chunk.m_length - 6, SEEK_CUR);
		break;
		}
		//C+=chunk.m_length;
		//fseek(m_fptr,chunk.m_length - 6 - extra,SEEK_CUR);
	}
}

//================================================================

void Loader_3DS::loadTriMeshMapping(TriMesh_3DS &object) {

	uint16 nVerts;

	readData(nVerts);
	
	// SKIP FOR NOW

	// check if vertices not yet are allocated
	object.m_mapping.resize(nVerts);

	float32 u,v;

	for (int C =0 ; C < nVerts; C++) {
	
		readData(u);
		readData(v);
		object.m_mapping[C].m_u = u;
		object.m_mapping[C].m_v = v;
	}
}

//================================================================

void Loader_3DS::loadTriMeshMatrix(TriMesh_3DS &object) {
		
	// clear matrix
	memset(&object.m_matrix, 0, sizeof(float32) * 16);
	object.m_matrix[0][0] = 1.0f;
	object.m_matrix[1][1] = 1.0f;
	object.m_matrix[2][2] = 1.0f;
	object.m_matrix[3][3] = 1.0f;

	// read matrix
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			readData(object.m_matrix[i][j]);
	
	// swap Y/Z
	for (i = 0; i < 3; i++)
		std::swap(object.m_matrix[i][1], object.m_matrix[i][2]);
	for (int j = 0; j < 3; j++)
		std::swap(object.m_matrix[1][j], object.m_matrix[2][j]);
		
	// read translation (pivot)
	readData(object.m_matrix[3][0]);
	readData(object.m_matrix[3][2]);
	readData(object.m_matrix[3][1]);

	// set pivot point
	object.m_pivot = Vector3(object.m_matrix[3][0], object.m_matrix[3][1], object.m_matrix[3][2]);
}

//================================================================

void Loader_3DS::loadLight(const std::string &name, Scene_3DS &scene, long chunkLength) {

}

//================================================================

void Loader_3DS::loadCamera(const std::string &name, Scene_3DS &scene, long chunkLength) {

	Camera_3DS	*cam;		// new camera
	float32		px,py,pz;	// position vector comp
	float32		tx,ty,tz;	// target vector comp
	float32		bank,lense;	// bank, lens of camera
	
	// allocate a new camera and add it to scene
	cam = new Camera_3DS;
	scene.m_listCamera.push_back(cam);
	
	// set camera name
	cam->m_name = name;
		
	Debug::debug("Loader_3DS::loadCamera","Camera name [%s]",name.c_str());
	
	// read position vector
	readData(px);
	readData(pz);
	readData(py);	
	
	// read target vector
	readData(tx);
	readData(tz);
	readData(ty);
	
	// read bank and lense
	readData(bank);
	readData(lense);

	// set position
	cam->m_position = Vector3(px,py,pz);
	cam->m_target = Vector3(tx,ty,tz);
	cam->m_roll = 0.0f;
	cam->m_fov = (45.0 * X3M_PI / 180.0);
}

//================================================================

void Loader_3DS::loadEditScene(Scene_3DS &scene, long chunkLength) {

	Chunk chunk;
	char objName[256];
	uint32 C = 0;

	while (C < chunkLength) {
		
		readChunk(chunk);
		
		long pos = ftell(m_fptr);

		// check id to determine which type
		switch (chunk.m_id) {
		
		case CHUNK_OBJ:
			
			// get object name
			readString(objName);
			loadObject(objName, scene, chunk.m_length - 6 - strlen(objName) - 1);
		
		break;
		
		case CHUNK_MTRL:
			loadMaterial(scene, chunk.m_length - 6);
		break;

		default:	
			
			// read past chunk
			fseek(m_fptr,chunk.m_length - 6,SEEK_CUR);
		}
		
		// manually seek to chunk after object, in case something wasn't correcly read..
		fseek(m_fptr,pos + chunk.m_length - 6,SEEK_SET);
		C+= chunk.m_length;
	}
	
}

//================================================================

int32 Loader_3DS::loadSceneTexture(Scene_3DS &scene) {
	
	char texFile[80];
	readString(texFile);

	// check if a texture is used
	if (strlen(texFile) < 1)
		return Texture_3DS::ID_NONE;

	// check if already exist in scene's managers
	for (int iTex=0; iTex < scene.m_textureManager.size(); iTex++) {
	
		if (scene.m_textureManager[iTex].m_name.compare(texFile) == 0) {

			// increase reference count on that texture and return its ID
			scene.m_textureManager[iTex].m_refCount++;
			return scene.m_textureManager[iTex].m_id;
		}
	}

	// ok, not found,
	Texture_3DS texture;
	texture.m_name = texFile;
	texture.m_refCount = 1;
	texture.m_id = scene.m_textureManager.size();
	
	// add texture
	scene.m_textureManager.push_back(texture);
	return texture.m_id;
}

//================================================================

void Loader_3DS::loadMaterialTextureInfo(Scene_3DS &scene, TextureInfo_3DS &texInfo, long chunkLength) {

	Chunk chunk;
	long iLength = 0;

	Debug::debug("Loader_3DS::loadMaterial", "Load a new material");
	
	// exists, set to true
	texInfo.m_valid = true;

	while (iLength < chunkLength) {

		readChunk(chunk);
		long currentPos = ftell(m_fptr);
		
		switch (chunk.m_id) {

		case CHUNK_TMAP_NAME: 
			texInfo.m_textureID = loadSceneTexture(scene);
			break;	

		case CHUNK_TMAP_TILING: 
			readData(texInfo.m_flags);
			break;

		case CHUNK_TMAP_BLUR:
			readData(texInfo.m_blur);
			break;
			
		case CHUNK_TMAP_SCALEU:
			readData(texInfo.m_scaleU);
			break;	

		case CHUNK_TMAP_SCALEV: 
			readData(texInfo.m_scaleV);
			break;	

		case CHUNK_TMAP_OFFSETU:
			readData(texInfo.m_offsetU);
			break;

		case CHUNK_TMAP_OFFSETV: 
			readData(texInfo.m_offsetV);
			break;

		case CHUNK_TMAP_ROTATION: 
			readData(texInfo.m_rotation);
			break;	

		case CHUNK_TMAP_COLOR1: 
			readData(texInfo.m_rgbTint_1);
			break;

		case CHUNK_TMAP_COLOR2: 
			readData(texInfo.m_rgbTint_2);
			break;

		case CHUNK_TMAP_REDCOL: 
			readData(texInfo.m_rgbTint_r);
			break;	

		case CHUNK_TMAP_GREENCOL: 
			readData(texInfo.m_rgbTint_g);
			break;	

		case CHUNK_TMAP_BLUECOL	: 
			readData(texInfo.m_rgbTint_b);
			break;	

		default:
			Debug::debug ("Loader_3DS::loadMaterialTextureInfo", "Unkown chunk [%x]", chunk.m_id);
		}
	
		// manually seek to chunk after object, in case something wasn't correcly read..
		fseek(m_fptr,currentPos + chunk.m_length - 6,SEEK_SET);
		iLength += chunk.m_length;
	}
}

//================================================================

void Loader_3DS::loadMaterial(Scene_3DS &scene, long chunkLength) {

	Chunk chunk;
	long iLength = 0;
	Material_3DS material;

	Debug::debug("Loader_3DS::loadMaterial", "Load a new material");

	while (iLength < chunkLength) {

		// read chunk
		readChunk(chunk);

		// keep current position
		long currentPos = ftell(m_fptr);

		switch (chunk.m_id) {

		case CHUNK_MTRL_NAME:
		readString(material.m_name);
		break;
		
		case CHUNK_MTRL_AMBIENT:
		readData(material.m_ambient);
		break;
		
		case CHUNK_MTRL_DIFFUSE:
		readData(material.m_diffuse);
		break;
		
		case CHUNK_MTRL_SPECULAR:
		readData(material.m_specular);
		break;
		
		case CHUNK_MTRL_SHINEPCT:
		readIntPercent(material.m_shininess);
		break;
		
		case CHUNK_MTRL_SHINESTR:	
		readIntPercent(material.m_shineStrength);
		break;
		
		case CHUNK_MTRL_ALPHAPCT:
		readIntPercent(material.m_transparency);
		break;
		
		case CHUNK_MTRL_ALPHASTR:		
		readIntPercent(material.m_transStrength);
		break;
		
		case CHUNK_MTRL_ADDITIVE:	
		material.m_additive = true;
		break;
		
		case CHUNK_MTRL_WIREFRAMED:
		material.m_wireFramed = true;
		break;
		
		case CHUNK_MTRL_FACEMAP:
		material.m_faceMap = true;
		break;
		
		case CHUNK_MTRL_PHONGSOFT:
		material.m_phongSoft = true;
		break;
		
		case CHUNK_MTRL_WIRE_ABS:
		material.m_wireAbs = true;
		break;
		
		case CHUNK_MTRL_WIRE_SIZE:
		readData(material.m_wireAbs);
		break;
		
		case CHUNK_MTRL_SHADING:
		readData(material.m_shadeType);
		break;
		
		case CHUNK_MTRL_TWOSIDE:
		material.m_twoSided = true;
		break;

		case CHUNK_MTRL_TEXTURE:
		loadMaterialTextureInfo(scene,material.m_textMap1, chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_TEXMASK:
		loadMaterialTextureInfo(scene,material.m_textMask1,chunk.m_length - 6);
		break;
	
		case CHUNK_MTRL_TEXTURE2:
		loadMaterialTextureInfo(scene,material.m_textMap2,chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_TEXMASK2:
		loadMaterialTextureInfo(scene,material.m_textMask2,chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_BUMPMAP:
		loadMaterialTextureInfo(scene,material.m_bumpMap,chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_BUMPMASK:
		loadMaterialTextureInfo(scene,material.m_bumpMask,chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_SPECMAP	:
		loadMaterialTextureInfo(scene,material.m_specMap,chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_SPECMASK:
		loadMaterialTextureInfo(scene,material.m_specMask,chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_OPACMAP:
		loadMaterialTextureInfo(scene,material.m_opacMap,chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_OPACMASK:
		loadMaterialTextureInfo(scene,material.m_opacMask,chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_SHINMAP	:
		loadMaterialTextureInfo(scene,material.m_shineMap,chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_SHINMASK:
		loadMaterialTextureInfo(scene,material.m_shineMask,chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_RFLCTMAP:
		loadMaterialTextureInfo(scene,material.m_reflectMap,chunk.m_length - 6);
		break;
		
		case CHUNK_MTRL_RFLCTMASK:
		loadMaterialTextureInfo(scene,material.m_reflectMask,chunk.m_length - 6);
		break;
			
		// unsupported chunk
		default:

			Debug::debug("Loader_3DS::loadMaterial", "Unknown chunk [%x]", chunk.m_id);
			// read past chunk
			fseek(m_fptr,chunk.m_length - 6,SEEK_CUR);
		};
		
		// manually seek to chunk after object, in case something wasn't correcly read..
		fseek(m_fptr,currentPos + chunk.m_length - 6,SEEK_SET);
		iLength += chunk.m_length;

	}

	// copy material to scene
	scene.m_listMaterial.push_back(material);
}

//================================================================

void Loader_3DS::loadObject(const std::string &name, Scene_3DS &scene, long chunkLength) {

	Chunk		chunk;
	long		C = 0;
	int			D;
	Matrix4x4	m;
	Vector3	a,b;
	TriMesh_3DS*	mesh;
		
	while (C < chunkLength) {
		
		readChunk(chunk);
		
		switch (chunk.m_id) {
		
		case CHUNK_OBJ_TRIMESH:
			
			mesh = new TriMesh_3DS;
			mesh->m_name = name;
			
			// add mesh to scene
			scene.m_listMesh.push_back(mesh);
			
			// load trimesh
			loadTriMesh(*mesh, chunk.m_length - 6);
						
			// transform vertices into objectspace
			for (D=0; D < mesh->m_vertices.size(); D++) {

				float x = mesh->m_matrix[3][0];
				float y = mesh->m_matrix[3][1];
				float z = mesh->m_matrix[3][2];	
				
				mesh->m_vertices[D] -= Vector3(x,y,z);
				mesh->m_position = Vector3(x,y,z);
			}
			

			// calc face normals
			for (D=0; D < mesh->m_faces.size(); D++) {

				a = mesh->m_vertices[mesh->m_faces[D].m_vertices[1]] - mesh->m_vertices[mesh->m_faces[D].m_vertices[0]];
				b = mesh->m_vertices[mesh->m_faces[D].m_vertices[2]] - mesh->m_vertices[mesh->m_faces[D].m_vertices[0]];

				a.normalize();
				b.normalize();

				mesh->m_faces[D].m_normal = a % b;
				mesh->m_faces[D].m_normal.normalize();
			}
				
			// calculate bounding sphere
			mesh->m_bsphere = mesh->m_vertices[0].getLength();

			for (D=1; D < mesh->m_vertices.size(); D++) {
		
				if (mesh->m_vertices[D].getLength() > mesh->m_bsphere)
					mesh->m_bsphere = mesh->m_vertices[D].getLength();
			}

		break;
				
		case CHUNK_OBJ_CAMERA:
			loadCamera(name,scene,chunk.m_length - 6);
		break;

		case CHUNK_OBJ_LIGHT:
	//		loadLight(name,scene, chunk.m_length - 6);
	//	break;
		// fall through to default
		default:
			fseek(m_fptr,chunk.m_length - 6,SEEK_CUR);
		}
		
		C+= chunk.m_length;
	}
}

//================================================================

void Loader_3DS::loadTriMeshVertices(TriMesh_3DS &object) {
	
	uint16 vtxCnt;
	readData(vtxCnt);
	
	// resize and obtain pointer to mesh's vertices
	object.m_vertices.resize(vtxCnt);
	
	for (int C=0; C < vtxCnt; C++) {
		
		// store vertice data, y = z and z = inverse of y (-1 * y)
		readData(object.m_vertices[C][0]);
		readData(object.m_vertices[C][2]);	
		readData(object.m_vertices[C][1]);
	}
}

//================================================================

void Loader_3DS::loadTriMeshFaces(TriMesh_3DS &object) {
	
	uint16 fceCnt;
	uint16 fceIdx;
	static int j = 0;

	// read amount of faces
	readData(fceCnt);

	// resize facebuffer
	object.m_faces.resize(fceCnt);
	
	// load faces from disc
	for (int C=0;  C < fceCnt; C++) {
	
			readData(fceIdx);
			object.m_faces[C].m_vertices[1] = fceIdx;
			readData(fceIdx);
			object.m_faces[C].m_vertices[0] = fceIdx;
			readData(fceIdx);
			object.m_faces[C].m_vertices[2] = fceIdx;
		
		// set face color, every second to a different color.
/*		if (j == 0) 
			object.m_faces[C].m_color = (j == 0) ? 0x000022 : 0x00120000;
		else 
			object.m_faces[C].m_color = 0x002211;*/
		
		j = 1 - j;		
	
		/// Some unidentified value
		readData(fceIdx);
	}
}

//================================================================

void Loader_3DS::loadKeyFraming(Scene_3DS &scene, long chunkLength) {

	long C = 0;
	Chunk chunk;

	while (C < chunkLength) {

		readChunk(chunk);

		switch (chunk.m_id) 
		{
		
		case CHUNK_KF_LIGHT_AMBIENT:
		Debug::debug("Loader_3DS::loadKeyFraming","Light[ambient] object");
		loadKeyFramingLight(scene, chunk.m_length - 6);
		break;
		
		case CHUNK_KF_LIGHT_OMNI:
		Debug::debug("Loader_3DS::loadKeyFraming","Light[omni] object");
		loadKeyFramingLight(scene, chunk.m_length - 6);
		break;

		case CHUNK_KF_LIGHT_SPOT:
		Debug::debug("Loader_3DS::loadKeyFraming","Light[spot] object");
		loadKeyFramingLight(scene, chunk.m_length - 6);
		break;

		case CHUNK_KF_LIGHT_TARGET:
		Debug::debug("Loader_3DS::loadKeyFraming","Light[target] object");
		loadKeyFramingLight(scene, chunk.m_length - 6);
		break;
		
		case CHUNK_KF_MESH:		
		Debug::debug("Loader_3DS::loadKeyFraming","TriMesh object");
		loadKeyFramingMesh(scene, chunk.m_length - 6);
		break;

		case CHUNK_KF_CAMERA:
		Debug::debug("Loader_3DS::loadKeyFraming","Camera[normal] object");
		loadKeyFramingCamera(scene, chunk.m_length - 6);
		break;

		case CHUNK_KF_CAMERA_TARGET:
		Debug::debug("Loader_3DS::loadKeyFraming","Camera[target] object");
		loadKeyFramingCameraTarget(scene, chunk.m_length - 6);
		break;
		
		case CHUNK_KF_FRAMES:
		Debug::debug("Loader_3DS::loadKeyFraming","Frame information");
		loadKeyFramingFrames(scene);
		break;

		default:	
		fseek(m_fptr,chunk.m_length - 6,SEEK_CUR);
		}
		
		C+= chunk.m_length;
	}
}

//================================================================

void Loader_3DS::loadKeyFramingFrames(Scene_3DS &scene) {

	uint32 start;
	uint32 end;
	readData(start);
	readData(end);

	Debug::debug("Loader_3DS::loadKeyFramingFrames","Start[%d] End[%d]",start,end);
}

//================================================================

void Loader_3DS::loadKeyFramingLight(Scene_3DS &scene, long length) {

	Debug::debug("Loader_3DS::loadKeyFramingLight","Load Light Keyframing");
	
	long C = 0;
	Chunk chunk;
	long current;
	Camera_3DS*	camera;

	/// just seek past chunk and return for now
	fseek(m_fptr,length,SEEK_CUR);
	return;

	while (C < length) {

		readChunk(chunk);

		switch (chunk.m_id) {
		
		case CHUNK_KF_OBJECT_NAME:

		// store current file position
		current = ftell(m_fptr);
		current+= chunk.m_length-6;

		camera= (Camera_3DS*)getKeyFramingObject(scene);

		// set to offset after chunk
		fseek(m_fptr,current,SEEK_SET);
		break;	
		
		// mesh tracks
		case CHUNK_TRACK_POS:
		Debug::debug("Loader_3DS::loadKeyFramingLight","Light Position track");
		loadTrack(&camera->m_trackPos);
		break;

		case CHUNK_TRACK_FOV:
		Debug::debug("Loader_3DS::loadKeyFramingLight","Light FOV track");
		loadTrack(&camera->m_trackFov);
		break;
		
		case CHUNK_TRACK_ROLL:
		Debug::debug("Loader_3DS::loadKeyFramingLight","Light roll track");
		loadTrack(&camera->m_trackRoll);
		break;
		
		case CHUNK_TRACK_ROT:
		Debug::debug("Loader_3DS::loadKeyFramingLight","Light rotation track");

		case CHUNK_KF_OBJECT_PIVOT:
		case CHUNK_TRACK_COLOR:		
		case CHUNK_TRACK_MORPH:
		default:
		fseek(m_fptr,chunk.m_length-6,SEEK_CUR);
		}
	
		C+=chunk.m_length;
	}		
}

//================================================================

void Loader_3DS::loadKeyFramingCamera(Scene_3DS &scene, long length) {

 	Debug::debug("Loader_3DS::loadKeyFramingCamera","Load Camera[normal] Keyframing\n");
	
	Chunk			chunk;
	Camera_3DS*	camera;
	long iLength = 0;
	long current;
	long chunkStart = ftell (m_fptr);	

	while (iLength < length) {

		readChunk(chunk);

		switch (chunk.m_id) {
		
		case CHUNK_KF_OBJECT_NAME:

		// store current file position
		current = ftell(m_fptr);
		current+= chunk.m_length-6;

		camera= (Camera_3DS*)getKeyFramingObject(scene);
		
		if (camera==NULL) {

			Debug::error ("Loader_3DS::loadKeyFramingCamera", "No object found for these tracks!");
			fseek(m_fptr,chunkStart + length,SEEK_SET);
			return;
		}

		// set to offset after chunk
		fseek(m_fptr,current,SEEK_SET);
		break;	
		
		// mesh tracks
		case CHUNK_TRACK_POS:
		Debug::debug("Loader_3DS::loadKeyFramingCamera","Camera position track");
		loadTrack(&camera->m_trackPos);
		break;

		case CHUNK_TRACK_FOV:
		Debug::debug("Loader_3DS::loadKeyFramingCamera","Camera FOV track");
		loadTrack(&camera->m_trackFov);
		break;
		
		case CHUNK_TRACK_ROLL:
		Debug::debug("Loader_3DS::loadKeyFramingCamera","Camera roll track");
		loadTrack(&camera->m_trackRoll);
		break;
		
		case CHUNK_TRACK_ROT:
		Debug::debug("Loader_3DS::loadKeyFramingCamera","Camera rotation track");

		case CHUNK_KF_OBJECT_PIVOT:
		case CHUNK_TRACK_COLOR:		
		case CHUNK_TRACK_MORPH:
		default:
		fseek(m_fptr,chunk.m_length-6,SEEK_CUR);
		}
	
		iLength+=chunk.m_length;
	}
}

//================================================================

void Loader_3DS::loadKeyFramingCameraTarget(Scene_3DS &scene, long length) {

 	Debug::debug("Loader_3DS::loadKeyFramingCameraTarget","Load Camera[target] Keyframing\n");
	
	Chunk			chunk;
	Camera_3DS*	camera;
	long iLength = 0;
	long current;
	long chunkStart = ftell (m_fptr);

	while (iLength < length) {

		readChunk(chunk);

		switch (chunk.m_id) {
		
		case CHUNK_KF_OBJECT_NAME:

		// store current file position
		current = ftell(m_fptr);
		current+= chunk.m_length-6;

		camera= (Camera_3DS*)getKeyFramingObject(scene);
		
		if (camera==NULL) {

			Debug::error ("Loader_3DS::loadKeyFramingCamera", "No object found for these tracks!");
			fseek(m_fptr,chunkStart + length,SEEK_SET);
			return;
		}

		// set to offset after chunk
		fseek(m_fptr,current,SEEK_SET);
		break;	
		
		// mesh tracks
		case CHUNK_TRACK_POS:
		loadTrack(&camera->m_trackTarget);
		break;

		case CHUNK_TRACK_FOV:
		Debug::debug("Loader_3DS::loadKeyFramingCameraTarget","Camera fov track");
		loadTrack(&camera->m_trackFov);
		break;
		
		case CHUNK_TRACK_ROLL:
		Debug::debug("Loader_3DS::loadKeyFramingCameraTarget","Camera roll track");
		loadTrack(&camera->m_trackRoll);
		break;
		
		case CHUNK_KF_OBJECT_PIVOT:
		Debug::debug("Loader_3DS::loadKeyFramingCameraTarget","Camera object pivot track");

		case CHUNK_TRACK_ROT:
		Debug::debug("Loader_3DS::loadKeyFramingCameraTarget","Camera rotation track");

		case CHUNK_TRACK_COLOR:		
		case CHUNK_TRACK_MORPH:
		default:
		fseek(m_fptr,chunk.m_length-6,SEEK_CUR);
		}
	
		iLength+=chunk.m_length;
	}
}

//================================================================

void Loader_3DS::loadKeyFramingMesh(Scene_3DS &scene, long length) {

	Debug::debug("Loader_3DS::loacKeyFramingMesh","Load Mesh Keyframing");
	Chunk			chunk;
	TriMesh_3DS*	mesh;
	long iLength = 0;
	long current;
	long chunkStart = ftell(m_fptr);

	while (iLength < length) {

		readChunk(chunk);

		switch (chunk.m_id) {
		
		case CHUNK_KF_OBJECT_NAME:

		// store current file position
		current = ftell(m_fptr);
		current+= chunk.m_length-6;

		mesh = (TriMesh_3DS*)getKeyFramingObject(scene);

		if (mesh == NULL) {

			Debug::error ("Loader_3DS::loadKeyFramingMesh", "No object found for these tracks!");
			fseek(m_fptr,chunkStart + length,SEEK_SET);
			return;
		}

		// set to offset after chunk
		fseek(m_fptr,current,SEEK_SET);
		break;	
		
		// mesh tracks
		case CHUNK_TRACK_POS:
		Debug::debug("Loader_3DS::loadKeyFramingMesh","Mesh position track");		
		loadTrack(&mesh->m_trackPos);
		break;
		
		case CHUNK_TRACK_SCALE:
		Debug::debug("Loader_3DS::loadKeyFramingMesh","Mesh scale track");
		loadTrack(&mesh->m_trackScale);
		break;

		case CHUNK_TRACK_ROT:
		Debug::debug("Loader_3DS::loadKeyFramingMesh","Mesh rotation track");
//		loadTrack(mesh->m_trackRot);
//		break;
		case CHUNK_KF_OBJECT_PIVOT:
		case CHUNK_TRACK_COLOR:		
		case CHUNK_TRACK_MORPH:
		default:
		fseek(m_fptr,chunk.m_length-6,SEEK_CUR);
		}
	
		iLength+=chunk.m_length;
	}
}

//================================================================

Object_3DS* Loader_3DS::getKeyFramingObject(Scene_3DS &scene) {
	
	static char name[255];
	uint16		flags[3];
	
	readString(name);
	Debug::debug("Loader_3DS","Attempt to find object [%s]",name);

	// read flags
	readData(flags[0]);
	readData(flags[1]);
	readData(flags[2]);
	
	// seek cameras
	Debug::debug("Loader_3DS::getKeyFramingOject","Seek in camera list",name);
	std::list<Camera_3DS*>::iterator i = scene.m_listCamera.begin();
	while (i!=scene.m_listCamera.end()){

		if (strcmp((*i)->m_name.c_str(), name) == 0)
			return *i;
		i++;
	}

	Debug::debug("Loader_3DS::getKeyFramingOject","Seek in mesh list",name);
	std::list<TriMesh_3DS*>::iterator j = scene.m_listMesh.begin();
	while (j != scene.m_listMesh.end()){

		if (strcmp((*j)->m_name.c_str(), name) == 0)
			return *j;
		
		j++;
	}

	Debug::debug("Loader_3DS::getKeyFramingOject","Seek in light list",name);
	std::list<Light_3DS*>::iterator k = scene.m_listLight.begin();
	while (k != scene.m_listLight.end()){

		if (strcmp((*k)->m_name.c_str(), name) == 0)
			return *k;
		
		k++;
	}

	Debug::error ("Loader_3DS::getKeyFramingObject","Object not found!!");

	return NULL;
}

//================================================================
