#ifndef __EXTREME_TYPEDEFS_INC__
#define __EXTREME_TYPEDEFS_INC__

#include <stdio.h>

namespace Extreme {


/**
 * Extreme engine source options and type 
 * definitions.
 * @author	:	Peter Nordlander
 * @date	:	2001-10-15
 */

//========================================================================
// Debug control macros
//========================================================================

// #define X3M_FORCEDEBUG					///< Set if logging should occur in release mode
#define X3M_DEBUG_DEFAULT_FILE			///< Set if default debug monitor should write to file
//#define X3M_DEBUG_DEFAULT_CONSOLE		///< Set if default debug monitor should write to a console window

	
//========================================================================
// Compiler speedup and customization pragmas
//========================================================================

#pragma warning (disable:4786)

#ifndef _DEBUG
/*
	#pragma optimize("p",on)	///< Optimize floating point aritmethics, generate fpu instructions directly
	#pragma intrinsic(memcpy)	///< Force function memcpy to be inlined
	#pragma intrinsic(memset)	///< Force function memset to be inlined
	#pragma intrinsic(memcmp)	///< Force function memcpy to be inlined
	#pragma intrinsic(strcpy)	///< Force function strcpy to be inlined
	#pragma intrinsic(strcat)	///< Force function strcat to be inlined
	#pragma intrinsic(strcmp)	///< Force function strcmp to be inlined
	#pragma intrinsic(strlen)	///< Force function strlen to be inlined
	#pragma intrinsic(fabs)		///< Force function fabs to be inlined
	#pragma intrinsic(abs)		///< Force function abs to be inlined
*/
#endif

//========================================================================
// System compiler conventions
//========================================================================
	
	#define X3M_INLINE	 __forceinline
	#define X3M_FASTCALL __fastcall

//========================================================================
// System owndefined types
//========================================================================

	/// unsigned types
	typedef unsigned long	uint32;
	typedef unsigned short	uint16;
	typedef unsigned char	uint8;
	
	/// signed types
	typedef __int64	int64;
	typedef long	int32;
	typedef short	int16;
	typedef char	int8;

	/// floating point types
	typedef float	float32;
	typedef double	float64;
	typedef float32	gpu_float;


//========================================================================
// Math constants
//========================================================================

	const float64 X3M_PI		= 3.1415926535897932384626433832795;
	const float64 X3M_TWOPI		= 6.283185307179586476925286766559;
	const float64 X3M_RADTODEG	= 57.295779513082320876798154814105;
	const float64 X3M_DEGTORAD	= 0.017453292519943295769236907684886;

} // end namespace

#endif
