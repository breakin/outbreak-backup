#ifndef __EXTREME_ROOT_SYSTEM_INC__
#define __EXTREME_ROOT_SYSTEM_INC__

#include "x3m_typedef.h"
#include "rendersystem\x3m_rendersystem.h"
#include "resource\x3m_texturemanager.h"
#include "resource\x3m_materialmanager.h"
#include "soundsystem\x3m_soundsystem.h"


namespace Extreme {

	/**
	 * @namespace	System
	 *				Extreme's system methods, applications uses these methods
	 *				to gain access to any of extreme's singleton system managers and subsystem's
	 * @author		Peter Nordlander
	 * @date		2001-12-30
	 *
	 * @todo		Make it possible to get information about the current device's capabilities (Pure device, hw vertexproc. etc)
	 *
	 */

	class System : public TSingleton<System> 
	{
	public:

		/**
		 * Constructor
		 */
		System();

		/**
		 * Destructor
		 */
		~System();
		
		/**
		 * Get singleton instance of Extreme rendersystem
		 * @return Pointer to System's RenderSystem
		 */
		RenderSystem * getRenderSystem() {
			return &RenderSystem::getInstance();
		}

		/**
		 * Get singleton instance of Extreme texturemaneger
		 * @return Pointer to System's TextureManager
		 */
		TextureManager * getTextureManager() {
				return &TextureManager::getInstance();
		}

		/**
		 * Get singleton instance of sound subsystem
		 * @return Pointer to System's SoundSystem
		 */
		SoundSystem * getSoundSystem() {
			return &SoundSystem::getInstance();
		}

	private:
		
		TSmartPtr<ModelManager>		 mModelManager;
		TSmartPtr<TextureManager>	 mTextureManager;	///< Extreme system's texturemanager
		TSmartPtr<MaterialManager>   mMaterialManager;	///< Extreme system's materialmanager
		TSmartPtr<RenderSystem>  	 mRenderSystem;		///< Extreme system's rendersystem
		TSmartPtr<SoundSystem>   	 mSoundSystem;		///< Extreme system's soundsystem
	};
}

#endif