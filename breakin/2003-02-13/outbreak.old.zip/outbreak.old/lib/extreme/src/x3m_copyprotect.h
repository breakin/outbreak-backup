#ifndef __EXTREME_NOCOPIABLE_INC__
#define __EXTREME_NOCOPIABLE_INC__

namespace Extreme {

	/**
	 * @class	CopyProtected
	 * @brief	Only serves one purpose, all classes inheriting this class will not be able to copy implicitly
	 * @author	Peter Nordlander
	 * @date	2001-10-29
	 */
	
	class CopyProtected
	{
	public:
		
		/// constructors
		CopyProtected() {};

		/// destructor
		~CopyProtected() {};

	protected:

		/// hide copy contructor and assigment operator
		CopyProtected(const CopyProtected& other) {}
		CopyProtected& operator = (const CopyProtected & other) { return *this; }
	};
}

#endif
