//================================================================================
// Include files
//================================================================================

#include "x3m_msgqueue.h"
#include "debug\x3m_debug.h"

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

static uint32 s_ref_cnt = 0;

//================================================================================
// Method implementations
//================================================================================

MsgQueue::MsgQueue()  {

	// make uniqe name
	char temp[10];
	sprintf (temp,"mutex_%d", s_ref_cnt++);

	Debug::debug ("MsgQueue", "Constructing...");
	mFilter = MSGGROUP_ALL;

	mMutex.create(temp);
	mEvent.create();
}

//===================================================================================

MsgQueue::~MsgQueue() {

	Debug::debug ("MsgQueue", "Destructing");
}

//===================================================================================

bool MsgQueue::addMessage(eMsgGroup group, eMsgType msg, uint32 param, uint32 extra) {

	/// check if message is alloewed in queue
	if (!(group & mFilter))
		return true;
	
	/// lock mutex
	if (mMutex.wait()) {;

		/// build message
		Msg newMsg;
		newMsg.mGroup	= group;
		newMsg.mMsg		= msg;
		newMsg.mParam	= param;
		newMsg.mExtra	= extra;

		/// push last in queue
		mQueue.push_back(newMsg);

		/// unlock mutex
		mMutex.unlock();
		
		// sen "message arrive" signal
		mEvent.pulse();

		return true;
	}
	
	Debug::error ("MsgQueue","Mutex were not able to lock!");
	return false;
}

//===================================================================================

bool MsgQueue::waitMessage(Msg &msg) {

	/// if there are messages in queue, threre is no need to wait and block
	if (!mQueue.empty())
		return getMessage(msg, true);

	/// queue is empty, wait for message
	mEvent.wait();
	return getMessage(msg, true);
}

//===================================================================================
 
bool MsgQueue::getMessage(Msg &msg, bool waitIfBusy) {

	if (mQueue.empty())
		return false;

	if (mMutex.wait(waitIfBusy ? SignalObject::WAIT_INFINITE : 0)) {

		/// obtain message
		msg = mQueue.front();
		mQueue.pop_front();

		/// unlock mutex
		mMutex.unlock();
	
		return true;
	}

	Debug::error ("MsgQueue","Mutex were not able to lock!");
	return false;
}

//===================================================================================

bool MsgQueue::isEmpty() {

	return mQueue.empty();
}

//===================================================================================

const uint32 MsgQueue::getFilter() const {

	return mFilter;
}

//===================================================================================

void MsgQueue::setFilter(const uint32 filter) {

	mFilter = filter;

	// additial check, do not let user to filter SYS messages
	if (!(mFilter & MSGGROUP_SYS))
		mFilter |= MSGGROUP_SYS;

}

//===================================================================================

bool MsgQueue::flush() {

	if (!mMutex.wait())
		return false;

	Debug::log ("MsgQueue", "Flush message queue...");
	mQueue.clear();
	mMutex.unlock();

	return true;
}

//===================================================================================

