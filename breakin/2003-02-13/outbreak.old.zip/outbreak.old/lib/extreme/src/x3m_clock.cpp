//================================================================================
// Include files
//================================================================================

#include "x3m_clock.h"
#include "debug\x3m_debug.h"
#include "resource\x3m_texturemanager.h"
#include <windows.h>

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Method implementations
//================================================================================

Clock::Clock() {

	X3M_DEBUG ("Clock", "Constructing...");
	
	TextureManager::getInstance();

	mStart		= 0.0;
	mStop		= 0.0;
	mRunning	= false;
	
	// retrieve frequency
	__int64 frequency;
	QueryPerformanceFrequency((LARGE_INTEGER*)&frequency);
	
	// convert freq. to float64 format
	mFrequency = static_cast<float64> (frequency);
}

//================================================================================

Clock::~Clock() {
	X3M_DEBUG ("Clock", "Desstructing...");
}

//================================================================================

void Clock::start() {

	__int64 start;
	QueryPerformanceCounter((LARGE_INTEGER*)&start);
	
	// convert to float64 format
	mStart = (float64)start;
	mRunning = true;
}

//================================================================================

void Clock::stop () {

	__int64 stop;
	QueryPerformanceCounter((LARGE_INTEGER*)&stop);
	
	// convert to float64 format
	mStop	  = (float64)stop;
	mRunning = false;
}

//================================================================================

const float64 Clock::getTime() const {
	
	float64 endTime = mStop;
	
	// get current time if clock is running
	if (mRunning) {

		__int64 intTime;
		QueryPerformanceCounter((LARGE_INTEGER*)&intTime);
		endTime = (float64) intTime;
	}

	// return time in seconds
	return (endTime - mStart) / mFrequency;
}

//================================================================================
