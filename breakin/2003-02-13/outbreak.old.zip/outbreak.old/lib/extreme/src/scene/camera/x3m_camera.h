#ifndef __EXTREME_SCENE_CAMERA_INC__
#define __EXTREME_SCENE_CAMERA_INC__

#include "..\x3m_scenenode.h"
#include "..\volume\x3m_frustum.h"
#include "..\..\math\x3m_vector.h"
#include "..\..\math\x3m_matrix.h"

namespace Extreme {

	/**
	 * @class	Camera
	 * @brief	Represent a target camera
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */

	class Camera : public SceneNode
	{
	public:

		/**
		 * Constructor
		 */
		Camera();
		
		/**
		 * Destructor
		 */
		virtual ~Camera();

		/**
		 * Set roll angle
		 * @param roll Angle of rotation around view/lookat vector
		 */
		void setRoll(const float32 roll);
		
		/**
		 * Get roll value
		 * @return Current roll angle round cameras lookat vector
		 */
		const float32 getRoll() const;

		/**
		 * Set field of view
		 * @param fov FieldOfView in radians
		 */
		void setFOV(const float32 fov);

		/**
		 * Get Camera's field of view
		 * @return Currently set field of view, in radians
		 */
		const float32 getFOV() const;

		/**
		 * Set camera's target vector
		 * @param target Target/lookat vector
		 */
		void setTarget(const Vector3 &target);

		/**
		 * Get camera's target vector
		 * @return Camera's target/lookat vector
		 */
		const Vector3 getTarget() const;

		/**
		 * Get camers focal length
		 * @return Camera's focal length
		 */
		const float32 getFocalLength() const;
		
		/**
		 * Get camera's view frustum volume
		 * @return Camera's view frustum volume
		 */
		const Frustum & getFrustum() const;

		/**
		 * Update transformation matrix
		 */
		void updateMatrix();


	protected:

		/// rebuild the frustum with current configuration
		void updateFrustum();
	
		float32	mRoll;		///< Camera's roll angle
		float32 mFov;		///< Camera's Field Of View
		Vector3	mTarget;	///< Camera's Target vector
		Frustum mFrustum;	///< Camera's View Frustum volume
	};
}

#endif
