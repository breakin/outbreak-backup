#ifndef __EXTREME_SCENEGRAPH_RENDERABLE_INC__
#define __EXTREME_SCENEGRAPH_RENDERABLE_INC__

namespace Extreme {


	class Renderable
	{
	public:

	protected:
	};
}

#endif
