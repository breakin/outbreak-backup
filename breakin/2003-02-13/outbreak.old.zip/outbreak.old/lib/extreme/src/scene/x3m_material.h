#ifndef __EXTREME_SCENE_MATERIAL_INC__
#define __EXTREME_SCENE_MATERIAL_INC__

#include "..\..\x3m_typedef.h"
#include "..\..\device\d3d\x3m_d3dversion.h"
#include "x3m_texture.h"

namespace Extreme {

	class Material
	{
	public:

		void setAmbient(const float32 ambient);
		const float32 getAmbient() const;

		void setSpecular(const float32 specular);
		const float32 getSpecular() const;

		void setDiffuse(const float32 i

	protected:

		uint32		m_textureID;
		D3DMATERIAL	m_d3dMaterial;
	};
}

#endif