#ifndef __EXTREME_SCENE_VERTEXBUFFER_INC__
#define __EXTREME_SCENE_VERTEXBUFFER_INC__

#include "..\rendersystem\x3m_d3dutil.h"
#include "..\resouces\x3m_resoucemanager.h"

namespace Extreme {

	/**
	 * [Extreme Technology 3D Engine]
	 * ==============================
	 * @class	:	CVertexBuffer
	 * @brief	:	Encapuslates functionallity of a Direct3D vertexbuffer together with an indexbuffer
	 * @author	:	Peter Nordlander
	 * @date	:	2001-12-05
	 */
	
	template <typename VERTEX>
	class VertexBuffer : public HardwareResouce
	{
	public:
		
		/**
		 * Vertexbuffer allocation/usage models
		 */
		enum {

			DYNAMIC = 0x01,
			STATIC	= 0x02,
		}

		/// constructor/destructor
		VertexBuffer();
		~VertexBuffer();

		/// create device dep. vertexbuffer
		void create(uint32 numVertices, const int32 usage = VertexBuffer<VERTEX>::STATIC);
		
		/// release vertexbuffer
		void release();
	
		/// check if vertexbuffer currently is locked
		const bool isLocked() const;

		/// get vertexbuffer type information
		const int32 getType() const;

		/// get number of vertices currently stored within buffer
		const uint32 getSize() const;

		/// get format of vertices stored in buffer
		const uint32 getVertexFormat() const;

		/// get access to vertex data 
		const VERTEX * lock(const bool discard = true);

		/// get access to the direct3d hardware vertexbuffer interface
		IDirect3DVertexBuffer * getD3DVertexBuffer();

		/// unlock vertexbuffer
		void unlock();

		/// upload vertexdata to hardware optimal memory
		void upload();

	protected:
		
		/// create mirror in hardware
		void createHardwareResource();

		/// initialize members to default
		void init();
		
		int32					m_type;				///< Buffer type (static/dynamic)
		int32					m_size;				///< Number of vertices in buffer
		IDirect3DVertexBuffer	m_d3dVB;			///< D3D Vertexbuffer interface
		VERTEX *				m_swVB;				///< Software backup
		bool					m_hwOptimized;		///< True if buffer resides in hardware
	};


//==============================================================================================

template <typename VERTEX>
X3M_INLINE VertexBuffer<VERTEX>::VertexBuffer() {
		
	// initialize vb data to default
	init();
}

//==============================================================================================

template <typename VERTEX>
X3M_INLINE const int32 VertexBuffer<VERTEX>::getSize() const {

	return m_size;
}

//==============================================================================================

template <typename VERTEX>
X3M_INLINE const uint32 VertexBuffer<VERTEX>::getVertexFormat() const {

	return VERTEX::FORMAT;
}

//==============================================================================================

template <typename VERTEX>
X3M_INLINE void VertexBuffer<VERTEX>::allocateHardwareResource() {

	IDirect3DDevice * d3dDevice = RenderSystem::getInstance().getD3DDevice();

	X3M_ASSERT (d3dDevice);
	X3M_ASSERT (m_d3dVB == NULL);

	// find correct usage for this vb type
	DWORD usage = (m_type == DYNAMIC) ? D3DUSAGE_DYNAMIC : D3DUSAGE_WRITEONLY;
	
	// create buffer
	HRESULT result = d3dDevice->CreateVertexBuffer(size * sizeof(VERTEX), usage, VERTEX::FORMAT, D3DPOOL_MANAGED, &m_d3dVB);
	
	if (result != D3D_OK)
		throw Exception ("Failed to create vertexbuffer! [%s]", Direct3DUtil::getInstance().resultToString(result));
}

//==============================================================================================

template <typename VERTEX>
X3M_INLINE void VertexBuffer<VERTEX>::create(const uint32 size, const int32 type) {

	// set properties accordingly
	m_type = type;
	m_size = size;

	// create vertexbuffer in system memory
	m_swVB = new VERTEX[size];
}

//==============================================================================================

template <typename VERTEX>
X3M_INLINE void VertexBuffer<VERTEX>::release() {

	COM_SAFE_RELEASE(m_d3dVB);

	// no software backup i yet implemented, include just for sake of safety
	if (m_swVB)
		delete[] m_swVB;

	init();
}

//==============================================================================================

template <typename VERTEX>
X3M_INLINE void VertexBuffer<VERTEX>::init() {

	m_d3dVB  = NULL;
	m_swVB	 = NULL;
	m_size	 = 0;
	m_locked = false;
	bool hwOptimized = false;
}

//==============================================================================================

template <typename VERTEX>
X3M_INLINE VERTEX * VertexBuffer<VERTEX>::isLocked() {

	return m_locked;
}

//==============================================================================================

template <typename VERTEX>
X3M_INLINE VERTEX * VertexBuffer<VERTEX>::Lock(const bool discardContents) {

	X3M_ASSERT (!isLocked());
	VERTEX * pData = NULL;

	if (m_type == DYNAMIC) {

		X3M_ASSERT (m_d3dVB != NULL);

		DWORD lockUsage = 0;

		// only apply usage of lock if buffer is dynamic
		if (m_type == DYNAMIC)
			lockUsage = discardContents ? D3DLOCK_DISCARD : D3DLOCK_NOOVERWRITE;

		// lock the buffer
		HRESULT result = m_d3dVB->Lock(0,0,(BYTE**)&pData, lockUsage);

		// check for errors
		if (result != D3D_OK)
			throw Exception ("Unable to lock vertexbuffer [%s]", Direct3DUtil::resultToString(result)); 
	}
	else {

		X3M_ASSERT (m_swVB != NULL);
		pData = m_swVB;
	}

	m_locked = true;
	return pData;
}

//==============================================================================================

template <typename VERTEX>
X3M_INLINE void VertexBuffer<VERTEX>::unlock() {

	X3M_ASSERT (isLocked);
	X3M_ASSERT (m_d3dVB != NULL);
	
	// unlock vertexbuffer
	HRESULT result = m_d3dVB->Unlock();

	// check for errors
	if (result != D3D_OK)
		throw Exception ("Unable to unlock vertexbuffer [%s]", Direct3DUtil::resultToString(result)); 

	m_locked = false;
}

//==============================================================================================

#endif
