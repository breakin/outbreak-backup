#ifndef __EXTREME_SCENE_INC__
#define __EXTREME_SCENE_INC__

#include "..\math\x3m_matrix.h"
#include "..\template\x3m_smartptr.h"
#include "..\rendersystem\x3m_rendercache.h"
#include "volume\x3m_bsphere.h"

#include <string>
#include <map>

namespace Extreme {

	/**
	 * @class	SceneNode
	 * @brief	Represents a sceneNode interface, only abstract and must be inhertied/subclassed
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */
	class SceneNode
	{
	public:        
		
		/**
		 * Virtual destructor
		 */
		virtual ~SceneNode();

		/** di
		 * Add a sceneNode child
		 * @param child Any object implementing the SceneNode interface
		 */ 
		void addChild (const SceneNode * Node);

		/**
		 * Remove a child to this scenenode by its name
		 * @param name Name of child to remove
		 */
		void removeChild(const std::string &name);
		
		/**
		 * Retrieve a childobject by its name
		 * @param name Name of child to retrieve
		 * @return The child with name @a name, NULL if not found
		 */
		TSmartPtr<SceneNode> getChild(const std::string &name);

		/**
		 * Retrieve a childobject by its name (const)
		 * @param name Name of child to retrieve
		 * @return The child with name @a name, NULL if not found
		 */
		const TSmartPtr<SceneNode> getChild(const std::string &name) const;

		/** 
		 * Update frame of animation on this object and all of it children recursivly
		 * @param frame A numeric framenumber, valid values differs and are scene specific
		 */ 
		void update(const float32 frame);

		/** 
		 * Update frame of animation on this object and all of it children recursivly
		 * @param frame A numeric framenumber, valid values differs and are scene specific
		 */ 
	//	void exportRenderUnits(Accumulator &renderCache, LightListHandle lightList = NULL, TSmartPtr<SceneNode> parent = NULL);

		/**
		 * Get matrix which transforms this sceneNode into other spaces
		 * @return The sceneNode's transformation matrix
		 */
		const Matrix4x4 & getToParent() const;

		/**
		 * Get matrix which transform others into this sceneNode's space
		 * @return The sceneNode's inverse transformation matrix
		 */
		const Matrix4x4 & getToLocal() const;

		/**
		 * Set transformation matrix
		 * @return The sceneNode's transformation matrix
		 */	
		const Matrix4x4 & getMatrix() const;

		/**
		 * Set transformation matrix
		 * @param matrix The matrix object to associate with this sceneNode
		 */
		void setMatrix(const Matrix4x4 &matrix);

		/**
		 * Get this node's bounding sphere
		 * @return The boudningsphere surrounding this node
		 */
		const BSphere & getBoundingSphere();

	protected:
				
		/**
		 * Constructor
		 */
		SceneNode();
		
		typedef std::map<std::string, TSmartPtr<SceneNode> > SceneNodeMap;

		bool						mInvalidMatrix;		///< Flag indicating weihter the sceneNode's matrix is invalid
		BSphere						mBoundingSphere;	///< Bouding sphere surrounging the total volume of the sceneNode	
		SceneNodeMap				mChildren;			///< List of children
	};

	/**
	 * SceneNode handle
	 */
	typedef TSmartPtr<SceneNode> SceneNodeHandle;
}

#endif