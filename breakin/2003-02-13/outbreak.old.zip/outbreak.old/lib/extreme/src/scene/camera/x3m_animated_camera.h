#ifndef __EXTREME_SCENE_CAMERA_ANIMATED_INC__
#define __EXTREME_SCENE_CAMERA_ANIMATED_INC__

#include "x3m_camera.h"
#include "..\x3m_animated.h"

namespace Extreme {

	/**
	 * @class	AnimatedCamera
	 * @brief	Represent an animated target camera
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */

	class AnimatedCamera : public Camera, public AnimatedObject
	{
	public:
		
		/// constructor/destructor
		AnimatedCamera();
		virtual ~AnimatedCamera();

		/// update camera keyframing tracks/matrix
		void updateKeyFraming(const float32 t);
		
		/// set camera'a tracks
		void setTargetTrack(const TrackVector &targetTrack);
		void setRollTrack(const TrackFloat &rollTrack);
		void setFovTrack(const TrackFloat &fovTrack);

		/// get camera's tracks
		TrackFloat&  getRollTrack();
		TrackFloat&  getFovTrack();
		TrackVector& getTargetTrack();

	protected:
		
		TrackFloat	mTrackRoll;		///< Camera Roll track
		TrackFloat	mTrackFov;		///< Camera Field of view track
		TrackVector	mTrackTarget;	///< Camera Target track
	};
}

#endif
