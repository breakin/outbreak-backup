#ifndef __EXTREME_VOLUME_BOUNDSPHERE_INC__
#define __EXTREME_VOLUME_BOUNDSPHERE_INC__

#include "..\..\math\x3m_vector.h"
#include "x3m_volume.h"

namespace Extreme {

	/**
	 * @class	BSphere
	 * @brief	Bounding Sphere Volume
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */

	class BSphere : public BVolume
	{
	public:

		/**
		 * Constructor
		 */
		BSphere() {}

		/**
		 * Constructor
		 * @param centre Centre of sphere
		 * @param radius Radius of sphere
		 */
		BSphere(const Vector3 &centre, const float32 radius) : mCentre(centre), mRadius(radius) {}
		
		/**
		 * Copy constructor
		 * @param other Other to initialize this object with
		 */
		BSphere(const BSphere &other);

		/**
		 * Get sphere's radius 
		 * @return Sphere's radius
		 */
		const float32 getRadius() const;

		/**
		 * Set sphere's radius 
		 * @param radius New radius of sphere
		 */
		void setRadius(const float32 radius);

		/**
		 * Get sphere's centre point
		 * @return Sphere's centre point
		 */
		const Vector3 &getCentre() const;
		
		/**
		 * Set sphere's centre point 
		 * @param position Sphere's new position
		 */
		void setCentre(const Vector3 &position);

		float32	mRadius;	///< Sphere's radius
		Vector3	mCentre;	///< Sphere's position/centre

		const BSphere merge(const BSphere &other) const;
		virtual const bool isIntersecting(const Vector3 &position, const Vector3 &direction, const double maxT=-1) const;
		virtual const double getIntersection(const Vector3 &position, const Vector3 &direction, const double maxT=-1) const;
		virtual const bool isIntersecting(const Vector3 &position) const;
	};
}

#endif