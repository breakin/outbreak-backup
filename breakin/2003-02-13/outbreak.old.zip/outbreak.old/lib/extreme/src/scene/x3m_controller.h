#ifndef __EXTREME_OBJECT_CONTROLLER_INC__
#define __EXTREME_OBJECT_CONTROLLER_INC__

namespace Extreme {

	/**
	 * @class Controller
	 * @brief Object controller interface, controls and updates an object dependant on time
	 * @author Peter Nordlander
	 */
	class Controller
	{
	public:
		
		/**
		 * Destructor
		 */
		virtual ~Controller();

		/**
		 * Update attached object of this controller
		 * @param t Time factor
		 */
		virtual void update(const float32 t);

		// virtual void attachObject(
	protected:

		Controller();
	};

}