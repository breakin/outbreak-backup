#ifndef __EXTREME_SCENE_INC__
#define __EXTREME_SCENE_INC__

#include "..\math\x3m_matrix.h"

namespace Extreme {

	/**
	 * @class	SceneGraph
	 * @brief	Represents a scenegraph interface, only abstract and must be inhertied/subclassed
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */

	class SceneNode
	{
	public:        
		
		/**
		 * Virtual destructor
		 */
		virtual ~SceneGraph();

		/** 
		 * Add a scenegraph child
		 * @param child Any object implementing the SceneGraph interface
		 */ 
		virtual void addLight(SceneGraph * child);

		virtual void addCamera(Camera * camera);

		virtual void addMesh(Mesh * mesh);

		virtual Mesh * getMesh(const std::string &name);
		virtual const Mesh * getMesh(const std::string &name) const;

		virtual Camera * getCamera(const std::string &name);
		virtual const Camera * getCamera (const std:.string &name) const;

		virtual Light * getLight(const std::string &name);
		virtual const Light * getLight(const std::string &name) const;

		virtual void removeCamera(const std::string &name);

		virtual void removeLight(const std:.string &name);

		virtual void removeMesh(const std::string &name);

		/** 
		 * Remove a scenegraph child
		 * @param child Addrees of child object to remove from children
		 */ 
		void removeChild(SceneGraph * graph);
		
		/** 
		 * Update frame of animation on this object and all of it children recursivly
		 * @param frame A numeric framenumber, valid values differs and are scene specific
		 */ 
		void updateAnimation(const float32 frame);

		/** 
		 * Update frame of animation on this object and all of it children recursivly
		 * @param frame A numeric framenumber, valid values differs and are scene specific
		 */ 
		void exportVisibleGeometry(Camera &camera, DrawList &list);

		/**
		 * Get matrix which transforms this scenegraph into other spaces
		 * @return The scenegraph's transformation matrix
		 */
		const Matrix4x4 & getToParent() const;

		/**
		 * Get matrix which transform others into this scenegraph's space
		 * @return The scenegraph's inverse transformation matrix
		 */
		const Matrix4x3 & getToLocal() const;

		/**
		 * Set transformation matrix
		 * @return The scenegraph's transformation matrix
		 */	
		const Matrix4x4 & getMatrix() const;

		/**
		 * Set transformation matrix
		 * @param matrix The matrix object to associate with this scenegraph
		 */
		void setMatrix(const Matrix4x4 &matrix);

	protected:
		
		/**
		 * Constructor
		 */
		SceneGraph();
		
		bool						mInvalidMatrix;		///< Flag indicating weihter the scenegraph's matrix is invalid
		BSphere						mBoundingSphere;	///< Bouding sphere surrounging the total volume of the scenegraph	
		std::list<SceneGraph*>		mChildren;			///< List of children belonging to this scenegraph
	};
}

#endif