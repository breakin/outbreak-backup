#ifndef __EXTREME_VOLUME_FRUSTUM_INC__
#define __EXTREME_VOLUME_FRUSTUM_INC__

#include "x3m_bsphere.h"
#include "x3m_aabb.h"
#include "..\..\math\x3m_plane.h"
#include "..\..\math\x3m_vector.h"

// stl
#pragma warning (disable:4786)
#include <vector>


namespace Extreme {


	/**
	 * @class	:	Frustum
	 * @brief	:	Representin a Frustum viewing volume
	 * @author	:	Peter Nordlander
	 * @date	:	2001-12-22
	 */
	
	class Frustum
	{
	public:

		/**
		 * Frustum Volume Test Results
		 */
		enum eVolumeTest {

			VOLUME_INSIDE  = 0x01,	///< Volume is indside frustum
			VOLUME_OUTSIDE = 0x02,	///< Volume is outside frustum
			VOLUME_CLIPPED = 0x03,	///< Volume is partially inside
		};
	
		/**
		 * Constructor
		 */
		Frustum();

		/**
		 * Add plane to frustum
		 * @param plane An infinite plane which will be added to the frustum
		 */
		void addPlane(const Plane &plane);

		/**
		 * Get a plane in frustum from its index
		 * @param index A valid index in plane storage
		 * @return Reference to a plane associcated with index
		 */
		Plane & getPlane(const int32 index);
		
		/**
		 * Get amount of planes which makes up the frustum
		 * @return Amount of planes in frustum
		 */
		const uint32 getNumPlanes() const;

		/**
		 * Bounding volume tests, frustum<>bounding sphere
		 * @param planeMask will contain the planes on which the volume intersected as a bitmask, NULL if not used
		 * @return An eVolumeTest indicating weither sphere was inside, outside or intersecting @see eVolumeTest
		 */
		const eVolumeTest checkCollision(const BSphere &sphere, uint32 * planeMask = NULL);
		
		/**
		 * Bounding volume tests, frustum<>axis aligned bounding box
		 * @param planeMask will contain the planes on which the volume intersected as a bitmask, NULL if not used
		 * @return An eVolumeTest indicating weither sphere was inside, outside or intersecting @see eVolumeTest
		 */		
		const eVolumeTest checkCollision(const AABB &box, uint32 * planeMask = NULL);

	protected:

		std::vector<Plane>	mPlanes;	///< Frustum's planes
	};

}

#endif