//================================================================================
// Include files
//================================================================================

#include "x3m_animated_camera.h"
#include "..\..\debug\x3m_debug.h"

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Method implementaton
//================================================================================

AnimatedCamera::AnimatedCamera() {

	Debug::debug ("AnimatedCamera::AnimatedCamera", "Constructing...");
}

//================================================================================

AnimatedCamera::~AnimatedCamera() {

	Debug::debug ("AnimatedCamera::~AnimatedCamera", "Destructing...");
}

//================================================================================

void AnimatedCamera::updateKeyFraming(const float32 t) {

	// update object position and transformation from it's tracks
	mFov = mTrackFov.getKey(t);
	mRoll = mTrackRoll.getKey(t);
	mTarget = mTrackTarget.getKey(t);
	mPosition = mTrackPosition.getKey(t);

	// invalidate matrix
	mUpdateMatrix = true;
}

//================================================================================

TrackFloat& AnimatedCamera::getRollTrack() {

	return mTrackRoll;
}

//================================================================================

TrackFloat& AnimatedCamera::getFovTrack() {

	return mTrackFov;
}

//================================================================================

TrackVector& AnimatedCamera::getTargetTrack() {

	return mTrackTarget;
}

//================================================================================

