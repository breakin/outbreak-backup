//================================================================================
// Include files
//================================================================================

#include "x3m_bsphere.h"

#define SQR(a) ((a)*(a))

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Method implementation
//================================================================================

const float32 BSphere::getRadius() const {
	return mRadius;
}

//================================================================================

BSphere::BSphere(const BSphere &other) : mRadius(other.mRadius), mCentre(other.mCentre) {
}

//================================================================================

const Extreme::Vector3& Extreme::BSphere::getCentre() const {
	return mCentre;
}

//================================================================================

void Extreme::BSphere::setCentre(const Vector3 &position) {
	mCentre = position;
}

//================================================================================

void Extreme::BSphere::setRadius(const float32 radius) {
	mRadius = radius;
}

//================================================================================

#define SMALL_ERROR 0.25

const Extreme::BSphere BSphere::merge(const BSphere &other) const {
	
	Vector3 centreDiff = other.mCentre - mCentre;
	float32 radiusDiff = other.mRadius - mRadius;
	float32 centreDiffSqr = centreDiff.getLengthSquared();
	float32 radiusDiffSqr = SQR(radiusDiff);

	// check if either sphere contain the other
	if (radiusDiffSqr >= centreDiffSqr) {
		
		// this sphere contains the other
		if (radiusDiff >= 0.0f)		
			return other;

		return *this;
	}
	
	// spheres do intersect
	float32 dist = sqrtf(centreDiffSqr);
	float32 t = (dist + radiusDiff) / (dist * 2.0);
	
	return BSphere(mCentre + (centreDiff * t), (dist + mRadius + other.mRadius) * 0.5f);
}

//================================================================================

const bool Extreme::BSphere::isIntersecting(const Extreme::Vector3 &position, const Extreme::Vector3 &direction, const double maxT) const {
	if (getIntersection(position,direction,maxT)>=0) return true;
		else return false;
}

//================================================================================

const double Extreme::BSphere::getIntersection(const Extreme::Vector3 &position, const Extreme::Vector3 &direction, const double maxT) const {

	const double DV0=direction*(position-mCentre);

	// We calculate what under the root sign
	double upper=SQR(DV0)-(SQR(position-mCentre)-SQR(mRadius));
	
	// Are there any non-imaginary solutions?
	if (upper<0) return -1;

	upper=sqrt(upper);

	// Calculate the two solutions
	const double t1=-DV0+upper;
	const double t2=-DV0-upper;

	// Make sure t1,t2 is smaller than maxT (unless maxT is unused (=-1))
	if (maxT>=0 && t1>maxT && t2>maxT) return -1;

	// Return the smallest solution >=0, return -1 if both are smaller than 0
	if (t1>t2 && t2>=0) return t2;
		else if (t1>=0) return t1;
			else return -1;
}

//================================================================================

const bool Extreme::BSphere::isIntersecting(const Vector3 &position) const {
	if ((position-mCentre).getLength()<=mRadius) return true;
		else return false;
}

//================================================================================