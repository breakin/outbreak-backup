#ifndef __EXTREME_VOLUME_AXISALIGNED_BBOX_INC__
#define __EXTREME_VOLUME_AXISALIGNED_BBOX_INC__

#include "..\..\math\x3m_vector.h"

namespace Extreme {

	/**
	 * @class	AABB
	 * @brief	Axis aligned bounding box
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */

	class AABB
	{
	public:

		/**
		 * Constructor
		 */
		AABB();

		/**
		 * Set minimum x,y,z of the axis aligned bounding box
		 * @param min The vector representing the minimum x, y and z position
		 */
		void setMin (const Vector3 &min);
		
		/**
		 * Set maximum x,y,z of the axis aligned bounding box
		 * @param min The vector representing the maximum x, y and z position
		 */
		void setMax (const Vector3 &max);

		/**
		 * Get the minimum x,y,z of the axis aligned bounding box
		 * @return A vector representing the minimum x, y and z position
		 */
		const Vector3 & getMin() const;

		/**
		 * Get the maximum x,y,z of the axis aligned bounding box
		 * @return A vector representing the maximum x, y and z position
		 */
		const Vector3 & getMax() const;
		
	protected:

		Vector3	mMin;	///< Min position components
		Vector3 mMax;	///< Max position components

	};
}

#endif
