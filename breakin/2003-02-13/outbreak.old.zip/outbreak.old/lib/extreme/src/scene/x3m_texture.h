#ifndef __EXTREME_SCENE_TEXTURE_INC__
#define __EXTREME_SCENE_TEXTURE_INC__


namespace Extreme {

	class Texture
	{
	
	};
}

#endif