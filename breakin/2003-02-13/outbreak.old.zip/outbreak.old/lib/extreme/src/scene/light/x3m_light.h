#ifndef __EXTREME_SCENE_LIGHT_INC__
#define __EXTREME_SCENE_LIGHT_INC__

#include "..\x3m_object.h"
#include <d3d8.h>

namespace Extreme {

	/**
	 * @class	Light
	 * @brief	Represent a light source within a scene
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */
	class Light : public SceneNode
	{
	public:
		
		/**
		 * Light types
		 */
		enum
		{
			TYPE_SPOT	= 0x01,
			TYPE_OMNI	= 0x02,
			TYPE_TARGET	= 0x03,
		};

		/// constructor/destructor
		Light(int32 lightType = Light::TYPE_TARGET);
		
		/// destructor
		~Light();

		/// clear/initialize parameters to default
		void init();
		
		/// get light type
		const int32 getType() const;

		/// set ligh type
		void setType(const int32 lightType);

		/// gset light attenuation
		const float32 getAttenuation() const;

		/// get light diffuse
		const float32 getDiffuse() const;

		/// get light specular strength
		const float32 getSpecular() const;

		/// get light ambient strength
		const float32 getAmbient() const;

		/// get light falloff
		const float32 getFalloff() const;
		
		/// get light range
		const float32 getRange() const;

		/// set light attenuation
		void setAttenuation(const float32 val);

		/// set light diffuse
		void setDiffuse(const float32 val);

		/// set light specular strength
		void setSpecular(const float32 val);

		/// set light ambient strength
		void setAmbient(const float32 val);
		
		/// set light rangle
		void setRange(const float32 val);

		/// set light direction
		void setDirection(const Vector3 &dir);
		
		/// get light direction
		const Vector3 & getDirection() const;

		/// update matrix
		void updateMatrix();

	protected:

		float32		mAttenuation;	///< Light's attenuation
		float32		mDiffuse;		///< Light's diffuse component
		float32		mSpecular;		///< Light's specualar component
		float32		mAmbient;		///< Light's ambient compoent	
		float32		mFalloff;		///< Light's falloff factor
		float32		mRange;			///< Light's range
		int32		mType;			///< Light enumerated type
		Vector3		mDirection;		///< Light's direction
	};
}

#endif
