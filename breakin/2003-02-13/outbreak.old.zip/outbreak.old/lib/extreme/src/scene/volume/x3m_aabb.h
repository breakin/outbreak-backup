#ifndef __EXTREME_VOLUME_AXISALIGNED_BBOX_INC__
#define __EXTREME_VOLUME_AXISALIGNED_BBOX_INC__

#include "..\..\math\x3m_vector.h"

namespace Extreme {

	/**
	 * @class	AABB
	 * @brief	Axis aligned bounding box
	 * @author	Peter Nordlander
	 * @date	2002-02-26
	 */

	class AABB
	{
	public:

		/// Constructor
		AABB();

		/**
		 * Get the minimum position for the AABB
		 */
		Vector3 &getMin() { return mMin; }

		/**
		 * Get the maximum position for the AABB
		 */		
		Vector3 &getMax() { return mMax; }

		/**
		 * Get the minimum position for the AABB (const)
		 */
		const Vector3 &getMin() const { return mMin; }
		
		/**
		 * Get the maximum position for the AABB (const)
		 */		
		const Vector3 &getMax() const { return mMax; }

		/**
		 * Get the size for the AABB
		 * Assumes min<max for all components (or size component will have negative sign)
		 */	
		const Vector3 getSize() const { return Vector3(getSizeX(), getSizeY(), getSizeZ()); }

		/**
		 * Get the size for the AABB on the x-axis
		 * Assumes minX<maxX for or size will have negative sign
		 */	
		const float getSizeX() const { return mMax.x-mMin.x; }

		/**
		 * Get the size for the AABB on the y-axis
		 * Assumes minY<maxY for or size will have negative sign
		 */	
		const float getSizeY() const { return mMax.y-mMin.y; }

		/**
		 * Get the size for the AABB on the z-axis
		 * Assumes minZ<maxZ for or size will have negative sign
		 */	
		const float getSizeZ() const { return mMax.z-mMin.z; }

		
	protected:

		Vector3	mMin;	///< Min position components
		Vector3 mMax;	///< Max position components

	};
}

#endif
