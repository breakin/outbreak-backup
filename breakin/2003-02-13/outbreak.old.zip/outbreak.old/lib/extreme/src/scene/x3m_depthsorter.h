#ifndef __EXTREME_SCENE_STATESORTER_INC__
#define __EXTREME_SCENE_STATESORTER_INC__

#include "..\math\x3m_matrix.h"
#include "x3m_renderunit.h"

namespace Extreme {

	class FrontToBackSorter : public Accumulator
	{
	public:

		virtual void accumulate(RenderUnit * unit);
		
		virtual void render();

	private:

		struct RenderUnitLess {
			const bool operator() (const MaterialHandle &x, const MaterialHandle &y) const;
		};
		
		typedef std::map<MaterialHandle, const RenderUnit *, RenderUnitLess> SortedUnitList;

		SortedUnitList	mDisplayList;
		Matrix4x4		mViewMatrix;

	};

	class BackToFronSorter : public Accumulator
	{

	
	};
}

#endif