#ifndef __EXTREME_VOLUME_INC__
#define __EXTREME_VOLUME_INC__

#include "..\..\math\x3m_vector.h"

namespace Extreme {


	/**
	 * @class	:	BVolume
	 * @brief	:	Baseclass for bounding volumes
	 * @author	:	Anders Nilsson
	 * @date	:	2002-04-21
	 */
	
	class BVolume
	{
	public:

		/**
		 * Virtual Destructor
		 */
		virtual ~BVolume() {}

		/**
		 * Test for intersection with ray
		 * @param position is the position of the ray
		 * @param direction is the direction of the ray
		 * @param maxT is the maximum distance to test for (-1 means test for all distances)
		 * @return A bool that is true if intersecting (for t>=0 and t<=maxT unless maxT=-1)
		 */
		virtual const bool isIntersecting(const Vector3 &position, const Vector3 &direction, const double maxT=-1) const = 0;

		/**
		 * Get intersection length with ray
		 * @param position is the position of the ray
		 * @param direction is the direction of the ray
		 * @param maxT is the maximum distance to test for (-1 means test for all distances)
		 * @return A double that is >=0 if intersecting between 0 and maxT (unless -1). A return value of -1 means no intersection
		 */
		virtual const double getIntersection(const Vector3 &position, const Vector3 &direction, const double maxT=-1) const = 0;

		/**
		 * Test for intersection with a point
		 * @param position is the position of the point
		 * @return A bool that is true if point is inside the volume
		 */
		virtual const bool isIntersecting(const Vector3 &position) const = 0;

	};

}

#endif