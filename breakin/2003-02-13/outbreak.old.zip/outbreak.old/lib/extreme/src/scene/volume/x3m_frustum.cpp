//================================================================================
// Include files
//================================================================================

#include "x3m_frustum.h"

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Method implmentation
//================================================================================

Frustum::Frustum() {
	// init code here
}

//================================================================================

void Frustum::addPlane(const Plane &plane) {
	mPlanes.push_back(plane);
}

//================================================================================

Plane & Frustum::getPlane(const int32 index) {
	X3M_ASSERT ((index < mPlanes.size()));
	return mPlanes[index];
}

//================================================================================

const uint32 Frustum::getNumPlanes() const {
	return mPlanes.size();
}

//================================================================================

const Frustum::eVolumeTest Frustum::checkCollision(const BSphere &sphere, uint32 * planeMask) {

	Frustum::eVolumeTest result;

	// optimzie and only test if planeMask is passed to meth once
	if (planeMask) {

		// clear all bits in planemask
		*planeMask = 0;

		// traverse all planes and check the sphere against each plane
		for (int iPlane = 0; iPlane < mPlanes.size(); iPlane++) {

			// get distance from spheres center to planes[iPlane]
			float32 distance = mPlanes[iPlane].getPointDistance(sphere.mCentre);
			
			// check if the sphere is behind the plane
			if (distance < 0) {

				if (-distance > sphere.mRadius) {
					
					// set bit for this plane to 1
					*planeMask |= (1 << iPlane);
				}
				// if totallt outside, return immidiately
				else 
					return VOLUME_OUTSIDE;
			}			
		}
		
		// We reached here, the volume is at least partially inside the frustum
		result = VOLUME_INSIDE;

		// test if planeMask contains any set bits, which proofs that the sphere is clipped
		if (planeMask > 0)
			result = VOLUME_CLIPPED;

		return result;
	}
	// traverse and ignore planeMask
	else {
	
		for (int iPlane = 0; iPlane < mPlanes.size(); iPlane++) {

			// get distance from centre of sphere to plane
			float32 distance = mPlanes[iPlane].getPointDistance(sphere.mCentre);

			// check if behind
			if (distance < 0) {
					
				// if it clips plane, return immidiately
				if (-distance > sphere.mRadius)
					return VOLUME_CLIPPED;
				else
					return VOLUME_OUTSIDE;
			}
		}

		// if we got this far, the sphere was inside the frsutum
		return VOLUME_INSIDE;
	}
}

//================================================================================

