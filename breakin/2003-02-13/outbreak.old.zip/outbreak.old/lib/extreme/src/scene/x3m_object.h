#ifndef __EXTREME_SCENE_OBJECT_INC__
#define __EXTREME_SCENE_OBJECT_INC__

#include "..\math\x3m_vector.h"
#include "..\math\x3m_matrix.h"

namespace Extreme {

	/**
	 * @class	Object
	 * @brief	Represent an abstract object within an Extreme scene
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */

	class Object
	{
	public:
	
		/// constructor/ destructor
		Object();
		virtual ~Object();

		/// set/get position
		virtual void setPosition(const Vector3 &position);
		
		/// get object position vector
		virtual const Vector3 & getPosition() const;

		/// set object's name
		virtual void setName(const std::string &name);

		/// get object's name
		virtual const std::string & getName() const;

		/// get transformation matrix
		virtual const Matrix4x4& getMatrix();

		/// get transformations to different spaces
		virtual const Matrix4x4& getToParent();

		/// get objects transformation for a "to object space" transformation
		virtual const Matrix4x4& getToLocal();

		/// update transformation matrix, must be overriden by subclasses
		virtual void updateMatrix() = 0;

	protected:
		
		bool		mUpdateMatrix;	///< Flag indicating if matrix must be rebuilt
		Matrix4x4	mMatrix;		///< Object's tranformation matrix
		Vector3		mPosition;		///< Object's position
		std::string	mName;			///< Object's name
	};
}

#endif
