#ifndef __EXTREME_SCENE_GROUP_INC__
#define __EXTREME_SCENE_GROUP_INC__

#include "..\math\x3m_matrix.h"

namespace Extreme {

	/**
	 * @class	SceneNode
	 * @brief	Represents a sceneNode interface, only abstract and must be inhertied/subclassed
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */

	class SceneGroup : public SceneNode
	{
	public:     
				
		/**
		 * Virtual destructor
		 */
		virtual ~SceneGroup();
	
		/**
		 * Add light
		 * @param light Lightobject to be added to the scene
		 * @remarks The light will not be traversed during exportRenderUnits, in that case
		 * the light must also be added thruogh addNode
		 */
		virtual void addLight(const Light * light);

		/**
		 * Add a camera to the scene
		 * @param camera Camera object to be added to the scene
		 * @remarks The camera will not be traversed during exportRenderUnits, in that case
		 * the camera must also be added thruogh addNode
		 */
		virtual void addCamera(const Camera * camera);

		/**
		 * Add a scenenode
		 * @param node Any object derived from SceneNode
		 */
		virtual void addNode(const SceneNode * node);
		
		/**
		 * Retrive a light by its name
		 * @param name Name of light to retrieve
		 * @return The light with name @a name, NULL if not found
		 */
		virtual Light * getLight(const std::string &name);
		
		/**
		 * Retrive a light by its name (const)
		 * @param name Name of light to retrieve
		 * @return The light with name @a name, NULL if not found
		 */		
		virtual const Light * getLight(const std::string &name) const;

		/**
		 * Retrieve a camera by its name
		 * @param name Name of camera to retrieve
		 * @return The camera with name @a name, NULL if not found
		 */
		virtual Camera * getCamera(const std::string &name);

		/**
		 * Retrieve a camera by its name(const)
		 * @param name Name of camera to retrieve
		 * @return The camera with name @a name, NULL if not found
		 */
		virtual const Camera * getCamera(const std::string &name) const;

		/** 
		 * Update frame of animation on this object and all of it children recursivly
		 * @param t Timeunit to update controllers with, valid values differs and are scene specific
		 */ 
		virtual void update(const float32 t);

		/**
		 * Get matrix which transforms this sceneNode into other spaces
		 * @return The sceneNode's transformation matrix
		 */
		virtual const Matrix4x4 & getToParent() const;

		/**
		 * Get matrix which transform others into this sceneNode's space
		 * @return The sceneNode's inverse transformation matrix
		 */
		virtual const Matrix4x4 & getToLocal() const;

		/**
		 * Set transformation matrix
		 * @return The sceneNode's transformation matrix
		 */	
		virtual const Matrix4x4 & getMatrix() const;

		/**
		 * Set transformation matrix
		 * @param matrix The matrix object to associate with this sceneNode
		 */
		virtual void setMatrix(const Matrix4x4 &matrix);

	protected:
				
		/**
		 * Constructor, hidden - only let derived classes create me
		 */
		SceneGroup();

		bool						mInvalidMatrix;		///< Flag indicating weihter the sceneNode's matrix is invalid
		BSphere						mBoundingSphere;	///< Bouding sphere surrounging the total volume of the sceneNode	
		std::list<SceneNode*>		mChildren;			///< List of children belonging to this sceneNode
	};
}

#endif