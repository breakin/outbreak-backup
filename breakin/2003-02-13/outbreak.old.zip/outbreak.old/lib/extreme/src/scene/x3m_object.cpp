//================================================================================
// Include files
//================================================================================

#include "x3m_object.h"
#include "..\debug\x3m_debug.h"

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

//================================================================================
// Method implementation
//================================================================================

Object::Object() : mUpdateMatrix(true), mName("noname") {

	Debug::debug ("Object::Object", "Constructing...");
}

//================================================================================

Object::~Object() {

	Debug::debug ("Object::~Object", "Destructing object[%s]...",mName.c_str());
}

//================================================================================

const Vector3 & Object::getPosition() const {
	return mPosition;
}

//================================================================================

void Object::setPosition(const Vector3 &position) {
	mPosition = position;
}

//================================================================================

const std::string & Object::getName() const {
	return mName;
}

//================================================================================

void Object::setName(const std::string &name) {
	mName = name;
}

//================================================================================

const Matrix4x4& Object::getMatrix() {

	// check if we need to update matrix
	if (mUpdateMatrix)
		this->updateMatrix();
	
	return mMatrix;
}

//================================================================================

const Matrix4x4& Object::getToParent() {

	// check if we need to update matrix
	if (mUpdateMatrix)
		updateMatrix();

	return mMatrix;
}

//================================================================================

const Matrix4x4& Object::getToLocal() {

	// check if we need to update matrix
	if (mUpdateMatrix)
		updateMatrix();

	return mMatrix.getTranspose();
}

//================================================================================


