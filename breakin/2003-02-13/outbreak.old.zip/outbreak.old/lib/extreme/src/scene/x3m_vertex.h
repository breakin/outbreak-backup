#ifndef __EXTREME_SCENE_VERTEX_INC__
#define __EXTREME_SCENE_VERTEX_INC__

#include "..\math\x3m_vector.h"
#include <d3d8.h>

namespace Extreme {

	/**
	 * Extreme engines predefined vertexformats
	 */
	const uint32 X3M_VF_UV1	= D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_NORMAL | D3DFVF_TEX1;
	const uint32 X3M_VF_TNL	= D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1;		
	const uint32 X3M_VF_UV2	= D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_NORMAL | D3DFVF_TEX2;

	/**
	 * @struct	Texel
	 * @brief	Texture cordinate 
	 * @author	Peter Nordlander
	 * @date	2002-01-22
	 */

	struct Texel
	{
		float32 u;	///< U component->texture 2d x axis
		float32 v;	///< V compoenet->texture 2d y axis
	};

	/**
	 * @class	VertexDUV1
	 * @brief	Untransformed vertex structures with position/normal/diffuse and 1 texture coordinate
	 * @author	Peter Nordlander
	 * @date	2001-12-04
	 */
	struct VertexDUV1

		/**
		 * Format constant
		 */
		enum {
	
			FORMAT = X3M_VF_UV1,
		};

		Vector3	mPosition;	///< Vertex position
		uint32	mDiffuse;	///< Vertex diffuse color;
		Vector3 mNormal;	///< Vertex normal
		Texel	mTexel1;	///< Vertex texture cordinate pair (1)
	};

	/**
	 * @class	VertexDUV2
	 * @brief	Untransformed vertex structures with position/normal/diffuse and 2 texture coordinates
	 * @author	Peter Nordlander
	 * @date	2001-12-04
	 */
	struct VertexDUV2

		/**
		 * Format constant
		 */
		enum {
	
			FORMAT = X3M_VF_UV2,
		};

		Vector3	mPosition;	///< Vertex position
		uint32	mDiffuse;	///< Vertex diffuse color;
		Vector3 mNormal;	///< Vertex normal
		Texel	mTexel1;	///< Vertex texture cordinate pair (1)
		Texel	mTexel2;	///< Vertex texture cordinate pair (2)
	};

	/**
	 * @class	Vertex2D
	 * @brief	Untransformed vertex structures with position/normal/diffuse and 2 texture coordinates
	 * @author	Peter Nordlander
	 * @date	2001-12-04
	 */
	struct Vertex2D

		/**
		 * Format constant
		 */
		enum {
	
			FORMAT = X3M_VF_TNL;
		};


		Vector3	mPosition;	///< Vertex position
		float32	mRHW;		///< Vertex reciprocal of homogenous w
		Texel	mTexel1;	///< Texture cordinate pair(1)	
	};
}

#endif
