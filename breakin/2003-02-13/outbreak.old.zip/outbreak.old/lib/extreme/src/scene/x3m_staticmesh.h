#ifndef __EXTREME_SCENE_TRIMESH_INC__
#define __EXTREME_SCENE_TRIMESH_INC__

namespace Extreme {

	class StaticMesh : public SceneNode
	{
	public:

		/**
		 * Constructor
		 * @param meshModel Model to instanciate this mesh from
		 */
		StaticMesh(ModelHandle meshModel);

		/**
		 * Destructor
		 */
		virtual ~StaticMesh();

		/** 
		 * Update frame of animation on this object and all of it children recursivly
		 * @param frame A numeric framenumber, valid values differs and are scene specific
		 */ 
		void exportRenderUnits(RenderCache &renderSet, Camera * camera, LightList * lightList = NULL, SceneNode * parent = NULL);

	protected:
	
	};
}

#endif
