#ifndef __EXTREME_SCENE_OBJECT_ANIMATED_INC__
#define __EXTREME_SCENE_OBJECT_ANIMATED_INC__

#include "..\keyframing\x3m_tracks.h"

namespace Extreme {

	/**
	 * @class	Animated
	 * @brief	Interface all animated objects within a scene must derive from
	 * @author	Peter Nordlander
	 * @date	2001-12-22
	 */

	class AnimatedObject
	{
	public:	
		/// Destructor
		virtual ~AnimatedObject();

		// Method all animated objects must implement
		virtual void updateKeyframing(const float32 t);

		/// Get position Track, common for all animated objects as they *must* have a position 
		virtual TrackVector * getPositionTrack();

	protected:

		TrackVector	mTrackPosition;	///< Position track
	};
}

#endif