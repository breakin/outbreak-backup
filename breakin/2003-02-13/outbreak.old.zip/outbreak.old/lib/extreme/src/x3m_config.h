#ifndef __EXTREME_CONFIG_INC__
#define __EXTREME_CONFIG_INC__

#include "x3m_typedef.h"
#include "debug\x3m_debug.h"

// stl includes
#pragma warning (disable:4786)
#include <string>
#include <map>

namespace Extreme {

	/**
	 * @class	ConfigValue
	 * @brief	General configuration parameter value
	 * @author	Peter Nordlander
	 * @date	2002-04-25
	 */
	class ConfigValue
	{
	public:
	
		/**
		 * Constructor
		 * @param val Boolean parameter initialization
		 */
		ConfigValue(const bool val) {
			char value[6];
			sprintf (value, "%s", val ? "true" : "false");
			mVal = value;
		}

		/**
		 * Constructor
		 * @param val Integer parameter initialization
		 */
		ConfigValue(const int32 val) { 
			char value[6];
			sprintf (value, "%d", val);
			mVal = value;
		};
		
		/**
		 * Constructor
		 */		
		ConfigValue() {
			mVal = "";
		}

		/**
		 * Constructor
		 * @param val String parameter initialization
		 */
		ConfigValue(const std::string val) : mVal(val) { };
		ConfigValue(const char * val) : mVal(val) { }

		/**
		 * Retrieve config-value (int)
		 * @return Integer configuration value
		 */
		const int32 getIntVal() const;

		/**
		 * Retrieve config-value (bool)
		 * @return Boolean configuration value
		 */
		const bool getBoolVal() const;

		/**
		 * Retrieve config-value (string)
		 * @return String configuration value
		 */
		const std::string getVal() const;
		
		/**
		 * Compare two configuration variables
		 * @return True if values are equal, false otherwise
		 */
		const bool operator == (const ConfigValue & other) { return mVal == other.mVal; }

	private:

		std::string mVal;	///< Common string format data
	};
	
	/**
	 * @class ConfigMap
	 * @brief Configuration map
	 * @author Peter Nordlander
	 */
	class ConfigMap
	{
	public:
		/** 
		 * Constructor
		 */
		ConfigMap();

		/**
		 * Destructor
		 */
		~ConfigMap();

		/**
		 * Register a configuration parameter
		 * @param name Name of parameter to register
		 */
		void registerParam(const std::string &name, const ConfigValue val);

		/**
		 * Set a configuration parameter
		 * @param name Name of parameter to set
		 * @param value The value to assign to the parameter
		 * @return True on success, false if parameter was not found
		 */
		const bool setParam(const std::string &name, const ConfigValue &value);

		/**
		 * Check weither a certain parameter exist within the configuraton record
		 * @return True if a parameter with name @a name exist, false otherwise
		 */
		const bool hasParam(const std::string &name);

		/**
		 * Retrieve a configuration parameter
		 * @param name Name of parameter to retrieve
		 * @return Reference to the value-object assigned to this parameter
		 * @remarks Throw's exception on invalud parameter name
		 */
		ConfigValue & getParam(const std::string &name);
	
		/**
		 * Clear map contents
		 */
		void clear();

	private:
		
		/**
		 * Performs a conversion to the internal storage format
		 * @param name to format/convert
		 * @return Formatted string with proper format
		 */
		std::string convertParam(const std::string &param);

		std::map<std::string, ConfigValue> mConfigMap;	///< The datarecord containing all the configuration parameters
	};

}

#endif
