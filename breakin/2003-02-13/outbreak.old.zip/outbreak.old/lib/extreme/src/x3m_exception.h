#ifndef __EXTREME_EXCEPTION_INC__
#define __EXTREME_EXCEPTION_INC__

#include "debug\x3m_debug.h"
#include <exception>
#include <stdarg.h>
#include <stdio.h>

namespace Extreme {

	/**
	 * @class	Exception
	 * @brief	Extreme multiparam exception class
	 * @author	Peter Nordlander
	 * @date	2001-10-15
	 */

	class Exception: public std::exception
	{
	public:
		
		/**
		 * Exception types
		 */
		enum eExceptionType 
		{
			EXCEPTION_UNDEF		= 0x00,
			EXCEPTION_DEVICE	= 0x01,
			EXCEPTION_IO		= 0x02,
			EXCEPTION_MEMORY	= 0x03,
		};
		
		/// deafult contructor
		Exception() {
	
			exception::operator = ("Exception unspecified");
		};

		/**
		 * Variable argument constructor
		 * @param fmt Format string in printf syntax
		 */
		Exception(const char fmt[], ...) {

			char e_msg[256];

			va_list args;
			va_start(args, fmt);
			vsprintf (e_msg, fmt, args);

			exception::operator = (e_msg);
			Debug::error("Exception::Exception",e_msg);
		}
	
		/**
		 * Variable argument constructor
		 * @return Type of exception @see eExceptionType
		 */
		const uint32 getType() const { return mType; }

	protected:

		uint32 mType;	/// Exception type
	};


	/**
	 * @class	NotFoundException
	 * @brief	Extreme multiparam exception class / error in devices such as API wrappers etc.
	 * @author	Peter Nordlander
	 * @date	2001-12-20
	 */
	class NotFoundException : public Exception
	{
	public:

		/**
		 * Variable argument constructor
		 * @param fmt Format string in printf syntax
		 */
		NotFoundException(const char * fmt, ...) {

			char e_msg[256];

			va_list args;
			va_start(args, fmt);
			vsprintf (e_msg, fmt, args);

			exception::operator = (e_msg);
			Debug::error("DeviceException::DeviceException",e_msg);
	
			mType = EXCEPTION_DEVICE;
		}
	};


	/**
	 * @class	IOException
	 * @brief	Extreme multiparam exception class / error in I/O 
	 * @author	Peter Nordlander
	 * @date	2001-12-20
	 */

	class IOException : public Exception 
	{
	public:

		/**
		 * Variable argument constructor
		 * @param fmt Format string in printf syntax
		 */
		IOException (const char * fmt, ...) {

			char e_msg[256];

			va_list args;
			va_start(args, fmt);
			vsprintf (e_msg, fmt, args);

			exception::operator = (e_msg);
			Debug::error("IOException::IOException",e_msg);
	
			mType = EXCEPTION_IO;		
		}
	};

	/**
	 * @class	NullPointerException
	 * @brief	Extreme multiparam exception class / error in memory managment
	 * @author	Peter Nordlander
	 * @date	2001-12-20
	 */
	class NullPointerException : public Exception 
	{
	public:

		/**
		 * Variable argument constructor
		 * @param fmt Format string in printf syntax
		 */
		NullPointerException(const char * fmt, ...) {

			char e_msg[256];

			va_list args;
			va_start(args, fmt);
			vsprintf (e_msg, fmt, args);

			exception::operator = (e_msg);
			Debug::error("MemoryException::MemoryException",e_msg);
	
			mType = EXCEPTION_MEMORY;		
		}
	};
}

#endif