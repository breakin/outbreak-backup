//================================================================================
// Include files
//================================================================================

#include "x3m_soundsystem.h"
#include "..\x3m_exception.h"

//================================================================================
// Used namespaces
//================================================================================

using namespace Extreme;

//==========================================================================================

SoundSystem * TSingleton<SoundSystem>::sSingletonObject = NULL;

//================================================================================
// Method implementation
//================================================================================

SoundSystem::SoundSystem() {

	X3M_DEBUG ("SoundSystem", "Constructing...");

	// load FMOD
	if (FSOUND_Init(44100, 1 ,0) == FALSE)
		throw Exception ("Could not Initialize FMOD!");

	init();
}


//================================================================================

SoundSystem::~SoundSystem() {

	X3M_DEBUG ("SoundSystem", "Destructing...");

	if (mLoaded)
		unload();

	// close and unload FMOD
	FSOUND_Close();
}

//================================================================================

void SoundSystem::init() {

	mStream	 = 0;
	mPlaying = false;
	mPaused	 = false;
	mLoaded	 = false;
}

//================================================================================

void SoundSystem::load(const std::string &song) {

	mStream = FSOUND_Stream_OpenFile(song.c_str(),0,0);
	
	if (!mStream)
		throw Exception ("Could not find file [%s]", song.c_str());

	mLoaded = true;

}

//================================================================================

void SoundSystem::unload() {

	if (mStream) {

		FSOUND_Stream_Close(mStream);
		mLoaded = false;
	}
}

//================================================================================

const float64 SoundSystem::getTime() const {

	X3M_ASSERT (mStream!=NULL);
	
	int32 time = FSOUND_Stream_GetTime(mStream);
	
	// return and convert time offset in seconds
	return float64(time) / 1000.0;
}

//================================================================================

void SoundSystem::start() {

	X3M_ASSERT (mStream!=NULL);

	if (mPaused) {

		//FSOUND_Stream_SetPaused(mStream, FALSE);
		mPaused = false;
	}
	else {
	
		if (!mPlaying)
			FSOUND_Stream_Play(0, mStream);
		mPlaying = true;
	}
}

//================================================================================

void SoundSystem::stop() {

	X3M_ASSERT (mStream!=NULL);

	FSOUND_Stream_Stop(mStream);
	mPlaying = false;

}

//================================================================================

void SoundSystem::pause() {

	X3M_ASSERT (mStream!=NULL);

 	//FSOUND_Stream_SetPaused(mStream, TRUE);
	mPaused = true;
}

//================================================================================

const float32 SoundSystem::getVU(const int32 channel) const {

	return FSOUND_GetCurrentVU(channel);
}

//================================================================================

