#ifndef __EXTREME_MUSIC_INC__
#define __EXTREME_MUSIC_INC__

#include "..\x3m_timerinterface.h"
#include "..\template\x3m_singleton.h"
#include <fmod.h>
#include <string>

namespace Extreme {

	/**
	 * @class	SoundSystem
	 *			SoundSystem handles all music and sfx within the engine,
	 *			Alse inherits the TimerInterface - which makes it possible to use a song a timer synchronization base
	 *			in any application.
	 *
	 * @author	Peter Nordlander
	 * @date	2001-10-29
	 */
	
	class SoundSystem : public TimerInterface , public TSingleton<SoundSystem>
	{
	public:
		
		/**
		 * Constructor
		 */
		SoundSystem();
	
		/**
		 * Destructor
		 */
		~SoundSystem();

		/**
		 * Load song
		 * @param path Path to the file containing the music/song data
		 */
		void load (const std::string &path);
		
		/**
		 * Unload song from memory
		 */		
		void unload ();
		
		/**
		 * Start playing the song
		 */
		void start();
		
		/**
		 * Stop playing the song
		 */
		void stop();

		/**
		 * Pause song 
		 */
		void pause();

		/**
		 * Get UV/Channel info
		 * @param channel The channel from which to fetch the VU information
		 * @return Value of VU value of 0.0..1.0
		 */
		const float32 getVU(const int32 channel = 0) const;

		/**
		 * Get current time in song
		 * @return The elapsed time in seconds 
		 */
		const float64 getTime() const;
	
	private:

		/**
		 * Init default values
		 */
		void init();
		
		bool			mLoaded;	///< Song loaded indicator
		bool			mPlaying;	///< Song playing indicator
		bool			mPaused;	///< Song paused indicator
		FSOUND_STREAM*	mStream;	///< Song stream
	};
}

#endif
