Panorama Window Manager
=========================

	Copyright by Outbreak 2002.

	Read the information in the documents path to
	read more about Panorama.



Paths & Files
===============


	Documentation/

		Contains class diagrams, specifications and
		other documents describing the library.


	Library/

		Contains the compiled library files.

		
	Public skins/
		
		Skins that you may use in addition to the
		Panorama license.


	Source/

		Contains the sourcetree for the library.


	Temp/

		Contains temporary compiler files.


	Panorama.dsp

		The project file, to be included in your
		workspace.
