#ifndef P_PANORAMA_H
#define P_PANORAMA_H

#include "utils/singleton.h"
#include "components/component.h"
#include "observers/event.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	Panorama
	 * @brief	Main Panorama include
	 * @author	Albert Sandberg
	 */
	class Panorama : public Singleton<Panorama> {

	private:
	public:

		/**
		 * Constructor, in private block to avoid creating outside singleton.
		 */
		Panorama();

		/**
		 * Destructor
		 */
		~Panorama();
		
		/**
		 * Finds the component with the matching name (id)
		 *
		 * @param  name   Name of the component to be found.
		 * @return        A pointer to the item with the corresponding name.
		 */
		Component& findItem(const std::string& name);
	};

};

#endif