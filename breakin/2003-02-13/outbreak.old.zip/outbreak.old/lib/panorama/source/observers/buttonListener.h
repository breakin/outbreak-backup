#ifndef P_BUTTONLISTENER_H
#define P_BUTTONLISTENER_H

#include "eventlistener.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	ButtonListener
	 * @brief	Special eventlistener case for buttons
	 * @author	Albert Sandberg
	 */
	class ButtonListener : public EventListener {
	public:

		/**
		 * Constructor
		 */
		ButtonListener();
		
		/**
		 * Destructor
		 */
		virtual ~ButtonListener();

		/**
		 * On event, used with callbacks, handle and
		 * dispatch all events to sub-events if needed.
		 *
		 * @param pEvent   The event to be processed.
		 */
		void onEvent(const Panorama::Event& pEvent);
	};
}

#endif