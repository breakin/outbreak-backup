#include "eventlistener.h"
#include "../panorama.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Panorama::EventListener::attach(const std::string& pName) {
	
	// Get singleton instance of panorama
	Panorama &p = Panorama::getInstance();

	// Find item with matching name and add this observer
	p.findItem(pName).addEventListener(this);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Panorama::EventListener::detach(const std::string& pName) {
	
	// Get singleton instance of panorama
	Panorama &p = Panorama::getInstance();

	// Find item with matching name and delete this observer
	p.findItem(pName).removeEventListener(this);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Panorama::EventListener::onEvent(const Event& pEvent) {

	// Do nothing
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
