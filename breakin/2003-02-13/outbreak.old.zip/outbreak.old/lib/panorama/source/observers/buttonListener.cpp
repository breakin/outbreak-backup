#include "buttonlistener.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::ButtonListener::ButtonListener() : EventListener() {

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Panorama::ButtonListener::onEvent(const Event& event) {

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
