#ifndef P_EVENTLISTENER_H
#define P_EVENTLISTENER_H

#include "event.h"
#include <string>

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	EventListener
	 * @brief	Part of the observer pattern for the callback methodiology
	 * @author	Albert Sandberg
	 */
	class EventListener {
	public:
		
		/**
		 * Constructor
		 */
		EventListener();

		/**
		 * Destructor
		 */
		virtual ~EventListener();

		/**
		 * Attach an observer to an item
		 *
		 * @param name   Name of the item to be associated with.
		 */
		void attach(const std::string& pName);

		/**
		 * Detach an observer from an item
		 * 
		 * @param name   Name of item to detach from.
		 */
		void detach(const std::string& pName);

		/**
		 * On event, used with callbacks, handle and
		 * dispatch all events to sub-events if needed.
		 *
		 * @param pEvent   The event to be processed.
		 */
		void onEvent(const Panorama::Event& pEvent);
	};
}

#endif