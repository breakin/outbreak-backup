#ifndef P_EVENT_H
#define P_EVENT_H

#include "../components/component.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	Event
	 * @brief	From components...
	 * @author	Albert Sandberg
	 */
	class Event {
	public:

		// Variables
		int			mEventID;
		int			mGroup;
		Panorama::Component*	mComponent;

		/** 
		 * Constructor
		 *
		 * @param pID         What is happening
		 * @param pGroup      What does it apply to
		 * @param pComponent  Pointer to component
		 */
		Event::Event(const Component::eComponentType pEventID, const int pGroup, Component* pComponent) {

			// Set locals
			mEventID = pEventID;
			mGroup = pGroup;
			mComponent = pComponent;
		}
	};
}

#endif