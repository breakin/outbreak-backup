#ifndef P_AREA_H
#define P_AREA_H

#include "point.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	Area
	 * @brief	Rectangles on screen with nice functionality.
	 * @author	Albert Sandberg
	 */
	class Area {

	private:
		// Area properties
		int mLeft, mTop, mWidth, mHeight;

	public:

		/**
		 * Constructor
		 *
		 * @param newLeft   Position on the horisontal axis
		 * @param newTop    Position on the vertical axis
		 * @param newWidth  Width of the area
		 * @param newHeight Height of the area
		 */
		Area(int pLeft=0, int pTop=0, int pWidth=0, int pHeight=0) {
		
			// Set dimensions
			set(pLeft, pTop, pWidth, pHeight);
		}

		/**
		 * Destructor
		 */
		~Area() {}

		// Set methods
		void setLeft  (const int pLeft)   { mLeft=pLeft;     }
		void setTop   (const int pTop)    { mTop=pTop;       }
		void setWidth (const int pWidth)  { mWidth=pWidth;   }
		void setHeight(const int pHeight) { mHeight=pHeight; }

		void set(const int pLeft=0, const int pTop=0, const int pWidth=0, const int pHeight=0) {
			mLeft   = pLeft;
			mTop    = pTop;
			mWidth  = pWidth;
			mHeight = pHeight;			
		}

		void setTopLeft(const int pLeft=0, const int pTop=0) {
			mLeft = pLeft;
			mTop  = pTop;
		}

		// Get methods
		const int getLeft()   const { return mLeft; }
		const int getTop()    const { return mTop; }
		const int getWidth()  const { return mWidth; }
		const int getHeight() const { return mHeight; }

		const int getSize()   const { return mWidth*mHeight; }
		const bool isEmpty()  const { return !(mWidth*mHeight); }

		const Point getTopLeft() {

			// Return top left
			return Point(mLeft, mTop);
		}

		// Check if inside
		const bool isInside(const Point &pPoint) {

			// If inside
			if ((pPoint.getX()>=mLeft) && (pPoint.getX()<mLeft+mWidth) && (pPoint.getY()>=mTop)  && (pPoint.getY()<mTop+mHeight)) {
				
				// Inside, return true
				return true;
			}

			// Else false...
			return false;
		}

		// Offset by a point (move upper left)
		void operator+=(const Point &pPoint) {
			mLeft += pPoint.getX();
			mTop  += pPoint.getY();
		}

		// Offset by a point (move upper left)
		Area operator+(const Point &pPoint) {
			
			// Create new area and add point
			Area result(*this);
			result+=pPoint;

			// Return new area
			return result;
		}

		// Minimum area that includes both areas
		void operator|=(const Area &pOther) {

			// If area is empty, then just return
			if (isEmpty()) {
				*this = pOther;
			} else {

				// If not the other area is empty
				if (!pOther.isEmpty()) {

					// Set up new dimensions temporary variables
					int newLeft   = mLeft;
					int newTop    = mTop;
					int newWidth  = mWidth;
					int newHeight = mHeight;

					// Check left and top side
					if (pOther.getLeft() < mLeft) newLeft = pOther.getLeft();					
					if (pOther.getTop()  < mTop)  newTop  = pOther.getTop();

					// Check right side
					if (mLeft+mWidth > pOther.getLeft()+pOther.getWidth()) {
						
						// This rectangle is the rightest of them both...
						newWidth = mLeft+mWidth - newLeft;
					} else {

						// pOther is the rightest rectangle
						newWidth = pOther.getLeft() + pOther.getWidth() - newLeft;
					}
					
					// Check bottom side
					if (mTop+mHeight > pOther.getTop()+pOther.getHeight()) {
						
						// This rectangle hass the lowest edge of them both...
						newHeight = mTop+mHeight - newTop;
					} else {

						// pOther has the lowest rectangle edge
						newHeight = pOther.getTop() + pOther.getHeight() - newTop;
					}

					// Set new dimensions
					mLeft   = newLeft;
					mTop    = newTop;
					mWidth  = newWidth;
					mHeight = newHeight;					
				}
			}
		}

		// Minimum area that includes both areas
		Area operator|(const Area &pOther) {
			
			// Set up new area
			Area result(*this);
			result |= pOther;

			// Return new area
			return result;
		}

		// Union area (overlap)
		void operator&=(const Area &pOther) {
			
			// If completely outside, don't even start
			if ((pOther.getLeft()                   > mLeft+mWidth) ||
				(pOther.getLeft()+pOther.getWidth() < mLeft       ) ||
				(pOther.getTop()                    > mTop+mHeight) ||
				(pOther.getTop()+pOther.getHeight() < mTop        )) {

				// Set area to nothing
				set(0,0,0,0);

				// Return at once
				return;
			}

			// New temporaries
			int newLeft   = mLeft;
			int newTop    = mTop;
			int newWidth,newHeight=100;

			// Set upper left
			if (mLeft < pOther.getLeft()) newLeft = pOther.getLeft();
			if (mTop  < pOther.getTop())  newTop  = pOther.getTop();

			// Set right
			if (mLeft+mWidth < pOther.getLeft()+pOther.getWidth()) {

				// Set new width
				newWidth = mLeft+mWidth -newLeft;
			} else {

				// Set new width
				newWidth = pOther.getLeft()+pOther.getWidth() -newLeft;
			}

			// Set lower
			if (mTop+mHeight < pOther.getTop()+pOther.getHeight()) {

				// Set new width
				newHeight = mTop+mHeight - newTop;
			} else {

				// Set new width
				newHeight = pOther.getTop()+pOther.getHeight() - newTop;
			}

			// Set new area
			set(newLeft, newTop, newWidth, newHeight);
		}

		// Union area (overlap)
		Area operator&(const Area &pOther) const {
			
			// Create new area
			Area result(*this);
			result &= pOther;

			// Return new area
			return result;
		}

		// Comparison
		const bool operator==(const Area &pOther) {
			if (mWidth==pOther.getWidth() && mHeight==pOther.getHeight()) return true;
			return false;
		}

		// [not] Comparison
		const bool operator!=(const Area &pOther) {
			if (mWidth!=pOther.getWidth() || mHeight!=pOther.getHeight()) return true;
			return false;
		}

	};

};

#endif