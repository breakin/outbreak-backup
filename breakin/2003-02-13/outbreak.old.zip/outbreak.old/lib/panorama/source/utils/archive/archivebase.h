#ifndef P_ARCHIVEBASE_H
#define P_ARCHIVEBASE_H

#include "../image.h"
//#include <string>

namespace Panorama {

	/**
	 * Struct for files
	 */
	struct File {

		std::string    mPath;
		std::string    mFilename;
		unsigned long  mSize;
		unsigned char* mData;
	};

	typedef SmartPointer<File> FileHandle;

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	ArchiveBase
	 * @brief	Archive superclass
	 * @author	Albert Sandberg
	 */
	class ArchiveBase {
	private:

	public:

		/**
		 * Default constructor
		 */
		ArchiveBase() { }

		/**
		 * Destructor
		 */
		virtual ~ArchiveBase() { }

		/**
		 * Set working archive
		 *
		 * @param   pFilename  File or path to archive.
		 * @throw              If archive cannot be found.
		 */
		void setArchive(const std::string& pFilename);

		/**
		 * Lods a file from the archive
		 *
		 * @param   pFilename  File inside achive to be loaded.
		 * @return             File if loaded, NULL otherwise.
		 */
		virtual FileHandle load(const std::string& pFilename) { return NULL; }

		/**
		 * Loads an image
		 *
		 * @param  pFilename  Filename of the image inside the archive
		 * @return            ImageHandle to new image, NULL if not found
		 */
		virtual ImageHandle loadImage(const std::string pFilename) { return NULL; }

	};
}

#endif