#ifndef P_ARCHIVEDIRECTORY_H
#define P_ARCHIVEDIRECTORY_H

#include "archive.h"
#include "imageloader.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	ArchiveDirectory
	 * @brief	Read directories 'raw'
	 * @author	Albert Sandberg
	 */
	class ArchiveDirectory : public ArchiveBase {
	private:

		// Archive directory
		std::string mPath;

		// Instance of an imageloader
		ImageLoader imageLoader;
		
	public:

		/**
		 * Default constructor
		 */
		ArchiveDirectory(const std::string& pPath="");

		/**
		 * Destructor
		 */
		virtual ~ArchiveDirectory();

		/**
		 * Set working archive
		 *
		 * @param  pFilename  File or path to archive.
		 * @throw             If archive cannot be found.
		 */
		void setArchive(const std::string& pPath="");

		/**
		 * Lods a file from the archive
		 *
		 * @param  pFilename  File inside achive to be loaded.
		 * @return            File if loaded, NULL otherwise.
		 */
		FileHandle load(const std::string& pFilename);

		/**
		 * Loads an image
		 *
		 * @param  pFilename  Filename of the image inside the archive
		 */
		ImageHandle loadImage(const std::string pFilename);

	};
}

#endif