#include "archivedirectory.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::ArchiveDirectory::ArchiveDirectory(const std::string& pPath) : ArchiveBase() {

	// Set archive
	setArchive(pPath);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::ArchiveDirectory::~ArchiveDirectory() {

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Panorama::ArchiveDirectory::setArchive(const std::string& pPath) {

	// Set path
	mPath = pPath;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::FileHandle Panorama::ArchiveDirectory::load(const std::string& pFilename) {

	// Create new filehandle
	FileHandle fh(new File);

	// Open file
	std::string totalFilename = mPath + "/" + pFilename;
	FILE* file = fopen(totalFilename.c_str(), "rb");

	// Set defaults
	fh->mPath = mPath;
	fh->mFilename = pFilename;
	fh->mSize = 0;
	fh->mData = NULL;


	// If file exist
	if (file) {

		// Go to end of file
		fseek(file, 0, SEEK_END);

		// Store filesize
		fh->mSize = ftell(file);
		
		// Create temporary memory buffer
		fh->mData = new unsigned char[fh->mSize];

		// Go back to beginning of file
		fseek(file, 0, SEEK_SET);

		// Read file to memory buffer
		fread(fh->mData, fh->mSize, 1, file);

		fclose(file);
	}

	// Return filehandle
	return fh;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::ImageHandle Panorama::ArchiveDirectory::loadImage(const std::string pFilename) {

	// Return image after loading
	return imageLoader.loadImage(load(pFilename));
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
