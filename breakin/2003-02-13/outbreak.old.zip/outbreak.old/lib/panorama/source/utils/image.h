#ifndef P_IMAGE_H
#define P_IMAGE_H

#include <string>
#include "smartpointer.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	Image
	 * @brief	Panoramas image format
	 * @author	Albert Sandberg
	 */
	class Image {
	private:

		// Width & height
		int mWidth;
		int mHeight;

		// Data
		unsigned long* mData;

	public:

		/**
		 * Constructor
		 *
		 * @param  pWidth   Width of image
		 * @param  pHeight  Height of image
		 */
		Image(const int pWidth=0, const int pHeight=0);

		/**
		 * Destructor
		 */
		~Image();

		/**
		 * Get data pointer
		 *
		 * @return Pointer to image data.
		 */
		unsigned long* get() { return mData; }

		/**
		 * Get width of image
		 */
		const int getWidth() { return mWidth; }

		/**
		 * Get height of image
		 */
		const int getHeight() { return mHeight; }

		/**
		 * Clear image
		 *
		 * @param color   Color to clear with
		 */
		void clear(const unsigned long pColor=0xffff00);

		/**
		 * Resize image
		 *
		 * @param width   New width of image
		 * @param height  New height of image
		 */
		void resize(const int pWidth=0, const int pHeight=0);
	}; 

	/**
	 * Type definition for SmartPointer (autopointer)
	 */
	typedef SmartPointer<Image> ImageHandle;

}

#endif