#ifndef P_ARCHIVE_H
#define P_ARCHIVE_H

#include <string>
#include <vector>
#include "archivebase.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	Archive
	 * @brief	Archive system
	 * @author	Albert Sandberg
	 */
	class Archive {
	private:

		// Contains largest id...
		int mTopID;

		struct ArchiveData {

			int mID;
			SmartPointer<ArchiveBase> mArchive;
		};

		// Archives stored by this class
		std::vector<ArchiveData*> mArchives;

	public:
		/**
		 * Default constructor
		 */
		Archive();

		/**
		 * Destructor
		 */
		virtual ~Archive();

		/**
		 * Adds an archive.
		 * Method automaticly creates the right type of archive
		 * and stores it in the archive list.
		 *
		 * @param   pFilename  File or path to archive
		 * @return  ID to this particular archive
		 */
		const int addArchive(const std::string& pFilename);

		/**
		 * Loads an image
		 *
		 * @param  pFilename  Filename of the image inside an archive
		 * @return            ImageHandle to new image, NULL if not found
		 */
		ImageHandle loadImage(const std::string pFilename, const int pArchiveID=0);
	};
}

#endif