#include "imageloader.h"
#include "../standard.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::ImageLoader::ImageLoader() {

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::ImageLoader::~ImageLoader() {

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::ImageHandle Panorama::ImageLoader::loadImage(Panorama::FileHandle pFile) {

	// Check extension
	if (pFile->mFilename.substr(pFile->mFilename.length()-4,4)==".tga") {

		return loadTGA(pFile);
	}

	// Else return NULL
	return NULL;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::ImageHandle Panorama::ImageLoader::loadTGA(Panorama::FileHandle pFile) {

	Image* image=NULL;

	// If file does not exist, throw
	if (pFile->mData == NULL) {
		
		std::string message = "Could not load image " + pFile->mPath + "/" + pFile->mFilename + ".";
		throw std::exception(message.c_str());
	}

	// Set temporary pointer for nicer code
	unsigned char* fileData = (unsigned char*)pFile->mData;

	// Load header
	int tga_width      = (fileData[13]<<8) + fileData[12];
	int tga_height     = (fileData[15]<<8) + fileData[14];
	int tga_bitDepth   = fileData[16];
	int tga_pixelSize  = tga_bitDepth / 8;
	int tga_bufferSize = tga_width * tga_height * tga_pixelSize;				

	// We only support 24 & 32 bit tga's
	if (tga_pixelSize!=3 && tga_pixelSize!=4) {
	
		throw std::exception("Only 24bit and 32bit tga's supported!");
	}

	// Create image
	image = new Image;

	// Resize to fit tga
	image->resize(tga_width, tga_height);

	// Pointer to image data
	unsigned long* imageData = image->get();

	// Load data depedning on bitdepth
	if (tga_bitDepth==32) {

		// Decompress 32-bit picture
		for (int y=0; y<tga_height; y++) {
			for (int x=0; x<tga_width; x++) {
			
				// Load color values
				unsigned char b = (unsigned char)fileData[18 + (y*tga_width+x)*4 + 0];
				unsigned char g = (unsigned char)fileData[18 + (y*tga_width+x)*4 + 1];
				unsigned char r = (unsigned char)fileData[18 + (y*tga_width+x)*4 + 2];
				unsigned char a = (unsigned char)fileData[18 + (y*tga_width+x)*4 + 3];

				// Set data
				imageData[(tga_height-y-1)*tga_width + x] = (a<<24) | (r<<16) | (g<<8) | b;
			}
		}

	} else {

		// Decompress 24-bit picture and set the alpha channel to 0xff
		for (int y=0; y<tga_height; y++) {
			for (int x=0; x<tga_width; x++) {
			
				// Load color values
				unsigned char b = fileData[18 + (y*tga_width+x)*3 + 0];
				unsigned char g = fileData[18 + (y*tga_width+x)*3 + 1];
				unsigned char r = fileData[18 + (y*tga_width+x)*3 + 2];

				// Set data
				imageData[(tga_height-y-1)*tga_width + x] = (255<<24) | (r<<16) | (g<<8) | b;
			}
		}
	}

	// Return new image
	return image;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
