#include "archive.h"

#include "archivedirectory.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::Archive::Archive() {

	// Set static member
	mTopID=1;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::Archive::~Archive() {

	// Delete content of archives
	for (int i=0; i<mArchives.size(); i++) {

		// Remove content of list
		delete mArchives[i];
	}

	// Delete list
	mArchives.clear();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const int Panorama::Archive::addArchive(const std::string& pFilename) {

	// Only ArchiveDirectory is implemented ATM, so start with that.
	ArchiveBase* archive = new ArchiveDirectory(pFilename);

	// Set up archive data structure
	ArchiveData* ad = new ArchiveData;
	ad->mID = mTopID;
	ad->mArchive = archive;
	mArchives.push_back(ad);

	// Increase top id
	mTopID++;

	// Return ID
	return ad->mID;	
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::ImageHandle Panorama::Archive::loadImage(const std::string pFilename, const int pArchiveID) {

	// If archive specified, try to load image from the specified archive
	if (pArchiveID != 0) {

		// Find archive
		for (int i=0; i<mArchives.size(); i++) {

			// If found, load
			if (mArchives[i]->mID == pArchiveID) {

				// Load and return image
				return mArchives[i]->mArchive->loadImage(pFilename);
			}
		}
	}

	// If archive not specified, return first occurance of the specified file in any archive
	for (int i=0; i<mArchives.size(); i++) {

		ImageHandle ih = mArchives[i]->mArchive->loadImage(pFilename);

		// If image actually loaded, return image
		if (ih != NULL) return ih;
	}

	// If not found, return NULL
	return NULL;
}
