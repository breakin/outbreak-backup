#ifndef P_CLOCK_H
#define P_CLOCK_H

#include "singleton.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	Clock
	 * @brief	Returns a number in seconds (float) since the program was started. 
	 * @author	Albert Sandberg
	 */
	class Clock : public Singleton<Clock> {
	private:

		// The original time
		float mStartTime;

		// Get method
		const float getTime();

	public:
		
		/**
		 * Default constructor
		 */
		Clock();

		/**
		 * Destructor
		 */
		~Clock() {
		}

		/**
		 * Get numer of ms passed since program was started.
		 */
		const float get();
	};
};

#endif