#ifndef P_IMAGELOADER_H
#define P_IMAGELOADER_H

#include "../image.h"
#include "archivebase.h"
#include "../singleton.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	Imageloader
	 * @brief	Loads images from virtual files
	 * @author	Albert Sandberg
	 */
	class ImageLoader {
	private:

		/**
		 * Load .tga image
		 */
		ImageHandle loadTGA(Panorama::FileHandle pFile);

	public:
		/**
		 * Default constructor
		 */
		ImageLoader();

		/**
		 * Destructor
		 */
		virtual ~ImageLoader();

		/**
		 * Load image
		 */
		ImageHandle loadImage(Panorama::FileHandle pFile);
	};
}

#endif