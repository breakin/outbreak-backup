#include "clock.h"

// Set singleton static
Panorama::Clock * Panorama::Singleton<Panorama::Clock>::sSingletonObject = NULL;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

#ifdef _WIN32
	#define WIN32_LEAN_AND_MEAN
	#include <windows.h>
#endif

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::Clock::Clock() {

	// Remember start position
	mStartTime=getTime();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const float Panorama::Clock::getTime() {
	
#ifdef _WIN32
	return GetTickCount() / 1000.0f;
#endif

	return 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const float Panorama::Clock::get() {
	
	return getTime()-mStartTime;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
