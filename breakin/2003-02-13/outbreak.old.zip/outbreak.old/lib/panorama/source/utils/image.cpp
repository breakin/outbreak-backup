#include "image.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::Image::Image(const int pWidth, const int pHeight) {

	// Set data pointer to NULL for security
	mData = NULL;

	// Resize image to desired resolution
	resize(pWidth,pHeight);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::Image::~Image() {
	
	// Remove data if not null
	if (mData!=NULL) delete[] mData;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Panorama::Image::clear(const unsigned long pColor) {

	// Make sure data is valid
	if (mData==NULL) throw std::exception("Image32::clear(), mData is not valid.");

	// Clear data with selected color
	memset((unsigned long*)mData, (unsigned long)pColor, mWidth*mHeight);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Panorama::Image::resize(const int pWidth, const int pHeight) {

	// Set width&height
	mWidth = pWidth;
	mHeight = pHeight;

	// Remove old data
	if (mData!=NULL) delete[] mData;

	// Create new data
	mData = new unsigned long[mWidth*mHeight];

	// Clear data
	clear();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
