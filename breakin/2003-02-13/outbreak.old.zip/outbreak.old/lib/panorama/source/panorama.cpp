#include "panorama.h"

// Set singleton static
Panorama::Panorama * Panorama::Singleton<Panorama::Panorama>::sSingletonObject = NULL;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

