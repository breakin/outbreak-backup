#ifndef P_FRAME_H
#define P_FRAME_H

#include <vector>
#include "component.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	Frmae
	 * @brief	Frame for holding components
	 * @author	Albert Sandberg
	 */
	class Frame : public Component {
	private:

		// List of components
		std::vector<const Component*> mComponents;

	public:
		/**
		 * Default constructor
		 */
		Frame();

		/**
		 * Destructor
		 */
		virtual ~Frame();
	};
}

#endif