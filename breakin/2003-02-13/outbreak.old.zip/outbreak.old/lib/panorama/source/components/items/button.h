#ifndef P_BUTTON_H
#define P_BUTTON_H

#include "../component.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	Button
	 * @brief	Standard button
	 * @author	Albert Sandberg
	 */
	class Button : public Component {
	private:

	public:
		/**
		 * Default constructor
		 */
		Button();

		/**
		 * Destructor
		 */
		virtual ~Button();

	};
}

#endif