#ifndef P_COMPONENT_H
#define P_COMPONENT_H

#include <vector>

namespace Panorama {

	class EventListener;

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	Component
	 * @brief	General functionality for all components
	 * @author	Albert Sandberg
	 */
	class Component {
	private:

		// List of eventlisteners
		std::vector<const Panorama::EventListener*> mEventListeners;

	public:

		/**
		 * Enumeration for the different types of components.
		 * Mainly there for the event processing.
		 */
		enum eComponentType {
			WORKSPACE,
    		FRAME,
    		WINDOW,

			LABEL,
    		BUTTON,
    		IMAGEBUTTON,
    		TIMER,
			TEXTINPUT,
			CHECKBOX,
			SCROLLBARHORISONTAL,
			SCROLLBARVERTICAL,
			PROGRESSBAR,
		};

		/**
		 * Default constructor
		 */
		Component();

		/**
		 * Destructor
		 */
		virtual ~Component();

		/**
		 * Add an eventlist observer to the component callbacklist
		 *
		 * @param eventListener   Pointer to an eventlist observer
		 */
		void addEventListener(const EventListener* pEventListener);

		/**
		 * Remove eventlist observer from the component callbacklist
		 *
		 * @param eventListener   Pointer to an eventlist observer
		 */
		void removeEventListener(const EventListener* pEventListener);
	};
}

#endif