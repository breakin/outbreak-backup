#include "component.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::Component::Component() {

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Panorama::Component::~Component() {
	
	// Remove all observers to be sure everything's cleared
	mEventListeners.clear();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Panorama::Component::addEventListener(const EventListener* pEventListener) {

	// Parse through eventlisteners to see if already added
	for (int i=0; i<mEventListeners.size(); i++) {
		
		// Check if pointers match
		if (mEventListeners[i] == pEventListener) {

			// Return to avoid double occurance
			return;
		}
	}

	// Add eventlistener to observer list
	mEventListeners.push_back(pEventListener);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void Panorama::Component::removeEventListener(const EventListener* pEventListener) {

	// Parse through the eventlisteners
	for (int i=0; i<mEventListeners.size(); i++) {
	
		// See if pointers match
		if (mEventListeners[i] == pEventListener) {
			
			// Remove eventlistener from observer list
			mEventListeners.erase(mEventListeners.begin()+i);

			// Return then found
			return;
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
