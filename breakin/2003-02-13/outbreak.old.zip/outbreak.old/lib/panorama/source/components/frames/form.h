#ifndef P_FORM_H
#define P_FORM_H

#include "../frame.h"

namespace Panorama {

	/**
	 * [Panorama Windows Manager]
	 *
	 * @class	Form
	 * @brief	Standard form which inherits frame... to store components
	 * @author	Albert Sandberg
	 */
	class Form : public Frame {
	private:

	public:
		/**
		 * Default constructor
		 */
		Form();

		/**
		 * Destructor
		 */
		virtual ~Form();

	};
}

#endif