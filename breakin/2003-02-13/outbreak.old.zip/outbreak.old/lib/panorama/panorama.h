#ifndef PANORAMA
#define PANORAMA

#include "source/panorama.h"

#endif