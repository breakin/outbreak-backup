#ifndef HELPER_HELPER_IMAGETOOL_H
#define HELPER_HELPER_IMAGETOOL_H

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Breakin
 @ Class		: ImageTool
 @ Brief		: Keeps a list of ImageCoders. Decodes/encodes correct
                  depending on extensions.

 @ Features     :

  * Jpg saving/loading
  * Tga saving/loading

================================================================================*/

#include "../typedefs.h"
#include "../file.h"

#include "imagecoder/imagecoder.h"

#include <vector>
#include <string>

namespace Helper {

	class ImageTool {
	private:

		std::vector<ImageCoder*> mCoders;

		ImageCoder* getDecoder(const std::string &extension) const;
		ImageCoder* getEncoder(const std::string &extension) const;

	public:

		ImageTool();
		~ImageTool();

		void save(Blob &result, const BaseImage32 &sourceImage, const AreaInt &sourceArea, const std::string &destinationExtension, const ImageCoder::EncodeSettings &encodeSettings=ImageCoder::defaultEncodeSettings) const;

		void save(Blob &result, const BaseImage32 &sourceImage, const std::string &destinationExtension, const ImageCoder::EncodeSettings &encodeSettings=ImageCoder::defaultEncodeSettings) const {
			save(result,sourceImage,sourceImage.getArea(),destinationExtension,encodeSettings);
		}

		void load(BaseImage32 &result, const Blob &sourceBlob, const std::string &sourceExtension, const ImageCoder::DecodeSettings &decodeSettings=ImageCoder::defaultDecodeSettings) const;

		// NOTICE! The ImageCoder will be deleted by ImageTool
		void addImageCoder(ImageCoder* imageCoder);

		const bool isEncoder(const std::string &extension) const;
		const bool isDecoder(const std::string &extension) const;
	};
};

#endif