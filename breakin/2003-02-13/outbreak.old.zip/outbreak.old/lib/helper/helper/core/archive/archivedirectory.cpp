#include "archivedirectory.h"
#include "../debug/debug.h"
#include "../exception.h"
#include <iostream>

#include <direct.h>
#include <windows.h>

/*
	TODO:
	Maybe make all get/remove/* use fixFileName so that we go case-insensitive?

	TODO:
	Implement toLower in fixFileName
*/

// ---------------------------------------------------------------------------

Helper::ArchiveDirectory::ArchiveDirectory(const std::string &directoryName, const bool buildIndex) : Archive() {
	
	// Construct file-list via recurse-file-listing
	// Create directory if it does not exist

	// Save current working directory
	char currentDirectory[_MAX_PATH+1];
	getcwd(currentDirectory, _MAX_PATH);
	std::string cds(currentDirectory);
	
	// We will have to get the absolute path to the directory we are going
	// to work with. The following code does that.

	fixFileName(cds, true);

	std::string temp(directoryName);
	fixFileName(temp, true);

	if (temp.empty()) {
		mDirectoryName=cds;

	} else if (temp[0]=='.') {
		mDirectoryName=cds;

	} else if (temp[0]=='/') {

		// Since the path starts with a slash it must be located at the root
		// We append the drive name and ':' and it's absolute
		cds.erase(2,cds.length()-2);
		mDirectoryName=cds+temp;

	} else if (temp.length()>2 && temp[1]==':') {

		// Since there is a drive letter path is already absolute
		mDirectoryName=temp;

	} else {

		// This is a normal relative path, we append full current path
		mDirectoryName=cds+temp;
	}

	Debug::logSystem("Helper::ArchiveDirectory::ArchiveDirectory", "Initializing filelist for '%s' ('%s')", mDirectoryName.c_str(), directoryName.c_str());

	// Check if the directory exists
	if (chdir(mDirectoryName.c_str())==0) {

		// Ok it existed, let's change back!
		chdir(currentDirectory);

		// Directory existed, build fileList
		if (buildIndex) initializeInnerMethod(mDirectoryName, "");

	} else {

		Debug::logSystem("Helper::ArchiveDirectory::ArchiveDirectory", "Directory is created");

		// Directory did not exist, create!
		// There will be no files so need to build an index
		createRootDirectory(mDirectoryName);
	}

	Debug::logSystem("Helper::ArchiveDirectory::ArchiveDirectory", "Done initializing filelist for '%s'", directoryName.c_str());
}

// ---------------------------------------------------------------------------

Helper::ArchiveDirectory::~ArchiveDirectory() {
	Debug::logSystem("Helper::ArchiveDirectory::ArchiveDirectory", "Destructor for '%s'", mDirectoryName.c_str());
}

// ---------------------------------------------------------------------------

/* 
Appends trailing '/' if needed (only for onlyDirectory==true)
Changes all '\' into '/'
*/

void Helper::ArchiveDirectory::fixFileName(std::string &directoryToFix, const bool onlyDirectory) const {

	// If it's an empty string leave it that way
	if (directoryToFix.empty()) return;

	// Change all '\' into '/'
	for (int C=0; C<directoryToFix.length(); C++) {
		if (directoryToFix[C]=='\\') directoryToFix[C]='/';
	}

	// Append trailer
	if (onlyDirectory) {
		if (directoryToFix[directoryToFix.length()-1]!='/') {
			directoryToFix+="/";
		}
	}
}

// ---------------------------------------------------------------------------

/* Returns the number of files in the directory */

const int Helper::ArchiveDirectory::getFileCount() const {
	return mFileList.size();
}

// ---------------------------------------------------------------------------

/* Returns true if the file 'filename' exists, false if it does not.
   'filename' includes full path from 'mDirectoryName'. */

const bool Helper::ArchiveDirectory::isExist(const std::string &filename) const {
	if (mFileList.find(filename)==mFileList.end()) return false;
		else return true;
}

// ---------------------------------------------------------------------------

/* Returns a File& object to the file with the filename 'filename'. Throws an exception
   if the file is not found. */

const Helper::File& Helper::ArchiveDirectory::getFile(const std::string &fileName) const {
	const std::map<std::string, ArchiveDirectory::FileDirectory>::const_iterator i=mFileList.find(fileName);

	if (i==mFileList.end()) throw FileException("ArchiveDirectory::getFile(filename); The file '%s' does not exist in '%s'", fileName.c_str(), mDirectoryName.c_str());
		else return i->second;
}

Helper::File& Helper::ArchiveDirectory::getFile(const std::string &fileName) {
	std::map<std::string, ArchiveDirectory::FileDirectory>::iterator i=mFileList.find(fileName);

	if (i==mFileList.end()) throw FileException("ArchiveDirectory::getFile(filename); The file '%s' does not exist in '%s'", fileName.c_str(), mDirectoryName.c_str());
		else return i->second;
}

// ---------------------------------------------------------------------------

/* Returns a File& object to the file with the index fileIndex in the fileList.
   Throws an exception if the index is out of bound. */

const Helper::File& Helper::ArchiveDirectory::getFile(const int fileIndex) const {

	if (fileIndex<0 || fileIndex>=mFileList.size()) {
		throw Helper::Exception("ArchiveDirectory::getFile[int]; Index out of bound (%d, range=0 to %d)", fileIndex, getFileCount());
	}

	std::map<std::string, ArchiveDirectory::FileDirectory>::const_iterator i=mFileList.begin();

	for (int C=0; C<fileIndex; C++, i++);	

	return i->second;
}

Helper::File& Helper::ArchiveDirectory::getFile(const int fileIndex) {

	if (fileIndex<0 || fileIndex>=mFileList.size()) {
		throw Helper::Exception("ArchiveDirectory::getFile[int]; Index out of bound (%d, range=0 to %d)", fileIndex, getFileCount());
	}

	std::map<std::string, ArchiveDirectory::FileDirectory>::iterator i=mFileList.begin();

	for (int C=0; C<fileIndex; C++, i++);	

	return i->second;
}

// -[FileDirectory]-----------------------------------------------------------

/* Remove the file. Does not complain if the file did not exist. */

void Helper::ArchiveDirectory::FileDirectory::remove() {
	if (!isWriteable()) throw Helper::Exception("ArchiveDirectory::FileDirectory; Cant remove '%s' due to no write access!", getName().c_str());

	mContext->remove(getName());
}

// ---------------------------------------------------------------------------

/* Loads the file. */

Helper::Blob Helper::ArchiveDirectory::FileDirectory::get() const {
	if (!isReadable()) throw Helper::Exception("ArchiveDirectory::FileDirectory; Cant read '%s' due to no read access", getName().c_str());

	return mContext->getData(getName(), getSize());
}

// ---------------------------------------------------------------------------

void Helper::ArchiveDirectory::initializeInnerMethod(const std::string &searchRoot, const std::string &root) {
	
	std::string directory(searchRoot);
	directory+=root;
	directory+="*.*";

	WIN32_FIND_DATA findFileData;
	HANDLE hFindFile=FindFirstFile(directory.c_str(), &findFileData);

	// No files applied to the search critieria
	if (hFindFile==INVALID_HANDLE_VALUE) {
		return;
	}

	do {

		// Ignore hidden and offline files
		if ((findFileData.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN)  !=0 ||
			(findFileData.dwFileAttributes & FILE_ATTRIBUTE_OFFLINE) !=0) {

			continue;
		}

		// Recurse if another directory
		if ((findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) !=0) {

			const std::string directoryName=findFileData.cFileName;

			if (directoryName!="." && directoryName!="..") {

				std::string newDirectory(root);
				newDirectory+=directoryName;
				newDirectory+="/";

				initializeInnerMethod(searchRoot, newDirectory);
			}

		} else {

			// Add the file to the fileList

			// Create the full fileName
			std::string result(root);
			result+=findFileData.cFileName;

			// Create the temporary file object
			Helper::ArchiveDirectory::FileDirectory temp;

			temp.setName(result);
			temp.setContext(this);
			temp.setSize(findFileData.nFileSizeLow);
			temp.setReadable(true);
			temp.setWriteable((findFileData.dwFileAttributes & FILE_ATTRIBUTE_READONLY)==0);

			Helper::Debug::logSystem("Helper::ArchiveDirectory::initialize", "%8d - %s", temp.getSize(), temp.getName().c_str());

			mFileList[result]=temp;
		}

	} while (FindNextFile(hFindFile, &findFileData)!=0);

	FindClose(hFindFile);
}

// ---------------------------------------------------------------------------

/* This methods require a trailing /-slash and that only '/'-are used (not '\').
   That should be true after a call to fixDirectory. */

void Helper::ArchiveDirectory::createRootDirectory(const std::string &directoryName) {

	if (directoryName.length()<3) {
		throw FileException("Helper::ArchiveDirectory::createRootDirectory; Couldn't create directory");
	}
	
	std::string directoriesLeft=directoryName;
	fixFileName(directoriesLeft, false);

	std::string::size_type position=3;

	while (position < directoriesLeft.length()) {

		// Find the next '/' and then increase position with one
		// so that it is _after_ the '/' (oterwise it will be found the next time too)
		position=directoriesLeft.find("/", position);
		position++;

		// Due to this filenames are okey aswell (no end slash)
		if (position==0) return;

		mkdir(directoriesLeft.substr(0, position).c_str());
	}
}

// ---------------------------------------------------------------------------

Helper::Blob Helper::ArchiveDirectory::getData(const std::string &fileName, const int bytesToRead) const {

	std::string realName(mDirectoryName);
	realName+=fileName;
	fixFileName(realName, false);
	
	FILE *f=fopen(realName.c_str(), "rb");

	if (!f) throw Helper::FileException("ArchiveDirectory::getData; Could not open '%s' (%d bytes)", fileName.c_str(), bytesToRead);

	Blob returnBlob(bytesToRead);
	fread(returnBlob.get(), bytesToRead, 1, f);

	fclose(f);

	return returnBlob;
}

// ---------------------------------------------------------------------------

void Helper::ArchiveDirectory::remove(const std::string &fileName) {

	Debug::logSystem("Helper::ArchiveDirectory::remove", "Removing '%s'", fileName.c_str());

	std::map<std::string, ArchiveDirectory::FileDirectory>::iterator i=mFileList.find(fileName);

	if (i==mFileList.end()) throw FileException("ArchiveDirectory::remove(filename); The file '%s' does not exist in '%s'", fileName.c_str(), mDirectoryName.c_str());

	std::string realName(mDirectoryName);
	realName+=fileName;
	fixFileName(realName, false);

	const int removeResult=::remove(realName.c_str());

	if (removeResult==-1) {
		throw FileException("Helper::ArchiveDirectory::remove; Couldn't delete '%s' (already open)", realName.c_str());
	} else if (removeResult!=0) {
		throw FileException("Helper::ArchiveDirectory::remove; Couldn't delete '%s'", realName.c_str());
	}

	mFileList.erase(i,i);
}

// ---------------------------------------------------------------------------

void Helper::ArchiveDirectory::save(const std::string &fileName, const Blob &source) {

	Debug::logSystem("Helper::ArchiveDirectory::createFile", "Creating '%s'", fileName.c_str());

	std::string realName(mDirectoryName);
	realName+=fileName;
	fixFileName(realName, false);

	createRootDirectory(realName);

	FILE *f=fopen(realName.c_str(), "wb+");
	if (!f) throw Helper::FileException("ArchiveDirectory::createFile; Could not create '%s'", realName.c_str());

	fwrite(source.getReadOnly(), source.getSize(), 1, f);
	fclose(f);

	FileDirectory temp;
	temp.setName(fileName);
	temp.setContext(this);
	temp.setSize(source.getSize());
	temp.setReadable(true);
	temp.setWriteable(true);

	mFileList[fileName]=temp;
}

// ---------------------------------------------------------------------------