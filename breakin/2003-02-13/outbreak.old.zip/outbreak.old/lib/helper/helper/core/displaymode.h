#ifndef __HELPER_CORE_DISPLAYMODE_INC__
#define __HELPER_CORE_DISPLAYMODE_INC__

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Tooon
 @ Class		: DisplayMode
 @ Brief		: A Common display mode class, with resolution, bits per pixel and
				  pixelformat.

================================================================================*/

#include "pixelformat.h"

namespace Helper {

class DisplayMode
{
	public:

		// constructors
		DisplayMode(int32 _width, int32 _height, int32 _bpp) : width(_width), height(_height), bpp(_bpp) {}		
		DisplayMode() : width(0), height(0), bpp(0) {}
		
		// explcilitly set displaymode 
		void set(int32 _width, int32 _height, int32 _bpp) {
			/// set properties
			width  = _width;
			height = _height;
			bpp	   = _bpp;
		}
			
		/// expl. set pixelformat
		void setPixelFormat(const PixelFormat &pfsrc) {
			// set pixelformat structure
			pixelFormat = pfsrc;
		}

		// compares two displaymodes and 
		bool operator==(const DisplayMode &other) const {

			return ((width == other.width) && (height == other.height) && (bpp == other.bpp));
		}

		int32			width;		 ///< Width of displaymode
		int32			height;		 ///< Height of displaymode
		int32			bpp;		 ///< Bits per pixel
		PixelFormat		pixelFormat; ///< Pixelformat in "bit detail" format
};

// displaymode list
typedef std::vector<DisplayMode> DisplayModeList;

}


#endif