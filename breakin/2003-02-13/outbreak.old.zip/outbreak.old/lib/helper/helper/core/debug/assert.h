#ifndef __HELPER_DEBUG_ASSERT_H__
#define __HELPER_DEBUG_ASSERT_H__

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Tooon
 @ Class		: DEBUG_ASSERT macros
 @ Brief		: DEBUG_ASSERT will evalute expressions and only be compiled in
				  Debug builds.

 @ Features
 
  * Only compiled in Debug builds
  * An ignore switch for each assert can be set to force the assert not to
	be evaulated further in the application's lifetime.

================================================================================*/

//======================================================================
// define how assert should exit the application
#define ASSERT_EXIT __asm { int 0x03 }
//#define ASSERT_EXIT ExitProcess(0);


//======================================================================
// define USE_ASSERT to force assersion to be compiled int
// release builds as well
#ifdef _DEBUG
#define USE_ASSERT
#endif

#ifdef USE_ASSERT

// handleAssert prototype
bool handleAssert(const char module[], int line, const char statement[], bool &ignore);
 
//======================================================================
// Debug Assert
//======================================================================
/**
 * @ DEBUG_ASSERT
 * param<x>		=	Statement to be evalutated
 * remarks		:	if statement <x> is evaluated to false, 
 *					DEBUG_ASSERT will break the application.
 */
#define DEBUG_ASSERT(x)	{											\
static bool assert_AlwaysIgnore = false;							\
if (!(x) && (!assert_AlwaysIgnore))									\
	if (handleAssert(__FILE__, __LINE__, #x, assert_AlwaysIgnore))	\
		ASSERT_EXIT													\
}							

#else

// Release version, compiles to NADA
#define DEBUG_ASSERT(x)

#endif

//======================================================================
// Debug Break
//======================================================================
/**
 * @ DEBUG_ASSERT
 * param<x>		=	Statement to be evaluated
 * remarks		:	DEBUG_BREAK evaluated x, if false it will generate a breakpoint
 *					and stop execution.	
 */
#ifdef USE_ASSERT

#define DEBUG_BREAK(x)	\
	if (!(x))			\
	__asm {int 0x03}	

#else
// Release Version, compilees to NADA
#define DEBUG_BREAK(x)
#endif

#endif
