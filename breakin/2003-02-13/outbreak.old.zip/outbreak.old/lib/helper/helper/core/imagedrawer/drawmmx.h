#ifndef __MMX_BLITTER__
#define __MMX_BLITTER__

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Tooon
 @ Class		: Drawer_MMX
 @ Brief		: Lower level MMX routines used by wrapper classes (Imagedrawer).

 @ Features
 
  * See class ImageDrawer

================================================================================*/

#include "drawasm.h"


namespace Helper {


class Drawer_MMX : public Drawer_ASM
{
	public:
		
		
		/**
		 * Bilinear interpolation versions of all blit methods
		 */	
		void bilerp_copy				 (uint8 *src, uint8 *dst, int width , int height, int srcPitch, int dstPitch);
		void bilerp_blit				 (uint8 *src, uint8 *dst, int width , int height, int srcPitch, int dstPitch);
		void bilerp_blit_alpha			 (uint8 *src, uint8 *dst, int width , int height, int srcPitch, int dstPitch);
		void bilerp_blit_saturation		 (uint8 *src, uint8 *dst, int width , int height, int srcPitch, int dstPitch);
		void bilerp_blit_alpha_saturation(uint8 *src, uint8 *dst, int width , int height, int srcPitch, int dstPitch);
	
		/**
		 * Copy pixels from src to dst
		 */
		void copy (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);
		
		/**
		 * Clears ARGB or RGB attributes of dst's pixels
		 */
		void clear_rgb	(uint8 *dst, int width, int height, int dstPitch);
		void clear_argb	(uint8 *dst, int width, int height, int dstPitch);
		
		/**
		 * Clears ARGB or RGB attributes of dst's pixels
		 */
		void blit (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);

		/**
		 * Different alphablend routines
		 * copies pixels from src to dst an applies transculency
		 */
		void blit_alpha	(uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);
		void blit_alpha_saturation(uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);

		/**
		 * Different alphablend routines
		 * copies pixels from src to dst an applies "constant" transculency
		 */
		void blit_alpha_const (uint8 *src, uint8 *dst, int alpha, int width, int height, int srcPitch, int dstPitch);
		void blit_alpha_const_saturation(uint8 *src, uint8 *dst, int alpha, int width, int height, int srcPitch, int dstPitch);
		
		/**
		 * Adds pixels in src width dst, with byte saturation
		 */
		void blit_saturation (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);

};

}

#endif
