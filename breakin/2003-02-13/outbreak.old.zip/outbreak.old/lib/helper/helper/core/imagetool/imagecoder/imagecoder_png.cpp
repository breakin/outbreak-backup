#include "imagecoder_png.h"
#include "imagecoder_png_pointers.h"
#include "../../exception.h"
#include <libpng/inc/png.h>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------

Helper::ImageCoder_PNG::ImageCoder_PNG() : ImageCoder() {
}

// ---------------------------------------------------------------------------

Helper::ImageCoder_PNG::~ImageCoder_PNG() {
}

// ---------------------------------------------------------------------------

void Helper::ImageCoder_PNG::encode(Blob &result, const BaseImage32 &sourceImage, const AreaInt &sourceArea, const EncodeSettings &settings) const {
}

// ---------------------------------------------------------------------------

void Helper::ImageCoder_PNG::decode(BaseImage32 &result, const Blob &sourceBlob, const DecodeSettings &settings) const {
	png_structp png_ptr;
	png_infop 	info_ptr;
	png_infop 	end_ptr;

	// png structures
	png_ptr  = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	info_ptr = png_create_info_struct(png_ptr);
	end_ptr  = png_create_info_struct(png_ptr);

	// properly loaded?
	if ((png_ptr == NULL) || (info_ptr == NULL) || (end_ptr == NULL)) {
		throw "Could not allocate png structures...";
	}

	// pass file handle to libpng
	png_set_read_fn(png_ptr, (void *) (&sourceBlob), read_png_data);

	// get image details (height, width, bpp, etc)
	png_read_info(png_ptr, info_ptr);

	int width = png_get_image_width(png_ptr, info_ptr);
	int height = png_get_image_height(png_ptr, info_ptr);
	int bit_depth = png_get_bit_depth(png_ptr, info_ptr);
	int color_type = png_get_color_type(png_ptr, info_ptr);

	// resize destination image
	result.resize(width, height);

	// so that we get proper alpha
	bool update = false;

	// we only handle 8-bit images
    if (color_type == PNG_COLOR_TYPE_PALETTE) {
		png_set_palette_to_rgb(png_ptr);
		update = true;
	}
    if (color_type == PNG_COLOR_TYPE_GRAY && bit_depth < 8) png_set_gray_1_2_4_to_8(png_ptr);
    if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS)) {
		png_set_tRNS_to_alpha(png_ptr);
		update = true;
	}
    if (bit_depth == 16) png_set_strip_16(png_ptr);
    if (bit_depth < 8) png_set_packing(png_ptr);

    if (color_type == PNG_COLOR_TYPE_GRAY || color_type == PNG_COLOR_TYPE_GRAY_ALPHA) {
          png_set_gray_to_rgb(png_ptr);
		  update = true;
	}

	if (update) {
		png_read_update_info(png_ptr, info_ptr);
		color_type = png_get_color_type(png_ptr, info_ptr);
	}

	// no transparency
    if (color_type == PNG_COLOR_TYPE_RGB)
		png_set_filler(png_ptr, 0xff, PNG_FILLER_BEFORE);

	// I want the data in argb-format
    if (color_type == PNG_COLOR_TYPE_RGB_ALPHA)
        png_set_swap_alpha(png_ptr);

	png_read_update_info(png_ptr, info_ptr);

	char *pix = new char[width * height * 4];

	int *row_pointers = new int[height];
	int rowbytes = (width * 4);

	// make a table of pointes to each row of the surface
	for (int i = 0; i < height; i++) {
		row_pointers[i] = (int) pix+(i*rowbytes);
	}

	// read image
	png_read_image(png_ptr, (png_byte **) row_pointers);

	// put the pixeldata into the resulting image
	uint32 *imgPix = result.get();

	int pos1 = 0;
	int pos2 = 0;
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			imgPix[pos1] =	(pix[pos2+0]&0xff) << 24 |
							(pix[pos2+1]&0xff) << 16 |
							(pix[pos2+2]&0xff) <<  8 |
							(pix[pos2+3]&0xff) <<  0;
			pos1++;
			pos2 += 4;
		}
	}

	// deallocate mem
	delete row_pointers;
	delete pix;

	// finish reading the file
	png_read_end(png_ptr, info_ptr);

	// rm png_struct
	png_destroy_read_struct(&png_ptr, &info_ptr, &end_ptr);
}

// ---------------------------------------------------------------------------

const bool Helper::ImageCoder_PNG::isEncoder(const std::string &fileName) const {
	// not implemented yet
	return false;
}

// ---------------------------------------------------------------------------

const bool Helper::ImageCoder_PNG::isDecoder(const std::string &fileName) const {
	return (fileName.empty() || isExtension(fileName, "png"));
}
