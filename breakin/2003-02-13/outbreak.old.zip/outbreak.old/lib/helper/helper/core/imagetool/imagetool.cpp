#include "imagetool.h"
#include "imagecoder/imagecoder_tga.h"
#include "imagecoder/imagecoder_jpg.h"
#include "imagecoder/imagecoder_png.h"
#include "../exception.h"

//****************************************************************************

Helper::ImageCoder* Helper::ImageTool::getDecoder(const std::string &extension) const {
	
	for (int C=0; C<mCoders.size(); C++) {
		if (mCoders[C]->isDecoder(extension)) return mCoders[C];
	}

	return 0;
}

//****************************************************************************

Helper::ImageCoder* Helper::ImageTool::getEncoder(const std::string &extension) const {
	
	for (int C=0; C<mCoders.size(); C++) {
		if (mCoders[C]->isEncoder(extension)) return mCoders[C];
	}

	return 0;
}

//****************************************************************************

Helper::ImageTool::ImageTool() {
	addImageCoder(new ImageCoder_TGA);
	addImageCoder(new ImageCoder_JPG);
	addImageCoder(new ImageCoder_PNG);
}

Helper::ImageTool::~ImageTool() {
	for (int C=0; C<mCoders.size(); C++) {
		delete mCoders[C];
	}

	mCoders.clear();
}

//****************************************************************************

void Helper::ImageTool::addImageCoder(ImageCoder *imageCoder) {
	mCoders.push_back(imageCoder);
}

//****************************************************************************

const bool Helper::ImageTool::isDecoder(const std::string &extension) const {
	if (extension.empty()) return false;
	return getDecoder(extension)!=0;
}

//****************************************************************************

const bool Helper::ImageTool::isEncoder(const std::string &extension) const {
	if (extension.empty()) return false;
	return getEncoder(extension)!=0;
}

//****************************************************************************

void Helper::ImageTool::save(Blob &result, const BaseImage32 &sourceImage, const AreaInt &sourceArea, const std::string &destinationExtension, const ImageCoder::EncodeSettings &encodeSettings) const {
	const ImageCoder* const encoder=getEncoder(destinationExtension);
	
	if (!encoder) throw Helper::Exception("ImageTool::encode; Could not find a encoder for '%s'", destinationExtension.c_str());

	encoder->encode(result, sourceImage, sourceArea, encodeSettings);
}

//****************************************************************************

void Helper::ImageTool::load(BaseImage32 &result, const Blob &sourceBlob, const std::string &sourceExtension, const ImageCoder::DecodeSettings &decodeSettings) const {
	const ImageCoder* const decoder=getDecoder(sourceExtension);
	
	if (!decoder) throw Helper::Exception("ImageTool::decode(Blob); Could not find a decoder for '%s'", sourceExtension.c_str());

	decoder->decode(result, sourceBlob, decodeSettings);
}

//****************************************************************************
