#ifndef __DEVICE2D_H__
#define __DEVICE2D_H__

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Tooon
 @ Class		: Device2d
 @ Brief		: A 2D device interface class..
				  --- more to come ---

================================================================================*/

//===============================================================================
// Includes
//===============================================================================
#include "typedefs.h"
#include <map>
#include <string>
#include "image32.h"
#include "baseimage32.h"
#include "message.h"
#include "config.h"
#include "pixelformat.h"
#include "displaymode.h"

namespace Helper {

/**
 * Basic highlevel Device2D Interface, inherits CMsgQueue which 
 * makes devices works as message queus as well.
 * This will provide a stable, platform independent way of
 * getting messages/events from the OS.
 */
	class Device2D : public MsgQueue
	{
		public:
			
			// constructor/ desstructor
			Device2D(){}
			virtual	~Device2D(){}
			
			// add configuration parameter to device
			virtual  void  config (const std::string field, const std::string value) { m_config[field] = value; }

			//  get/set current configuration
			virtual  void  getConfig(Helper::Config &cfgmap) { cfgmap = m_config;}
			virtual  void  setConfig(Helper::Config &cfgmap) { m_config = cfgmap;}
			
			// open/close device
			virtual  void	open()  = 0;
			virtual  void	close() = 0;
		
			// update device's backbuffer to screen (flip), 
			// if forceScreenUpdate = true, always flip even if screen hasn't changed
			virtual  void	update(bool forceScreenUpdate=true, bool waitSysEvent = false) = 0;
			
			// get methods to retrieve device's current states
			virtual  int	getWidth () const = 0;
			virtual  int	getHeight() const = 0;
			virtual  int	getPitch () const = 0;
			
			// get/set Mouse Position
			virtual  PointInt getMousePosition() const { return PointInt(0,0); }
			virtual  void	setMousePosition(const PointInt &point) = 0;

			virtual  void	getPixelFormat(PixelFormat &format) const = 0;
			
			// get list of supported displaymodes
			virtual  const DisplayModeList& getDisplayModeList() const { return m_displayModes; }

			// retrieve device's backbuffer
			virtual BaseImage32& getBackBuffer() = 0;
			
		protected:
			
			/**
			 * m_config - STL template map class
			 * all devices based on IDevice2D will be provided with a m_config member
			 */
			Config			m_config;
			DisplayModeList	m_displayModes;
		};

}// end namespace 

#endif

