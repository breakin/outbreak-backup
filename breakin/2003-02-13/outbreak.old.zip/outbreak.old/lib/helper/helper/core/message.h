#ifndef __MSGQUEUE_INCLUDED__
#define __MSGQUEUE_INCLUDED__

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Tooon
 @ Class		: Msg/MsgQueue
 @ Brief		: Managing all messages send through the system such as
				  mouse movements, keyboard presses and other useful system
				  messages send to us from the operating system.

 @ Features
 
  * 100% thread safe
  * Possibilty to block application and slee until it receives a msg.
  * Runtime timeout configuration

================================================================================*/

//==========================================================================================
// includes
//==========================================================================================
#include <windows.h>
#include "point.h"
#include "typedefs.h"
#include <queue>

//==========================================================================================
// namespace Aurora
//==========================================================================================
namespace Helper {

//==========================================================================================
// message structure
//==========================================================================================
struct Msg
{
  
	/**
	 * Message type enumeration
	 * conains a list of valid types that can be
	 * stored int member m_message
	 */
	enum 
	{
		MSG_KEYDOWN,
		MSG_KEYUP,
		MSG_LMOUSEDOWN,
		MSG_RMOUSEDOWN,
		MSG_LMOUSEUP,
		MSG_RMOUSEUP,
		MSG_KEYCHAR,
		MSG_GOTFOCUS,
		MSG_LOSTFOCUS,
		MSG_PAINT,
		MSG_CLOSE,
		MSG_QUIT,
	};

	/**
	* MSG_KEYDOWN info passes in m_extra;
	*/
	enum
	{
		KEY_EXTRA_ALT,
		KEY_EXTRA_SHIFT,
		KEY_EXTRA_CTRL,
	};

	/**
	 * CMsg properties
	 */
	uint32  	  message;
	uint32			param;
	uint32			extra;
	Point<int>  mousePosition;
};

//==========================================================================================
// class CMsgQueue structure
//==========================================================================================
class MsgQueue
{
	public:
		
		/**
		 * Constructor, Destructor
		 */
		MsgQueue();
		~MsgQueue();

		/**
		 * To add a message to the queue. addMessage is 100% thread safe and the all data
		 * is protected through a mutex.
		 * The messages can be of any enumerated CMsg type like CMsg::MSG_QUIT etc
		 * Params and extra data is passed in <param> and <extra> as well as the
		 * current mouse position (optional)
		 */ 
		void addMessage(uint32 message, uint32 param, uint32 extra, int mouse_x, int mouse_y);

		/**
		 * getMessage retrieves a message from the messagequeue
		 * If a message currently is added to the queue,
		 * the methods can either return false directly
		 * or wait for the message to be added, and then
		 * retrieve it. This is chosen depending on the parameter
		 * <infiniteWait> 
		 * Returns true if message was retrieven, false otherwise
		 */
		bool getMessage(Helper::Msg &msg, bool infiniteWait = false);

		/**
		 * waitMessage retrieves a message is excist, otherwise it blocks
		 * and wait for a newMessageEvent to occur and return when retrieved
		 */
		void waitMessage(Helper::Msg &msg);

		/**
		 * isEmpty peeks the messagequeue for new messages
		 */
		bool isEmpty() const;
    

	protected:
		
		/**
		 * CMsgQueue data
		 */
		HANDLE           hEvent;		// Event signalled when a message is added to the queue.
		HANDLE			 hMutex;		// Protect m_queue from beeing processed by multiple threads 
		std::queue<Helper::Msg> msgQueue;  // STL queue, container of CMsg's
};

} // end namespace inclution
#endif
