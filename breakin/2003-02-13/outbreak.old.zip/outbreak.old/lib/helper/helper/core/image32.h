#ifndef HELPER_IMAGE32_H
#define HELPER_IMAGE32_H

#include "typedefs.h"
#include "area.h"
#include "exception.h"
#include "baseimage32.h"
#include "debug/assert.h"

/* Author: Breakin
   Remark: (see blob.h for design pattern)
*/

namespace Helper {
	
	class Image32 : public BaseImage32 {
	private:

		uint32 *mBuffer;
		uint8  *mOriginalBuffer;
		int     mWidth;
		int     mHeight;
		AreaInt mArea;
		
		void operator=(const BaseImage32 &baseImage) {}
		void operator=(const Image32 &image) {}

	public:

		Image32();
		Image32(const int width, const int height);
		virtual ~Image32();

		// This method will resize the Image32
		void resize(const int width, const int height);

		// NOTE! This will resize(0,0) not just making the image black!
		void clear();

		const bool isEmpty()     const { return (mBuffer==0) || (mWidth==0) || (mHeight==0); }
		const int  getWidth()    const { return mWidth;       }
		const int  getHeight()   const { return mHeight;      }
		const AreaInt& getArea() const { return mArea;        }
		const int  getPitch()    const { return getWidth()*4; }		
		
		uint32 * get() {
			DEBUG_ASSERT(mBuffer!=0);
			return mBuffer;
		}

		const uint32 * const get() const {
			DEBUG_ASSERT(mBuffer!=0);
			return mBuffer;
		}

		__forceinline void set(const int index, const uint32 value) {

			DEBUG_ASSERT(mBuffer!=0);

			// Check boundaries
			DEBUG_ASSERT(index>=0);
			DEBUG_ASSERT(index<getWidth()*getHeight());

			mBuffer[index]=value;
		}
	};
}

#endif