#include "draw.h"
#include "..\debug\debug.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

using namespace Helper;

// declare static variables

int Drawer::m_initialized = false;

// Saturation Lookup Table
static int SLUT[512];

//===========================================================================================
// interpolate bilinear and return a filtered color
//===========================================================================================
/*
__forceinline uint32 calc_color_bilinear(uint32 *data, float xpos, float ypos, int width){

	int	  r,g,b,a;
	int   r2,g2,b2,a2;
	int   intPart;
	float fraction;

	// add interpolated attributes
	intPart		= (int)xpos;
	fraction	= xpos - (float)intPart;
	
	// extract color attributes, from the current pixel and one to the left 
	a  = (data[0]>>24)& 0xff;
	r  = (data[0]>>16)& 0xff;
	g  = (data[0]>>8) & 0xff;
	b  =  data[0]     & 0xff;

	a2 = (data[1]>>24)& 0xff;
	r2 = (data[1]>>16)& 0xff;
	g2 = (data[1]>>8) & 0xff;
	b2 =  data[1]     & 0xff;

	// add interpolated attributes
	a = (int)(((1.0 - fraction) * (float)a) + fraction * (float)a2)&0xff;
	r = (int)(((1.0 - fraction) * (float)r) + fraction * (float)r2)&0xff;
	g = (int)(((1.0 - fraction) * (float)g) + fraction * (float)g2)&0xff;
	b = (int)(((1.0 - fraction) * (float)b) + fraction * (float)b2)&0xff;
	
	// calculate vertical interpolation
	intPart		= (int)ypos;
	fraction	= ypos - (float)intPart;
	
	// extract lower pixel's attributes
	a2 = (data[width]>>24)& 0xff;
	r2 = (data[width]>>16)& 0xff;
	g2 = (data[width]>>8) & 0xff;
	b2 =  data[width]     & 0xff;
	
	// add x and y interpolated attributes
	a =(int) (((1.0 - fraction) * (float)a) + fraction * (float)a2)&0xff;	
	r =(int) (((1.0 - fraction) * (float)r) + fraction * (float)r2)&0xff;
	g =(int) (((1.0 - fraction) * (float)g) + fraction * (float)g2)&0xff;
	b =(int) (((1.0 - fraction) * (float)b) + fraction * (float)b2)&0xff;

	// return color
	return ((a<<24)|(r<<16)|(g<<8)|b);
}
*/
//=============================================================================================================



//=============================================================================================================

Drawer::Drawer()
{

	if (!m_initialized)
	{
		// initlize saturation lookup table
		for (int I=0; I<512; I++)
			if (I > 255)
				SLUT[I] = 255;
			else
				SLUT[I] = I;

		m_initialized = true;
	}

}

//=============================================================================================================

__forceinline uint32 bilerp_col(uint32 *data, uint32 xpos, uint32 ypos, uint32 width) {

	uint32 color;
	uint32 pitch  = width * 4;
	uint32 fracX  = xpos & 0xff;
	uint32 fracY  = ypos & 0xff;
	uint32 iFracX = 0xff - fracX;
	uint32 iFracY = 0xff - fracY;
		

	__asm {

		mov		  edi, data			//  load src address in edi
		pxor	  mm7, mm7			//  mm7 = [0] , used as a zero reg  (used in pack/unpack instr.)
		
		movq	  mm3, fracX		//  mm3 = horizontal fraction
		movq	  mm4, iFracX		//  mm4 = 1.0 - horizontal fraction
			
		punpcklwd mm3,mm3			//  mm3 = 0000 0000 00ff 00ff
		punpckldq mm3,mm3			//  mm3 = 00ff 00ff 00ff 00ff
		
		punpcklwd mm4,mm4			//  mm4 = 0000 0000 00ff 00ff
		punpckldq mm4,mm4			//  mm4 = 00ff 00ff 00ff 00ff

		movd	  mm5, [edi]		//  mm5 = 0000 0000 aarr ggbb, upper left pixel	
		movd	  mm6, [edi + 4]	//  mm6 = 0000 0000 aarr ggbb, upper right pixel

		punpcklbw mm5, mm7			//  mm5 = 00aa 00rr 00gg 00bb
		punpcklbw mm6, mm7			//  mm6 = 00aa 00rr 00gg 00bb
		
		pmullw	  mm5, mm4			//  mm5 = fafa frfr fgfg fbfb 
		pmullw	  mm6, mm3 			//  mm6 = fafa frfr fgfg fbfb 
		
		psrlw	  mm5, 8			//  mm5 = 00fa 00fr 00fg 00fb
		psrlw	  mm6, 8			//  mm6 = 00fa 00fr 00fg 00fb
			
		paddusb	  mm6, mm5			//  blend unpacked pixels, save an upack instruction later;)
					
		movd	  mm3, fracX		//  mm3 = x fraction in mm3 
		movd	  mm2, iFracX		//  mm2 = 1,0 - fraction
	
		punpcklwd mm3,mm3			//  mm3 = 0000 0000 00ff 00ff
		punpckldq mm3,mm3			//  mm3 = 00ff 00ff 00ff 00ff
		
		punpcklwd mm2,mm2			//  mm2 = 0000 0000 00ff 00ff
		punpckldq mm2,mm2			//  mm2 = 00ff 00ff 00ff 00ff
			
		add		  edi, pitch		//  add pitch to get next row of pixels
		pxor	  mm5, mm5			//  mm5 = [0], needed for unpacking color attrubutes
		movd	  mm5, [edi]		//  mm5 = 0000 0000 00rr ggbb, lower left pixel
		movd	  mm1, [edi + 4]	//  mm1 = 0000 0000 00rr ggbb, lower right pixel
	
		punpcklbw mm5, mm7			//  mm5 = 00aa 00rr 00gg 00bb
		punpcklbw mm1, mm7			//  mm1 = 00aa 00rr 00gg 00bb

		pmullw	  mm5, mm2			//  mul mm5 with (1.0 - fraction)
		pmullw	  mm1, mm3			//  mul mm1 with fraction

		psrlw	  mm5, 8			//  mm5 = 00aa 00rr 00gg 00bb
		psrlw	  mm1, 8			//  mm1 = 00aa 00rr 00gg 00bb

		paddusb	  mm5, mm1			//  mm5 = 00na 00nr 00rg 00rg
	
		movd	  mm3, fracY		//  mm3 = vertical fraction
		movd	  mm2, iFracY		//  mm2 = 1.0 - vertical fraction
		
		punpcklwd mm3,mm3			//  mm3 = 0000 0000 00ff 00ff
		punpckldq mm3,mm3			//  mm3 = 00ff 00ff 00ff 00ff
		
		punpcklwd mm2,mm2			//  mm2 = 0000 0000 00ff 00ff
		punpckldq mm2,mm2			//  mm2 = 00ff 00ff 00ff 00ff
	
		pmullw	  mm6, mm2			//  mm6 = fafa frfr fgfg fbfb, 1.0 - fraction * upper blended pixel
		pmullw	  mm5, mm3			//  mm5 = fafa frfr fgfg fbfb, fraction * lower blended pixel

		psrlw	  mm6, 8			//  mm6 = 00aa 00rr 00gg 00bb
		psrlw	  mm5, 8			//  mm5 = 00aa 00rr 00gg 00bb

		paddusb	  mm6, mm5			//  blend upper and lower restults to final color
		packuswb  mm6, mm6			//  pack to dword format(1 byte / attribute)
		movd	  color, mm6		//  store color in [color]
	}

	return color;
}

//=============================================================================================================


void Drawer::scale_bilinear(uint32* src, const AreaInt &srcArea, int srcPitch, uint32 *dst, const AreaInt &dstArea, int dstPitch)
{
	// variables..
	int32 deltax;
	int32 deltay;
	uint32 x,y;

	/**
	 * calculate zoom deltas
	 */
	deltax = (srcArea.getWidth () << 16) / dstArea.getWidth();
	deltay = (srcArea.getHeight() << 16) / dstArea.getHeight();
		
	/**
	 * calculate src offsets, first pixel
	 */
	src+=(srcArea.getLeft() + srcArea.getTop() * (srcPitch>>2));	


	x = 0;
	y = 0;
	
	for (int height = 0; height < dstArea.getHeight(); height++)
	{
		
		for (int width = 0; width < dstArea.getWidth(); width++) {

			dst[width] = bilerp_col(&src[(x >> 16) + (y >> 16) * (srcPitch>>2) ], (x>>8), (y>>8), (srcPitch>>2));	
			
			x+=deltax;
		}
		dst+=(dstPitch>>2);
		y +=deltay;
		x  = 0;
	}

	__asm { emms }
}

//=============================================================================================================

void Drawer::scale_linear(uint32 *src,const AreaInt &srcArea, int srcPitch, uint32* dst, const AreaInt &dstArea, int dstPitch)
{
	float deltax;
	float deltay;

	/**
	 * Calculate deltas
	 */
	deltax = (float)srcArea.getWidth()  / (float)dstArea.getWidth();
	deltay = (float)srcArea.getHeight() / (float)dstArea.getHeight();
		
	/**
	 * Calcate offset of src surface's first pixel
	 * Assume *dst points to first pixel in destination surface
	 * and that dstArea only contain a valid width, height pair
	 */
	src+=(srcArea.getLeft() + srcArea.getTop() * (srcPitch>>2));
	
	float xsrc = 0;
	float ysrc = 0;

	for (int height = 0; height < dstArea.getHeight(); height++)
	{
		for (int width = 0; width < dstArea.getWidth(); width++)
		{
			dst[width] = src[(int)xsrc + (int)ysrc * (srcPitch>>2)];
			xsrc+=deltax;
		}

		xsrc  = 0;
		ysrc += deltay;
		dst+=(dstPitch>>2);	
	}
}

//=============================================================================================================

void Drawer::blit(uint8 *srcPixels, uint8 *dstPixels, int width, int height, int srcPitch, int dstPitch)
{
	for (int Y =0; Y<height; Y++)
	{
		memcpy(dstPixels,srcPixels, (width * 4));
		srcPixels+= srcPitch;
		dstPixels+= dstPitch;
	}
}


//=============================================================================================================

void Drawer::blit_alpha(uint8 *srcPixels, uint8 *dstPixels, int width, int height, int srcPitch, int dstPitch)
{
	int32 sr,sg,sb,sa;
	int32 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;
		
		for (int X=0; X<width; X++)
		{
			
			// extract source channels
			sa = (src[X] >> 24);
			sr = (uint8)(src[X] >> 16);
			sg = (uint8)(src[X] >> 8);
			sb = (uint8)(src[X]);
			
			// extract dest channels
			da = (uint8)(0xff - sa);
			dr = (uint8)(( (da * ((dst[X]>>16)&0xff)) + (sa * sr + 255)) >> 8);
			dg = (uint8)(( (da * ((dst[X]>>8 )&0xff)) + (sa * sg + 255)) >> 8);
			db = (uint8)(( (da * ((dst[X]	 )&0xff)) + (sa * sb + 255)) >> 8);
/*			dr = (uint8)(dst[X] >> 16);
			dg = (uint8)(dst[X] >> 8);
			db = (uint8)(dst[X]);
			// extract dest channels
			
			dr =(uint8) dr + ((sa * (sr - dr))>>8);
			dg =(uint8) dg + ((sa * (sg - dg))>>8);
			db =(uint8) db + ((sa * (sb - db))>>8);*/

			// pack pixel
			dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}
//=============================================================================================================

void Drawer::blit_alpha_const (uint8 *srcPixels, uint8 *dstPixels, int alpha, int width, int height, int srcPitch, int dstPitch)
{
	uint8 sr,sg,sb,sa;
	uint8 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;

		for (int X=0; X<width; X++)
		{
			// extract source channels
			sa = (uint8) alpha;
			sr = (uint8)(src[X] >> 16);
			sg = (uint8)(src[X] >> 8);
			sb = (uint8)(src[X]);
			
			// extract dest channels
			da = (uint8)(0xff - sa);
			dr = (uint8)(( (da * ((dst[X]>>16)&0xff)) + (sa * sr)) >> 8);
			dg = (uint8)(( (da * ((dst[X]>>8 )&0xff)) + (sa * sg)) >> 8);
			db = (uint8)(( (da * ((dst[X]	 )&0xff)) + (sa * sb)) >> 8);

			// pack pixel
			dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}
//=============================================================================================================

void Drawer::blit_colorkey(uint8 *srcPixels, uint8 *dstPixels, uint32 colorkey, int width, int height, int srcPitch, int dstPitch)
{
	uint32 *src;
	uint32 *dst;

	for (int H=0; H<height; H++)
	{
		src = (uint32*) srcPixels;
		dst = (uint32*) dstPixels;

		for (int W=0; W<width; W++)
		{
			if ((src[W]&0x00ffffff) != (colorkey&0x00ffffff)) src[W] = dst[W];
		}
		srcPixels += srcPitch;
		dstPixels += dstPitch;
	}	
}

//=============================================================================================================

void Drawer::copy(uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch)
{
	for (int H = 0; H < height; H++) 
	{
		memcpy(dst, src, width * 4);
		src += srcPitch;
		dst += dstPitch;
	}
}

//=============================================================================================================

void Drawer::clear_argb(uint8 *dstPixels, int width, int height, int dstPitch)
{

	for (int H=0; H<height; H++)
	{	
		// clear each line
		memset(dstPixels,0, (width << 2));	
		
		// move to next
		dstPixels += dstPitch;
	}
}

//=============================================================================================================

void Drawer::clear_rgb (uint8 *dstPixels, int width, int height, int dstPitch)
{
	uint32 *dst;

	for (int H=0; H<height; H++)
	{
		
		dst = (uint32*) dstPixels;

		for (int W=0; W<width; W++)
		{
			// clear all but alpha
			dst[W] &= 0xff000000;
		}	
		// move to next line
		dstPixels += dstPitch;
	}
}

//=============================================================================================================

void Drawer::blit_saturation (uint8 *srcPixels, uint8 *dstPixels,int width, int height, int srcPitch, int dstPitch)
{

	for (int H = 0; H < height; H++)
	{
		for (int W = 0; W < width * 4; W++)
		{
			dstPixels[W] = (uint8) SLUT[srcPixels[W] + dstPixels[W]];
		}	
		
		srcPixels += srcPitch;
		dstPixels += dstPitch;
	}

}

//=============================================================================================================

void Drawer::blit_alpha_saturation (uint8 *srcPixels, uint8 *dstPixels, int width, int height, int srcPitch, int dstPitch)
{
	uint8 sr,sg,sb,sa;
	uint8 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;

		for (int X=0; X<width; X++)
		{
			// extract source channels
			sa = (uint8)(src[X] >> 24);
			sr = (uint8)(src[X] >> 16);
			sg = (uint8)(src[X] >> 8);
			sb = (uint8)(src[X]);
			
			// extract dest channels
			da = (uint8)(0xff - sa);
			dr = (uint8)SLUT[((dst[X]>>16)&0xff) + ((sa * sr) >> 8)];
			dg = (uint8)SLUT[((dst[X]>>8 )&0xff) + ((sa * sg) >> 8)];
			db = (uint8)SLUT[(dst[X] &0xff) + ((sa * sb) >> 8)];

			// pack pixel
			dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}

//=============================================================================================================

void Drawer::blit_colorkey_saturation (uint8 *srcPixels, uint8 *dstPixels, int colorkey, int width, int height, int srcPitch, int dstPitch)
{
	for (int H = 0; H < height; H++)
	{
		for (int W = 0; W < width * 4; W++)
		{
			if (dstPixels[W] != colorkey)
				dstPixels[W] = (uint8) SLUT[srcPixels[W] + dstPixels[W]];
		}	
		
		srcPixels += srcPitch;
		dstPixels += dstPitch;
	}
}

//=============================================================================================================

void Drawer::blit_alpha_const_saturation (uint8 *srcPixels, uint8 *dstPixels, int alpha, int width, int height, int srcPitch, int dstPitch)
{
	uint8 sr,sg,sb,sa;
	uint8 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;

		for (int X=0; X<width; X++)
		{
			// extract source channels
			sa = (uint8) alpha;
			sr = (uint8)(src[X] >> 16);
			sg = (uint8)(src[X] >> 8);
			sb = (uint8)(src[X]);
			
			// extract dest channels
			da = (uint8)(0xff - sa);
			dr = (uint8)SLUT[((dst[X]>>16)&0xff) + ((sa * sr) >> 8)];
			dg = (uint8)SLUT[((dst[X]>>8 )&0xff) + ((sa * sg) >> 8)];
			db = (uint8)SLUT[(dst[X] &0xff) + ((sa * sb) >> 8)];

			// pack pixel
			dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}

//=============================================================================================================

void Drawer::blit_alpha_const_colorkey (uint8 *srcPixels, uint8 *dstPixels, int alpha, uint32 colorkey, int width, int height, int srcPitch, int dstPitch)
{
	uint8 sr,sg,sb,sa;
	uint8 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;

		for (int X=0; X<width; X++)
		{
			if (src[X] != colorkey)
			{
				// extract source channels
				sa = (uint8) alpha;
				sr = (uint8)(src[X] >> 16);
				sg = (uint8)(src[X] >> 8);
				sb = (uint8)(src[X]);
				
				// extract dest channels
				da = (uint8)(0xff - sa);
				dr = (uint8)(( (da * ((dst[X]>>16)&0xff)) + (sa * sr)) >> 8);
				dg = (uint8)(( (da * ((dst[X]>>8 )&0xff)) + (sa * sg)) >> 8);
				db = (uint8)(( (da * ((dst[X]	 )&0xff)) + (sa * sb)) >> 8);

				// pack pixel
				dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
			}
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}

//=============================================================================================================

void Drawer::blit_alpha_colorkey (uint8 *srcPixels, uint8 *dstPixels, uint32 colorkey, int width, int height, int srcPitch, int dstPitch)
{
	uint8 sr,sg,sb,sa;
	uint8 dr,dg,db,da;
	uint32* src;
	uint32* dst;

	for (int Y =0; Y<height; Y++)
	{
		src = (uint32*)srcPixels;
		dst = (uint32*)dstPixels;

		for (int X=0; X<width; X++)
		{
			if (src[X] != colorkey)
			{
				// extract source channels
				sa = (uint8)(src[X] >> 24);
				sr = (uint8)(src[X] >> 16);
				sg = (uint8)(src[X] >> 8);
				sb = (uint8)(src[X]);
				
				// extract dest channels
				da = (uint8)(0xff - sa);
				dr = (uint8)(( (da * ((dst[X]>>16)&0xff)) + (sa * sr)) >> 8);
				dg = (uint8)(( (da * ((dst[X]>>8 )&0xff)) + (sa * sg)) >> 8);
				db = (uint8)(( (da * ((dst[X]	 )&0xff)) + (sa * sb)) >> 8);

				// pack pixel
				dst[X] = (uint32)((dr<<16) | (dg<<8) | db);
			}
		}
		
		// jump to next line
		dstPixels += dstPitch;
		srcPixels += srcPitch;
	}
}
