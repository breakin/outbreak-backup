#ifndef HELPER_DIALOG_FRAME_MENUITEM
#define HELPER_DIALOG_FRAME_MENUITEM

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : MenuItem
	@ Brief       : Menuitem such as "File" "File->New" etc. Adds other menu-
					items and can draw them recursive

	@ Todo :
		* Can't draw submenus right now. Fix later.

  =============================================================================
*/

// Removes silly, annoying microsoft-warning which is impossible for us to avoid
// At least it seems like it, anyone may try to solve this, but I couldn't /thec
#pragma warning(disable:4786)

#include "../base/framebase.h"
#include "../font/font.h"

namespace Helper {

	class MenuItem : public FrameBase {
	protected:
		Font* font;
		uint32 minimumWidth;
		uint32 light;

		Image32 upperLeft, upperMiddle, upperRight;
		Image32 left, middle, right;
		Image32 bottomLeft, bottomMiddle, bottomRight;

		Image32 selectedLeft, selectedMiddle, selectedRight;
		Image32 arrow;
		
		uint32  normalColor;
		uint32  highlightColor;

		virtual void load();

	public:
		MenuItem();
		~MenuItem();

		void setFont(Font& font);
		void setName(std::string newName);
		void setColor(uint32 newNormalColor, uint32 newHighlightColor);
		void setMinimumWidth(const uint32 newMinimumWidth) { minimumWidth = newMinimumWidth; }

		void updateArea(const bool subMenu=false);
		virtual void add(ItemBase* _item, const bool subMenu=false);

		virtual const std::string processEvent(const Msg& message, const AreaInt& clientArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
	};
}

#endif