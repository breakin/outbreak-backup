#ifndef HELPER_CHUNKWRITER
#define HELPER_CHUNKWRITER

#include "../typedefs.h"
#include "../blob.h"
#include "../exception.h"
#include <stack>
#include "../debug/debug.h"
#include "../debug/assert.h"

// TODO: Implement buffering here or in blob

namespace Helper {

	template<typename IDTYPE, typename SIZETYPE>class ChunkWriter {

		private:

			Blob *m_blob;
			
			struct ChunkStructure {
				
				IDTYPE  id;
				int		startingOffset;

			};

			std::stack<ChunkStructure> m_chunk_stack;

		public:

			ChunkWriter(Blob *blob) : m_blob(blob) {
				DEBUG_ASSERT(m_blob!=0);
			}

			~ChunkWriter() { m_blob=0; }

			void openChunk(const IDTYPE id) {

				const ChunkStructure temp={id, m_blob->ftell()};
				m_chunk_stack.push(temp);

				m_blob->fwrite(&id, sizeof(IDTYPE));

				// We don't know the size of the chunk so we come back here
				// when we're closing it. Write dummy til then.
				const SIZETYPE sizeDummy=0;
				m_blob->fwrite(&sizeDummy, sizeof(SIZETYPE));
			}

			void closeChunk() {

				DEBUG_ASSERT(m_chunk_stack.empty()==false);

				// Save away the current blob file position
				const int currentOffset=m_blob->ftell();

				// Get the last chunk structure
				const ChunkStructure t=m_chunk_stack.top();
				
				// Calculate size of this chunk (including header)
				const SIZETYPE currentSize=currentOffset-t.startingOffset;

				DEBUG_ASSERT(currentSize>=0);
			
				// Jump back to where the size is located
				m_blob->fseek(t.startingOffset+sizeof(IDTYPE), SEEK_SET);

				// Print the new size
				m_blob->fwrite(&currentSize, sizeof(SIZETYPE));

				// Seek back to the end of the chunk
				m_blob->fseek(currentOffset, SEEK_SET);

				// Pop the last chunk from the stack
				m_chunk_stack.pop();
			}

			void fwrite(const void * const text, const int bytes, const int times=1) {
				DEBUG_ASSERT(text!=0 && bytes>0 && times>0);

				m_blob->fwrite(text,bytes,times);
			}

			void fprintf(const char * const text, ...) {
				DEBUG_ASSERT(text!=0);

				static char temp_message[1024];
				
				va_list  args;
				va_start(args,text);

				const int length=vsprintf(temp_message,text,args);

				va_end(args);

				if (length==0) return;

				m_blob->fwrite(temp_message,length);
			}
	};
}

#endif