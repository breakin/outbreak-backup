#ifndef __CONFIG_H__
#define __CONFIG_H__

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Tooon
 @ Class		: Config
 @ Brief		: Configuration database

================================================================================*/

namespace Helper{
	
#include "typedefs.h"
#include <map>

class Config
{
	public:

		/**
		 * add methods, adds different data into CConfig
		 * always set as std::string, std::string
		 */
		void set(const std::string &key, const std::string &data)
		{
			m_table[key] = data;
		}

		/**
		 * get... methods - Stores keydata inside variable referenced by <data>
		 */
		void get(const std::string &key,  bool &data) {

			if ((m_table[key] == "true") || (m_table[key] == "false"))
			data = (bool)(m_table[key] == "true");
		}

		void get(const std::string &key, int  &data) {

			data = atoi(m_table[key].c_str());
		} 

		void get(const std::string &key, char *data) {

			strcpy(data,m_table[key].c_str());
		}

		void get(const std::string &key, std::string &data) {

			data = m_table[key];
		}

		void get(const std::string &key, char &data) {

			data = (m_table[key].c_str()[0]);
		}

		/**
		 * operator[",,,,"], CMap class can be used
		 * widht operator[] like config["WITDH"] = "320" 
		 */
		std::string& operator[](std::string key)
		{
			return m_table[key];
		}

  protected:
    
		/**
		 * Data is stored in a STL map<std::string, std::string> container
		 */
		std::map<std::string, std::string> m_table;

};
} 

#endif