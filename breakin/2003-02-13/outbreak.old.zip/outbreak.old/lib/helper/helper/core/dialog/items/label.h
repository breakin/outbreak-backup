#ifndef HELPER_DIALOG_ITEM_LABEL
#define HELPER_DIALOG_ITEM_LABEL

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Label
	@ Brief       : Draws a piece of text on the screen.
  =============================================================================
*/

#include "../base/itembase.h"
#include "../font/font.h"

namespace Helper {

	class Label : public ItemBase {
	protected:
		Font*       font;
		std::string text;
		uint32      color;

	public:
		Label();
		~Label();

		virtual void setFont(Font& font);
		virtual void setText(std::string newText);
		virtual void setColor(uint32 newColor) { color = newColor; }

		virtual const std::string processEvent(const Msg& message, const AreaInt& parentArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
	};
}

#endif
