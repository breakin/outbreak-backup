#ifndef HELPER_DIALOG_ITEM_RADIOBUTTON
#define HELPER_DIALOG_ITEM_RADIOBUTTON

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Radiobutton
	@ Brief       : A list of alternatives where you can choose one.
  =============================================================================
*/

#include "../base/itembase.h"

namespace Helper {

	class RadioButton : public ItemBase {
	protected:
		Image32 imageNormal;
		Image32 imageSelected;

		std::string selected;

		struct Data {
			std::string name;
			AreaInt     area;
		};

		std::vector<Data> radiobuttonList;

	public:
		RadioButton();
		~RadioButton();

		virtual void setSelected(const std::string which);
		virtual const std::string getSelected() const;

		virtual void setArea(const std::string _name, const AreaInt& area);

		virtual void load();

		virtual const std::string processEvent(const Msg& message, const AreaInt& parentArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
	};
}

#endif