#ifndef HELPER_DIALOG_ITEM_IMAGEBUTTON
#define HELPER_DIALOG_ITEM_IMAGEBUTTON

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : ImageButton
	@ Brief       : A button with a custom image instead of a label.
  =============================================================================
*/

#include "../base/itembase.h"

namespace Helper {

	class Archive;

	class ImageButton : public ItemBase {
	protected:
		bool light;

		Image32 normal;
		Image32 highlight;

	public:
		ImageButton();
		~ImageButton();

		void setImageNormal   (Archive& archive, std::string& _normal);
		void setImageHighlight(Archive& archive, std::string& _highlight);

		virtual const std::string processEvent(const Msg& message, const AreaInt& parentArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
	};
}

#endif