#ifndef HELPER_DIALOG_ITEM_CHECKBOX
#define HELPER_DIALOG_ITEM_CHECKBOX

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Checkbox
	@ Brief       : A standard checkbox.
  =============================================================================
*/

#include "../base/itembase.h"

namespace Helper {

	class Checkbox : public ItemBase {
	protected:
		Image32 imageNormal;
		Image32 imageSelected;

		bool selected;

	public:
		Checkbox();
		~Checkbox();

		virtual void setSelected(const bool option);
		virtual const bool getSelected() const;

		virtual void load();

		virtual const std::string processEvent(const Msg& message, const AreaInt& parentArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
	};
}

#endif