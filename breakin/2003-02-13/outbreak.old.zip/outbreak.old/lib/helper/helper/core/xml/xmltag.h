#ifndef HELPER_TAG_H
#define HELPER_TAG_H

#include <string>
#include <vector>
#include <iostream>
#include "../typedefs.h"
#include "../blob.h"

namespace Helper {

	class XmlTag {
	public:

		class Argument {
		private:

			std::string name;
			std::string value;

		public:

			Argument(const std::string &newName, const std::string &newValue) : name(newName), value(newValue){
			}

			const std::string &getName() const { return name; }
			const std::string &getValue() const { return value; }
			void setName(const std::string &newName) { name=newName; }
			void setValue(const std::string &newValue) { value=newValue; }
		};

	private:

		bool closed;
		std::string name;
		std::vector<Argument> arg;

		inline const int Helper::XmlTag::parseWhiteSpace(const Blob &input, const int offset) const;
		inline const int Helper::XmlTag::parseAttribute(const Blob &input, const int offset);
		inline const int Helper::XmlTag::parseTagName(const Blob &input, const int offset);
		
	public:

		XmlTag();
		XmlTag(const Blob &blob, const int offset);
		XmlTag(const std::string &newName);
		~XmlTag();

		void setTag(const XmlTag &tag);
		
		// Returns the name of the tag
		const std::string &getName() const;

		// Returns the value of a given attribute
		const std::string &getValue(const std::string &name) const;

		// Returns if the tag is closed, ie. has a /-marker
		const bool getClosed() const;

		// Set the state of the tag
		void setClosed(const bool newClosed=true);
		void setName  (const std::string &newName);
		void setValue (const std::string &name, const std::string &value);
		void setValue (const std::string &name, const float64 value);
		void setValue (const std::string &name, const int value);

		// Empties all data for the tag, (clearing the attributelist)
		void erase();

		// Methods used for iterating through all attributes
		const std::vector<Argument> &getArg() const;
		      std::vector<Argument> &getArg();

		const int parse(const Blob &blob, const int offset);
		void write(Blob &result) const;
	};
}


#endif
