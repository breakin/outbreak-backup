#include "exception.h"

#include "debug\debug.h"
#include <stdarg.h>

//****************************************************************************

Helper::Exception::Exception() {}

//****************************************************************************

Helper::Exception::Exception(const char * const message,...) {

	char m_message[256];
	
	va_list  args;
	va_start(args,message);
	vsprintf(m_message,message,args);
	va_end(args);

	exception::operator=(exception(m_message));

	Debug::logException("Exception", what());			
};

//****************************************************************************

Helper::FileException::FileException(const char * const message, ...) {
	char m_message[256];
	
	va_list  args;
	va_start(args,message);
	vsprintf(m_message,message,args);
	va_end(args);

	exception::operator=(exception(m_message));

	Debug::logException("FileException", what());
}

//****************************************************************************

Helper::DeviceException::DeviceException(const char * const message,...) {
	char m_message[256];
	
	va_list  args;
	va_start(args,message);
	vsprintf(m_message,message,args);
	va_end(args);

	exception::operator=(exception(m_message));

	Debug::logException("DeviceException", what());
}

//****************************************************************************