#include "blob.h"
#include "exception.h"
#include <memory.h>
#include <stdarg.h>
#include "debug/assert.h"
#include "debug/debug.h"

// TODO: Perhaps implement buffering for fwrite/fprintf so we don't have to
// resize all the time

//****************************************************************************

Helper::Blob::Blob() : blobRef(0), fileOffset(0) {
}

//****************************************************************************

Helper::Blob::Blob(const Blob &other) : blobRef(other.blobRef), fileOffset(other.fileOffset) {
	DEBUG_ASSERT(this!=&other);

	if (blobRef) blobRef->refCount++;
}

//****************************************************************************

Helper::Blob::Blob(const uint8 * const memory, const int size) : blobRef(0), fileOffset(0) {
	setMemory(memory, size);
}

//****************************************************************************

Helper::Blob::Blob(const int newSize) : blobRef(0), fileOffset(0) {
	resize(newSize, false);
}

//****************************************************************************

Helper::Blob::~Blob() {
	clear();
}

//****************************************************************************

void Helper::Blob::operator=(const Blob &other) {
	if (blobRef==other.blobRef) return; // this will also reject this=&other

	clear();

	blobRef=other.blobRef;
	if (blobRef) blobRef->refCount++;	
}

//****************************************************************************

void Helper::Blob::clear() {
	
	if (blobRef) {
		if (blobRef->refCount==1) {
			delete [] blobRef->mBuffer;
			delete blobRef;
		} else {
			blobRef->refCount--;
		}

		blobRef=0;
	}	
}

//****************************************************************************

void Helper::Blob::makeUniqueCopy() {
	if (blobRef && blobRef->refCount!=1) {

		// We've gotta make a copy in order to get the blob unique
		
		const int size=blobRef->mSize;

		BlobRef *temp=new BlobRef;

		temp->refCount=1;
		temp->mSize=size;
		temp->mBuffer=new uint8[size];

		memcpy(temp->mBuffer, blobRef->mBuffer, size);

		blobRef->refCount--;

		blobRef=temp;
	}
}

//****************************************************************************

void Helper::Blob::setMemory(const uint8 * const memory, const int size) {
	resize(size, false);                    // Resize and make a valid (unique) blobRef
	memcpy(blobRef->mBuffer, memory, size); // Copy memory
	blobRef->mSize=size;
}

//****************************************************************************

void Helper::Blob::giveMemory(uint8* memory, const int size) {
	clear();                                // Clear the blobRef
	blobRef=new BlobRef;                    // Make a new blobRef (no allocation here!)
	blobRef->mBuffer=memory;
	blobRef->mSize=size;
	blobRef->refCount=1;
}

//****************************************************************************

Helper::uint8* Helper::Blob::takePointer() {
	if (!blobRef) return 0;

	makeUniqueCopy();

	uint8* temp=blobRef->mBuffer;

	delete blobRef;
	blobRef=0;

	return temp;
}

//****************************************************************************

void Helper::Blob::resize(const int newSize, const bool keepData) {
	DEBUG_ASSERT(newSize>0);

	if (!blobRef) {
		blobRef=new BlobRef;
		blobRef->mBuffer=new uint8[newSize];
		blobRef->mSize=newSize;
		blobRef->refCount=1;
	} else {

		if(keepData) {
			if (blobRef->refCount==1) {

				uint8* temp=new uint8[newSize];

				memcpy(temp, blobRef->mBuffer, blobRef->mSize > newSize ? newSize : blobRef->mSize);

				delete [] blobRef->mBuffer;
				blobRef->mBuffer=temp;
				blobRef->mSize=newSize;
				
			} else {

				blobRef->refCount--;
				BlobRef *temp=new BlobRef;
				temp->mSize=newSize;
				temp->refCount=1;
				temp->mBuffer=new uint8[newSize];

				memcpy(temp->mBuffer, blobRef->mBuffer, 
					   blobRef->mSize > newSize ? newSize : blobRef->mSize);

				blobRef=temp; 

			}
		} else {
			if (blobRef->refCount==1) {
				delete [] blobRef->mBuffer;
				blobRef->mBuffer=new uint8[newSize];
				blobRef->mSize=newSize;
			} else {
				clear();
				BlobRef *temp=new BlobRef;
				temp->refCount=1;
				temp->mBuffer=new uint8[newSize];
				temp->mSize=newSize;
				blobRef=temp;
			}
		}
	}
    
}

//****************************************************************************

void Helper::Blob::fseek(const int position, const int mode) {

	DEBUG_ASSERT(blobRef!=0 && (mode==SEEK_SET || mode==SEEK_END || mode==SEEK_CUR));
		
	if (mode==SEEK_SET) {
		
		// Can't seek before start (SEEK_SET)
		DEBUG_ASSERT(position>=0);

		// Can't seek after end (but we let it be one byte ahead) (SEEK_SET)
		DEBUG_ASSERT(position<=blobRef->mSize);
		
		fileOffset=position;

	} else if (mode==SEEK_END) {
	
		// Can't seek after end (SEEK_END)
		DEBUG_ASSERT(position<=0);

		fileOffset=blobRef->mSize+position;

	} else if (mode==SEEK_CUR) {

		const int newFileOffset=fileOffset+position;

		// Can't seek after end (SEEK_CUR) || Can't seek before start (SEEK_CUR)
		DEBUG_ASSERT((newFileOffset <= blobRef->mSize) && (newFileOffset>=0));
		
		fileOffset=newFileOffset;
	}
}

//****************************************************************************

const int Helper::Blob::ftell() const {
	return fileOffset;
}

//****************************************************************************

void Helper::Blob::fread(void *dest, const int bytes) {
	DEBUG_ASSERT(blobRef!=0);
	DEBUG_ASSERT(bytes>0);
	DEBUG_ASSERT(bytes+fileOffset <= blobRef->mSize);	

	memcpy(dest, blobRef->mBuffer+fileOffset, bytes);
	fileOffset+=bytes;
}

//****************************************************************************

void Helper::Blob::fprintf(const char * const text, ...) {

	DEBUG_ASSERT(text!=0);

	static char temp_message[1024];
	
	va_list  args;
	va_start(args,text);

	const int length=vsprintf(temp_message,text,args);

	va_end(args);

	if (length==0) return;

	makeUniqueCopy();

	if (blobRef) {

		const int extra=fileOffset+length-getSize();
		if (extra>0) resize(getSize()+extra, true);

	} else {
		resize(length);
	}

	memcpy(blobRef->mBuffer+fileOffset, temp_message, length);
	fileOffset+=length;
}

//****************************************************************************

void Helper::Blob::fwrite(const void * const text, const int bytes, const int times) {

	DEBUG_ASSERT((text!=0) && (times>0 && bytes>0));
	
	const int length=bytes*times;

	makeUniqueCopy();

	if (blobRef) {

		const int extra=fileOffset+length-getSize();
		if (extra>0) resize(getSize()+extra, true);

	} else {
		resize(length);
	}	
	
	for (int T=0; T<times; T++) {
		memcpy(blobRef->mBuffer+fileOffset, text, bytes);
		fileOffset+=bytes;
	}
}

//****************************************************************************
