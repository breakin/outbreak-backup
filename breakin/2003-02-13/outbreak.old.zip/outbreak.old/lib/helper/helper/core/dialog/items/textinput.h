#ifndef HELPER_DIALOG_ITEM_TEXTINPUT
#define HELPER_DIALOG_ITEM_TEXTINPUT

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Text Input
	@ Brief       : An item for text input to the program.

    @ Features : 
		* Adding every character which exist in the font is possible.
		* Scrolling within the window
		* Fast Ctrl+Cursor move to next word.
		* Maximum characters to enter.

	@ Todo :
		* Select text
		* Cut,copy&paste

  =============================================================================
*/

#include "../base/itembase.h"
#include "../font/font.h"

namespace Helper {

	class TextInput : public ItemBase {
	protected:
		Image32 imageLeft;
		Image32 imageMiddle;
		Image32 imageRight;
		Image32 imageCarret;
		
		Font*       font;
		std::string text;
		uint32      color;
		bool        selected;
		int32       carret;
		int32       offset;
		int32       maxSize;

	public:
		TextInput();
		~TextInput();

		virtual void load();

		virtual void setFont(Font& font);
		virtual void setText(std::string newText);
		virtual const std::string& getText() const { return text; }
		virtual void setColor(uint32 newColor);
		virtual void setMax(int32 newMax);

		virtual const bool getSelected();
		virtual void setSelected(const bool newSelected);

		virtual const std::string processEvent(const Msg& message, const AreaInt& parentArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
	};
}

#endif
