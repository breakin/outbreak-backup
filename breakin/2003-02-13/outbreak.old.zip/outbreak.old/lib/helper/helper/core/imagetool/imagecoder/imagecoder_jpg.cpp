#include "imagecoder_jpg.h"
#include "../../exception.h"
#include <string>
#include <vector>

// The following file will include jpeglib and our source/dest managers
#include "imagecoder_jpg_managers.h"

// ---------------------------------------------------------------------------

/**
 *
 * Jpeglib is all about understanding all the different kinds of callbacks
 * and do something quick before you die from the experience. Move in quick,
 * do it and go out while you are still sane.
 * I've learned some more about callbacks while doing the D3D-device for
 * the 3d-engine and from that experiences I've managed to produce
 * far better code than my last jpeglib implementation had. I will try to
 * put a comment here and there, along with some notes about how to compile
 * jpeglib.
 *
 **/

// ---------------------------------------------------------------------------

/**
 *
 * jpeglib.h must be in jpeglib/
 * jpeglib/jconfig.vc must be copied to jpeglib/jconfig.h (for msvc)
 * refine RGB_PIXELSIZE as 4 (not 3) int jpeglib/jmorecfg.h (to skip 
 *   alpha-values)
 * Reverse RGB_RED,GREEN,BLUE so we have bgr instead of rgb 
 *   (2,1,0 - not 0,1,2)
 *
 * Just throw everything from jpeglib/ into your workspace. Remove all 
 * files with a main() method and you are on the right track.
 * Remove jmem[ansi,name,dos,mac].c from the project and you are all done.
 *
 **/

// ---------------------------------------------------------------------------

Helper::ImageCoder_JPG::ImageCoder_JPG() : ImageCoder() {
}

// ---------------------------------------------------------------------------

Helper::ImageCoder_JPG::~ImageCoder_JPG() {
}

// ---------------------------------------------------------------------------

const bool Helper::ImageCoder_JPG::isEncoder(const std::string &fileName) const {
	return (fileName.empty() || isExtension(fileName, "jpg"));
}

// ---------------------------------------------------------------------------

const bool Helper::ImageCoder_JPG::isDecoder(const std::string &fileName) const {
	return (fileName.empty() || isExtension(fileName, "jpg"));
}

// ---------------------------------------------------------------------------

void Helper::ImageCoder_JPG::encode(Blob &result, const BaseImage32 &sourceImage, const AreaInt &sourceArea, const EncodeSettings &settings) const {
	if ((sourceImage.getWidth()*sourceImage.getHeight())==0) throw Helper::Exception("ImageCoder_JPG::encode; Image is empty");
	
	jpeg_compress_struct cinfo;
	
	MyDestMgr destManager(result, cinfo);

	// Tell jpeglib the dimensions of the image to be written
	cinfo.image_width=sourceImage.getWidth();
	cinfo.image_height=sourceImage.getHeight();

	// Shall we save the alpha channel as an grayscale jpeg, or an 24-bit?
	if (settings.saveAlphaChannelAsGreyScale) {

		// Save alpha as grayscale
		cinfo.input_components=1;
		cinfo.in_color_space=JCS_GRAYSCALE;

	} else {

		// Save 24-bit
		cinfo.input_components=4;
		cinfo.in_color_space=JCS_RGB;
	}

	// Set the rest of the compression settings based on the defaults (depends on in_color_space)
	// Default settings might be overrided later (such as quality)
	jpeg_set_defaults(&cinfo);

	// Set the quality for the output image. Quality ranges from 0.0 to 1.0 where 1.0 is best quality
	int qualityInt=static_cast<int>(settings.colorQuality*100.0);
	if (qualityInt<0) qualityInt=0;
	if (qualityInt>100) qualityInt=100;

	jpeg_set_quality(&cinfo, qualityInt, TRUE);

	// After this no more settings or changes can be made to cinfo		
	jpeg_start_compress(&cinfo, TRUE);

	// Jpeglib wants a list with a pointer to each scanline
	std::vector<JSAMPROW> row_pointers(cinfo.image_height);

	if (cinfo.input_components==1) {

		// We are to save the alphaChannel as a greyscale image
		
		// We must make a copy of the alphaChannel first
		Blob grayScaleBuffer(cinfo.image_width*cinfo.image_height);

		// Grayscale jpeg (from alphachannel)
		// We must unconst the souce-texture since jpeglib wants row_pointers to be const, well...
		uint32* sourceData = (uint32*)sourceImage.get();
		uint8*  destData=grayScaleBuffer.get();
		
		int C;

		// Move the alphachannel of the image to a temporary buffer
		for (C=0; C<cinfo.image_height*cinfo.image_width; C++) {
			destData[C]=sourceData[C]>>24;
		}
		
		// Save the pointer to the start of each scanline
		for (C=0; C<cinfo.image_height; C++) {
			row_pointers[C]=&destData[C*cinfo.image_width*cinfo.input_components];
		}

		// Write all scanlines
		while (cinfo.next_scanline < cinfo.image_height) {
			jpeg_write_scanlines(&cinfo, &row_pointers[0]+cinfo.next_scanline, cinfo.image_height-cinfo.next_scanline);
		}

	} else {
		
		// We are to save a full color jpeg (24-bit)

		// Jpeglib does require a non-const so we unconst it, but we are not going to
		// write anything so readOnly is fine
		uint8 *sourceData=(uint8*)(sourceImage.get());

		// Save the pointer to the start of each scanline
		for (int C=0; C<cinfo.image_height; C++) {
			row_pointers[C]=&sourceData[C*cinfo.image_width*cinfo.input_components];
		}

		// Write all scanlines
		while (cinfo.next_scanline < cinfo.image_height) {
			jpeg_write_scanlines(&cinfo, &row_pointers[0]+cinfo.next_scanline, cinfo.image_height-cinfo.next_scanline);
		}
	}

	// Clean up
	jpeg_finish_compress(&cinfo);
}

// ---------------------------------------------------------------------------

void Helper::ImageCoder_JPG::decode(BaseImage32 &result, const Blob &sourceBlob, const DecodeSettings &settings) const {

	jpeg_decompress_struct cinfo;
	MySourceMgr sourceManager(sourceBlob, cinfo);

	// Read the file header and check so that we can read it properly
	jpeg_read_header(&cinfo, TRUE);

	cinfo.output_width=cinfo.image_width;
	cinfo.output_height=cinfo.image_height;

	// Jpeglib will convert grayscaled pictures into color so we let it do that
	// unless alpha-channel loading has been enabled
	if (!settings.storeInAlphaChannel) {
		cinfo.out_color_space=JCS_RGB;
		cinfo.out_color_components=4;
	} else {
		if (cinfo.jpeg_color_space==JCS_GRAYSCALE) {
			cinfo.out_color_space=JCS_GRAYSCALE;
			cinfo.out_color_components=1;
		} else {
			throw Helper::Exception("ImageCoder_JPG::decode; Can not load a RGB-image to the alpha channel");
		}
	}

	result.resize(cinfo.image_width, cinfo.image_height);

	jpeg_start_decompress(&cinfo);

	// Jpeglib wants a list with a pointer to each scanline
	std::vector<JSAMPROW> row_pointers(cinfo.output_height);

	if (cinfo.out_color_components==1) {

		Blob grayScaleBuffer(cinfo.output_height*cinfo.output_width);
		unsigned char *tempDest=grayScaleBuffer.get();

		for (unsigned int C=0; C<cinfo.image_height; C++) row_pointers[C]=&tempDest[C*cinfo.image_width];

		// Read all scanlines
		while (cinfo.output_scanline < cinfo.output_height) {
			jpeg_read_scanlines(&cinfo, &row_pointers[cinfo.output_scanline], cinfo.output_height-cinfo.output_scanline);
		}

		uint8* dest=(uint8*)result.get();
		
		for (int O=0; O<cinfo.image_height*cinfo.image_width; O++) {
			*dest++=0xff;
			*dest++=0xff;
			*dest++=0xff;
			*dest++=*tempDest++;
		}

	} else {
		
		// Setup row_pointers for an rgb-destination
		uint32 *dest=result.get();
		for (int C=0; C<cinfo.image_height; C++) row_pointers[C]=(JSAMPROW)&dest[C*cinfo.image_width];

		// Read all scanlines
		while (cinfo.output_scanline < cinfo.output_height) {
			jpeg_read_scanlines(&cinfo, &row_pointers[cinfo.output_scanline], cinfo.output_height-cinfo.output_scanline);
		}

		// Fill the alphaChannel with 0xff
		for (int O=0; O<cinfo.image_height*cinfo.image_width; O++) {
			*dest++|=0xff000000;
		}
	}

	// Clean up
	jpeg_finish_decompress(&cinfo);
}

// ---------------------------------------------------------------------------