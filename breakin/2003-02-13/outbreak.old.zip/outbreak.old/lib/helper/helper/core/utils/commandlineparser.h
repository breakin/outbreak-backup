#ifndef COMMAND_LINE_PARSER
#define COMMAND_LINE_PARSER

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Brief       : Command Line Parser, parses lines like:
	                "demo.exe /fullscreen /x:320 /y:240 /time:50.00 /bpp:32"
  =============================================================================
*/

#include <string>
#include <vector>

namespace Helper {

	// Parses a command line like "demo.exe /fullscreen /x:320 /y:240 /time:52.00
	class CommandLineParser {

	private:

		// Entity data
		struct EntityData {
			std::string name;
			std::string value;
		};

		// Entity list.
		std::vector<EntityData> entity;

		// Trim and sets entity.
		void addEntity(const std::string& input);

		// Trimmer
		std::string trim(const std::string& input);

	public:
		
		// Creates the register of strings
		CommandLineParser();

		// Check if command is entered, good for detecting "demo.exe /fullscreen"
		const bool isEntity(const std::string& name);

		// Get entity with entered name, for instance, "demo.exe /x:320 /y:240 /bpp:32"
		const std::string getEntity(const std::string& name);
	};
}

#endif