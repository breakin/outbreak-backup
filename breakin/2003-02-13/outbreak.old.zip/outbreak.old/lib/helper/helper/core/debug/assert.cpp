#include "assert.h"
#ifdef USE_ASSERT

#include <windows.h>
#include <stdio.h>
#include <string>

//================================================================================================

bool handleAssert(const char module[], int line, const char statement[], bool &ignore) {

	static char assertMsg[512];
	DWORD		pressedButton;

	std::string fileName(module);

	sprintf (assertMsg,"Statement : (%s) (%s :: %.3d)\n\n\n(Ignore will discard this assert throughout the rest of the \nprogram execution!)", 
		statement,
		&module[fileName.find_last_of('\\') + 1],
		line);
	
	pressedButton = MessageBox(NULL,assertMsg, "Assert Failed!", MB_TOPMOST|MB_ICONWARNING|MB_ABORTRETRYIGNORE);
	
	switch (pressedButton) {

	case IDABORT:
	return true;
	case IDIGNORE:
	ignore = true; 
	case IDRETRY:
	return false;
	}


return false;
}

//================================================================================================

#endif
