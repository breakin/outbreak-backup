#include "xmltag.h"
#include <ctype.h>
#include "../exception.h"
#include <iostream>
#include <sstream>

// ---------------------------------------------------------------------------

namespace Helper {
	
	// We need to return a const reference to a string when getting a value, but if there is not value
	// for the name passed we must return a referece to an empty string and here it is!
	// Keeping a static in a namespace is silly, but ... :)

	static const std::string emptyString;
}

// ---------------------------------------------------------------------------

Helper::XmlTag::XmlTag() : closed(false) {
}

// ---------------------------------------------------------------------------

Helper::XmlTag::XmlTag(const Blob &blob, const int offset) : closed(false) {
	parse(blob, offset);
}

// ---------------------------------------------------------------------------

Helper::XmlTag::XmlTag(const std::string &newName) : name(newName), closed(false) {
}

// ---------------------------------------------------------------------------

Helper::XmlTag::~XmlTag() {
}

// ---------------------------------------------------------------------------

const std::string &Helper::XmlTag::getValue(const std::string &name) const {
	for (int C=0; C<arg.size(); C++) {
		if (arg[C].getName()==name) {
			return arg[C].getValue();
		}
	}

	return emptyString;
}

// ---------------------------------------------------------------------------

const bool Helper::XmlTag::getClosed() const { 
	return closed; 
}

// ---------------------------------------------------------------------------

void Helper::XmlTag::setClosed(const bool newClosed) {
	closed=newClosed;
}

// ---------------------------------------------------------------------------

void Helper::XmlTag::setName(const std::string &newName) {
	name=newName;
}

// ---------------------------------------------------------------------------

const std::string &Helper::XmlTag::getName() const { 
	return name;
}

// ---------------------------------------------------------------------------

void Helper::XmlTag::setValue(const std::string &name, const std::string &value) {

	for (int C=0; C<arg.size(); C++) {
		if (arg[C].getName()==name) {
			arg[C].setValue(value);
			return;
		}
	}

	arg.push_back(Argument(name,value));
}

// ---------------------------------------------------------------------------

void Helper::XmlTag::setValue(const std::string &name, const int value) {
	char buffer[512];
	sprintf(buffer, "%0d", value);
	setValue(name, buffer);
}

// ---------------------------------------------------------------------------

void Helper::XmlTag::setValue(const std::string &name, const float64 value) {
	char buffer[512];
	sprintf(buffer, "%.25g", value);
	setValue(name, buffer);
}

// ---------------------------------------------------------------------------

const std::vector<Helper::XmlTag::Argument> &Helper::XmlTag::getArg() const {
	return arg;
}

// ---------------------------------------------------------------------------

std::vector<Helper::XmlTag::Argument> &Helper::XmlTag::getArg() {
	return arg;
}

// ---------------------------------------------------------------------------

void Helper::XmlTag::setTag(const XmlTag &tag) {
	*this=tag;
}

// ---------------------------------------------------------------------------

void Helper::XmlTag::write(Blob &result) const {

	std::ostringstream temp;

	if (getArg().empty()) {
		temp << "<";
		if (getClosed()) temp << "/";		
		temp << getName();

	} else {
		temp << "<" << getName();

		for (int C=0; C<getArg().size(); C++) {
			temp << " " << getArg()[C].getName() << "=" << '"' << getArg()[C].getValue() << '"';
		}

		if (getClosed()) temp << "/";
	}

	temp << ">" << std::endl;

	result.fwrite(temp.str().c_str(), temp.str().length());
}

// ---------------------------------------------------------------------------

const int Helper::XmlTag::parseTagName(const Blob &input, const int offset) {


	std::string temp;

	for (int C=0; C<input.getSize()-offset; C++) {

		const char c=input.get(offset+C);

		if (!isalnum(c) || c=='>') {

			if (C>0) {

				setName(temp);
				return C;

			} else {

				throw Exception("XmlTag::parseTagName; blabla");
			}
		} else {

			temp+=c;
		}
	}

	throw Exception("XmlTag::parseTagName; The tag was not closed");
}

// ---------------------------------------------------------------------------

const int Helper::XmlTag::parseAttribute(const Blob &input, const int offset) {

	std::string name, value;

	int C=offset;

	while (true) {

		const char c=input.get(C);

		if (!isgraph(c) || c=='=') {
			break;
		} else {
			name+=c;
		}

		C++;
	}

	C+=parseWhiteSpace(input, C);

	if (input.get(C++)!='=') throw Exception("XmlTag::parseAttribute; '=' expected!");

	C+=parseWhiteSpace(input, C);

	if (input.get(C)=='"') {

		C++;

		while (true) {

			const char c=input.get(C);

			if (c=='"') {
				break;
			} else {
				value+=c;
			}

			C++;
		}

		C++;
		setValue(name, value);

	} else {
		
		while (true) {

			const char c=input.get(C);

			if (!isgraph(c) || c=='>' || c=='/') {
				break;
			} else {
				value+=c;
			}

			C++;
		}

		setValue(name, value);
	}

	return C-offset;
}

// ---------------------------------------------------------------------------

const int Helper::XmlTag::parseWhiteSpace(const Blob &input, const int offset) const {

	int C=0;
	const int size=input.getSize();

	while (true) {

		if (offset+C>=size) throw Exception("XmlTag::parseWhiteSpace; EOF");
		if (!isspace(input.get((C) + offset))) return C;		
		C++;
	}
}

// ---------------------------------------------------------------------------

const int Helper::XmlTag::parse(const Blob &input, const int offset) {

	int currentOffset=parseWhiteSpace(input, offset);
	if (input.get(offset+currentOffset++)!='<') throw Exception("XmlTag::parse; Could not find '<'");
	
	getArg().clear();
	setClosed(false);

	currentOffset+=parseWhiteSpace(input, offset+currentOffset);
	
	// Cover the </TAGNAME> case
	if (input.get(offset+currentOffset)=='/') { 
		setClosed(true);
		currentOffset++;
		currentOffset+=parseWhiteSpace(input, offset+currentOffset);
	}

	// Read the TAGNAME
	currentOffset+=parseTagName(input, offset+currentOffset);

	while (true) {

		currentOffset+=parseWhiteSpace(input, offset+currentOffset);

		if (input.get(offset+currentOffset)=='/') { setClosed(true); currentOffset++; continue; }
		if (input.get(offset+currentOffset)=='>') { return currentOffset+1; }

		// Read an attribute
		currentOffset+=parseAttribute(input, offset+currentOffset);
	}	
}

// ---------------------------------------------------------------------------