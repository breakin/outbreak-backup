#include "filemonitor.h"
#include <string.h>

using namespace Helper;


DebugMonitorFile::DebugMonitorFile() {
	
	strcpy(m_filename,"debug.log");
	m_opened = false;
	m_first = true;
	m_filter = 0xff;
}

DebugMonitorFile::DebugMonitorFile(const char filename[]) {

	strcpy(m_filename,filename);
	m_opened = false;
	m_filter = 0xff;
	m_first = true;
}

DebugMonitorFile::~DebugMonitorFile() {

	if (m_opened) close();
}

void DebugMonitorFile::open() {

	if (m_first) {
		m_handle = fopen (m_filename,"w+");
		m_first = false;
	} else {
	
		m_handle = fopen (m_filename,"a+");
	}
	m_opened = true;
}

void DebugMonitorFile::close() {

	if (m_opened) {
	
		fclose(m_handle);
		m_opened = false;
	}
}

void DebugMonitorFile::onDebugMessage(int msgType, const char message[]) {

	if (msgType & m_filter) {

		open();
		fprintf (m_handle,message);
		close();
	}
}

