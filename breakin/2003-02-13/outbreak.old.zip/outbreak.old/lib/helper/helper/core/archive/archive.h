#ifndef HELPER_ARCHIVE_ARCHIVE_H
#define HELPER_ARCHIVE_ARCHIVE_H

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Breakin
 @ Class		: Archive
 @ Brief		: Baseclass for archies
 @ Todo         : Include encoding/decoding settings for load/save(Image)

================================================================================*/

#include "../typedefs.h"
#include "../blob.h"
#include <string>
#include "../file.h"
#include "../imagetool/imagetool.h"

namespace Helper {

	class Archive {
	private:

		ImageTool imageTool;

	public:

		virtual ~Archive() {
		}

		virtual const bool  isExist(const std::string &filename) const =0;
		virtual const int   getFileCount() const = 0;

		virtual const File &getFile(const std::string &fileName) const = 0;
		virtual const File &getFile(const int fileIndex) const = 0;
		virtual File &getFile(const std::string &fileName) = 0;
		virtual File &getFile(const int fileIndex) = 0;

		virtual const File &operator[] (const std::string& fileName) const { return getFile(fileName); }
		virtual const File &operator[] (const int fileIndex) const { return getFile(fileIndex); }
		virtual File &operator[] (const std::string& fileName) { return getFile(fileName); }
		virtual File &operator[] (const int fileIndex) { return getFile(fileIndex); }

		virtual void save(const std::string &fileName, const Blob &source) = 0;

		void load(BaseImage32 &result, const std::string &fileName) {
			imageTool.load(result, getFile(fileName).get(),fileName);
		}

		void save(const std::string &fileName, const BaseImage32 &source, const AreaInt &sourceArea) {
			Blob result;
			imageTool.save(result, source, sourceArea, fileName);
			save(fileName, result);
		}
		
		void save(const std::string &fileName, const BaseImage32 &source) {
			save(fileName,source,source.getArea());
		}
	};
}

#endif