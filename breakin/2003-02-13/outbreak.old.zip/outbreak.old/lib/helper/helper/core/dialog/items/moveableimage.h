#ifndef HELPER_DIALOG_ITEM_MOVEABLEIMAGE
#define HELPER_DIALOG_ITEM_MOVEABLEIMAGE

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Moveable Image
	@ Brief       : If you need to drag an image somewhere, use this class.
					You can lock any direction if needed.
  =============================================================================
*/

#include "../base/itembase.h"

namespace Helper {

	class MoveableImage : public ItemBase {
	protected:
		// Image data
		bool loaded;
		Image32 image;

		// Locked data
		bool lockedHorisontal;
		bool lockedVertical;
		bool locked;
		PointInt lastMousePosition;

		bool hasMovedBool;
		bool clipToParent;

	public:
		MoveableImage();
		~MoveableImage();

		virtual void setLeft(const uint32 newLeft);

		virtual void setImage(Image32& newImage);

		virtual void setLockedHorisontal(const bool lock);
		virtual void setLockedVertical(const bool lock);
		virtual void setClipToParent(const bool newClipToParent);

		virtual const bool hasMoved();

		virtual const std::string processEvent(const Msg& message, const AreaInt& parentArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
	};
}

#endif
