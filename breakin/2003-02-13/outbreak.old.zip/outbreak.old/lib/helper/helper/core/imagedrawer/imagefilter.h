#ifndef HELPER_IMAGEFILTER
#define HELPER_IMAGEFILTER

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Breakin
 @ Class		: ImageFilter
 @ Brief		: Does some advanced filtering using MMX-instructions.
                  Supports dest and sourceAreas and pitch but no clipping
 
 @ Features
 
  * ColorBalance
  * Invert (255-color)
  * CrossfadeToColor

================================================================================*/
/*

* colorBalance(colorBalance(ARGB))

	dest=source*colorBalance
	
* negateByAmount_ColorBalance(negateAmount(ARGB), colorBalance(ARGB))

	dest=	(source*(255-negateAmount)+(255-source)*negateAmount)*colorBalance
	
* negateByAlpha_ColorBalance(colorBalance(ARGB))
	
	dest=	(source*(255-source.A)+(255-source)*source.A)*colorBalance

* blackAndWhiteByAmount(blackAndWhiteAmount(byte))

	dest=(source*(255-blackAndWhiteAmount)+source.r+source.g+source.b)/3*blackAndWhiteAmount)

?	How to make faster? (/3) He divide by four instead and include alpha =)

* blackAndWhiteByAlpha()

	See above but amount from alpha-channel

* crossfadeByAmount(color(ARGB), crossfadeAmount(ARGB))
* crossfadeByAlpha(color(ARGB))

	Crossfadeamounts in alpha-channel.
	
?	Include colorBalance if it's free

*/

#include "../baseimage32.h"

namespace Helper {

	class ImageFilter {
	private:
	public:

		// Color Balance
		void colorBalance(BaseImage32 &dest, const AreaInt &destArea, const BaseImage32 &source, const AreaInt &sourceArea, const Helper::uint32 colorBalanceAmounts) const;

		// Blurs
		//void blurHorisontal_Wrap(BaseImage32 &dest, const AreaInt &destArea, const BaseImage32 &source, const AreaInt &sourceArea, const Helper::uint32 blurWidth1616) const;
		
		// Invert
		void invert(BaseImage32 &dest, const AreaInt &destArea, const BaseImage32 &source, const AreaInt &sourceArea) const;
		void invert(BaseImage32 &dest, const AreaInt &destArea, const BaseImage32 &source, const AreaInt &sourceArea, const Helper::uint32 negateAmounts, const Helper::uint32 colorBalanceAmounts=0xffffffff) const;
		//void negateByAlpha_colorBalance
	
		// Black'n'white
		//void blackAndWhite
		//void blackAndWhiteByAmounts(
		//void blackAndWhiteByAlpha

		// Crossfade to Color
		void crossfadeToColor(BaseImage32 &dest, const AreaInt &destArea, const BaseImage32 &source, const AreaInt &sourceArea, const Helper::uint32 color, const Helper::uint32 crossfadeAmounts, const Helper::uint32 colorBalanceAmounts=0xffffffff) const;
		//void crossfadeByAlpha
	};
}

#endif