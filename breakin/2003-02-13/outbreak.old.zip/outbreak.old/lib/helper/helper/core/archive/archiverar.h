#ifndef HELPER_ARCHIVE_ARCHIVERAR_H
#define HELPER_ARCHIVE_ARCHIVERAR_H

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Breakin
 @ Class		: ArchiveRar
 @ Brief		: RAR-implementation of Archive. Uses Urarlib.
                  Can't save, only load.

================================================================================*/

#include "archive.h"
#include <map>

namespace Helper {

	class ArchiveRAR : public Archive {
	private:

		// ---------------------------------------
		class FileRAR : public File {
		private:

			ArchiveRAR *mContext;

		public:

			void setContext(ArchiveRAR *context) { mContext=context; }

			virtual Blob get() const;
			virtual void remove();
		};
		
		// ---------------------------------------
		std::string                    mArchiveName;
		std::string                    mArchivePassword;
		std::map<std::string, FileRAR> mFileList;		

		friend FileRAR;

	public:

		ArchiveRAR(const std::string &archiveName, const std::string &archivePassword="");
		virtual ~ArchiveRAR();

		virtual const int   getFileCount() const;

		virtual const File &getFile(const std::string &fileName) const;
		virtual const File &getFile(const int fileIndex) const;
		virtual File &getFile(const std::string &fileName);
		virtual File &getFile(const int fileIndex);

		virtual const bool  isExist(const std::string &fileName) const;

		virtual void save(const std::string &fileName, const Blob &source);
	};
}

#endif
