#ifndef HELPER_DEMO_SCRIPT_SCRIPT_H
#define HELPER_DEMO_SCRIPT_SCRIPT_H

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Script Engine
	@ Brief       : Made for timing demos.

    @ Features : 
	  * Effects
	  * Attributes
	  * Triggers

	@ Todo :
	  * Splines

  =============================================================================
*/

#include <helper/core/clock.h>
#include <helper/core/typedefs.h>
#include <helper/core/xml/xmlparser.h>
#include <helper/core/demo/script/effect.h>
#include <vector>

#include "scriptEffect.h"

namespace Helper {

	class Script {
	private:
		// Update() control variables.
		float64  lastTime;

		void load(const XmlParser& xmlObject);
		float64  scriptEnd;

	public:
		// List of effects.
		std::vector<SEffect*> effectList;

		// Initialize the script object 
		Script();
		Script(const XmlParser& xmlObject);
		~Script();
	
		SEffect& getEffect(const std::string& name);
		const float64 getScriptEnd() const { return scriptEnd; }

		void deleteEffect(const int32 index);
		void addEffect(const std::string name, const int index=0, const float start=0, const float end=10);

		void addCallback(const std::string& effectName, Effect* effect);

		void save(XmlParser& xmlObject);

		const bool update(const float64& timer);
	};

}

#endif

