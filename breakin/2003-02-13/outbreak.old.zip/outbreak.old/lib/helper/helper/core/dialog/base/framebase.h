#ifndef HELPER_DIALOG_BASE_FRAMEBASE
#define HELPER_DIALOG_BASE_FRAMEBASE

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : FrameBase
	@ Brief       : "Item" responsible for holding and drawing other items.
  =============================================================================
*/

#include "itembase.h"
#include <vector>

namespace Helper {

	class FrameBase : public ItemBase {
	protected:
		/**
		 * A list of Item's (buttons, textfield, labels etc) which inherit from ItemBase
		 */
		std::vector<ItemBase*> item;

		bool verticalScrollbar;
		bool horizontalScrollbar;

		// Client area, all subitems are drawn within these borders
		// If client area is the same as area, setArea() will set the
		// clientarea to be the same size and position as the area.
		AreaInt clientArea;

		virtual void load();

		virtual AreaInt localClientToWorld(const AreaInt& parentArea);

	public:
		FrameBase();
		virtual ~FrameBase();

		virtual void setVerticalScrollbar(const bool use=false);
		virtual void setHorizontalScrollbar(const bool use=false);

		virtual void setArea(const std::string _name, const AreaInt& area);
		virtual void setClientArea(const AreaInt& newClientArea);
		virtual void setVisible(const bool option=true);

		virtual const std::string& getDescription(const PointInt& mousePosition, const AreaInt& parentArea);

		virtual void init(ImageDrawer& imageDrawer, Archive& archive, const bool doLoad=true);

		/**
		 * Add an item to the list to be rendered in the client area
		 */
		virtual void add(ItemBase* _item);

		virtual const std::string processEvent(const Msg& message, const AreaInt& parentArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
		virtual void resetChangedArea();
	};
}

#endif
