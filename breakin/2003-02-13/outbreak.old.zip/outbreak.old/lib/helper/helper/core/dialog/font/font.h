#ifndef HELPER_DIALOG_FONT
#define HELPER_DIALOG_FONT

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Font
	@ Brief       : Sets up a font from a font-image and uses the 
					imagedrawer to draw it on another image.

    @ Features : 
		* Width's of chars calculated so 'l' will have less width than 'W'.
  =============================================================================
*/

#include <helper/core/typedefs.h>
#include <string>
#include <helper/core/image32.h>
#include <helper/core/imagedrawer/imagedrawer.h>

namespace Helper {

	class Font {
	private:
		ImageDrawer imageDrawer;

		std::string name;
		bool        inited;
		bool        fixedWidth;
		
		int32       pitch;
		uint32      color;

		Image32     font[256];      // The font
		uint32      fontColor[256]; // So we don't need to clear RGB _every_ time!
		uint32      pitches[256];   // Pixels wide?

		uint32      fontWidth;
		uint32      fontHeight;

	public:
		Font();
		~Font();

		void createFont(BaseImage32& fontImage, const int32 pitch, const std::string fontName="");

		void setColor(const int color);
		void setFixedWidth(const bool use);

		uint32 getWidth() { return fontWidth; }
		uint32 getHeight() { return fontHeight; }

		const int len(const std::string& input);

		void drawLetter(BaseImage32& dest, const int32 x, const int32 y, const uint8 sign, const AreaInt* parentArea=NULL);
		void draw(BaseImage32& dest, const int32 x, const int32 y, const std::string& text, const AreaInt* parentArea=NULL);
	};

}

#endif