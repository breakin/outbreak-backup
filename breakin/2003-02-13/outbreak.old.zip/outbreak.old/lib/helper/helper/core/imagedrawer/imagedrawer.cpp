#include "imagedrawer.h"
#include "..\debug\debug.h"

using namespace Helper;


//=============================================================================================================

void ImageDrawer::copy(BaseImage32 &srcSurface, BaseImage32 &dstSurface)
{
	if ((srcSurface.getWidth() == dstSurface.getWidth()) && (srcSurface.getHeight() == dstSurface.getHeight())) {

		int width   = srcSurface.getWidth();
		int height  = srcSurface.getHeight();
		int spitch  = srcSurface.getPitch();
		int dpitch  = dstSurface.getPitch();

		Drawer_MMX::copy(	(uint8*)srcSurface.get(),
						(uint8*)dstSurface.get(), 
						width, height,
						spitch, dpitch);
	}
}

//=============================================================================================================

void ImageDrawer::clear(BaseImage32 &dstSurface,const AreaInt &dstArea, int clearCaps)
{
	uint8 *pixelOffset;
	
	// calculate offset
	pixelOffset =  (uint8*)dstSurface.get();
	pixelOffset += (dstArea.getLeft() * 4 ) + dstArea.getTop() * dstSurface.getPitch();

	// check if we should keep alpha
	if (clearCaps == CLEAR_ARGB)
	{
		Drawer_MMX::clear_argb(pixelOffset,
							dstArea.getWidth(), dstArea.getHeight(),
							dstSurface.getPitch());
	}	
	else
	{
		Drawer_MMX::clear_rgb (pixelOffset,
							dstArea.getWidth(), dstArea.getHeight(),
							dstSurface.getPitch());
	}
}


//=============================================================================================================

void ImageDrawer::draw(BaseImage32 &srcSurface, const AreaInt &srcArea, BaseImage32 &dstSurface, const AreaInt &dstArea, int blitFlags)
{
	uint8  *src_data, *dst_data;
	int     src_pitch, dst_pitch;
	int     dst_width, dst_height;
	int		src_x = 0, src_y = 0;
	Image32 zoomSurface;
	AreaInt	dstClipArea;

	
	// check if we need to zoom srcSurface
	if ((dstArea.getWidth () != srcArea.getWidth()) || (dstArea.getHeight() != srcArea.getHeight()))
	{
		// create new surface and area - rearanged to new zoomed surface
		if (dstArea.getSize() <= 0) 
			return;

		zoomSurface.resize(dstArea.getWidth(), dstArea.getHeight());
		
		// zoom srcsurface to fit in the dstArea
		if (m_scaleMode == SCALE_BILINEAR) {

			Drawer_MMX::scale_bilinear((uint32*)srcSurface.get() , srcArea, srcSurface.getPitch(),
								 (uint32*)zoomSurface.get(), dstArea, zoomSurface.getPitch());				
		} else {

			Drawer_MMX::scale_linear((uint32*)srcSurface.get() , srcArea, srcSurface.getPitch(),
								 (uint32*)zoomSurface.get(), dstArea, zoomSurface.getPitch());				
		}

		// calc pixel's address and pitch
		src_pitch = zoomSurface.getPitch();
		src_data  = (uint8*)zoomSurface.get();	
	}
	else
	{
		// get address and pitch from original source surface
		src_pitch = srcSurface.getPitch();
		src_data  = (uint8*)srcSurface.get();
		//src_data += (srcArea.getLeft() * 4) + srcArea.getTop() * src_pitch;			
		src_x	  = srcArea.getLeft();
		src_y	  = srcArea.getTop() * src_pitch;
	}

	if ((blitFlags & BLIT_NOCLIP) == 0) {

		// perform clipping
		dstClipArea = dstArea & dstSurface.getArea();
		if (dstArea.getLeft() < 0) src_x += -(dstArea.getLeft()); 
		if (dstArea.getTop()  < 0) src_y += -(dstArea.getTop()); 
	}

	src_data+= src_x * 4 + src_y * src_pitch;

	/* calc first pixels address in dest data.
	   and set pitch and dimensions of dest surface */
	dst_pitch = dstSurface.getPitch();
	dst_width = dstClipArea.getWidth();
	dst_height= dstClipArea.getHeight();
	dst_data  = (uint8*)dstSurface.get();
	dst_data += (dstClipArea.getLeft() * 4) + dstClipArea.getTop() * dst_pitch;

	if ((dst_width <=0) || (dst_height <=0))
		return;
	
	// check bitflags, and route to proper internal blit method
	switch (blitFlags)
	{
		case BLIT_NORMAL:
		Drawer_MMX::copy(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;
		
		case BLIT_SATURATION:
		Drawer_MMX::blit_saturation(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;

		case BLIT_ALPHABLEND:
		if (m_alphaMode == ALPHA_CONSTANT)
			Drawer_MMX::blit_alpha_const(src_data,dst_data, m_alphaChannel, dst_width, dst_height, src_pitch, dst_pitch);
		else
			Drawer_MMX::blit_alpha (src_data,dst_data, dst_width, dst_height, src_pitch, dst_pitch);
			
		break;

		case BLIT_COLORKEY:
		Drawer_MMX::blit_colorkey(src_data,dst_data, 0, dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_SATURATION|BLIT_COLORKEY:
		Drawer_MMX::blit_colorkey_saturation (src_data,dst_data, 0, dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_COLORKEY|BLIT_ALPHABLEND:
		
		if (m_alphaMode == ALPHA_CONSTANT)
			Drawer_MMX::blit_alpha_const_colorkey(src_data ,dst_data, m_alphaChannel,0,dst_width, dst_height, src_pitch, dst_pitch);
		else
			Drawer_MMX::blit_alpha_colorkey(src_data ,dst_data,0,dst_width, dst_height, src_pitch, dst_pitch);
		
		break;

		case BLIT_SATURATION|BLIT_ALPHABLEND:

		if (m_alphaMode == ALPHA_CONSTANT)
			Drawer_MMX::blit_alpha_const_saturation(src_data ,dst_data, m_alphaChannel,dst_width, dst_height, src_pitch, dst_pitch);
		else
			Drawer_MMX::blit_alpha_saturation(src_data ,dst_data,dst_width, dst_height, src_pitch, dst_pitch);
		
		default:
		// TODO : throw exception
		break;
	}
}


//=============================================================================================================
void ImageDrawer::draw(BaseImage32 &srcSurface, const AreaInt &srcArea, BaseImage32 &dstSurface, int x, int y, int blitFlags)
{
	uint8 *src_data,*dst_data;
	int  src_pitch,dst_pitch;
	int  dst_width,dst_height;
	int  src_x, src_y;
	
	/* get address and pitch from source surface
		 and set correct offsets */
	src_pitch = srcSurface.getPitch();
	src_data  = (uint8*)srcSurface.get();
	src_x	  = srcArea.getLeft();
	src_y	  = srcArea.getTop();

	
	/* calc first pixels address in dest data.
	   and set pitch and dimensions of dest surface */
	dst_pitch = dstSurface.getPitch();
	dst_width = srcArea.getWidth();
	dst_height= srcArea.getHeight();
	dst_data  = (uint8*)dstSurface.get();
	
	// test if totally outside dstSurface, conly exclude clip if specified
	if ((blitFlags & BLIT_NOCLIP) == 0) {

		if (((x + dst_width) <= 0) || ((y + dst_height) <= 0) || 
			 (x >= dstSurface.getWidth()) || (y >= dstSurface.getHeight())) 
			 return;

		if (x < 0) {
		
			dst_width  -=  -x;
			src_x += -x;
			x = 0;
		}

		if (y < 0) {
			
			dst_height -=  -y;
			src_y += -y;
			y = 0;
		}

		if ((x + dst_width) > dstSurface.getWidth()) {
			
			dst_width -= ((x + dst_width) - dstSurface.getWidth());
		}

		if ((y + dst_height) > dstSurface.getHeight()) {
			
			dst_height -= ((y + dst_height) - dstSurface.getHeight());
		}
	}

	dst_data += ( x * 4) + y * dst_pitch;
	src_data += (src_x * 4) + src_y * src_pitch;			

	// route to proper internal blit routine...
	switch (blitFlags)
	{
		case BLIT_NORMAL:
		Drawer_MMX::copy(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;
		
		case BLIT_SATURATION:
		Drawer_MMX::blit_saturation(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;

		case BLIT_ALPHABLEND:
		if (m_alphaMode == ALPHA_CONSTANT)
			Drawer_MMX::blit_alpha_const(src_data,dst_data, m_alphaChannel, dst_width, dst_height, src_pitch, dst_pitch);
		else
			Drawer_MMX::blit_alpha (src_data,dst_data, dst_width, dst_height, src_pitch, dst_pitch);
			
		break;

		case BLIT_COLORKEY:
		Drawer_MMX::blit_colorkey(src_data,dst_data, 0, dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_SATURATION|BLIT_COLORKEY:
		Drawer_MMX::blit_colorkey_saturation (src_data,dst_data, 0, dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_COLORKEY|BLIT_ALPHABLEND:
		
		if (m_alphaMode == ALPHA_CONSTANT)
			Drawer_MMX::blit_alpha_const_colorkey(src_data ,dst_data, m_alphaChannel,0,dst_width, dst_height, src_pitch, dst_pitch);
		else
			Drawer_MMX::blit_alpha_colorkey(src_data ,dst_data,0,dst_width, dst_height, src_pitch, dst_pitch);
		
		break;

		case BLIT_SATURATION|BLIT_ALPHABLEND:

		if (m_alphaMode == ALPHA_CONSTANT)
			Drawer_MMX::blit_alpha_const_saturation(src_data ,dst_data, m_alphaChannel,dst_width, dst_height, src_pitch, dst_pitch);
		else
			Drawer_MMX::blit_alpha_saturation(src_data ,dst_data,dst_width, dst_height, src_pitch, dst_pitch);
		
		default:
		// TODO : throw exception
		break;
	}

}

//=============================================================================================================

void ImageDrawer::draw(BaseImage32 &srcSurface, const AreaInt &srcArea, BaseImage32 &dstSurface, const AreaInt &clipArea, int x, int y, int blitFlags)
{
	uint8 *src_data,*dst_data;
	int  src_pitch,dst_pitch;
	int  dst_width,dst_height;
	
	dst_width  = srcArea.width;
	dst_height = srcArea.height;
	int srcOffsX = 0;
	int srcOffsY = 0;

	// clipArea is totally empty - no need to draw
	if (clipArea.isEmpty() || srcArea.isEmpty())
		return;

	// check if completely outside cliparea
	if ((x + srcArea.width <= clipArea.left) || (y + srcArea.height <= clipArea.top) ||
		(x >= clipArea.getRight()) || (y >= clipArea.getBottom()))
		return;
		
	// adjust src offsets according to top/left of clipArea
	srcOffsX = (clipArea.left - x <= 0) ? 0 : (clipArea.left - x);
	x+=srcOffsX;

	srcOffsY = (clipArea.top - y <= 0) ? 0 : (clipArea.top - y);
	y+=srcOffsY;

	// adjust top/left dimensions
	dst_width  -= srcOffsX;
	dst_height -= srcOffsY;
	
	if (x + dst_width > clipArea.left + clipArea.width)
		dst_width -= ((x + dst_width) - (clipArea.left + clipArea.width));

	if (y + dst_height > clipArea.top + clipArea.height)
		dst_height -= ((y + dst_height) - (clipArea.top + clipArea.height));
	
	
	// adjust offsets
	src_pitch= srcSurface.getPitch();
	dst_pitch= dstSurface.getPitch();
	src_data = (uint8*)srcSurface.get();
	dst_data = (uint8*)dstSurface.get();
	dst_data+= y * dst_pitch + x * 4;
	src_data+= (srcArea.top + srcOffsY) * src_pitch + (srcArea.left + srcOffsX) * 4;
	
	// route to proper internal blit routine...
	switch (blitFlags)
	{
		case BLIT_NORMAL:
		Drawer_MMX::copy(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;
		
		case BLIT_SATURATION:
		Drawer_MMX::blit_saturation(src_data,dst_data,dst_width,dst_height,src_pitch,dst_pitch);
		break;

		case BLIT_ALPHABLEND:
		if (m_alphaMode == ALPHA_CONSTANT)
			Drawer_MMX::blit_alpha_const(src_data,dst_data, m_alphaChannel, dst_width, dst_height, src_pitch, dst_pitch);
		else
			Drawer_MMX::blit_alpha (src_data,dst_data, dst_width, dst_height, src_pitch, dst_pitch);
			
		break;

		case BLIT_COLORKEY:
		Drawer_MMX::blit_colorkey(src_data,dst_data, 0, dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_SATURATION|BLIT_COLORKEY:
		Drawer_MMX::blit_colorkey_saturation (src_data,dst_data, 0, dst_width, dst_height, src_pitch, dst_pitch);
		break;

		case BLIT_COLORKEY|BLIT_ALPHABLEND:
		
		if (m_alphaMode == ALPHA_CONSTANT)
			Drawer_MMX::blit_alpha_const_colorkey(src_data ,dst_data, m_alphaChannel,0,dst_width, dst_height, src_pitch, dst_pitch);
		else
			Drawer_MMX::blit_alpha_colorkey(src_data ,dst_data,0,dst_width, dst_height, src_pitch, dst_pitch);
		
		break;

		case BLIT_SATURATION|BLIT_ALPHABLEND:

		if (m_alphaMode == ALPHA_CONSTANT)
			Drawer_MMX::blit_alpha_const_saturation(src_data ,dst_data, m_alphaChannel,dst_width, dst_height, src_pitch, dst_pitch);
		else
			Drawer_MMX::blit_alpha_saturation(src_data ,dst_data,dst_width, dst_height, src_pitch, dst_pitch);
		
		default:
		// TODO : throw exception
		break;
	}

}

//=============================================================================================================
void ImageDrawer::setAlphaMode(int alphaMode, int alphaChannel)
{
	m_alphaMode = alphaMode;
	m_alphaChannel = alphaChannel;
}

//=============================================================================================================
void ImageDrawer::setAlphaChannel(uint8 alphaVal)
{
	m_alphaChannel = alphaVal;
}

//=============================================================================================================
void ImageDrawer::setScaleMode( int scaleMode)
{
	// sanity check
	if ((scaleMode == SCALE_BILINEAR) || (scaleMode == SCALE_LINEAR))
	m_scaleMode = scaleMode;
}