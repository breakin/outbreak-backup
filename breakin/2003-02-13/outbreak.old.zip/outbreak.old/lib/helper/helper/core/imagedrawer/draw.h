#ifndef __STANDARD_BLITTER__
#define __STANDARD_BLITTER__

//============================================================================================
// Includes
//============================================================================================
#include "..\image32.h"
#include "..\area.h"

 
//============================================================================================
// Namespace Aurora
//============================================================================================
namespace Helper {

//============================================================================================
// Class or method implementations
//============================================================================================
class Drawer
{		
	public:

		Drawer();
		
		/**
		 * scale routines, linear and bilinear
		 */
		virtual void scale_linear	(uint32 *src, const AreaInt &srcArea, int srcPitch,
									 uint32 *dst, const AreaInt &dstArea, int dstPitch);

		virtual void scale_bilinear	(uint32 *src ,const AreaInt &srcArea, int srcPitch, 
									uint32 *dst, const AreaInt &dstArea, int dstPitch);			
	//	virtual void scale_bilinear_fixed(uint32 *src ,const AreaInt &srcArea, int srcPitch, 
	//								 uint32 *dst, const AreaInt &dstArea, int dstPitch);			

		/**
		 * clear methods
		 * clear_argb - clear whole surface data, including alphachannel
		 * clear_rgb  - clear rgb channels but keep alpga channel as is.
		 */
		virtual void clear_rgb	(uint8 *dst, int width, int height, int dstPitch);
		virtual void clear_argb	(uint8 *dst, int width, int height, int dstPitch);

		
		/**
		 * Copy pixels from two addresses
		 */
		virtual void copy (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);

		
		/**
		 * blit routines, apply effects when tranfering pixels from src
		 * pixels to dstpixels.
		 */
		virtual void blit (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_colorkey (uint8 *src, uint8 *dst, uint32 colorkey, int width, int height, int srcPitch, int dstPitch);
		
		
		virtual void blit_saturation (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_colorkey_saturation (uint8 *src, uint8 *dst, int colorkey, int width, int height, int srcPitch, int dstPitch);

		
		virtual void blit_alpha	(uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_alpha_colorkey (uint8 *src, uint8 *dst, uint32 colorkey, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_alpha_saturation (uint8 *src, uint8 *dst, int width, int height, int srcPitch, int dstPitch);

		virtual void blit_alpha_const (uint8 *src, uint8 *dst, int alpha, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_alpha_const_colorkey (uint8 *src, uint8 *dst, int alpha, uint32 colokey, int width, int height, int srcPitch, int dstPitch);
		virtual void blit_alpha_const_saturation (uint8 *src, uint8 *dst, int alpha, int width, int height, int srcPitch, int dstPitch);
	
	
	protected:

		static int m_initialized;
};


/*
uint32 calc_color_bilinear(uint32 *data, int32 xpos, int32 ypos, int width){

	int32 r,g,b,a;
	int32 r2,g2,b2,a2;
	int32 intPart;
	int32 fraction;

	// add interpolated attributes
	intPart		= xpos & 0xffff0000;
	fraction	= xpos - intPart;
	
	// extract color attributes, from the current pixel and one to the left 
	a  = (data[0]>>24)& 0xff;
	r  = (data[0]>>16)& 0xff;
	g  = (data[0]>>8) & 0xff;
	b  =  data[0]     & 0xff;

	a2 = (data[1]>>24)& 0xff;
	r2 = (data[1]>>16)& 0xff;
	g2 = (data[1]>>8) & 0xff;
	b2 =  data[1]     & 0xff;

	// add interpolated attributes
	a = ((((0x10000 - fraction) * a) + fraction * a2) >> 16) & 0xff;
	r = ((((0x10000 - fraction) * r) + fraction * r2) >> 16) & 0xff;
	g = ((((0x10000 - fraction) * g) + fraction * g2) >> 16) & 0xff;
	b = ((((0x10000 - fraction) * b) + fraction * b2) >> 16) & 0xff;
	
	// calculate vertical interpolation
	intPart		= ypos & 0xffff0000;
	fraction	= ypos - intPart;
	
	// extract lower pixel's attributes
	a2 = (data[width]>>24)& 0xff;
	r2 = (data[width]>>16)& 0xff;
	g2 = (data[width]>>8) & 0xff;
	b2 =  data[width]     & 0xff;
	
	// add x and y interpolated attributes
	a = ((((0x10000 - fraction) * a) + fraction * a2) >> 16) & 0xff;	
	r = ((((0x10000 - fraction) * r) + fraction * r2) >> 16) & 0xff;
	g = ((((0x10000 - fraction) * g) + fraction * g2) >> 16) & 0xff;
	b = ((((0x10000 - fraction) * b) + fraction * b2) >> 16) & 0xff;

	// return color
	return ((a<<24)|(r<<16)|(g<<8)|b);
}*/


}// end namespace

#endif