//================================================================================================
// includes
//================================================================================================
#include "message.h"

//================================================================================================
// use namespace Aurora
//================================================================================================
using namespace Helper;

//================================================================================================
// method implementation
//================================================================================================
MsgQueue::MsgQueue()
{
  /**
   * Create a Mutex and an event,
   * The Event should be 
   */
  #ifdef WIN32
  hMutex = CreateMutex(NULL,FALSE,NULL);
  hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
  #endif
}

//================================================================================================
MsgQueue::~MsgQueue()
{
  /**
   * Close Win32 Kernel objects
   */
  #ifdef WIN32
	CloseHandle(hMutex);
	CloseHandle(hEvent);
  #endif
}

//================================================================================================
void MsgQueue::addMessage(uint32 message, uint32 param, uint32 extra,int mouse_x, int mouse_y)
{
  /**
   * Wait infinite for hMutex beeing signalled
   */
  #ifdef WIN32
	WaitForSingleObject(hMutex,INFINITE);
  #endif
  /**
   * Setup a message
   */
	Helper::Msg msg;
	msg.message = message;
	msg.extra = extra;
	msg.mousePosition.set(mouse_x,mouse_y);
	msg.param = param;

  /**
   * and push on queue
   */
 	msgQueue.push(msg);
	
  /**
   * Release the mutex, we're done with it, so
   * set it to signaled
   */
  #ifdef WIN32
  ReleaseMutex(hMutex);
  PulseEvent(hEvent);
  #endif
}

//================================================================================================
bool MsgQueue::getMessage(Helper::Msg &msg, bool infiniteWait)
{
  /**
   * Wait for 0 or INFINITE milliseconds for mutex to be signalled
   */
  #ifdef WIN32
  if (WaitForSingleObject(hMutex,((infiniteWait) ? INFINITE:0)) == WAIT_TIMEOUT) return false;
  #endif

  if (!msgQueue.empty())
	{
		msg = msgQueue.front();
		msgQueue.pop();
    #ifdef WIN32
    ReleaseMutex(hMutex);
    #endif
    return true;
	}
  
  #ifdef WIN32
	ReleaseMutex(hMutex);
  #endif
  
  return false;
}

//================================================================================================
void MsgQueue::waitMessage(Helper::Msg &msg)
{
   /**
    * if queue is empty, block thread and wait for 
    * new message-event and then retrieve it.
    */
   if (msgQueue.empty())
   {
     #ifdef WIN32
     WaitForSingleObject(hEvent,INFINITE);
     #endif
     getMessage(msg,true);

   }else
   {
     getMessage(msg,true);
   }
}

//================================================================================================
bool MsgQueue::isEmpty() const
{
	return msgQueue.empty();
}

//================================================================================================
//================================================================================================
//================================================================================================
//================================================================================================



