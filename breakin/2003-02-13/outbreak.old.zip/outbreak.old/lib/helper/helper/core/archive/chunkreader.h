#ifndef HELPER_CHUNKREADER
#define HELPER_CHUNKREADER

#include "../typedefs.h"
#include "../blob.h"
#include "../exception.h"
#include <stack>
#include "../debug/assert.h"
#include "../debug/debug.h"

namespace Helper {

	template<typename IDTYPE, typename SIZETYPE>class ChunkReader {

		private:

			Blob *m_blob;
			
			struct ChunkStructure {
				
				int			startingOffset;

				IDTYPE		id;
				SIZETYPE	size;
			};

			std::stack<ChunkStructure> m_chunk_stack;

		public:

			ChunkReader(Blob *blob) : m_blob(blob) {
				DEBUG_ASSERT(m_blob!=0);
			}

			~ChunkReader() { m_blob=0; }

			// Pretend current position is at the start of a chunkHeader and opens it
			// Returns 0 if parent chunk is shorter than (IDTYPE+SIZETYPE)
			// Otherwise a new node will be created and must be closed by closeChunk
			const IDTYPE openChunk() {

				const int startingOffset=m_blob->ftell();

				// Check so that is at least room for one chunk header in the file
				if (m_chunk_stack.empty()) {

					if ((startingOffset-m_blob->getSize()) < (sizeof(SIZETYPE)+sizeof(IDTYPE))) return 0;

				} else {
				
					const ChunkStructure &top=m_chunk_stack.top();
					const int currentLength=startingOffset-top.startingOffset;
					
					if ((top.size-currentLength) < (sizeof(SIZETYPE)+sizeof(IDTYPE))) return 0;
				}

				// Read and push new chunk
				IDTYPE		ID;
				SIZETYPE	SIZE;
				m_blob->fread(&ID,   sizeof(IDTYPE));
				m_blob->fread(&SIZE, sizeof(SIZETYPE));

				const ChunkStructure newChunk={startingOffset, ID, SIZE};
				m_chunk_stack.push(newChunk);

				return ID;
			}

			// File pointer will be AFTER chunk after closing (not at the place
			// it was when openChunk was called)
			void closeChunk() {
				DEBUG_ASSERT(m_chunk_stack.empty()==false);

				const ChunkStructure &top=m_chunk_stack.top();

				// Place fileOffset after the current chunk
				m_blob->fseek(top.startingOffset+top.size, SEEK_SET);

				// Pop the chunk from the stack
				m_chunk_stack.pop();
			}

			void fread(void *dest, const int bytes) {
				DEBUG_ASSERT(dest!=0 && bytes>0);

				m_blob->fread(dest,bytes);
			}
	};
}

#endif