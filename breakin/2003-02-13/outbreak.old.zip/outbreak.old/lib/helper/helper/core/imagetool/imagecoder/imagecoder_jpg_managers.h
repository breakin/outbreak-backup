static const int DEST_BUFFER_SIZE=16000;

// ---------------------------------------------------------------------------

extern "C" {
	
	#include "jpeglib/jpeglib.h"

	// -[ERROR-HANDLER]-------------------------------------------------------

	// Override standard error-handlers
	// Call output_message
	METHODDEF(void) ImageCoder_JPG_error_exit (j_common_ptr cinfo) {
		(*cinfo->err->output_message) (cinfo);
	}

	// -----------------------------------------------------------------------

	// Destroy the cinfo-object and throw an exception
	METHODDEF(void) ImageCoder_JPG_output_message (j_common_ptr cinfo) {
		char buffer[JMSG_LENGTH_MAX];

		(*cinfo->err->format_message) (cinfo, buffer);

		jpeg_destroy(cinfo);
		std::string message("ImageCoder_JPG::JPEGLIB-INTERNAL; ");
		message+=buffer;

		throw Helper::Exception(message.c_str());
	}

	// -[DEST-MANAGER]--------------------------------------------------------

	METHODDEF(void)    ImageCoder_JPG_init_destination (j_compress_ptr cinfo);
	METHODDEF(boolean) ImageCoder_JPG_empty_output_buffer (j_compress_ptr cinfo);
	METHODDEF(void)	   ImageCoder_JPG_term_destination (j_compress_ptr cinfo);
	
	struct MyDestMgr : public jpeg_destination_mgr {

		Helper::uint8*        temp;
		Helper::Blob&         blob;
		jpeg_error_mgr        jerr;
		jpeg_compress_struct& cinfo;

		MyDestMgr(Helper::Blob &destination, jpeg_compress_struct &initCinfo) : blob(destination), cinfo(initCinfo) {
			temp=new Helper::uint8[DEST_BUFFER_SIZE];
	
			init_destination=ImageCoder_JPG_init_destination;
			empty_output_buffer=ImageCoder_JPG_empty_output_buffer;
			term_destination=ImageCoder_JPG_term_destination;

  			cinfo.err=jpeg_std_error(&jerr);
			cinfo.err->error_exit=ImageCoder_JPG_error_exit;
			cinfo.err->output_message=ImageCoder_JPG_output_message;

			// Create the compression object
			jpeg_create_compress(&cinfo);
			cinfo.dest=this;
		}

		~MyDestMgr() {
			jpeg_destroy_compress(&cinfo);
			delete [] temp;
		}	  
	};

	// -----------------------------------------------------------------------
	
	METHODDEF(void)    ImageCoder_JPG_init_destination (j_compress_ptr cinfo) {
		MyDestMgr* m=reinterpret_cast<MyDestMgr*>(cinfo->dest);

		m->next_output_byte = m->temp;
		m->free_in_buffer   = DEST_BUFFER_SIZE;
		m->blob.clear();
	}

	// -----------------------------------------------------------------------

	METHODDEF(boolean) ImageCoder_JPG_empty_output_buffer (j_compress_ptr cinfo) {
		MyDestMgr* m=reinterpret_cast<MyDestMgr*>(cinfo->dest);

		// Add data to our result-buffer
		m->blob.fwrite(m->temp, DEST_BUFFER_SIZE);

		// Reset pointer and free bytes in buffer counters
		m->next_output_byte=m->temp;
		m->free_in_buffer=DEST_BUFFER_SIZE;

		return TRUE;
	}

	// -----------------------------------------------------------------------

	METHODDEF(void)	   ImageCoder_JPG_term_destination (j_compress_ptr cinfo) {
		MyDestMgr* m=reinterpret_cast<MyDestMgr*>(cinfo->dest);

		m->blob.fwrite(m->temp, DEST_BUFFER_SIZE-m->free_in_buffer);
	}

	// -[SOURCE MANAGER]------------------------------------------------------

	METHODDEF(void)	   ImageCoder_JPG_init_source (j_decompress_ptr cinfo);
	METHODDEF(boolean) ImageCoder_JPG_fill_input_buffer (j_decompress_ptr cinfo);
	METHODDEF(void)	   ImageCoder_JPG_skip_input_data (j_decompress_ptr cinfo, long num_bytes);
	METHODDEF(void)	   ImageCoder_JPG_term_source (j_decompress_ptr cinfo);
	
	struct MySourceMgr : public jpeg_source_mgr {
		const Helper::Blob&     blob;
		jpeg_error_mgr          jerr;
		jpeg_decompress_struct& cinfo;

		MySourceMgr(const Helper::Blob &sourceBlob, jpeg_decompress_struct &initCinfo) : blob(sourceBlob), cinfo(initCinfo) {

			next_input_byte=blob.getReadOnly();
			bytes_in_buffer=blob.getSize();

			init_source=ImageCoder_JPG_init_source;
			fill_input_buffer=ImageCoder_JPG_fill_input_buffer;
			skip_input_data=ImageCoder_JPG_skip_input_data;
			resync_to_restart=jpeg_resync_to_restart;
			term_source=ImageCoder_JPG_term_source;

  			cinfo.err=jpeg_std_error(&jerr);
			cinfo.err->error_exit=ImageCoder_JPG_error_exit;
			cinfo.err->output_message=ImageCoder_JPG_output_message;

			// Create the compression object
			jpeg_create_decompress(&cinfo);
			cinfo.src=this;
		}

		~MySourceMgr() {
			jpeg_destroy_decompress(&cinfo);
		}
	};
	
	// -----------------------------------------------------------------------

	METHODDEF(void)	   ImageCoder_JPG_init_source (j_decompress_ptr cinfo) {}
	METHODDEF(void)	   ImageCoder_JPG_term_source (j_decompress_ptr cinfo) {}

	METHODDEF(boolean) ImageCoder_JPG_fill_input_buffer (j_decompress_ptr cinfo) {
		return TRUE;
	}

	METHODDEF(void)	   ImageCoder_JPG_skip_input_data (j_decompress_ptr cinfo, long num_bytes) {
		MySourceMgr* m=reinterpret_cast<MySourceMgr*>(cinfo->src);
		m->next_input_byte+=num_bytes;
	}
}

// ---------------------------------------------------------------------------