#include "xmlparser.h"
#include "../exception.h"

// Ideas: Might implement an operator[] for Iterator[Const]
// Might rename getRoot to something good <g>

// Fix operator-- for Iterator[Const]

//--------------------------------------------------------------------------//

Helper::XmlParser::XmlParser() {
}

Helper::XmlParser::~XmlParser() {
}

Helper::XmlParser::Iterator Helper::XmlParser::createIterator(const std::string &searchCriteria) {
	return root.createIterator(searchCriteria);
}

Helper::XmlParser::IteratorConst Helper::XmlParser::createIterator(const std::string &searchCriteria) const {
	return root.createIterator(searchCriteria);
}

void Helper::XmlParser::clear() {
	root.clear();
}

// ---------------------------------------------------------------------------

void Helper::XmlParser::parse(const Blob &input) {
	
	if (!root.getTag().getName().empty()) throw Exception("XmlParser::parseXml; Parser has already parsed a xml-file, use clear() first!");

	int parsed=0;

	try {

		XmlTag startTag;

		const int parseResult=startTag.parse(input, parsed);
		
		if (parseResult==0) {
			throw Exception("XmlParser::parseXml; Could not read first tag from the blob!");
		}

		if (startTag.getClosed()) throw Exception("XmlParser::parseXml; Root tag is closed!");

		Iterator i=createIterator();
		root.setTag(startTag);

		parseRecurse(input, parseResult, i);
	}

	catch(...) {
		throw Exception("Helper::XmlParser::parseXml; Error when parsing xml-file!");
	}
}

// ---------------------------------------------------------------------------

const int Helper::XmlParser::parseRecurse(const Blob &input, const int inputOffset, Iterator &parent) {

	XmlTag t;

	int parseResult=0;

	while (true) {

		parseResult+=t.parse(input, inputOffset+parseResult);

		// Jump out a branch if found end of current depth block
		if (t.getClosed() && t.getName()==parent.getRoot().getName()) {
			return parseResult;
		}

		Iterator i2=parent.addChild(t);

		if (!t.getClosed()) parseResult+=parseRecurse(input, inputOffset+parseResult, i2);
	}
}

// ---------------------------------------------------------------------------

void Helper::XmlParser::write(Blob &result, const std::string &intend) const {
	createIterator().getRoot().write(result);
	writeRecurse(result, createIterator(), intend, 1);
}

// ---------------------------------------------------------------------------

void Helper::XmlParser::writeRecurse(Blob &result, IteratorConst &parent, const std::string &intend, const int depth) const {

	while (++parent) {
		
		result.fwrite(intend.c_str(), intend.length(), depth);
		parent->write(result);

		if (!parent->getClosed()) writeRecurse(result, parent.createIterator(), intend, depth+1);
	}

	if (depth-1>0) result.fwrite(intend.c_str(), intend.length(), depth-1);
	result.fprintf("</%s>\n", parent.getRoot().getName().c_str());
}

// ---------------------------------------------------------------------------

Helper::XmlParser::Node::Node() {
}

Helper::XmlParser::Node::Node(const XmlTag &initTag) : tag(initTag) {
}

Helper::XmlParser::Node::~Node() {
	clear();
}

void Helper::XmlParser::Node::setTag(const XmlTag &newTag) {
	tag=newTag;
}

void Helper::XmlParser::Node::clear() {
	setTag(XmlTag());
	
	for (int C=0; C<children.size(); C++) {
		delete children[C];
	}

	children.clear();
}

Helper::XmlParser::Iterator Helper::XmlParser::Node::createIterator(const std::string &searchCriteria) {
	return Iterator(this, searchCriteria);
}

Helper::XmlParser::IteratorConst Helper::XmlParser::Node::createIterator(const std::string &searchCriteria) const {
	return IteratorConst(this, searchCriteria);
}

const Helper::XmlTag& Helper::XmlParser::Node::getTag() const {
	return tag;
}

Helper::XmlTag& Helper::XmlParser::Node::getTag() {
	return tag;
}

const int Helper::XmlParser::Node::getChildrens() const {
	return children.size();
}

const Helper::XmlParser::Node& Helper::XmlParser::Node::getChildren(const int index) const {
	return *children[index];
}

Helper::XmlParser::Node& Helper::XmlParser::Node::getChildren(const int index) {
	return *children[index];
}

Helper::XmlParser::Iterator Helper::XmlParser::Node::addChild(const int index, const XmlTag &childTag) {
	// Force parent tag to be opened (can't have children otherwise, can em?)
	tag.setClosed(false);

	if (index==children.size()) {
		children.push_back(new Node(childTag));
		return children.back()->createIterator();
	} else {

		// This might not be fully portable (using &element as a iterator), fix! (todo)
		children.insert(&children[index], new Node(childTag));
		return children[index]->createIterator();
	}
}

//--------------------------------------------------------------------------//

Helper::XmlParser::Iterator::Iterator(Node *newContext, const std::string &newSearchCriteria) :	
		context(newContext), 
		searchCriteria(newSearchCriteria),
		atBegin(true),
		atEnd(false),
		currentChild(-1) {
}

Helper::XmlParser::Iterator::~Iterator() {
}

const bool Helper::XmlParser::Iterator::isAtBegin() const {
	return atBegin;
}

const bool Helper::XmlParser::Iterator::isAtEnd() const {
	return atEnd;
}

Helper::XmlTag* Helper::XmlParser::Iterator::operator->() {
	if (atBegin) throw Exception("XmlParser::Iterator::operator->; Can't access before first element, try operator++ first!");
	if (atEnd) throw Exception("XmlParser::Iterator::operator->; Can't access after last element, no Tags matching searchCriteria?");
	return &context->getChildren(currentChild).getTag();
}

const Helper::XmlTag* Helper::XmlParser::Iterator::operator->() const {
	if (atBegin) throw Exception("XmlParser::Iterator::operator->; Can't access before first element!");
	if (atEnd) throw Exception("XmlParser::Iterator::operator->; Can't access after last element!");
	return &context->getChildren(currentChild).getTag();
}

const bool Helper::XmlParser::Iterator::operator++() {
	if (atEnd) throw Exception("XmlParser::Iterator::operator++; Called after last tag!");

	atBegin=false;

	if (currentChild+1>=context->getChildrens()) {
		currentChild=context->getChildrens();
		atEnd=true;
		return false;
	}

	if (searchCriteria.empty()) { 
		currentChild++;
		return true;
	}

	for (int C=currentChild+1; C<context->getChildrens(); C++) {
		if (context->getChildren(C).getTag().getName()==searchCriteria) {
			currentChild=C;
			return true;
		}
	}

	atEnd=true;
	return false;
}

const Helper::XmlTag& Helper::XmlParser::Iterator::getRoot() const {
	return context->getTag();
}

Helper::XmlTag& Helper::XmlParser::Iterator::getRoot() {
	return context->getTag();
}

Helper::XmlParser::Iterator Helper::XmlParser::Iterator::createIterator(const std::string &searchCriteria) const {
	return context->getChildren(currentChild).createIterator(searchCriteria);
}

Helper::XmlParser::Iterator Helper::XmlParser::Iterator::addChild(const XmlTag &childTag) {
	atEnd=false;
	atBegin=false;
	currentChild++;
	return context->addChild(currentChild, childTag);
}

void Helper::XmlParser::Iterator::setRoot(const XmlTag &t) {
	context->getTag()=t;
}

//--------------------------------------------------------------------------//

Helper::XmlParser::IteratorConst::IteratorConst(const Node * const newContext, const std::string &newSearchCriteria) :	
		context(newContext), 
		searchCriteria(newSearchCriteria),
		atBegin(true),
		atEnd(false),
		currentChild(-1) {
}

Helper::XmlParser::IteratorConst::IteratorConst(const Iterator &i) {
	*this=i;
}

Helper::XmlParser::IteratorConst::~IteratorConst() {
}

void Helper::XmlParser::IteratorConst::operator=(const Iterator &i) {
	atBegin=i.isAtBegin();
	atEnd=i.isAtEnd();
	context=i.getContext();
	searchCriteria=i.getSearchCriteria();
	currentChild=i.getCurrentChild();
}

const bool Helper::XmlParser::IteratorConst::isAtBegin() const {
	return atBegin;
}

const bool Helper::XmlParser::IteratorConst::isAtEnd() const {
	return atEnd;
}

const Helper::XmlTag* Helper::XmlParser::IteratorConst::operator->() const {
	if (atBegin) throw Exception("XmlParser::IteratorConst::operator->; Can't access before first element!");
	if (atEnd) throw Exception("XmlParser::IteratorConst::operator->; Can't access after last element!");
	return &context->getChildren(currentChild).getTag();
}

const bool Helper::XmlParser::IteratorConst::operator++() {
	if (atEnd) throw Exception("XmlParser::IteratorConst::operator++; Called after last tag!");

	atBegin=false;

	if (currentChild+1>=context->getChildrens()) {
		currentChild=context->getChildrens();
		atEnd=true;
		return false;
	}

	if (searchCriteria.empty()) { 
		currentChild++;
		return true;
	}

	for (int C=currentChild+1; C<context->getChildrens(); C++) {
		if (context->getChildren(C).getTag().getName()==searchCriteria) {
			currentChild=C;
			return true;
		}
	}

	atEnd=true;
	return false;
}

const Helper::XmlTag& Helper::XmlParser::IteratorConst::getRoot() const {
	return context->getTag();
}

Helper::XmlParser::IteratorConst Helper::XmlParser::IteratorConst::createIterator(const std::string &searchCriteria) const {
	return context->getChildren(currentChild).createIterator(searchCriteria);
}