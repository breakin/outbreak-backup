#include "music.h"
#include "../exception.h"
#include <fmod/inc/fmod.h>

//----------------------------------------------------------------------------

Helper::Music::Music() {
	if (FSOUND_Init(44100, 1, 0)==false) throw Helper::Exception("Music::Music; Could not intialize fmod");

	mPaused=false;
}

//----------------------------------------------------------------------------

Helper::Music::Music(const std::string &filename) {
	if (FSOUND_Init(44100, 1, 0)==false) throw Helper::Exception("Music::Music(filename); Could not intialize fmod");

	mPaused=false;

	load(filename);
}

//----------------------------------------------------------------------------

Helper::Music::~Music() {
	if (mStream) unload();
	FSOUND_Close();
}

//----------------------------------------------------------------------------

void Helper::Music::load(const std::string &filename) {
	mStream = FSOUND_Stream_OpenFile(filename.c_str(), 0, 0);

	if (!mStream) throw Exception("Could not load the song %s", filename.c_str());
}

//----------------------------------------------------------------------------

void Helper::Music::unload() {
	if (!mStream) throw Helper::Exception("Music::unload; No song loaded");

	if (FSOUND_Stream_Close(mStream)==false) {

		// We set mStream to NULL here so that ~Music don't call us again		
		mStream=NULL;

		throw Helper::Exception("Music::unload; Could not unload song");
	}

	mStream=NULL;
	mPaused=false;
}

//----------------------------------------------------------------------------

float Helper::Music::getVULeft() {
	return FSOUND_GetCurrentVU(0);
	
}

//----------------------------------------------------------------------------

float Helper::Music::getVURight() {
	return FSOUND_GetCurrentVU(0);
}

//----------------------------------------------------------------------------

void Helper::Music::play() {
	if (!mStream) throw Helper::Exception("Music::play; No song loaded");
	
	if (mPaused) {
		mPaused=false;
	}
	FSOUND_Stream_Play(0, mStream);
}

//----------------------------------------------------------------------------

void Helper::Music::pause() {
	if (!mStream) throw Exception("Music::pause; No song loaded");
	if ( mPaused) throw Exception("Music::pause; Already paused");

	FSOUND_Stream_Stop(mStream);
	mPaused=true;
}

//----------------------------------------------------------------------------

void Helper::Music::setTimer(const float32 timer) {
	if (!mStream) throw Exception("Music::setTimer; No song loaded");

	if (!FSOUND_Stream_SetTime(mStream, (int)(timer*1000.0))) {
		throw Helper::Exception("Music::setTimer; Could not set time to %2.2f", timer);
	}
}

//----------------------------------------------------------------------------

const Helper::float32 Helper::Music::getTimer() const {
	if (!mStream) throw Exception("Music::getTimer; No song loaded");

	const int millis = FSOUND_Stream_GetTime(mStream);

	//if (millis==0) throw Helper::Exception("Music::getTimer; Error");

	return (millis/1000.0);
}

//----------------------------------------------------------------------------
