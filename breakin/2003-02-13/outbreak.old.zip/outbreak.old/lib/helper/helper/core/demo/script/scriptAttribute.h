#ifndef HELPER_DEMO_SCRIPT_ATTRIBUTE_H
#define HELPER_DEMO_SCRIPT_ATTRIBUTE_H

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Attribute
	@ Brief       : Attribute script engine part.
  =============================================================================
*/

#include <helper/core/clock.h>
#include <helper/core/typedefs.h>
#include <helper/core/xml/xmlparser.h>
#include <helper/core/demo/script/effect.h>
#include <vector>

namespace Helper {
	class SAttribute {
	public:
		std::string name;
		std::string value;

		void load(const XmlParser::IteratorConst& attribute);
		void save(XmlParser::Iterator& root);
	};
}

#endif