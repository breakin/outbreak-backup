#ifndef HELPER_TYPEDEFS_H
#define HELPER_TYPEDEFS_H

#pragma warning(disable:4786)

#ifndef _DEBUG
	#pragma optimize("p",on)	///< Optimize floating point aritmethics, genereate fpu instruction directly
#endif

namespace Helper {

	typedef char				int8;
	typedef unsigned char		uint8;

	typedef float				float32;
	typedef double				float64;

	typedef short				int16;
	typedef unsigned short		uint16;

	typedef int					int32;
	typedef unsigned int		uint32;

	typedef	__int64				int64;
	typedef unsigned __int64	uint64;

	// Fixed point math
	typedef long	fixed32;
	typedef short	fixed16;
	typedef unsigned long ufixed32;
	typedef unsigned long ufixed16;

	//typedef long long				int64;
	//typedef unsigned long long	uint64;
};

#endif