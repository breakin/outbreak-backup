#ifndef HELPER_XmlParser_H
#define HELPER_XmlParser_H

#include "xmltag.h"
#include <vector>

namespace Helper {

	class XmlParser {
	public:

		class Node;
		class IteratorConst;

		//---------------------------------------------------------------------//
		
		class Iterator {
		private:

			Node*				context;
			int					currentChild;
			bool				atEnd,
								atBegin;
			const std::string	searchCriteria;

		public:

			Iterator(Node *newContext, const std::string &newSearchCriteria="");
			~Iterator();

			const bool isAtBegin() const;
			const bool isAtEnd() const;			

			const XmlTag& getRoot() const;
			XmlTag& getRoot();
			void setRoot(const XmlTag &);
			
			XmlTag* operator->();
			const XmlTag* operator->() const;
			const bool operator++();

			Iterator addChild(const XmlTag &childTag);
			Iterator createIterator(const std::string &searchCriteria="") const;

			// This are needed for iteratorConst copy-constructor, you don't need them
			Node* getContext() const { return context; }
			std::string getSearchCriteria() const { return searchCriteria; }
			const int getCurrentChild() const { return currentChild; }
		};

		//---------------------------------------------------------------------//

		class IteratorConst {
		private:

			Node const *		context;
			int					currentChild;
			bool				atEnd,
								atBegin;
			std::string			searchCriteria;

		public:

			IteratorConst(const Node const *newContext, const std::string &newSearchCriteria);
			~IteratorConst();
			
			IteratorConst(const Iterator &i);
			void operator=(const Iterator &i);

			const bool isAtBegin() const;
			const bool isAtEnd() const;			
			
			const XmlTag& getRoot() const;
			const XmlTag* operator->() const;
			const XmlTag* operator* () const;
			const bool operator++();

			IteratorConst createIterator(const std::string &searchCriteria="") const;

			const Node * const getContext() const { return context; }
		};

		//---------------------------------------------------------------------//

		class Node {
		private:

			XmlTag tag;
			std::vector<Node*> children;

		public:

			Node();
			Node(const XmlTag &initTag);
			~Node();

			void clear();

			const int getChildrens() const;
			const Node& getChildren(const int index) const;
			Node& getChildren(const int index);

			void setTag(const XmlTag &newTag);
			const XmlTag& getTag() const;
			XmlTag& getTag();

			Iterator addChild(const int index, const XmlTag &childTag);

			Iterator createIterator(const std::string &searchCriteria="");
			IteratorConst createIterator(const std::string &searchCriteria="") const;
		};

		//---------------------------------------------------------------------//

	private:		

		Node root;

		const int parseRecurse(const Blob &input, const int inputOffset, Iterator &parent);
		void writeRecurse(Blob &result, IteratorConst &parent, const std::string &intend, const int depth) const;

	public:

		XmlParser();
		~XmlParser();

		Iterator createIterator(const std::string &searchCriteria="");
		IteratorConst createIterator(const std::string &searchCriteria="") const;

		// Append the database as a xml-file to the blob
		void write(Blob &result, const std::string &intend="\t") const;

		// Parses a xml-file from the current blob-position
		void parse(const Blob &input);

		// Clears the current databse
		void clear();
	};
};

#endif