#ifndef HELPER_DEMO_SCRIPT_EFFECT_H
#define HELPER_DEMO_SCRIPT_EFFECT_H

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Effect
	@ Brief       : Base effect class to be inherited by demo effects.

	@ Todo :
		* Make smarter float-update to splines to make some time if possible.

  =============================================================================
*/

#include <string>
#include <helper/core/typedefs.h>

namespace Helper {

	class Effect {
	public:
		Effect() { }
		virtual ~Effect() { }
		
		// Executes a trigger within the script.
		virtual void executeTrigger(const std::string& name, const std::string& value) { }

		// Updates splines, spans and other helpful tasks.
		virtual void updateSpline(const std::string& name, const float64 value) { }

		// Update effect
		virtual void update(const float64 timer, const float64 delta, const float64 percent)=0;
	};

}

#endif
