#ifndef HELPER_DEMO_SCRIPT_TRIGGER_H
#define HELPER_DEMO_SCRIPT_TRIGGER_H

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Trigger
	@ Brief       : Trigger within the script engine.
  =============================================================================
*/

#include <helper/core/clock.h>
#include <helper/core/typedefs.h>
#include <helper/core/xml/xmlparser.h>
#include <helper/core/demo/script/effect.h>
#include <vector>

namespace Helper {
	class STrigger {
	public:
		int         executedCount;

		std::string name;
		std::string value;

		float64     start;
		int         repeat;
		float64     delay;

		void load(const XmlParser::IteratorConst& trigger);
		void save(XmlParser::Iterator& root);
	};
}

#endif