#ifndef __HELPER_BASEIMAGE32_H__
#define __HELPER_BASEIMAGE32_H__

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Tooon
 @ Class		: BaseImage32
 @ Brief		: Standard interface from which any class tend to represent an image 
				  must be derived from. All other classes within the system(Helper), 
				  uses this interface as a parameter type.

================================================================================*/

#include "typedefs.h"
#include "area.h"

namespace Helper {

	struct BaseImage32 {
	
		//virtual destructor
		virtual ~BaseImage32() {}

		// resize - creates and resize an image
		virtual void resize(const int width, const int height) = 0;

		// destroys and deallocates image mem
		virtual void clear() = 0;
				
		// methods for getting pixel data
		virtual uint32* get() = 0;
		virtual const uint32 * const get() const = 0;

		// methods for getting image properties
		virtual const AreaInt& getArea() const = 0;
		virtual const int  getWidth()  const = 0;
		virtual const int  getHeight() const = 0;
		virtual const int  getPitch()  const = 0;	
	};
}

#endif
