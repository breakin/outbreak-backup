#include "debug.h"

using namespace Helper;


// Set debug state - enabled or disabled
// depending if compiled in DEBUG mode
#ifdef HELPER_DEBUG
#define DEBUG_STATE true
#else
#define DEBUG_STATE false
#endif

//============================================================================
// Debug welcome message - 
// send to all monitors registering with Debug
static char *debugHeader[] = { 

	"\n",
	"   8888    88  88   888888   88888    88888    888888    8888    88  88\n",
	"  88  88   88  88     88     88  88   88  88   88       88  88   88  88\n",
	"  88  88   88  88     88     88  88   88  88   88       88  88   88  88\n",
	"  88  88   88  88     88     88888    88888    8888     888888   88888\n",
	"  88  88   88  88     88     88  88   88  88   88       88  88   88  88\n",
	"  88  88   88  88     88     88  88   88  88   88       88  88   88  88\n",
	"   8888     8888      88     88888    88  88   888888   88  88   88  88\n",
	"             - -( O U T B R E A K   L O G   S Y S T E M )- -\n",
	"\n",
	NULL,
};
 

//============================================================================
// Declare static class members
std::vector<DebugMonitor*> Debug::m_monitors;
DebugMonitorFile Debug::m_defaultMonitor;
bool	Debug::m_enabled	 = DEBUG_STATE;
bool	Debug::m_initialized = false;
int     Debug::m_filter		 = Debug::ALL;
Clock	Debug::m_clock;
char	Debug::m_message[512];

//============================================================================
// Debug methods
//============================================================================

int  Debug::getFilter() {

	return m_defaultMonitor.getFilter();
}

//============================================================================

void Debug::setFilter(int filter) {

	m_defaultMonitor.setFilter(filter);
}

//============================================================================

void Debug::initialize() {
	
	// set default monitor.
	addMonitor(&m_defaultMonitor);
	m_initialized = true;
}


//============================================================================

void Debug::addMonitor(DebugMonitor *monitor) {

	// add monitor to callback list
	m_monitors.push_back(monitor);
	
	// send welcome message to monitor
	int C = 0;
	while (debugHeader[C] != NULL)
	{
		monitor->onDebugMessage(Debug::ALL, debugHeader[C]);
		C++;
	}
}


//============================================================================

void Debug::releaseMonitor(DebugMonitor *monitor) {

	for (int C = 0; C < m_monitors.size(); C++)
		if (m_monitors[C] == monitor) {
			
			// remove entry from list
			m_monitors.erase(m_monitors.begin() + C);
			return;
		}
}

//============================================================================

void Debug::updateMonitors(int msgType, const char message[]) {
	
	for (int C = 0; C < m_monitors.size(); C++) m_monitors[C]->onDebugMessage(msgType, message);
}

//============================================================================

void Debug::enable() {

	m_enabled = true;
}

//=========================================================================

void Debug::disable() {
	
	m_enabled = false;
}
