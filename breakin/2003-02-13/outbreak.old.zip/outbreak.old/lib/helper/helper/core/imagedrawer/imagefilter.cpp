#include "imagefilter.h"
#include "../debug/assert.h"

//****************************************************************************

/*
	All routines sucks bigtime, but they work. Will be optimized as soon as I
	learn how to do it properly!
*/

//****************************************************************************

void Helper::ImageFilter::colorBalance(BaseImage32 &dest, const AreaInt &destArea, const BaseImage32 &source, const AreaInt &sourceArea, const Helper::uint32 colorBalanceAmounts) const {

	DEBUG_ASSERT(destArea.getWidth() ==sourceArea.getWidth())
	DEBUG_ASSERT(destArea.getHeight()==sourceArea.getHeight())

	const int width  = destArea.getWidth();
	const int height = destArea.getHeight();

	uint32* d=reinterpret_cast<uint32*>(reinterpret_cast<uint8*>(dest.get())+destArea.getLeft()*4+destArea.getTop()*dest.getPitch());

	const uint32* s=reinterpret_cast<const uint32*>(reinterpret_cast<const uint8*>(source.get())+sourceArea.getLeft()*4+sourceArea.getTop()*source.getPitch());

	const int sourcePitch=source.getPitch()-width*4;
	const int destPitch  =  dest.getPitch()-width*4;

	_asm {

		mov			edx, height

		mov			edi, d
		mov			esi, s

		pxor		mm5, mm5
		
		// Unpack colorBalanceAmounts into 64-bit reg
		movd		mm1, colorBalanceAmounts
		punpcklbw	mm1, mm5

		YLOOP:
			mov			ecx, width

			XLOOP:

				movd		mm2, [esi]		// mm2 = 0000 0000 aarr ggbb

				punpcklbw	mm2, mm5		// mm2 = 00aa 00rr 00gg 00bb

				pmullw		mm2, mm1
				psrlw		mm2, 8

				packuswb	mm2, mm2

				movd		eax,   mm2
				mov			[edi], eax

				add			edi, 4
				add			esi, 4

				dec			ecx
				jnz			XLOOP

			add esi,	sourcePitch
			add edi,	destPitch

			dec edx
			jnz YLOOP

		emms
	}
}

//****************************************************************************

void Helper::ImageFilter::invert(BaseImage32 &dest, const AreaInt &destArea, const BaseImage32 &source, const AreaInt &sourceArea) const {
	
	const Helper::uint64 ooff=0x00ff00ff00ff00ff;

	DEBUG_ASSERT(destArea.getWidth() ==sourceArea.getWidth())
	DEBUG_ASSERT(destArea.getHeight()==sourceArea.getHeight())

	const int width  = destArea.getWidth();
	const int height = destArea.getHeight();

	uint32* d=reinterpret_cast<uint32*>(reinterpret_cast<uint8*>(dest.get())+destArea.getLeft()*4+destArea.getTop()*dest.getPitch());

	const uint32* s=reinterpret_cast<const uint32*>(reinterpret_cast<const uint8*>(source.get())+sourceArea.getLeft()*4+sourceArea.getTop()*source.getPitch());

	const int sourcePitch=source.getPitch()-width*4;
	const int destPitch  =  dest.getPitch()-width*4;

	_asm {

		mov			edx,	height
		mov			edi,	d
		mov			esi,	s

		pxor		mm5,	mm5				// mm5=0000 0000 0000 0000
		movq		mm6,	ooff			// mm6=00ff 00ff 00ff 00ff

		YLOOP:

			mov	ecx, width

			XLOOP:

				// Fetch texel
				movd		mm0,	[esi]	// mm0 = 0000 0000 aarr ggbb
				punpcklbw	mm0,	mm5		// mm0 = 00aa 00rr 00gg 00bb

				// Move inverted texel into mm2 (inverted value=255-value)
				movq		mm2,	mm6
				psubusb		mm2,	mm0

				// Back result into dword
				packuswb	mm2,	mm2
				movd		eax,	mm2

				// Draw pixel
				mov			[edi],	eax

				add			edi,	4
				add			esi,	4

				dec			ecx
				jnz			XLOOP

			add edi, destPitch
			add esi, sourcePitch
			
			dec	edx
			jnz	YLOOP

		emms
	}
}

//****************************************************************************

void Helper::ImageFilter::invert(BaseImage32 &dest, const AreaInt &destArea, const BaseImage32 &source, const AreaInt &sourceArea, const Helper::uint32 negateAmounts, const Helper::uint32 colorBalanceAmounts) const { 

	const Helper::uint64 ooff=0x00ff00ff00ff00ff;

	DEBUG_ASSERT(destArea.getWidth() ==sourceArea.getWidth())
	DEBUG_ASSERT(destArea.getHeight()==sourceArea.getHeight())

	const int width  = destArea.getWidth();
	const int height = destArea.getHeight();

	uint32* d=reinterpret_cast<uint32*>(reinterpret_cast<uint8*>(dest.get())+destArea.getLeft()*4+destArea.getTop()*dest.getPitch());

	const uint32* s=reinterpret_cast<const uint32*>(reinterpret_cast<const uint8*>(source.get())+sourceArea.getLeft()*4+sourceArea.getTop()*source.getPitch());

	const int sourcePitch=source.getPitch()-width*4;
	const int destPitch  =  dest.getPitch()-width*4;

	_asm {

		mov			edx,	height

		mov			edi,	d
		mov			esi,	s

		pxor		mm5,	mm5				// mm5=0000 0000 0000 0000
		movq		mm6,	ooff			// mm6=00ff 00ff 00ff 00ff

		movd		mm4,	negateAmounts	// mm4=0000 0000 nanr ngnb
		punpcklbw	mm4,	mm5				// mm4=00na 00nr 00ng 00nb
		movq		mm3,	mm6				// mm3=00ff 00ff 00ff 00ff
		psubusb		mm3,	mm4				// mm3=mm3-mm4

		// Apply colorBalance to our negate-steps
		movq		mm7,	colorBalanceAmounts
		punpcklbw	mm7,	mm5
		
		pmullw	mm3, mm7
		pmullw	mm4, mm7
		psrlw	mm3, 8
		psrlw	mm4, 8

		YLOOP:
			mov ecx, width

			XLOOP:

				// Fetch texel
				movd		mm0,	[esi]	// mm0 = 0000 0000 aarr ggbb
				punpcklbw	mm0,	mm5		// mm0 = 00aa 00rr 00gg 00bb

				// Move inverted texel into mm2 (inverted value=255-value)
				movq		mm2,	mm6
				psubusb		mm2,	mm0

				// Multiply color (mm0) by negateInvert (mm3)
				// Multiply color (mm2) by negate (mm4)
				pmullw		mm0,	mm3
				pmullw		mm2,	mm4
				psrlw		mm0,	8			
				psrlw		mm2,	8

				// Saturate results into mm0 (mm0+mm2)
				paddusb		mm0,	mm2			

				// Back result into dword
				packuswb	mm0,	mm0
				movd		eax,	mm0

				// Draw pixel
				mov			[edi],	eax

				add			edi,	4
				add			esi,	4

				dec			ecx
				jnz			XLOOP

			add edi, destPitch
			add esi, sourcePitch

			dec edx
			jnz YLOOP

		emms
	}
}

//****************************************************************************

void Helper::ImageFilter::crossfadeToColor(BaseImage32 &dest, const AreaInt &destArea, const BaseImage32 &source, const AreaInt &sourceArea, const Helper::uint32 color, const Helper::uint32 crossfadeAmounts, const Helper::uint32 colorBalanceAmounts) const {

	const Helper::uint64 ooff=0x00ff00ff00ff00ff;

	DEBUG_ASSERT(destArea.getWidth() ==sourceArea.getWidth())
	DEBUG_ASSERT(destArea.getHeight()==sourceArea.getHeight())

	const int width  = destArea.getWidth();
	const int height = destArea.getHeight();

	uint32* d=reinterpret_cast<uint32*>(reinterpret_cast<uint8*>(dest.get())+destArea.getLeft()*4+destArea.getTop()*dest.getPitch());

	const uint32* s=reinterpret_cast<const uint32*>(reinterpret_cast<const uint8*>(source.get())+sourceArea.getLeft()*4+sourceArea.getTop()*source.getPitch());

	const int sourcePitch=source.getPitch()-width*4;
	const int destPitch  =  dest.getPitch()-width*4;

	_asm {

		mov			edx,	height
		mov			edi,	d
		mov			esi,	s

		pxor		mm5,	mm5				// mm5=0000 0000 0000 0000
		movq		mm6,	ooff			// mm6=00ff 00ff 00ff 00ff

		movd		mm4,	crossfadeAmounts// mm4=0000 0000 nanr ngnb
		punpcklbw	mm4,	mm5				// mm4=00na 00nr 00ng 00nb
		movq		mm3,	mm6				// mm3=00ff 00ff 00ff 00ff
		psubusb		mm3,	mm4				// mm3=mm3-mm4

		// Apply colorBalance to our crossfade-steps (colorBalance after crossfading)
		movq		mm7,	colorBalanceAmounts
		punpcklbw	mm7,	mm5

		pmullw	mm3, mm7
		pmullw	mm4, mm7
		psrlw	mm3, 8
		psrlw	mm4, 8

		// Move destination color into mm2
		movq		mm2,	color
		punpcklbw	mm2,	mm5
		
		YLOOP:

			mov ecx, width

			XLOOP:

				// Fetch texel
				movd		mm0,	[esi]	// mm0 = 0000 0000 aarr ggbb
				punpcklbw	mm0,	mm5		// mm0 = 00aa 00rr 00gg 00bb

				// Multiply color (mm0) by crossfadingAmountsInvert (mm3)
				// Multiply color (mm1) by crossfadingAmounts (mm4)
				movq		mm1,	mm2

				pmullw		mm0,	mm3
				pmullw		mm1,	mm4
				psrlw		mm0,	8			
				psrlw		mm1,	8

				// Saturate results into mm0 (mm0+mm1)
				paddusb		mm0,	mm1

				// Back result into dword
				packuswb	mm0,	mm0
				movd		eax,	mm0

				// Draw pixel
				mov			[edi],	eax

				add			edi,	4
				add			esi,	4

				dec			ecx
				jnz			XLOOP

			add edi, destPitch
			add esi, sourcePitch

			dec edx
			jnz YLOOP

		emms
	}
}

//****************************************************************************

/*void Helper::ImageFilter::blurHorisontal_Wrap(BaseImage32 &dest, const AreaInt &destArea, const BaseImage32 &source, const AreaInt &sourceArea, const Helper::uint32 blurWidth1616) const {

	DEBUG_ASSERT(destArea.getWidth() ==sourceArea.getWidth())
	DEBUG_ASSERT(destArea.getHeight()==sourceArea.getHeight())

	const int width  = destArea.getWidth();
	const int height = destArea.getHeight();

	uint32* d=reinterpret_cast<uint32*>(reinterpret_cast<uint8*>(dest.get())+destArea.getLeft()*4+destArea.getTop()*dest.getPitch());

	const uint32* s=reinterpret_cast<const uint32*>(reinterpret_cast<const uint8*>(source.get())+sourceArea.getLeft()*4+sourceArea.getTop()*source.getPitch());

	const int sourcePitch=source.getPitch()-width*4;
	const int destPitch  =  dest.getPitch()-width*4;

	const int blurWidth=(blurWidth1616 >> 16)-1;

	__asm {

		mov edx, height
		//shr edx, 1

		mov edi, d
		mov esi, s
		
		pxor mm5,mm5
		
		YLOOP:

			// Save start esi
			push		esi
			//push		esi

			// Sum pixels at the end of scanline ************************************
			// We will gather blurWidth pixels (first pixel is at start of scanline)
			mov			ecx,	blurWidth

			// ebx=esi+4*(width-1-(blurWidth)[ecx])
			mov			eax,	width
			dec			eax
			sub			eax,	ecx

			shl			eax,	2
			mov			ebx,	esi
			add			ebx,	eax

			// Save ebx for later
			push		ebx
			
			pxor		mm1,	mm1

			XLOOP_SUM_END:

				movd		mm0,	[ebx]	// mm0 = 0000 0000 aarr ggbb
				punpcklbw	mm0,	mm5		// mm0 = 00aa 00rr 00gg 00bb
				paddw		mm1,	mm0
				add			ebx,	4

				dec			ecx
				jnz			XLOOP_SUM_END

			// Sum pixels at start of the scanline ***********************************
			mov			ecx,	blurWidth
			inc			ecx

			XLOOP_SUM_START:

				movd		mm0,	[esi]	// mm0 = 0000 0000 aarr ggbb
				punpcklbw	mm0,	mm5		// mm0 = 00aa 00rr 00gg 00bb
				paddw		mm1,	mm0
				add			esi,	4

				dec ecx
				jnz XLOOP_SUM_START

			// Do blur. First blurWidth pixels will wrap *****************************

			mov			ecx,	blurWidth

			// Pop ebx (at position blurWidth pixels from width-1)
			pop			ebx
			
			XLOOP_WRAP_START:

				movq		mm0,	mm1
				psrlw		mm0,	6
				packuswb	mm0,	mm0
				movd		eax,	mm0
				mov			[edi], eax
				add			edi,	4

				movd		mm0,	[esi]	// mm0 = 0000 0000 aarr ggbb
				punpcklbw	mm0,	mm5		// mm0 = 00aa 00rr 00gg 00bb
				paddw		mm1,	mm0
				add			esi,	4

				movd		mm0,	[ebx]	// mm0 = 0000 0000 aarr ggbb
				punpcklbw	mm0,	mm5		// mm0 = 00aa 00rr 00gg 00bb
				psubw		mm1,	mm0
				add			ebx,	4

				dec ecx
				jnz XLOOP_WRAP_START

			// Do blur. **************************************************************

			mov			ecx,	width
			sub			ecx,	blurWidth
			sub			ecx,	blurWidth

			// Pop ebx at start of scanline (esi)
			pop			ebx

			XLOOP_MAIN:

				movq		mm0,	mm1
				psrlw		mm0,	5
				packuswb	mm0,	mm0
				movd		eax,	mm0
				mov			[edi], eax
				add			edi,	4

				movd		mm0,	[esi]	// mm0 = 0000 0000 aarr ggbb
				punpcklbw	mm0,	mm5		// mm0 = 00aa 00rr 00gg 00bb
				paddw		mm1,	mm0
				add			esi,	4

				movd		mm0,	[ebx]	// mm0 = 0000 0000 aarr ggbb
				punpcklbw	mm0,	mm5		// mm0 = 00aa 00rr 00gg 00bb
				psubw		mm1,	mm0
				add			ebx,	4

				dec ecx
				jnz XLOOP_MAIN

			// Do blur. Last blurWidth pixels will wrap ******************************

			//mov			ecx,	blurWidth
			//pop			esi
*/						
			/*XLOOP_WRAP_END:

				movq		mm0,	mm1
				psrlw		mm0,	6
				packuswb	mm0,	mm0
				movd		eax,	mm0
				mov			[edi], eax
				add			edi,	4

				movd		mm0,	[esi]	// mm0 = 0000 0000 aarr ggbb
				punpcklbw	mm0,	mm5		// mm0 = 00aa 00rr 00gg 00bb
				paddw		mm1,	mm0
				add			esi,	4

				movd		mm0,	[ebx]	// mm0 = 0000 0000 aarr ggbb
				punpcklbw	mm0,	mm5		// mm0 = 00aa 00rr 00gg 00bb
				psubw		mm1,	mm0
				add			ebx,	4
				
				dec ecx
				jnz XLOOP_WRAP_END

			mov esi,ebx
			*/
/*
			mov eax, blurWidth
			shl eax,2
			add edi,eax

			sub esi,4

			add edi,destPitch
			add esi,sourcePitch

			dec edx
			jnz YLOOP

		emms
	}
}*/

//****************************************************************************