#ifndef HELPER_MUSIC_MUSIC_H
#define HELPER_MUSIC_MUSIC_H

#include <string>
#include "../typedefs.h"

struct FSOUND_STREAM;

namespace Helper {

	class Music {
	private:

		FSOUND_STREAM *  mStream;
		bool             mPaused;

	public:

		Music();
		Music(const std::string &filename);
		~Music();

		void load(const std::string &filename);
		void unload();

		void play();
		void pause();

		float getVULeft();
		float getVURight();

		void setTimer(const float32 timer);
		const float32 getTimer() const;
	};
}

#endif
