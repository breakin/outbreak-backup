#ifndef HELPER_EXCEPTION_H
#define HELPER_EXCEPTION_H

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Tooon
 @ Class		: System Exceptions
 @ Derived		: C++'s exception
 @ Brief		: Exception objects in several different formats, extended
				  with extra features such as logging and unlimited amount
				  of parameters for passing data to an exception object.
				  

 @ Features
 
  * Automatically logs exception message to Helper::Debug
  * Using C's standard args, which makes it possible to specify and pass
	runtime values/objects of data causing the exception.


================================================================================*/

#include <exception>

namespace Helper {

	class Exception : public exception {
	public:

		Exception();
		Exception(const char * const param_message,...);
	};

	/**
	 * File Exception - thrown when any file IO error occurs
	 */
	class FileException : public Exception {
	public:

		FileException(const char * const message, ...);
	};

	/**
	 * Device Exception - thrown when device error occurs
	 */
	class DeviceException : public Exception {
	public:

		DeviceException(const char * const message,...);
	};
}

#endif