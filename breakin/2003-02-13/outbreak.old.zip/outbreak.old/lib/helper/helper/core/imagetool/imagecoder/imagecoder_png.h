#ifndef HELPER_HELPER_IMAGETOOL_IMAGECODER_PNG_H
#define HELPER_HELPER_IMAGETOOL_IMAGECODER_PNG_H

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : quarn
	@ Brief       : Encodes and decodes png-images.

    @ Features :
		* decode images in RGB-format
		* decode images in RGBA-format
		* decode images in GRAY-format
		* decode images in GRAYA-format
		* decode images in INDEX-format with tRNS-chunk

    @ Todo :
		* decode images in INDEX-format
		* encode images

    @ Known Bugs :
		* decodeing of images in INDEX-format does just not work

  
  =============================================================================
*/

#include "imagecoder.h"

namespace Helper {

	class ImageCoder_PNG : public ImageCoder {
	public:

		ImageCoder_PNG();		
		virtual ~ImageCoder_PNG();

		virtual void encode(Blob &result,        const BaseImage32 &sourceImage, const AreaInt &sourceArea, const EncodeSettings &settings=defaultEncodeSettings) const;
		virtual void decode(BaseImage32 &result, const Blob &sourceBlob,         const DecodeSettings &settings=defaultDecodeSettings) const;

		virtual const bool isEncoder(const std::string &fileName="") const;
		virtual const bool isDecoder(const std::string &fileName="") const;
	};
};



#endif
