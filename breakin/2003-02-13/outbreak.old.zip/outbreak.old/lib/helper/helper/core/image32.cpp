#include "image32.h"
#include "exception.h"
//#include <memory.h>
#include "debug/assert.h"
#include <stdio.h>
#include <windows.h>

#define IMAGE32_ALIGNMENT 32

//****************************************************************************

Helper::Image32::Image32() :  mBuffer(0), mOriginalBuffer(0), mWidth(0), mHeight(0) {
}

//****************************************************************************

Helper::Image32::Image32(const int width, const int height) :  mBuffer(0), mOriginalBuffer(0) {
	resize(width,height);
}

//****************************************************************************

Helper::Image32::~Image32() {
	clear();
}

//****************************************************************************

void Helper::Image32::clear() {
		
	delete[] mOriginalBuffer;	
	mOriginalBuffer=NULL;
	mBuffer=0;
	mHeight=0;
	mWidth=0;
	mArea.set(0,0,0,0);
}

//****************************************************************************

void Helper::Image32::resize(const int width, const int height) {

	DEBUG_ASSERT(width>0);
	DEBUG_ASSERT(height>0);

	const int newPixels=width*height;
	const int oldPixels=getWidth()*getHeight();

	if (newPixels!=oldPixels) {
		
		delete[] mOriginalBuffer;		
		mOriginalBuffer=new uint8[newPixels*4+IMAGE32_ALIGNMENT];
		
		if (mOriginalBuffer==0) 
			throw Helper::Exception("Image32::resize", "Out of memory (%dx%d->%dx%d)", getWidth(), getHeight(), width,height);

		// TODO: Make mBuffer aligned
		mBuffer=(uint32*)mOriginalBuffer;//reinterpret_cast<uint32*>(mOriginalBuffer);
	}

	mWidth=width;
	mHeight=height;
	mArea.set(0,0,width,height);
}

//****************************************************************************

