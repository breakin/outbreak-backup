#ifndef HELPER_DEMO_SCRIPT_SEFFECT_H
#define HELPER_DEMO_SCRIPT_SEFFECT_H

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Effect (script)
	@ Brief       : Effect within the script engine.
  =============================================================================
*/

#include <helper/core/typedefs.h>
#include <helper/core/xml/xmlparser.h>
#include <helper/core/demo/script/effect.h>
#include <vector>

#include "scriptAttribute.h"
#include "scriptTrigger.h"
#include "effect.h"

namespace Helper {
	class SEffect {
	public:
		float64		current;
		
		std::string name;
		float64     start;
		float64     end;

		// Effect callback
		Effect*     callback;

		std::vector<SAttribute*>   attributeList;
		std::vector<STrigger*>     triggerList;

		void setCallback(Effect* effect);

		void executeTriggers(const float64 timer);
		const std::string& getAttribute(const std::string& name);

		void load(const XmlParser::IteratorConst& effect);
		void save(XmlParser::Iterator& root);

		void update(const float64& current, const float64 delta);
	};
}

#endif