#ifndef HELPER_BLOB_H
#define HELPER_BLOB_H

#include "typedefs.h"
#include "exception.h"
#include <stdio.h>
#include "debug/assert.h"

/*
	Author: Breakin
*/

namespace Helper {
	
	class Blob {
	private:

		class BlobRef {
		public:

			uint8 *mBuffer;
			int    mSize;
			int    refCount;
		};

		BlobRef *blobRef;
		
		int fileOffset;

		void makeUniqueCopy();

	public:

		Blob();
		Blob(const Blob &other);
		Blob(const int size);
		Blob(const uint8 * const memory, const int size);
		~Blob();

		void operator=(const Blob &other);

		// This method will resize the blob
		void resize(const int newSize, const bool keepData=false);

		// This will clear the Blob, making it a null-blob
		void clear();

		// This will init the Blob with a copy of memory/size
		void setMemory(const uint8 * const memory, const int size);

		// This will give the Blob memory/size. Blob will delete the pointer by itself using delete []
		void giveMemory(uint8 *memory, const int size);

		// Give the pointer and the ownership (the one that deletes) to the user (delete using delete[])
		// The blob will be a null-blob from this on.
		uint8* takePointer();

		inline const bool isEmpty() const { return (blobRef==0 || blobRef->mBuffer==0); }
		inline const int  getSize() const { return ((blobRef==0) ? 0 : blobRef->mSize); }
		
		// get is not allowed on null-blobs!
		inline const uint8 * const getReadOnly() const { return (blobRef ? blobRef->mBuffer : 0); }

		inline uint8 * get() {
			makeUniqueCopy();
			return blobRef->mBuffer;
		}

		inline const uint8 get(const int index) const { return blobRef->mBuffer[index]; }

		inline void set(const int index, const uint8 value) {

			DEBUG_ASSERT((blobRef!=0) && (index>=0) && (index < blobRef->mSize));
			
			makeUniqueCopy();
			blobRef->mBuffer[index]=value;
		}


		void fseek(const int position, const int mode=SEEK_SET);
		const int ftell() const;
		void fread(void *dest, const int bytes);
		void fprintf(const char * const text, ...);
		void fwrite(const void * const text, const int bytes, const int times=1);
	};
}

#endif