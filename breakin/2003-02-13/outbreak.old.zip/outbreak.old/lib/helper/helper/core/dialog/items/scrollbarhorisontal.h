#ifndef HELPER_DIALOG_ITEM_SCROLLBARHORISONTAL
#define HELPER_DIALOG_ITEM_SCROLLBARHORISONTAL

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Scrollbar Horisontal.
	@ Brief       : Yep.
  =============================================================================
*/

#include "../base/itembase.h"

namespace Helper {

	class ScrollbarHorisontal : public ItemBase {
	protected:
		// Images for drawing
		Image32 imageLeft, imageRight, imageBar, imageBackground;

		// Scrollbar position variables
		uint32  max;
		uint32  unitsPerPage;
		float32 currentX;
		int32   originalMousePos;
		int32   lastMousePos;
		bool    mouseLock;
		bool    hasMovedBool;

		virtual void setPositionPixel(const int32 newPosition);

	public:
		ScrollbarHorisontal();
		~ScrollbarHorisontal();

		virtual void load();

		virtual void setMax(const uint32 newMax, const uint32 newUnitsPerPage=3);
		virtual const uint32 getMax();
		virtual void setPosition(const int32 newPosition);
		virtual const uint32 getPosition();

		virtual const bool hasMoved();

		virtual const std::string processEvent(const Msg& message, const AreaInt& parentArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
	};
}

#endif
