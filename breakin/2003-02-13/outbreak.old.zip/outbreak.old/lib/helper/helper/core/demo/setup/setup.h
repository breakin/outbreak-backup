#ifndef HELPER_DEMO_SETUP_H
#define HELPER_DEMO_SETUP_H

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Setup
	@ Brief       : Made to parse a setup file if we wan't one in a demo.
  =============================================================================
*/

#include "../../xml/xmlparser.h"
#include <string>

namespace Helper {

	class Setup {
	private:

		XmlParser::IteratorConst i;

	public:
		
		Setup(const XmlParser* const xmlBase, const std::string &setupName);
		const std::string &getAttribute(const std::string &attributeName) const;
	};
}

#endif
