#ifndef __HELPER_DEBUG_H__
#define __HELPER_DEBUG_H__

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Tooon
 @ Class		: Debug
 @ Brief		: Handling output of log messages to debugmonitors.
				  The Debug class to not output any logmessages by itself,
				  it routs the messages ,send to it, to its monitors.
				  A monitor could be anything, it could be a class handling
				  output to files, sending data over TCP/IP or printing the 
				  message onto a win32 window.

 @ Features		:

  * Unlimited amount of monitors
  * Prioriry logging (Appl, Sys, Exception)
  * Can be turned on/off explicitly in any build (Release/Debug) 
 
================================================================================*/

#include <stdarg.h>
#include <stdio.h>
#include <vector>

#include "..\clock.h"
#include "filemonitor.h"

// define following directive if logging should occur
// in both debug and release builds
//#define HELPER_FORCE_DEBUG

#ifdef _DEBUG
#define HELPER_FORCE_DEBUG
#endif

#ifdef HELPER_FORCE_DEBUG
#define HELPER_DEBUG
#endif

#ifdef	WIN32 
#define DEBUG_API __forceinline
#else
#define DEBUG_API inline
#endif


namespace Helper {

class Debug {
		
	public:
		
		enum {
	
			APPL		= 0x01,
			SYSTEM 		= 0x02,
			EXCEPTION	= 0x04,
			ALL			= 0xff,
		};

		// logs a message to registerd debug monitors
		static void logException(const char method[], const char message[],...);
		static void logSystem   (const char method[], const char message[],...);
		static void log			(const char method[], const char message[],...);

		// sets and gets the current priority filter of the default file monitor
		static int  getFilter();
		static void setFilter(int filter);
		
		// addMonitor		- register a monitor with Debug 
		// releaseMonitor	- removes the monitor from Debug's callback list		 
		static void addMonitor(DebugMonitor *monitor);
		static void releaseMonitor(DebugMonitor *monitorID);
		
		// Enables/Disables logging
		static void enable();
		static void disable();

		
	private:

		// initializes debug and set default monitor
		static void initialize();

		// update all registered monitors with message
		static void updateMonitors(int msgType, const char message[]);

		// Log's properties
		static std::vector<DebugMonitor*> m_monitors;
		static DebugMonitorFile m_defaultMonitor;		
		static int		m_filter;
		static bool		m_enabled;
		static bool		m_initialized;
		static Clock	m_clock;
		static char		m_message[512];
	
};

//=========================================================================

DEBUG_API void Debug::logSystem(const char method[], const char message[],...) {

#ifdef HELPER_DEBUG
	
	if (m_enabled) {
		
		if (!m_initialized) initialize();
		
		char logmsg[512];		
		va_list args;
		va_start(args,message);
		vsprintf(logmsg,message,args);
		sprintf(m_message,"[%.6f]\t %s->[%s]\n",m_clock.get(),method,logmsg);
		updateMonitors(Debug::SYSTEM, m_message);
	}

#endif
}

//=========================================================================

DEBUG_API void Debug::log (const char method[], const char message[],...) {
	
#ifdef HELPER_DEBUG

	if (m_enabled) {
		
		if (!m_initialized) initialize();

		char logmsg[512];		
		va_list args;
		va_start(args,message);
		vsprintf(logmsg,message,args);
		sprintf(m_message,"[%.6f]\t %s->[%s]\n",m_clock.get(),method,logmsg);
		updateMonitors(Debug::APPL, m_message);
	}

#endif
}

//=========================================================================

DEBUG_API void Debug::logException(const char method[], const char message[],...) {

#ifdef HELPER_DEBUG

	if (m_enabled) {
		
		if (!m_initialized) initialize();

		char logmsg[512];		
		va_list args;
		va_start(args,message);
		vsprintf(logmsg,message,args);
		sprintf(m_message,"[%.6f]\t %s->[%s]\n",m_clock.get(),method,logmsg);
		updateMonitors(Debug::EXCEPTION, m_message);
	}

#endif
}

}// end namespace Helper


#endif
