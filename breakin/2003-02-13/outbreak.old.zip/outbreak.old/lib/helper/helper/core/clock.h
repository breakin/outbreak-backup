#ifndef HELPER_CLOCK_H
#define HELPER_CLOCK_H

#include "typedefs.h"

/*
  
  Author: Breakin (code from Thec, ideas from Tooon)

*/

namespace Helper {

	class Clock {
	private:

		float64 startTime;

		static const float64 getTime();
		static void initTime();

	public:

		Clock();

		~Clock() {
		}

		inline const float64 get() const { return getTime()-startTime; }
		void reset() { startTime=getTime(); }
		void setWithDelta(const float64& deltaTime);
	};
};

#endif