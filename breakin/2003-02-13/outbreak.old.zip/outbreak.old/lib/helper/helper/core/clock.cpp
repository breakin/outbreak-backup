#include "clock.h"

// ***************************************************************************

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mmsystem.h>

namespace Helper {
	static bool usingPerformanceTimer;
	static float64 performanceTimerScale;
	static bool initialized=false;
}

// ***************************************************************************

Helper::Clock::Clock() {
	if (!initialized) initTime();
	startTime=getTime();
}

// ***************************************************************************

void Helper::Clock::initTime() {

	LONGLONG performanceFreq;
	
	if (QueryPerformanceFrequency((LARGE_INTEGER*)&performanceFreq)) {

		performanceTimerScale=1.0/static_cast<float64>(performanceFreq);
		usingPerformanceTimer = true;

	} else {

		usingPerformanceTimer = false;
	}

	initialized=true;
}

// ***************************************************************************

const Helper::float64 Helper::Clock::getTime() {
	
	if (usingPerformanceTimer) {

		LONGLONG currentTime;
		QueryPerformanceCounter((LARGE_INTEGER *)&currentTime);

		return static_cast<float64>(currentTime)*performanceTimerScale;

	} else {
		
		// Windows multimedia timer (winmm.lib->winmm.dll)
		return static_cast<float64>(timeGetTime())/1000.0;
	}
}

// ***************************************************************************

void Helper::Clock::setWithDelta(const float64& deltaTime) {
	startTime -= deltaTime;
}

// ***************************************************************************
