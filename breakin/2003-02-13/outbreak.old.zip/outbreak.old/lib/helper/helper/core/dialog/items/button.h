#ifndef HELPER_DIALOG_ITEM_BUTTON
#define HELPER_DIALOG_ITEM_BUTTON

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Button
	@ Brief       : Standard button with a label.

	@ Todo :
		* Everything.

  =============================================================================
*/

#include "../base/itembase.h"
#include "../font/font.h"

namespace Helper {

	class Button : public ItemBase {
	protected:
		Font font;
		std::string caption;

	public:
		Button();
		~Button();

		virtual void load();

		virtual const std::string processEvent(const Msg& message, const AreaInt& parentArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
	};
}

#endif
