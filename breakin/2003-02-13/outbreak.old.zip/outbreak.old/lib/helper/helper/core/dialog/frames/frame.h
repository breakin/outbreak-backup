#ifndef HELPER_DIALOG_FRAME_FRAME
#define HELPER_DIALOG_FRAME_FRAME

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Frame
	@ Brief       : A frame with borders which holds items.
  =============================================================================
*/

#include "../base/framebase.h"

namespace Helper {

	class Frame : public FrameBase {
	protected:
		bool moveable;

		bool usingOwnBackground;
		Image32* ownBackground;

		Image32 upperLeft, upperMiddle, upperRight;
		Image32 leftMiddle, background, rightMiddle;
		Image32 bottomLeft, bottomMiddle, bottomRight;

		virtual void load();

	public:
		Frame();
		~Frame();

		virtual void setMovable(const bool choice);
		virtual void setBackground(Image32& background);
		virtual void setOwnBackground(Image32& background);

		virtual const std::string processEvent(const Msg& message, const AreaInt& clientArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
	};
}

#endif