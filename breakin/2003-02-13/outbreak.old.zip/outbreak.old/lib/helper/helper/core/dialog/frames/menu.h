#ifndef HELPER_DIALOG_FRAME_MENU
#define HELPER_DIALOG_FRAME_MENU

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Menu
	@ Brief       : Draws a standard menu.
  =============================================================================
*/

#include <helper/core/typedefs.h>
#include "../base/framebase.h"
#include "../font/font.h"
#include "menuitem.h"

namespace Helper {

	class Menu : public FrameBase {
	protected:
		Font* font;
	
		uint32 light;  // Which item is highlighted, if none, -1.
		uint32 pushed; // Anyone opened any menuitem?

		Image32 background;
		Image32 textLeft, textMiddle, textRight;

		uint32  normalColor;
		uint32  highlightColor;

		virtual void load();

	public:
		Menu();
		~Menu();

		void setFont(Font& font);
		void setColor(uint32 newNormalColor, uint32 newHighlightColor);

		virtual void add(ItemBase* _item);

		virtual const std::string processEvent(const Msg& message, const AreaInt& clientArea);
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);
	};
}

#endif