/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : quarn
	@ Brief       : helpfunctions for the png encoder/decoder
  =============================================================================
*/
#include "../../blob.h"
#include "../../debug/debug.h"
using namespace Helper;

extern "C" {
	#include <libpng/inc/png.h>

	void read_png_data(png_structp png_ptr, png_bytep data, png_size_t length) {
		Blob *sourceBlob = (Blob *) png_get_io_ptr(png_ptr);

		sourceBlob->fread(data, length);
	}
}
