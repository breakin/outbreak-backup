#ifndef __HELPER_DEBUG_MONITOR_H__
#define __HELPER_DEBUG_MONITOR_H__

/**
 * DebugMonitor -  
 * contains a callback - "onMessage" which
 * (if registered) is called by Debug each
 * time a new message is logged.
 */

namespace Helper {

class DebugMonitor {

	public:
		
		virtual void onDebugMessage(int msgtype, const char message[]) = 0;
};

}

#endif
