#ifndef HELPER_DIALOG_BASE_ITEMBASE
#define HELPER_DIALOG_BASE_ITEMBASE

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : ItemBase
	@ Brief       : Items base. All items and frames inheritence from this
					class. Has some methods you'll need to implement.
  =============================================================================
*/

#include <helper/core/typedefs.h>
#include <helper/core/message.h>
#include <helper/core/area.h>
#include <helper/core/image32.h>
#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/archive/archive.h>

namespace Helper {

	class ItemBase {
	protected:
		std::string name;
		
		std::string description; // alt in html.

		bool focus;
		bool visible;
		bool extraImportant;

		ImageDrawer* imageDrawer;
		bool helpersInited;
		bool invalidateMyselfBool;
		bool drawInited;

		// For notify-parents system.
		AreaInt haveChanged;

		// Position and size. Relative to parent.
		AreaInt area; 
		AreaInt oldArea; // Used to update old area.

		virtual void load();
		Archive* archive;

		virtual AreaInt localToWorld(const AreaInt& parentArea);

	public:
		ItemBase();
		virtual ~ItemBase();

		const std::string& getName();
			
		virtual void setArea(const std::string _name, const AreaInt& _area);
		virtual void setArea(const AreaInt& _area);
		virtual const AreaInt& getArea() const;

		virtual void setVisible(const bool option=true);
		virtual const bool getVisible();

		virtual void setFocus(const bool option=true);
		virtual void invalidateMyself() { invalidateMyselfBool=true; }

		virtual void setDescription(std::string description);
		virtual const std::string& getDescription(const PointInt& mousePosition, const AreaInt& parentArea);

		virtual void init(ImageDrawer& imageDrawer, Archive& archive, const bool doLoad=true);

		/**
		 * Process an event message. Will not be called if item doesn't have focus.
		 * 
		 * clientArea is area as represented on _screen_. Very important to keep in mind.
		 */
		virtual const std::string processEvent(const Msg& message, const AreaInt& parentArea);

		/**
		 * Update method to update everything which will be dynamic.
		 * This method is called from draw.
		 */
		virtual const AreaInt update(const PointInt mousePosition, const AreaInt& parentArea);

		/**
		 * And of course every item has a drawmethod. clientArea applies to processEvent.
		 */
		virtual void draw(BaseImage32& dest, const AreaInt& parentArea, const AreaInt& changedArea);

		virtual void resetChangedArea() { haveChanged.set(0,0,0,0); }
	};
}

#endif
