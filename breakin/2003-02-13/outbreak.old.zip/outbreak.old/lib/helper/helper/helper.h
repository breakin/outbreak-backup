#ifndef HELPER_ALL_H
#define HELPER_ALL_H

#include "core/typedefs.h"

#include "core/area.h"
#include "core/point.h"
#include "core/clock.h"
#include "core/exception.h"

#include "core/music/music.h"

#include "core/image32.h"
#include "core/imagedrawer/imagedrawer.h"
#include "core/imagedrawer/imagefilter.h"
#include "core/imagetool/imagetool.h"
#include "core/device2d.h"

#include "core/xml/xmlparser.h"

#include "core/demo/setup/setup.h"
#include "core/demo/script/script.h"
#include "core/demo/script/effect.h"

#include "core/archive/archive.h"
#include "core/archive/archivedirectory.h"
#include "core/archive/archiverar.h"

#include "core/dialog/dialog.h"

#endif