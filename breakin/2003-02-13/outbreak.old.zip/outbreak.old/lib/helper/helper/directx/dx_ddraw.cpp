#include "dx_ddraw.h"
#include "..\core\exception.h"
#include "..\core\displaymode.h"
#include <windows.h>

using namespace Helper;

HMODULE DirectDraw::m_dllHandle = NULL;
bool	DirectDraw::m_dllLoaded = false;
int		DirectDraw::m_dllRef	 = 0;	

typedef HRESULT (WINAPI *DDCREATEFUNC) (GUID FAR*, LPDIRECTDRAW FAR*, IUnknown FAR*);

//=========================================================================================================

DirectDraw::~DirectDraw() {
	
	Debug::logSystem("DirectDraw::~DirectDraw()","Destructing instance[%d]...",m_dllRef);
	
	m_dllRef--;

	if ((m_dllRef == 0) && (m_dllLoaded))
		unload();
}


//=========================================================================================================


void DirectDraw::load() {

	if (!m_dllLoaded) {

		Debug::logSystem("DirectDraw::load()", "Loading ddraw.dll");
		m_dllHandle = (HMODULE) LoadLibrary("ddraw.dll");
		
		if (m_dllHandle == NULL) 
			throw DeviceException("Could not load ddraw.dll!");
		
		m_dllLoaded = true;
	}
}

//=========================================================================================================

void DirectDraw::unload() {

	if (m_dllLoaded) {
		
		Debug::logSystem("DirectDraw::unload()", "Unloading ddraw.dll");
		FreeLibrary(m_dllHandle);
		m_dllHandle = NULL;
		m_dllLoaded = false;
	}
}

//=========================================================================================================

void DirectDraw::create() {

	// check if dll is loaded, otherwise - load!
	if (!m_dllLoaded) load();

	if (!m_active) {

		// create a function pointer and an IID
		DDCREATEFUNC directDrawCreate;
		GUID dd7IID;

		Debug::logSystem("DirectDraw::create()", "Getting <DirectDrawCreate()> from ddraw.dll");
		
		// import DirectDrawCreate from dll
		directDrawCreate = (DDCREATEFUNC)GetProcAddress(m_dllHandle,"DirectDrawCreate");

		// check if it went ok
		if (directDrawCreate == NULL) 
			throw DeviceException("Could not import <DirectDrawCreate()> from ddraw.dll");

		// create a directdraw interface
		Debug::logSystem("DirectDraw::create()","Creating a IDirectDraw1 interface");
		
		if (directDrawCreate(NULL,&m_directDraw,NULL)!=DD_OK)
			throw DeviceException("Could not create IDirectDraw");
		
		// setup DD7 IID
		dd7IID.Data1    = 0x15e65ec0; 
		dd7IID.Data2    = 0x3b9c;
		dd7IID.Data3    = 0x11d2;
		dd7IID.Data4[0] = 0xb9;
		dd7IID.Data4[1] = 0x2f;
		dd7IID.Data4[2] = 0x00;
		dd7IID.Data4[3] = 0x60;
		dd7IID.Data4[4] = 0x97;
		dd7IID.Data4[5] = 0x97;
		dd7IID.Data4[6] = 0xea;
		dd7IID.Data4[7] = 0x5b;

		// query for IID_IDirectDraw7 interface
		Debug::logSystem("DirectDraw::create()","Query for IDirectDraw7 interface");
		
		if (m_directDraw->QueryInterface(dd7IID, (void**)&m_directDraw7)!=S_OK)
			throw DeviceException("Could not query for IDirectDraw7 interface");
		
		m_active = true;
	
		// enumerate displaymodes only if not onlt enumerated once	;	
		if (m_displayModes.empty()) {
		
			m_directDraw7->EnumDisplayModes(0, NULL, (LPVOID)this, (LPDDENUMMODESCALLBACK2)enumDisplayCallBack); 
			sortDisplayModes();
		}
	}
}

//=========================================================================================================

void DirectDraw::release(){

	if (m_active) {

		if (m_exclusive) {

			// restore displaymode and set cooperativelevel 
			// back to normal
			m_directDraw7->RestoreDisplayMode();
			setCooperativeLevel(false, m_hwnd);
		}

		m_directDraw7->Release();
		m_directDraw->Release();
		m_active = false;
	}
}

//=========================================================================================================

void DirectDraw::setCooperativeLevel(bool exclusive, HWND hwnd) {

	Debug::logSystem("DirectDraw::setCoopertiveLevel()","Exclusive access = %d",exclusive);

	if (exclusive)
		m_directDraw7->SetCooperativeLevel(hwnd, DDSCL_FULLSCREEN|DDSCL_EXCLUSIVE|DDSCL_ALLOWREBOOT|DDSCL_ALLOWMODEX);
	else
		m_directDraw7->SetCooperativeLevel(hwnd, DDSCL_NORMAL);

	m_exclusive = exclusive;
	m_hwnd = hwnd;
}

//=========================================================================================================

void DirectDraw::setDisplayMode(int width, int height, int bpp) {

	if (m_exclusive) {

		Debug::logSystem("DirectDraw::setDisplayMode()","width = %d, height =%d, bpp = %d",width,height,bpp);
		
		if (m_directDraw7->SetDisplayMode(width, height, bpp, 0, 0)!=DD_OK)
			throw DeviceException("Unsupported displaymode(%d,%d,%d)!",width, height, bpp);
	}
}

//=========================================================================================================

HRESULT WINAPI DirectDraw::enumDisplayCallBack(LPDDSURFACEDESC2 lpSurfaceDesc, LPVOID data) {
	
	LPDDPIXELFORMAT	pPixelFormat;
	DirectDraw		*driver = (DirectDraw*)data;
	DisplayMode		tempDm;
	PixelFormat		tempPf;
	
	pPixelFormat = &(lpSurfaceDesc->ddpfPixelFormat);

	// give a shit of 8 bit indexed formats!
	if (pPixelFormat->dwRGBBitCount == 8)
		return DDENUMRET_OK;


	// set current enumerated displaymode's pixel format
	tempPf.set(pPixelFormat->dwRGBBitCount, pPixelFormat->dwRBitMask, pPixelFormat->dwGBitMask, pPixelFormat->dwBBitMask);

	// set displaymode
	tempDm.set(lpSurfaceDesc->dwWidth, lpSurfaceDesc->dwHeight, pPixelFormat->dwRGBBitCount);
	tempDm.setPixelFormat(tempPf);

	// store displaymode in displaymode vector
	driver->m_displayModes.push_back(tempDm);

	// review display mode in debug monitors
	Debug::logSystem("CDirectDraw::enumDisplayCallBack","%4d x %4d x %2d", tempDm.width, tempDm.height, tempDm.bpp);
	return DDENUMRET_OK;
}

//=========================================================================================================

bool DirectDraw::testDisplayMode(int32 width, int32 height, int32 bpp, DisplayMode &displayMode) {

	for (int i = 0; i < m_displayModes.size(); i++) {
	
		if ((m_displayModes[i].width  == width)  &&
			(m_displayModes[i].height == height) && 
			(m_displayModes[i].bpp    == bpp)) {

			displayMode = m_displayModes[i];
			return true;
		}
	}

	return false;
}

//=========================================================================================================

void DirectDraw::sortDisplayModes() {

	uint32 i = 0;
	uint32 currentBitDepth = m_displayModes[0].bpp;
	uint32 currentIndex	   = 0;

	while (i < m_displayModes.size() - 1) {

		// only perform tests on displaymodes with equal pixelformats (bpp)
		if (m_displayModes[i+1].bpp != currentBitDepth) {

			currentBitDepth = m_displayModes[i+1].bpp;
			++i;
			currentIndex = i;
			continue;
		}

		// compare pixelarea
		if ((m_displayModes[i    ].width * m_displayModes[i    ].height) > 
			(m_displayModes[i + 1].width * m_displayModes[i + 1].height)) {

			std::swap(m_displayModes[i], m_displayModes[i + 1]);

			// to be sure, perform bubble shit on index.. 
			i = currentIndex;
			continue;
		}
		
		++i;
	}
}

//=========================================================================================================
