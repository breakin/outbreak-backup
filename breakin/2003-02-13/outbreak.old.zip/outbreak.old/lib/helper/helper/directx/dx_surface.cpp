#include "dx_surface.h"
#include "..\core\exception.h"
#include <ddraw.h>

using namespace Helper;

// ====================================================================================

DirectDrawImage::~DirectDrawImage(){

	Debug::logSystem("DirectDrawImage::~DirectDrawImage()","Destructing...");
	
	if (m_active) 
		clear();
}

// ====================================================================================

void DirectDrawImage::initialize(LPDIRECTDRAW7 directDraw, HWND clipWindow) {

	if (!m_initialized) {

		Debug::logSystem("DirectDrawImage::initialize()","Initializing directdraw");
		m_directDraw  = directDraw;
		m_hwnd  	  = clipWindow;
		m_initialized = true;
	}
}

// ====================================================================================

void DirectDrawImage::resize(const int width, const int height) {

	if (!m_active) {
	
		DDPIXELFORMAT  pixelFormat;
		DDSURFACEDESC2 surfaceDesc;

		if (m_fullscreen)
			createSurfaceFullscreen(width, height);
		else
			createSurfaceWindowed(width, height);

		/**
		 * Get backbuffer information
		 */
		surfaceDesc.dwSize = sizeof (surfaceDesc);
		m_secondary->GetSurfaceDesc (&surfaceDesc);

		m_pitches[0]= surfaceDesc.lPitch;
		m_width		= width;
		m_height	= height;
		m_area.set(0,0,width,height);
			
		// get primary pitch
		memset(&surfaceDesc,0,sizeof(surfaceDesc));
		surfaceDesc.dwSize = sizeof (surfaceDesc);
		m_primary->GetSurfaceDesc (&surfaceDesc);
		
		m_pitches[1] = surfaceDesc.lPitch;

		/**
		 * Get pixelformat from primarysurface
		 */
		pixelFormat.dwSize = sizeof (surfaceDesc);
		m_primary->GetPixelFormat(&pixelFormat);

		if (pixelFormat.dwRGBBitCount == 32)
			m_pixelFormat.set(PixelFormat::BPP_32);
		
		if (pixelFormat.dwRGBBitCount == 16) {

			// check 11th bit if 565 mode
			if (pixelFormat.dwGBitMask & 0x400) 
				m_pixelFormat.set(PixelFormat::BPP_16_565);
			else // 1555 mode
				m_pixelFormat.set(PixelFormat::BPP_16_1555);
		}

		// set surface to active
		m_currentBackbuffer = 0;
		m_active = true;
		m_locked = false;
	}
}	

// ====================================================================================

void DirectDrawImage::clear() {

	if (m_active){
		
		unlock();

		if (!m_fullscreen) {

			m_secondary->Release();
			m_clipper->Release();
		}
		
		m_primary->Release();
		m_active = false;
		m_initialized = false;
	}
}

// ====================================================================================

void DirectDrawImage::fullscreen(bool fullscreen) {

	m_fullscreen = fullscreen;
}

// ====================================================================================

void DirectDrawImage::flip() {

	static DWORD ret;
	static DDBLTFX bltFx;

	if (!m_locked) {

		if (m_fullscreen) {

			// flip primary surface chain
			if ((ret = m_primary->Flip(NULL, DDFLIP_WAIT)) != DD_OK) {
				
				if (ret == DDERR_SURFACELOST) {

					Debug::logSystem("DirectDrawImage","Surface lost - restore primarysurface...");
					m_primary->Restore();
					
					memset(&bltFx, 0, sizeof (DDBLTFX));
					bltFx.dwSize = sizeof (DDBLTFX);
					bltFx.dwFillColor = 0x000000;
					Debug::logSystem("DirectDrawImage","Clearing primarysurface...");
					m_primary->Blt(NULL, NULL, NULL, DDBLT_WAIT | DDBLT_COLORFILL, &bltFx);
					Debug::logSystem("DirectDrawImage","Flip was not succefully completed, screen not updated...");
				}

				Debug::logSystem("DirectDrawImage","FLIP WAS NOT SUCCESSFULLY COMPLETED [%d]!!!!",ret);
				return;
			}
			
			m_currentBackbuffer = 1 - m_currentBackbuffer;
		}
		else {

			RECT  rect;
			POINT *p;
			
			// Get Current client area
			GetClientRect(m_hwnd,&rect);

			// let p point to rect(top,left)
			p = (POINT*)&rect;
			
			// convert to screen cordinates
			ClientToScreen(m_hwnd,p);

			// increate p to rect(bottom,right)
			p++;
			
			// and convert lower - right corner aswell
			ClientToScreen(m_hwnd,p);
			
			// blit secondary surface to primary
			m_primary->Blt(&rect,m_secondary,NULL, DDBLT_WAIT,NULL);
		}
	}
}

// ====================================================================================

void DirectDrawImage::lock() const {

	if (!m_locked) {
		
		DDSURFACEDESC2 surfaceDesc;
		memset(&surfaceDesc,0,sizeof(surfaceDesc));
		surfaceDesc.dwSize  = sizeof(surfaceDesc);
		
		if (m_secondary->Lock(NULL,&surfaceDesc,DDLOCK_SURFACEMEMORYPTR | DDLOCK_WAIT, NULL)!=DD_OK)
			throw DeviceException("Could not lock Direct Draw Surface!");
		
		m_data = surfaceDesc.lpSurface;
		m_locked = true;
	}
}

// ====================================================================================

void DirectDrawImage::unlock() const {

	if (m_locked) {

		m_secondary->Unlock(NULL);
		m_locked = false;
	}
}

// ====================================================================================

uint32* DirectDrawImage::get() {

	// force image to be locked when gettin 
	// direct access to it's pixel data
	if (!m_locked)
		lock();

	return (uint32*)m_data;
}

// ====================================================================================

const uint32 * const DirectDrawImage::get() const {

	// force image to be locked when gettin 
	// direct access to it's pixel data
	if (!m_locked)
		lock();

	return (uint32*)m_data;
}

// ====================================================================================

void DirectDrawImage::createSurfaceWindowed(int width, int height){
	
	DDSURFACEDESC2 surfaceDesc;

	// clear structures
	memset(&surfaceDesc,0,sizeof(surfaceDesc));
	
	// create primarysurface
	surfaceDesc.dwSize  = sizeof(surfaceDesc);
	surfaceDesc.dwFlags = DDSD_CAPS;
	surfaceDesc.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
	
	Debug::logSystem("DirectDrawImage::createSurfaceWindowed()","Creating primary surface");

	if (m_directDraw->CreateSurface(&surfaceDesc,&m_primary,NULL)!=DD_OK)
		throw DeviceException("Could not create DirectDraw windowed primary surface!");
	
	Debug::logSystem("DirectDrawImage::createSurfaceWindowed()","Setting up secondary surface");
	
	// setup surface desc.
	memset(&surfaceDesc,0,sizeof(surfaceDesc));	
	surfaceDesc.dwSize  = sizeof(surfaceDesc);
	surfaceDesc.dwFlags = DDSD_CAPS|DDSD_WIDTH|DDSD_HEIGHT;
	surfaceDesc.dwWidth = width;
	surfaceDesc.dwHeight= height;
	surfaceDesc.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
	
	Debug::logSystem("DirectDrawImage::createSurfaceWindowed()","Creating secodary surface");
	
	// create surface
	if (m_directDraw->CreateSurface(&surfaceDesc,&m_secondary,NULL)!=DD_OK)
		throw DeviceException("Could not create DirectDraw secondary surface!");

	// create clipper
	Debug::logSystem("DirectDrawImage::createSurfaceWindowed()","Creating clipper");		
	m_directDraw->CreateClipper(0,&m_clipper,NULL);
	m_clipper->SetHWnd(0,m_hwnd);
	m_primary->SetClipper(m_clipper);
}

// ====================================================================================

void DirectDrawImage::createSurfaceFullscreen(int width, int height) {
	
	DDSURFACEDESC2  surfaceDesc;
	DDSCAPS2		surfaceCaps;

	Debug::logSystem("DirectDrawImage::createSurfaceFullscreen()","Creating primary surface");

	// create primarysurface
	memset(&surfaceDesc,0,sizeof(surfaceDesc));
	surfaceDesc.dwSize  = sizeof(surfaceDesc);
	
	// setup surface description
	surfaceDesc.dwFlags	= DDSD_CAPS;
	surfaceDesc.dwFlags|= DDSD_BACKBUFFERCOUNT;
	surfaceDesc.dwBackBufferCount = 1;
	surfaceDesc.ddsCaps.dwCaps  = DDSCAPS_PRIMARYSURFACE;
	surfaceDesc.ddsCaps.dwCaps |= DDSCAPS_COMPLEX;
	surfaceDesc.ddsCaps.dwCaps |= DDSCAPS_FLIP;
	
	// create direct draw surface
	if (m_directDraw->CreateSurface(&surfaceDesc,&m_primary,0) != DD_OK)
		throw DeviceException("Could not create DirectDraw fullscreen primary surface!");

	
	Debug::logSystem("DirectDrawImage::createSurfaceFullscreen()","Getting attached surface");

	// set surfacecaps to specify an attached backbuffer
	memset (&surfaceCaps,0,sizeof(surfaceCaps));
	surfaceCaps.dwCaps  = DDSCAPS_BACKBUFFER;
	
	// get the attached primarysurface into m_secondary
	if (m_primary->GetAttachedSurface(&surfaceCaps, &m_secondary) != DD_OK)
		throw DeviceException("Could not receive attached surface!");
}

// ====================================================================================
