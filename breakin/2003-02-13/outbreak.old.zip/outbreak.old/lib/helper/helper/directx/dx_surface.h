#ifndef __AURORA_DIRECTX_SURFACE__
#define __AURORA_DIRECTX_SURFACE__

/*=============================================================================
= Helper Library. (c) Outbreak 2001											  
===============================================================================
	
 @ Responsible	: Tooon
 @ Class		: DirectDrawImage
 @ Derived		: BaseImage32
 @ Brief		: DirectDraw surface, wrapper based on BaseImage32 - using the same 
				  interface.
				  Totally encapsulates all functionallity of a directDraw suface and provides an
				  common interface which makes it possible to use DirectDrawImage with all tools
				  able to perform work on BaseImage32 objects.

 @ Features
 
  * Different configuration based on window or fullscreen modes
  * interal locking mechanism hidden from user
  * 2 backbuffers switched/ flipped each frame

================================================================================*/

#include <ddraw.h>
#include "..\core\baseimage32.h"
#include "..\core\debug\debug.h"
#include "..\core\pixelformat.h"

namespace Helper {

class DirectDrawImage : public BaseImage32
{
	public:
		
		DirectDrawImage() : 

		    m_locked(false)   ,
			m_active(false)   ,
			m_primary(NULL)   ,
			m_secondary(NULL) ,
			m_clipper(NULL)   ,
			m_initialized(false) {

				Debug::logSystem("DirectDrawImage::DirectDrawImage()","Constructing...");
			}

		~DirectDrawImage();

		void initialize(LPDIRECTDRAW7 directDraw, HWND clipWindow = NULL);
		void fullscreen(bool fullscreen);

		// create and resize ddsurface
		void resize(const int width, const int height);
		void clear();
		
		// directdraw surfaces needs to be locked
		// and unlocked before access to pixel data
		void  lock() const;
		void  unlock() const;

		// flip primary and backbuffer
		void flip();

		// override getpixels
		uint32* get();
		const uint32 * const get() const;

		const AreaInt& getArea() const { return m_area; }
		const int  getWidth()  const { return m_width; }
		const int  getHeight() const { return m_height;}
		const int  getPitch()  const { return m_pitches[m_currentBackbuffer]; }	

		
	private:
		
		// creates a windowed/fullscreen surface depending
		// if the m_fullscreen flag is set
		void createSurfaceWindowed(int width, int height);
		void createSurfaceFullscreen(int width , int height);

		LPDIRECTDRAW7		 m_directDraw;
		LPDIRECTDRAWSURFACE7 m_primary;
		LPDIRECTDRAWSURFACE7 m_secondary;
		LPDIRECTDRAWCLIPPER  m_clipper;
		HWND				 m_hwnd;
		bool				 m_initialized;
		bool				 m_fullscreen;
		bool				 m_hasClipper;
		bool				 m_active;
		mutable bool		 m_locked;
		mutable void*		 m_data;
		int					 m_width;
		int					 m_height;
		int					 m_pitches[2];
		int					 m_currentBackbuffer;
		PixelFormat			 m_pixelFormat;
		AreaInt				 m_area;
};


}


#endif
