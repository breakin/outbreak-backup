#ifndef __AURORA_DIRECTX_DEVICE2D__
#define __AURORA_DIRECTX_DEVICE2D__

/*===========================================================================
= Helper Library. (c) Outbreak 2001
=============================================================================
	
 @ Responsible	: Tooon
 @ Class		: DirectDrawDevice2d
 @ Brief		: HighLevel GUI device based upon DirectDraw.
 
=============================================================================*/

#include "..\core\point.h"
#include "..\core\device2d.h"
#include "..\core\imagedrawer\imagedrawer.h"
#include "..\win32\win32_window.h"
#include "dx_surface.h"
#include "dx_ddraw.h"

namespace Helper {

class DirectDrawDevice2D : public Device2D
{
	public:
		
		DirectDrawDevice2D();
		virtual ~DirectDrawDevice2D();

		/**
		 * Open/Close device
		 */
		void open();
		void close();

		// update device's backbuffer to screen (flip), 
		// if forceScreenUpdate = true, always flip even if screen hasn't changed
		void	update(bool forceScreenUpdate=true, bool waitSysEvent = false);
		
		// Get device Properties
		int  getWidth() const { return m_width; }
		int  getHeight()const { return m_height;}
		int  getPitch() const { return m_pitch;	}
		void getPixelFormat(PixelFormat &pixelFormat) const {pixelFormat = m_pixelFormat; }
		
		// returns the current mouseposition inside the clientarea
		PointInt getMousePosition() const;
		void setMousePosition(const PointInt &p) { m_window.setMousePosition(p); }
	
		// get devices backbuffer
		BaseImage32& getBackBuffer();
		
		// get display modes supported / overridden
		const DisplayModeList& getDisplayModeList() const;

	protected:
		
		// bit conversion methods
		void convert32to15(uint8 *src, int width, int height, int pitch);
		void convert32to16(uint8 *src, int width, int height, int pitch);
		void convert32to24(uint8 *src, int width, int height, int pitch);

		// creates a 32bpp software buffer
		void createSoftwareBackBuffer();
	
		// resets all properties to default
		void reset();
		
		/**
		 * CDirectDrawDevice2D properties
		 */
		int					m_width;			///< Width of device
		int					m_height;			///< Height of device
		int					m_pitch;			///< Pitch of backbuffer
		bool				m_caption;			///< Has Caption flag
		bool				m_opened;			///< Open flag
		bool				m_fullscreen;		///< Fullscreen flag
		std::string			m_title;			///< Device's title
		PixelFormat			m_pixelFormat;		///< PixelFormat
		ImageDrawer			m_blitter;			///< blitter
		Win32Window			m_window;			///< Win32 Window
		DirectDrawImage 	m_backBuffer;		///< Hardware backbuffer
		DirectDraw			m_directDraw;		///< DirectDraw interface object
		Image32*			m_swBackBuffer;		///< Software guaranteed to be 32 bpp, used when device is set to other than 32bpp
		static int			m_openDeviceRef;	///< Reference counter of opened devices
		DisplayMode			m_currentDisplayMode; ///< Currenly set displaymode
};

//====================================================================================================



//====================================================================================================

}

#endif