#ifndef __AURORA_DIRECTDRAW_INC__
#define __AURORA_DIRECTDRAW_INC__

/*===========================================================================
= Helper Library. (c) Outbreak 2001
=============================================================================
	
 @ Responsible	: Tooon
 @ Class		: DirectDraw
 @ Brief		: Wrapper for loading and setting up DirectDraw COM interfaces
				  and the basic functionallity which they provide. 
				  DirectDraw is NOT dependant on any static import library, it 
				  excplicitly loads ddraw.dll and queries for IIDDirectDraw7.

 @ Features
 
  * Get/Set DisplayMode for both exclusive(fullscreen) and normal(windowed) modes 
  * Enumerating all driversupported displaymodes				   

============================================================================= */

#include <ddraw.h>
#include "..\core\debug\debug.h"
#include "..\core\displaymode.h"

namespace Helper {

class DirectDraw
{
	public:

		// constructor
		DirectDraw() : m_active(false), m_exclusive(false), m_directDraw7(NULL), m_directDraw(NULL) {

			m_dllRef++;
			Debug::logSystem("DirectDraw::DirectDraw()","Construcing instance[%d]...",m_dllRef); 
		};
		
		// destructors
		~DirectDraw();
		
		// Exports and create DDraw Interfaces
		void create();
		void release();
		
		// DDraw methods called through ddraw interfaces
		void setDisplayMode(int width, int height, int bpp);
		
		// Tests the width, height and bpp 
		// returns true and sets displayMode parameters in <displayMode>
		bool testDisplayMode(int32 width, int32 height, int32 bpp, DisplayMode &displayMode);
		
		// set cooperative level.
		void setCooperativeLevel(bool exclusive, HWND hwnd);
		
		// get direct draw
		LPDIRECTDRAW7 getDirectDraw7() const { return m_directDraw7;}

		// get displaymodes
		const DisplayModeList& getDisplayModes() const { return m_displayModes; }

		// access and initalization checks 
		bool isExclusive() const { return m_exclusive; }
		bool isLoaded() const { return m_dllLoaded; }

		// callback
		static HRESULT WINAPI enumDisplayCallBack(LPDDSURFACEDESC2 lpSurfaceDesc, LPVOID data);

	private:
		
		// sorts displaymodes by bitdepth and pixeldimensions
		void sortDisplayModes();

		// Loads and unloads DLL 
		void load();
		void unload();

		// only 1 dll mapped into address space
		static	bool			m_dllLoaded;		// true if dll is loaded into address space
		static  HMODULE			m_dllHandle;		// handle to ddraw.dll
		static  int				m_dllRef;			// lib reference counter;
		
		// instant specific vars
		bool					 m_active;			// true if interfaces has been created
		bool					 m_exclusive;		// exclusive Windows access
		LPDIRECTDRAW7			 m_directDraw7;		// direct draw interfaces
		LPDIRECTDRAW			 m_directDraw;
		HWND					 m_hwnd;
		std::vector<DisplayMode> m_displayModes;		///< Driver supported displaymodes
		
};


}


#endif
