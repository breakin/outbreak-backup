#ifndef __WIN32_CURSOR_H__
#define __WIN32_CURSOR_H__

/*===========================================================================
= Helper Library. (c) Outbreak 2001
=============================================================================
	
 @ Responsible : Tooon
 @ Class       : Win32 cursor
 @ Brief       : Used for turning the cursor on/off in any application

 @ Features : 

 * None worth bragging with 

 @ Todo :
 
 * May be useful to be able to change cursor bitmap as well.

============================================================================= */

#include <windows.h>

//================================================================================
// Cursor class
//================================================================================

class Win32Cursor
{
	
	public:
			
		static void show()
		{
			if (!m_visible)
			ShowCursor(true);
		}

		static void hide()
		{
			if (m_visible)
			ShowCursor(false);
		}


	protected:
		
		static bool m_visible;
};


// declare static member, set to visible as default
bool Win32Cursor::m_visible = true;


#endif
