#ifndef __WIN32_SURFACE__
#define __WIN32_SURFACE__

/*===========================================================================
= Helper Library. (c) Outbreak 2001
=============================================================================
	
 @ Responsible	: Tooon
 @ Class		: Win32Image
 @ Built upon	: BaseImage32 interface
 @ Brief		: Win32 GDI version a graphical device backbuffer

 @ Features : 

 * -

 @ Todo :
 
 * -

============================================================================= */

#include <windows.h>
#include "..\core\typedefs.h"
#include "..\core\baseimage32.h"
#include "..\core\pixelformat.h"

namespace Helper {

class Win32Image : public BaseImage32
{
	
	public:
	
		Win32Image(int width, int height);
		Win32Image();
		~Win32Image();

		/**
		 * Methods overriden from CSurface
		 */
		void    resize(const int width, const int height);
		void    clear();
		
		const int getWidth()  const { return m_width; }
		const int getHeight() const { return m_height; }
		const int getPitch()  const { return m_pitch; }
		const AreaInt& getArea() const { return m_area;}
		/**
		 * Methods for receiving pixel data
		 */
		uint32* get() { return m_data; }
		const uint32 * const get() const { return m_data; }

		/**
		 * CWin32Surace specific methods,
		 * Blt draws the surface on a Window's DeviceContext
		 */
		void    blt(HWND destWindow, int xpos=0, int ypos=0);
		HBITMAP	getBitmap() const { return m_bitmapHandle; }	

	protected:

		/**
		 * CWin32Surface properties
		 */
		HBITMAP m_bitmapHandle;		// handle to hitmap containing DIB Section
		bool    m_active;					// flag set if created
		int		m_width;
		int		m_height;
		int		m_pitch;
		AreaInt	m_area;
		uint32 *m_data;
};


}// end namespace Aurora


#endif
