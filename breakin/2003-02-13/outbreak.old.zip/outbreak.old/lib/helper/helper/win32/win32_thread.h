#ifndef __THREAD_H__
#include <windows.h>
#include <windowsx.h>

namespace Helper {

// thread router function
DWORD WINAPI Win32ThreadRouter(LPVOID threadInstance);
	
// class Win32Thread
class Win32Thread
{

	public:
		
		Win32Thread()
		{
			m_threadPriority= THREAD_PRIORITY_NORMAL;
			m_isRunning			= false;
			m_threadID			= 0;
			m_threadHandle	= NULL;
		}
		
		~Win32Thread()
		{
			if (m_isRunning) stop();
		}

		virtual void run()=0;
		virtual void start();
		virtual void stop();		
		
		void setThreadPriority(DWORD _priority);

	protected:
	
		bool    m_isRunning;
		DWORD		m_threadID;
		DWORD   m_threadPriority;
		HANDLE	m_threadHandle;
};

}// end namespace Aurora

#endif
