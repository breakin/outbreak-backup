#include "win32_image.h"

//============================================================================
// use namespace Aurora
//============================================================================
using namespace Helper;

//============================================================================
// Win32Image methods implementations
//============================================================================

Win32Image::Win32Image()
{
	m_active = false;
	m_width  = 0;
	m_height = 0;
	m_pitch  = 0;
	m_data   = NULL;
}

//============================================================================

Win32Image::Win32Image(int width, int height)
{
	m_active = false;
	resize(width, height);
}

//============================================================================

Win32Image::~Win32Image()
{
	clear();
}

//============================================================================

void Win32Image::resize(const int width, const int height)
{	
	BITMAPINFO bmi;

		//m_pixelFormat.set(PixelFormat::BPP_32);
		if (m_active) clear();

		if (!m_active)
		{
			// update surface caps
			m_width  = width;
			m_height = height;
			m_pitch  = m_width<<2;
			
			// fill in bitmap info
			bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
			bmi.bmiHeader.biClrImportant = 0;
			bmi.bmiHeader.biClrUsed	= 0;
			bmi.bmiHeader.biBitCount = 32;
			bmi.bmiHeader.biCompression = BI_RGB;
			bmi.bmiHeader.biWidth = width;
			bmi.bmiHeader.biHeight = -height; // negate height to get DIB pixels top down order
			bmi.bmiHeader.biPlanes = 1;
			bmi.bmiHeader.biSizeImage = 0;
			bmi.bmiHeader.biXPelsPerMeter = 0;
			bmi.bmiHeader.biYPelsPerMeter = 0;
			
			// create DIB section and save bitmap handle returned
			m_bitmapHandle = CreateDIBSection(NULL,&bmi,DIB_RGB_COLORS,(void**)&m_data,NULL,0);
			
			m_active = true;
		}

}

//============================================================================

void Win32Image::clear()
{
	if (m_active)
	{
		DeleteObject(m_bitmapHandle);
		m_active = false;
	}
}

//============================================================================

void Win32Image::blt(HWND destWindow, int xpos, int ypos)
{
	HDC			memDC;
	HDC			wndDC;
	HBITMAP	oldBitmap;

		// get destination window's devicecontext and 
		// create a memory dc - compatible with destwindow's.
		wndDC = GetDC(destWindow);
		memDC = CreateCompatibleDC(wndDC);
	
		// select DIB Bitmap into memory device context
		oldBitmap = (HBITMAP)SelectObject(memDC,m_bitmapHandle);

		// Blt the pixels..
		BitBlt(wndDC,xpos,ypos,m_width,m_height,memDC,0,0,SRCCOPY);

		// select back the old bitmap into the memdc before delete it
		SelectObject(memDC,oldBitmap);

		// delete and release device contexts
		DeleteDC(memDC);
		ReleaseDC(destWindow,wndDC);
}

//============================================================================
//============================================================================
