
#include <helper/helper.h>
#include <conio.h>

using namespace Helper;

/*
	This is a test for the music class. Currently setTimer is behaving very
	strange so the code is kinda weird below. Oh well =)

	Breakin
*/

void main(void) {

	try {

		Music music;
		music.load("test.mp3");

		music.play();

		while (music.getTimer()==0) Sleep(1);

		bool set=false;

		while (!kbhit()) {

			if (set) std::cout << "After: ";
			std::cout << music.getTimer() << std::endl;

			Sleep(10);
			
			if (music.getTimer()>10.0) {

				music.setTimer(1.0);
				
				set=true;
			}
		}

	}

	catch (const Helper::Exception &e) {
		std::cout << "ERROR: " << e.what() << std::endl;
	}
}