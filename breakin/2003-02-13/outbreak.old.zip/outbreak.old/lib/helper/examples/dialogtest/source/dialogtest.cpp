#include <helper\helper.h>
#include <helper\directx\dx_device2d.h>
//#include <helper\win32\win32_device2d.h>
#include <helper\core\dialog\font\font.h>
#include <helper\core\dialog\frames\frame.h>
#include <helper\core\dialog\items\imagebutton.h>
#include <helper\core\dialog\items\checkbox.h>
#include <helper\core\dialog\items\radiobutton.h>
#include <math.h>
#include "windows.h"

using namespace Helper;
using namespace std;

// Winmain
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {

	try {
	
	DirectDrawDevice2D gui;
	//Win32Device2D gui;
	gui.config("width", "512");
	gui.config("height", "384");
	gui.config("title", "Dialog test");
	gui.config("bpp", "32");
	gui.config("caption", "true");
	gui.config("fullscreen", "false");

	gui.open();

	ImageDrawer imageDrawer;

	Font font;
	Image32 fontTexture;
	ArchiveDirectory ad(".");
	ad.load(fontTexture, "trebuchet30pix.tga");
	font.createFont(fontTexture, 3);
	font.setColor(0xffff00);

	BaseImage32& screen = gui.getBackBuffer();
	imageDrawer.clear(screen, screen.getArea());
	Msg msg;

	Clock clock;

	// Dialog stuff
	Image32 background(512,384);
	uint32* pixels = background.get();
	for (int i=0; i<background.getWidth()*background.getHeight(); i++) {
		pixels[i] = 0xffaaaaaa;
	}

	ArchiveDirectory archive("dialog2");

	Frame frame;
	frame.setArea("Mainframe", screen.getArea());
	frame.setOwnBackground(background);
	frame.init(imageDrawer, archive);
	
	Frame frame2;
	frame2.setArea("Frame 1", AreaInt(110,70));
	frame2.init(imageDrawer, archive);
	frame.add(&frame2);

	ImageButton runDemo;
	runDemo.setArea("run demo", AreaInt(88,167));
	runDemo.setImageNormal(ArchiveDirectory("."), string("buttonRunDemoNormal.tga"));
	runDemo.setImageHighlight(ArchiveDirectory("."), string("buttonRunDemoHighlight.tga"));
	frame2.add(&runDemo);

	Checkbox sound;
	sound.setArea("sound checkbox", AreaInt(138,108));
	frame2.add(&sound);
	sound.setSelected(true);

	Checkbox fullscreen;
	fullscreen.setArea("fullscreen checkbox", AreaInt(138,92));
	frame2.add(&fullscreen);

	RadioButton radioButton;
	radioButton.setArea("640x480", AreaInt(16,93));
	radioButton.setArea("512x384", AreaInt(16,109));
	radioButton.setArea("400x300", AreaInt(16,125));
	frame2.add(&radioButton);
	
	std::string strresolution;
	std::string strfullscreen;
	std::string strsound;

	float64 started = clock.get();
	uint32  frames  = 0;

		bool yepp = false;

		while (true) {
			float64 fps = frames / (clock.get() - started);
			frames++;

			char fpsString[100];
			sprintf(fpsString, "Current fps:%.2f", fps);

			if (gui.getMessage(msg)) {
				// If close (alt+f4 or menu->close in windowed mode)
				if (msg.message == Helper::Msg::MSG_CLOSE) break;

				// Log key events
				if (msg.message == Helper::Msg::MSG_KEYDOWN) {
					Debug::log("WinMain()", "Key param:%d, extra:%d", msg.param, msg.extra);

					// If escape, really escape :-)
					if (msg.param == 27) {
						break;
					}
				}

				std::string ret = frame.processEvent(msg, screen.getArea());
				Debug::log("Main()", "ret=%s.", ret.c_str());

				if (ret == "run demo") {
					yepp = true;	
					break;
				}
			}

			// Update gui and save changed area.
			AreaInt changedArea = frame.update(gui.getMousePosition(), frame.getArea());

			//imageDrawer.clear(screen, screen.getArea(), ImageDrawer::CLEAR_RGB);
			uint32* pixels = screen.get();
			uint32  nr = screen.getWidth()*screen.getHeight();

			if (!changedArea.isEmpty()) {
				frame.draw(screen, screen.getArea(), changedArea);

				// Draw invalidated area
				uint32 color = ((rand()%255)<<16) + ((rand()%255)<<8) + (rand()%255);

				for (int x=changedArea.getLeft(); x<changedArea.getRight(); x++) {
					pixels[(changedArea.getTop()*screen.getWidth())+x] = color;
					pixels[((changedArea.getBottom()-1)*screen.getWidth())+x] = color;
				}

				for (int y=changedArea.getTop(); y<changedArea.getBottom(); y++) {
					pixels[(y*screen.getWidth())+changedArea.getLeft()] = color;
					pixels[(y*screen.getWidth())+changedArea.getRight()-1] = color;
				}
			}		
			
			// Clear behind font
			for (int y=0, offset=0; y<30; y++, offset+=(screen.getWidth()-170)) {
				for (int x=0; x<170; x++, offset++) {
					pixels[offset]=0xff;
				}
			}
			font.draw(screen, 3,-5, fpsString);
			gui.update();
		}

		strresolution = radioButton.getSelected();
		if (fullscreen.getSelected()) {
			strfullscreen = "yes";
		} else {
			strfullscreen = "no";
		}
		if (sound.getSelected()) {
			strsound = "yes";
		} else {
			strsound = "no";
		}

		char a[200];
		sprintf(a, "The user selected %s as resolution, sound:%s, fullscreen:%s.", strresolution.c_str(), strsound.c_str(), strfullscreen.c_str());

		if (yepp)
			MessageBox(NULL, a, "User information", MB_OK);

	} catch (Exception& exception) {
		MessageBox(NULL, exception.what(), "Error", MB_OK);
	} catch (...) {
		MessageBox(NULL, "Unrecognized error!", "Error", MB_OK);
	}

	return 0;
}
