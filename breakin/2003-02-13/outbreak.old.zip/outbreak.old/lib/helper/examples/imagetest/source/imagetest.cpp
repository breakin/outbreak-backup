
#include <helper/helper.h>

using namespace Helper;

void main(void) {

	try {

		ImageTool it;
		
		ArchiveRAR input("images.rar");
		ArchiveDirectory output("result");
		
		Image32 inputImage=it.decode(input.getFile("test24.jpg"));
		output.createFile("out_test24.jpg.tga", it.encode(inputImage, "tga"));
		output.createFile("out_test24.jpg.jpg", it.encode(inputImage, "jpg"));

		inputImage=it.decode(input.getFile("testgrey.jpg"));
		output.createFile("out_testgrey.jpg.tga", it.encode(inputImage, "tga"));
		output.createFile("out_testgrey.jpg.jpg", it.encode(inputImage, "jpg"));	
	}

	catch (const Helper::Exception &e) {
		std::cout << "ERROR: " << e.what() << std::endl;
	}
}