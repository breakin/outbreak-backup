#ifndef __EFFECTS_GRID_INC__
#define __EFFECTS_GRID_INC__

#include <helper\core\typedefs.h>
#include <helper\core\image32.h>
#include <math\e3d_vector.h>

using namespace Helper;
using Eternity::CVector3d;

//============================================================================

struct ZBuffer {

	ZBuffer (int width, int height) {
	
		data = new uint32[width * height];
		this->width = width;
		this->height = height;
		memset(data,0, sizeof(int) * width * height);
	}
	
	~ZBuffer() {

		delete[] data;
	}
	void update() {

		frame++;

		if (frame > 65535) {

			memset(data,0, sizeof(uint32) * width * height);
			frame = 0;
		}
	}

	uint32*	data;
	int32	frame;
	int32	width;
	int32	height;
};

//============================================================================

struct Vertex {
	
	Vertex() : orig(0.0f,0.0f,0.0f), normal(0.0f,0.0f,0.0f), faceCount(0) {} 
	
	CVector3d orig;
	CVector3d trans;
	CVector3d normal;
	int		  faceIndexes[8];
	int		  faceCount;
};

//============================================================================

struct Pixel {

	int32 x;
	int32 y;
	int32 c;
};

//============================================================================

struct Face {

	int			v1;
	int			v2;
	int			v3;
	CVector3d	normal;
};

//============================================================================

struct Camera {
	
	float32 z;
	float32 focalLength;
	float32 fov;
};


//============================================================================

struct Light {

	CVector3d	position;
	CVector3d	direction;
	CVector3d	color;
	float32		intense;
	float32		attenuation;
};

//============================================================================

class Grid 
{
public:

	Grid(int x = 20, int y = 20, int cellSpace = 8);
	~Grid();
	
	void create(int x, int y, int cellSpace);
	void release();
	int width() const { return m_width;}
	int height() const { return m_height; }
	void cellSpace(int cellSpace);
	void moveAround(float deg);
	void render(BaseImage32 &image, const Camera &camera, const Light &light, ZBuffer &zbuffer);
	void setTexture(BaseImage32 &image);

private:
	
	void calcVertexNormals();
	void calcFaceNormals();
	void drawLine(BaseImage32 &dest, int32 x1, int32 y1, int32 x2, int32 y2,  uint32 attr1, uint32 attr2);	
	void makeFaces();
	void makeFace(int squareID, int v1, int v2, int v3, int v4);
	void fillFace(int c, BaseImage32 &screen, ZBuffer &zbuffer);
	
	Face*			m_face;
	Vertex*			m_data;
	Vertex*			m_trns;
	Pixel*			m_scrn;
	int				m_width;
	int				m_height;
	BaseImage32*	m_texture;
	int				m_cellSpace;
	int				m_faceCount;
};

//============================================================================

#endif
