#include "grid.h"
#include <math.h>
#include <helper\directx\dx_device2d.h>
#include <helper\win32\win32_device2d.h>
#include <helper\core\image32.h>
#include <helper\core\imagedrawer\imagedrawer.h>
#include <helper\core\imagetool\imagetool.h>
#include <helper\core\archive\archivedirectory.h>

#define GRID_WIDTH  10
#define GRID_HEIGHT 10

float32 *bendMask;

#define MASK_SIZE  (sizeof bendMask / sizeof(int)) 


// =================================================================================================

void darkenImage(BaseImage32 &image, float);

// =================================================================================================

void drawLine2(BaseImage32 &dest, int32 x1, int32 y1, int32 x2, int32 y2, uint32 attr1, uint32 attr2);

// =================================================================================================

void blur32(BaseImage32 &image);

// =================================================================================================

void generateLense(BaseImage32 &image);

// =================================================================================================
int WINAPI WinMain(HINSTANCE hInstance , HINSTANCE pPrevInstace, LPSTR cmdLine, int show) {
	
try {
		
	// appl. objects
	DirectDrawDevice2D	device;
	Msg					msg;
	ImageDrawer			drawer;
	Image32				texture;
	float32				deg = 0;
	float32				degadd = 0.004f;
	bool				run = true;
	Grid				grid (20,20,20);
	Camera				camera;
	Light				light;
	ArchiveDirectory	a(".");
	ImageTool			tool;
	ZBuffer				zbuffer(640, 480);
	
	bendMask = new float32[20 * 18];

	// setup bendmask
	#define LINE(x) 20 * x
	#define HIGHGRADE 60.0
	
	memset(bendMask,0,sizeof(float32)*(20*18));

	DisplayMode mode;

	for (int i= 0; i < device.getDisplayModeList().size(); i++) {

		mode = device.getDisplayModeList()[i];
		Debug::log("GRID", "%d, %d, %d", mode.width, mode.height, mode.bpp); 
	}
	// setup device
	device.config("width","640");
	device.config("height","480");
	device.config("bpp","32");
	device.config("fullscreen","false");
	device.config("title", "Grid Effect");
	device.open();

	// get device's backbuffer
	BaseImage32 &backBuffer = device.getBackBuffer();
	
	//texture = tool.decode(a.getFile("tunnel2.jpg"));
//	texture = tool.decode(a.getFile("tunnel2.jpg"));
	a.load(texture, "texture10.JPG");

	grid.setTexture(texture);
	// set camera focal length
	camera.focalLength = 1.0f / tanf(60.0f * 3.1415f / 180.0f);
	
	// set light;
	light.position.make(0,0,-300);
	light.direction.make(0,0,-400);
	
//	darkenImage(texture,0.45);

	while (run) {
		
		if (device.getMessage(msg,true)) {

			switch (msg.message) {

			case Msg::MSG_CLOSE:
			case Msg::MSG_KEYDOWN:
			run = false;
			}
		}
		
		light.intense = 255.0;//+ sin(deg) * cos(deg) * 54;
		light.position.x = 200;
		light.attenuation = 600;
		camera.z = -160.0f;
		deg += degadd;

		grid.moveAround(deg);
		grid.render(backBuffer, camera, light,zbuffer);
		device.update();
		blur32(device.getBackBuffer());
		//drawer.clear(device.getBackBuffer(),backBuffer.getArea());
		zbuffer.update();
	}
}
catch (exception &e) {

	MessageBox(NULL, e.what(), "EXCEPTION!!", MB_OK);
}
	
delete[] bendMask;
	  return 1;
}

//==========================================================================

Grid::Grid(int x, int y, int cellSpace) : m_scrn(NULL), m_trns(NULL), m_data(NULL), m_width(0), m_height(0) {
	
	if (x && y)
		create(x,y,cellSpace);
}

//==========================================================================

Grid::~Grid() {

	release();
}

//==========================================================================

void Grid::create(int x, int y, int cellSpace) {

	if (m_data)
		release();

	m_data   = new Vertex[x * y];
	m_scrn   = new Pixel [x * y];
	m_width  = x;
	m_height = y;
	m_cellSpace = cellSpace;

	float originX	= -((m_width *cellSpace) / 2);
	float originY	= -((m_height*cellSpace) / 2);
	float gox		= -(m_width  / 2);
	float goy		= -(m_height / 2);

	for (int i = 0; i < y ; i++) {

		for (int j = 0; j < x ; j++) {
		
			m_data[i * m_width + j].orig.x = originX + (float32)(j * m_cellSpace);
			m_data[i * m_width + j].orig.y = originY + (float32)(i * m_cellSpace);
			m_data[i * m_width + j].orig.z = 1.0f;
			float fx = (float)(gox + j) / (float)m_width;
			float fy = (float)(goy + i) / (float)m_height;
            
			//m_data[i * m_width + j].normal.x = 
			//m_data[i * m_width + j].normal.y = 
            
			float fd = 1.0 - sqrtf(fx * fx + fy * fy);

			m_data[i * m_width + j].orig.w = (fd < 0.0f) ? 0.0f : fd;		
			m_data[i * m_width + j].faceCount = 0;
		}
	}
	
	makeFaces();
}

//==========================================================================

void Grid::setTexture(BaseImage32 &image) {

	m_texture = &image;
}

//==========================================================================

void Grid::release(){

	if (m_data)
		delete[] m_data;

	if (m_scrn)
		delete[] m_scrn;
	
	if (m_face)
		delete[] m_face;

	m_width  = 0;
	m_height = 0;
	m_data = NULL;
	m_scrn = NULL;
	m_face = NULL;
}

//==========================================================================

void Grid::cellSpace(int cellSpace) {

	m_cellSpace = cellSpace;
}

//==========================================================================

void Grid::moveAround(float deg) {
	
	DEBUG_ASSERT(m_data != NULL)
	DEBUG_ASSERT(m_trns != NULL)
	DEBUG_ASSERT(m_scrn != NULL)

	int offs = 0;
/*	int i = 0;

	// copy all from data to trns
	while (i < m_width * m_height) {

		float dist = m_data[i].orig.w;
		m_data[i].trans.x = m_data[i].orig.x + dist * sin(deg) * 30.0;
		m_data[i].trans.y = m_data[i].orig.y + dist * cos(deg) * 40.0;
		m_data[i].trans.z = m_data[i].orig.z;
		++i;
	}
	
	for (int j = 0; j < MASK_SIZE; j++) {

		float dist = m_data[bendMask[j]].orig.w;
		float dist2 = dist * dist;
	
		m_data[bendMask[j]].trans.z	= m_data[bendMask[j]].orig.z + dist2 * 192.0  * sin(deg + sin(dist2 * dist)/* * dist2 * sin(dist)*///NEW) * cos(deg + dist/* * dist*/);
	//}
	
	float dispFact = 210.0;

	for (int i = 0; i < m_height; i++) {

		for (int j = 0; j < m_width; j++) {
			
			float dist = m_data[offs + j].orig.w;
			float dist2 = dist * dist;

			m_data[offs + j].trans.x	= m_data[offs + j].orig.x + dist2 * sin(deg) * dist2 * 40.0;
			m_data[offs + j].trans.y	= m_data[offs + j].orig.y + dist2 * cos(deg) * dist * 40.0;
			
			dispFact = 250 ;//+ bendMask[offs + j];
			//if ((j & 0x03) && (i & 0x03))
			// m_data[offs + j].trans.z	= m_data[offs + j].orig.z + (dist2 * dispFact - (sin(dist2) * 60.0)) * sin(deg + sin(dist2 * dist)/* * dist2 * sin(dist)*/) * cos(deg + dist/* * dist*/);
			m_data[offs + j].trans.z	= m_data[offs + j].orig.z + dist2 * 220.0  * sin(deg + sin(dist2 * dist)/* * dist2 * sin(dist)*/) * cos(deg + dist/* * dist*/);
		}	

		offs += m_width;
	}

	calcFaceNormals();
	calcVertexNormals();
}

//==========================================================================

void Grid::calcVertexNormals() {

	for (int i = 0; i < (m_width * m_height); i++) {

		m_data[i].normal.make(0,0,0);

		for (int j = 0; j < m_data[i].faceCount; j++) {
	
			m_data[i].normal += m_face[m_data[i].faceIndexes[j]].normal;
		}
		
		m_data[i].normal *= (1.0f / (float32)m_data[i].faceCount);
	}
}

#define PACK_RGB(x) ((x << 16) | (x << 8) | x)
#define RGB_TO_R(x) ((x >> 16) & 0xff)
#define RGB_TO_G(x) ((x >> 8 ) & 0xff)
#define RGB_TO_B(x) ((x) & 0xff)

void Grid::render(BaseImage32 &image, const Camera &camera, const Light &light, ZBuffer &zbuffer) {

	int32		n		= 0;
	int32		size	= m_width * m_height;
	int32		width	= image.getWidth()  >> 1;
	int32		height  = image.getHeight() >> 1;
	int32		wDiv	= (width  << 16);
	int32		hDiv	= (height << 16);
	CVector3d	lightVector;
	float		 maxz = 145.0;

	float32 recipAttenuation = 1.0 / light.attenuation;
	
	while (n < size) {

		m_scrn[n].x = wDiv + width  * ((m_data[n].trans.x * camera.focalLength / (m_data[n].trans.z - camera.z)) * 65536.0);
		m_scrn[n].y = hDiv + height * ((m_data[n].trans.y * camera.focalLength / (m_data[n].trans.z - camera.z)) * 65536.0);
		m_scrn[n].c = 0x000000;
		
		lightVector = light.position - m_data[n].trans;
		float32 lightLength = lightVector.getLength();
		
		if (lightLength < light.attenuation) {
		
			lightVector.normalize();
			
			float l = (m_data[n].normal * lightVector);
			
			if (l > 0) {

				m_scrn[n].c = (uint32) ((1.0 - lightLength * recipAttenuation) * l * l * light.intense) & 0xff;
				m_scrn[n].c = PACK_RGB(m_scrn[n].c);
			}
		}

		n++;
	}

	int offs  = 0;	

	for (int i = 0; i < m_faceCount; i++) {
			
			fillFace(i, image, zbuffer);
			
			/*drawLine(image, m_scrn[m_face[i].v1].x,
							m_scrn[m_face[i].v1].y,
							m_scrn[m_face[i].v2].x,
							m_scrn[m_face[i].v2].y,
							m_scrn[m_face[i].v1].c,
							m_scrn[m_face[i].v2].c);

			drawLine(image, m_scrn[m_face[i].v2].x,
							m_scrn[m_face[i].v2].y,
							m_scrn[m_face[i].v3].x,
							m_scrn[m_face[i].v3].y,
							m_scrn[m_face[i].v2].c,
							m_scrn[m_face[i].v3].c);

			drawLine(image, m_scrn[m_face[i].v3].x,
							m_scrn[m_face[i].v3].y,
							m_scrn[m_face[i].v1].x,
							m_scrn[m_face[i].v1].y,
							m_scrn[m_face[i].v3].c,
							m_scrn[m_face[i].v1].c);*/
	
	
		
	}
/*
	for (int j = 0; j < m_height -1; j++) {

		for (int i = 0; i < m_width - 1; i++) {
			
			
 			drawLine(image, m_scrn[offs + i	].x,
							 m_scrn[offs + i	].y,
							 m_scrn[offs + i + 1].x,
							 m_scrn[offs + i + 1].y,
							 m_scrn[offs + i].c,
							 m_scrn[offs + i + 1].c);
		
			drawLine(image, m_scrn[offs + i	].x,
							 m_scrn[offs + i	].y,
							 m_scrn[offs + m_width + i].x,
							 m_scrn[offs + m_width + i].y,
							 m_scrn[offs + i].c,
							 m_scrn[offs + m_width + i].c);
		}
		
		offs += m_width;
	}

*/  
}

//==========================================================================

#define FIXED_CEIL(x) ((((x + 0xffff) >> 16) << 16))

void Grid::fillFace(int c, BaseImage32 &screen, ZBuffer &zbuffer) {
	
	uint32 *text  = (uint32*)m_texture->get();
	uint32 *pixel = (uint32*)screen.get();
	float32 deg = (-1 * m_face[c].normal.z);
	
	if (deg < 0)
		return;

	uint32 shade;
	int32 sy1, sy2, sy3;
	int32 y1, y2, y3;
	int32 x1, x2, x3;
	int32 u1, u2, u3;
	int32 v1, v2, v3;
	int32 r1, r2, r3;
	int32 g1, g2, g3;
	int32 b1, b2, b3;
	int32 z1, z2, z3;
	int32 dvdx; 
	int32 dudx;
	int32 drdx;
	int32 dgdx;
	int32 dbdx;
	int32 dx;
	
	// fetch needed vars.
	r1 = RGB_TO_R(m_scrn[m_face[c].v1].c) << 16;
	r2 = RGB_TO_R(m_scrn[m_face[c].v2].c) << 16;
	r3 = RGB_TO_R(m_scrn[m_face[c].v3].c) << 16;
	g1 = RGB_TO_G(m_scrn[m_face[c].v1].c) << 16;
	g2 = RGB_TO_G(m_scrn[m_face[c].v2].c) << 16;
	g3 = RGB_TO_G(m_scrn[m_face[c].v3].c) << 16;
	b1 = RGB_TO_B(m_scrn[m_face[c].v1].c) << 16;
	b2 = RGB_TO_B(m_scrn[m_face[c].v2].c) << 16;
	b3 = RGB_TO_B(m_scrn[m_face[c].v3].c) << 16;
		
	z1 = ((65536.0f / m_data[m_face[c].v1].trans.z) * 65536.0f);
	z2 = ((65536.0f / m_data[m_face[c].v2].trans.z) * 65536.0f);
	z3 = ((65536.0f / m_data[m_face[c].v3].trans.z) * 65536.0f);

	y1 = m_scrn[m_face[c].v1].y;
	y2 = m_scrn[m_face[c].v2].y;
	y3 = m_scrn[m_face[c].v3].y;
	
	x1 = m_scrn[m_face[c].v1].x;
	x2 = m_scrn[m_face[c].v2].x;
	x3 = m_scrn[m_face[c].v3].x;
	
	u1 = ((m_data[m_face[c].v1].normal.x * 127.0f + 128.0f) * 65536.0f);
	u2 = ((m_data[m_face[c].v2].normal.x * 127.0f + 128.0f) * 65536.0f);
	u3 = ((m_data[m_face[c].v3].normal.x * 127.0f + 128.0f) * 65536.0f);
	v1 = ((m_data[m_face[c].v1].normal.y * 127.0f + 128.0f) * 65536.0f);
	v2 = ((m_data[m_face[c].v2].normal.y * 127.0f + 128.0f) * 65536.0f);
	v3 = ((m_data[m_face[c].v3].normal.y * 127.0f + 128.0f) * 65536.0f);
	// calc gradients
	
	int32 minX = x1;
	int32 maxX = x1;
	int32 maxR = r1;
	int32 minR = r1;
	int32 maxG = g1;
	int32 minG = g1;
	int32 maxB = b1;
	int32 minB = b1;
	int32 minU = u1;
	int32 maxU = u1;
	int32 minV = v1;
	int32 maxV = v1;

	
	if (x2 < minX ) {

		minX = x2;
		minR = r2;
		minG = g2;
		minB = b2;
		minU = u2;
		minV = v2;
	}
	if (x2 > maxX ) {

		maxU = u2;
		maxV = v2;
		maxX = x2;
		maxR = r2;
		maxG = g2;
		maxB = b2;
	}
	if (x3 < minX) {

		minU = u3;
		minV = v3;
		minX = x3;
		minR = r3;
		minG = g3;
		minB = b3;
	}
	if (x3 > maxX) {

		maxU = u3;
		maxV = v3;
		maxX = x3;
		maxR = r3;
		maxG = g3;
		maxB = b3;
	}

//	if (x
//	if (x2 > x3) {

		dx   = (maxX - minX) >> 16;
		dvdx = (maxV - minV) / dx;
		dudx = (maxU - minU) / dx;
		drdx = (maxR - minR) / dx;
		dgdx = (maxG - minG) / dx;
		dbdx = (maxB - minB) / dx;
//	}
//	else {

//		dx = (x3 - x2) >> 16;
//		dvdx = (v3 - v2) / dx;
//		dudx = (u3 - u2) / dx;
//		drdx = (r3 - r2) / dx;
//		dgdx = (g3 - g2) / dx;
//		dbdx = (b3 - b2) / dx;
//	}

	// sort them by y (low->high)
	if (y1 > y2) {
	
		std::swap(r1, r2);
		std::swap(g1, g2);
		std::swap(b1, b2);
		std::swap(y1, y2);
		std::swap(x1, x2);
		std::swap(u1, u2);
		std::swap(v1, v2);
		std::swap(z1, z2);
	}

	if (y1 > y3) {

		std::swap(z1, z3);
		std::swap(r1, r3);
		std::swap(g1, g3);
		std::swap(b1, b3);
		std::swap(y1, y3);
		std::swap(x1, x3);
		std::swap(u1, u3);
		std::swap(v1, v3);
	}
	
	if (y2 > y3) {

		std::swap(z2, z3);
		std::swap(r2, r3);
		std::swap(g2, g3);
		std::swap(b2, b3);
		std::swap(y2, y3);
		std::swap(x2, x3);
		std::swap(u2, u3);
		std::swap(v2, v3);
	}
 
	sy1 = FIXED_CEIL(y1);
	sy2 = FIXED_CEIL(y2);
	sy3 = FIXED_CEIL(y3);

	int32 leDeltaZ;
	int32 riDeltaZ;
	int32 leDeltaX;
	int32 riDeltaX;
	int32 leDeltaU;
	int32 riDeltaU;
	int32 leDeltaV;
	int32 riDeltaV;
	int32 leDeltaR;
	int32 leDeltaG;
	int32 leDeltaB;
	int32 riDeltaR;
	int32 riDeltaG;
	int32 riDeltaB;

	
	// cacl. heights
	int scBotHeight = (sy3 - sy2) >> 16;
	int scTopHeight = (sy2 - sy1) >> 16;
	int scTotHeight = (sy3 - sy1) >> 16;
	int botHeight	= (y3  -  y2) >> 16;
	int topHeight	= (y2  -  y1) >> 16;
	int totHeight	= (y3  -  y1) >> 16;

	if (scTotHeight <= 1) {

		//Box(NULL, "NOHEIGHT FACE","JEEEEE",MB_OK);
		return;
	}
	
	// prec. fixed reciprocal factor
	int32 recip  = (1 << 16);
	int32 zframe = zbuffer.frame * 65536;

	// calc breakpoint
	int32 by3 = y2;
	int32 bx3 = x1 + (((x3 - x1) / (totHeight)) * topHeight);
	int32 bu3 = (u1 + (((u3 - u1) / (totHeight)) * topHeight));
	int32 bv3 = (v1 + (((v3 - v1) / (totHeight)) * topHeight));
	
	/// z breakpoint
	int32 bz3 = z1 + (((z3 - z1) / (totHeight)) * topHeight);
		
	// rgb
	int32 br3 = (r1 + (((r3 - r1) / (totHeight)) * topHeight));
	int32 bg3 = (g1 + (((g3 - g1) / (totHeight)) * topHeight));
	int32 bb3 = (b1 + (((b3 - b1) / (totHeight)) * topHeight));

	// setup top tr
	
	if (topHeight) {

		if (bx3 < x2 ) {

			// check horizontal order
			leDeltaX = (bx3 - x1) / topHeight;
			leDeltaU = (bu3 - u1) / topHeight;
			leDeltaV = (bv3 - v1) / topHeight;
			riDeltaX = (x2	- x1) / topHeight;
			riDeltaU = (u2	- u1) / topHeight;
			riDeltaV = (v2	- v1) / topHeight;

			// rgb
			leDeltaR = (br3 - r1) / topHeight;
			leDeltaG = (bg3 - g1) / topHeight;
			leDeltaB = (bb3 - b1) / topHeight;
			riDeltaR = (r2  - r1) / topHeight;
			riDeltaG = (g2  - g1) / topHeight;
			riDeltaB = (b2  - b1) / topHeight;

			leDeltaZ = (bz3 - z1) / topHeight;
			riDeltaZ = (z2  - z1) / topHeight;

		}
		else {

			// check horizontal order
			riDeltaX = (bx3 - x1) / topHeight;
			riDeltaU = (bu3 - u1) / topHeight;
			riDeltaV = (bv3 - v1) / topHeight;
			leDeltaX = (x2	- x1) / topHeight;
			leDeltaU = (u2	- u1) / topHeight;
			leDeltaV = (v2	- v1) / topHeight;
			
			//z
			leDeltaZ = (z2   - z1) / topHeight;
			riDeltaZ = (bz3  - z1) / topHeight;

			riDeltaR = (br3 - r1) / topHeight;
			riDeltaG = (bg3 - g1) / topHeight;
			riDeltaB = (bb3 - b1) / topHeight;
			leDeltaR = (r2	- r1) / topHeight;
			leDeltaG = (g2	- g1) / topHeight;
			leDeltaB = (b2	- b1) / topHeight;
		}
	}
	
	int32 subPixPercent = 0x10000 - (FIXED_CEIL(y1) - y1);

	int32 leStartX = x1;
	int32 riStartX = x1;
	int32 leStartU = u1;
	int32 riStartU = u1;
	int32 leStartV = v1;
	int32 riStartV = v1;
	int32 leStartR = r1;
	int32 leStartG = g1;
	int32 leStartB = b1;
	int32 riStartR = r1;
	int32 riStartG = g1;
	int32 riStartB = b1;
	int32 riStartZ = z1;
	int32 leStartZ = z1;

	int Y = 0;
	
	int offs = ((FIXED_CEIL(y1)) >> 16) * screen.getWidth();
	pixel+=offs;
	uint32 *pixasm = pixel;
	uint32  *zpix = zbuffer.data;
	zpix += offs;
	

/*
	int32 dx   = ((riStartX + riDeltaX * 20) - (leStartX + leDeltaX * 20));

	int32 dvdx = ((riStartV + riDeltaV * 20) - (leStartV + leDeltaV * 20)) / dx;
	int32 dudx = ((riStartU + riDeltaU * 20) - (leStartU + leDeltaU * 20)) / dx;
	int32 drdx = ((riStartR + riDeltaR * 20) - (leStartR + leDeltaR * 20)) / dx;
	int32 dgdx = ((riStartG + riDeltaG * 20) - (leStartG + leDeltaG * 20)) / dx;
	int32 dbdx = ((riStartB + riDeltaB * 20) - (leStartB + leDeltaB * 20)) / dx;
*/


	leStartX += ((subPixPercent * leDeltaX) >> 16);
	riStartX += ((subPixPercent * riDeltaX) >> 16);
	leStartU += ((subPixPercent * leDeltaU) >> 16);
	leStartV += ((subPixPercent * leDeltaV) >> 16);
	leStartR += ((subPixPercent * leDeltaR) >> 16);
	leStartG += ((subPixPercent * leDeltaG) >> 16);
	leStartB += ((subPixPercent * leDeltaB) >> 16);



	while (Y < scTopHeight) {
		
		int   width		= (riStartX - leStartX)>>16;
		int   cx1		= FIXED_CEIL(leStartX) >> 16;
		int   cx2		= FIXED_CEIL(riStartX) >> 16;
		int32 subPixX	= 0x10000 - FIXED_CEIL(leStartX) - leStartX;
		
		int iDeltaX = (cx2 - cx1);

		if (width> 0) {

			int32 iDeltaZ = (riStartZ - leStartZ) / (width);

			int32 startZ = leStartZ ;
			int32 startU = leStartU + ((subPixX * dudx) >> 16);
			int32 startV = leStartV + ((subPixX * dvdx) >> 16);
			int32 startR = leStartR + ((subPixX * drdx) >> 16);
			int32 startG = leStartG + ((subPixX * dgdx) >> 16);
			int32 startB = leStartB + ((subPixX * dbdx) >> 16);

			for (int n = cx1; n <= cx2; n++) {
							
				if (((startZ >> 16) + zframe) > zpix[n]) {
					
					pixasm = pixel + n;

					uint32 color = text[(startU >> 16) + ((startV >> 8) & 0xff00)];
					
					shade = ((startR & 0xff0000) | ((startG >> 8) & 0x00ff00) | ((startB>>16) & 0xff));
					
					_asm {

						mov  edi, pixasm
						movd mm0, shade
						movd mm1, color
					//	paddusb mm1, mm0
						movd [edi], mm1
					}
	
					zpix[n] = (startZ>>16) + zframe;
				}

				startU += dudx;
				startV += dvdx;
				startR += drdx;
				startG += dgdx;
				startB += dbdx;
				startZ += iDeltaZ;
									
			}
		}
		
		pixel+=screen.getWidth();
		zpix += zbuffer.width;
		leStartR += leDeltaR;
		leStartG += leDeltaG;
		leStartB += leDeltaB;

		leStartU += leDeltaU;
		leStartV += leDeltaV;
		leStartX += leDeltaX;
		riStartX += riDeltaX;
		riStartZ += riDeltaZ;
		leStartZ += leDeltaZ;
		
		Y++;
	}
	
	
	Y = 0;	

	if (botHeight) {

		if (x2 < bx3) {
			
			leStartZ = z2;
			riStartZ = bz3;

			leStartU = u2 + ((subPixPercent * leDeltaU)>>16);;
			leStartV = v2 + ((subPixPercent * leDeltaV)>>16);; 
			
			leDeltaR = (r3 - r2)  / botHeight;
			leDeltaG = (g3 - g2)  / botHeight;
			leDeltaB = (b3 - b2)  / botHeight;

			leStartR = r2 + ((subPixPercent * leDeltaR)>>16);;
			leStartG = g2 + ((subPixPercent * leDeltaG)>>16);;
			leStartB = b2 + ((subPixPercent * leDeltaB)>>16);;
			
			riDeltaZ = (z2 - bz3) / botHeight;
			riDeltaX = (x3 - bx3) / botHeight;
			
			leDeltaZ = (z3 - z2)  / botHeight;
			leDeltaX = (x3 - x2)  / botHeight;
			leDeltaU = (u3 - u2)  / botHeight;
			leDeltaV = (v3 - v2)  / botHeight;


			leStartX = x2  + ((subPixPercent * leDeltaX)>>16);
			riStartX = bx3 + ((subPixPercent * riDeltaX)>>16);;
		}
		else {
			
			leStartZ = bz3 ;
			riStartZ = z2;
				
			leDeltaZ = (z3 - bz3) / botHeight;
			leDeltaX = (x3 - bx3) / botHeight;
			leDeltaU = (u3 - bu3) / botHeight;
			leDeltaV = (v3 - bv3) / botHeight;
			
			riDeltaZ = (z3 - z2)  / botHeight;
			riDeltaX = (x3 - x2)  / botHeight;

			// rgb
			leDeltaR = (r3 - br3) / botHeight;
			leDeltaG = (g3 - bg3) / botHeight;
			leDeltaB = (b3 - bb3) / botHeight;

			leStartU = bu3 + ((subPixPercent * leDeltaU)>>16);
			leStartV = bv3 + ((subPixPercent * leDeltaV)>>16);

			leStartR = br3 + ((subPixPercent * leDeltaR)>>16);;
			leStartG = bg3 + ((subPixPercent * leDeltaG)>>16);;
			leStartB = bb3 + ((subPixPercent * leDeltaB)>>16);;

			leStartX = bx3 + ((subPixPercent * leDeltaX)>>16);
			riStartX = x2  + ((subPixPercent * riDeltaX)>>16);;
		}
	}
	
	while (Y < scBotHeight) {
	
		int width = (riStartX - leStartX)>>16; 
		int cx1 = FIXED_CEIL(leStartX) >> 16;
		int cx2 = FIXED_CEIL(riStartX) >> 16;
		
		int   iDeltaX = cx2 - cx1;
		
		if (width > 0) {
			
			int32 subPixX	= FIXED_CEIL(leStartX) - leStartX;
			int32 startZ	= leStartZ ;
			int32 startU	= leStartU + ((subPixX * dudx) >> 16);
			int32 startV	= leStartV + ((subPixX * dvdx) >> 16);
			int32 startR	= leStartR + ((subPixX * drdx) >> 16);
			int32 startG	= leStartG + ((subPixX * dgdx) >> 16);
			int32 startB	= leStartB + ((subPixX * dbdx) >> 16);			
			int32 iDeltaZ	= (riStartZ - leStartZ) / (width);

	
			for (int n = cx1; n <= cx2; n++) {
				
				if (((startZ >> 16) + zframe) > zpix[n]) {

					uint32 color = text[(startU >> 16) + ((startV >> 8) & 0xff00)];
					pixasm = pixel + n;

					//shade = ((startR & 0xff0000) | ((startG >> 8) & 0x00ff00) | ((startB>>16) & 0xff));

					_asm {
						
						mov  edi, pixasm
						movd  mm1, color
						movd mm0, shade
						//movd mm1, [edi]
					//	paddusb mm1, mm0
						movd [edi], mm1			
					}
					
					zpix[n] = (startZ>>16) + zframe;
				}
				
				startR += drdx;
				startG += dgdx;
				startB += dbdx;
				startZ += iDeltaZ;
				startU += dudx;
				startV += dvdx;
			}
		}
		
		zpix += zbuffer.width;
		pixel+= screen.getWidth();
		
		leStartZ += leDeltaZ;
		riStartZ += riDeltaZ;
		leStartR += leDeltaR;
		leStartG += leDeltaG;
		leStartB += leDeltaB;

		leStartU += leDeltaU;
		leStartV += leDeltaV;
		leStartX += leDeltaX;
		riStartX += riDeltaX;
		
		Y++;
	}

	_asm { emms }

}

void Grid::calcFaceNormals() {

	for (int i = 0; i < m_faceCount; i++) {

		CVector3d edge1(m_data[m_face[i].v1].trans, m_data[m_face[i].v2].trans);  
		CVector3d edge2(m_data[m_face[i].v1].trans, m_data[m_face[i].v3].trans);  
		edge1.normalize();
		edge2.normalize();

		m_face[i].normal = edge2 % edge1;
	}
}

void Grid::makeFaces() {

	m_faceCount = (m_height - 1) * (m_width - 1) * 2;
	m_face = new Face[m_faceCount];

	int n = 0;
	int c = 0;
	int squareHeight = m_height - 1;
	int squareWidth  = m_width  - 1;
	int offs = 0;

	for (int y = 0; y < m_height - 1; y++) {

		for (int n = 0; n < m_width - 1; n++) {

			makeFace(c, offs + n , offs + n + 1, offs + n + 1 + m_width, offs + (n + m_width));
			c++;
		}

		offs += m_width;
	}

	m_faceCount = c * 2;
}

//==========================================================================

void Grid::makeFace(int squareID, int v1, int v2, int v3, int v4) {

	m_face[(squareID << 1)	  ].v1 = v1;
	m_face[(squareID << 1)	  ].v2 = v2;
	m_face[(squareID << 1)	  ].v3 = v3;
	m_face[(squareID << 1) + 1].v1 = v3;
	m_face[(squareID << 1) + 1].v2 = v4;
	m_face[(squareID << 1) + 1].v3 = v1;
	
	// calc face indexes for face 1's vertices
	m_data[v1].faceIndexes[m_data[v1].faceCount++] = squareID << 1;
	m_data[v2].faceIndexes[m_data[v2].faceCount++] = squareID << 1;
	m_data[v3].faceIndexes[m_data[v3].faceCount++] = squareID << 1;

	// calc face indexes for face 2's vertices
	m_data[v3].faceIndexes[m_data[v3].faceCount++] = 1 + (squareID << 1);
	m_data[v4].faceIndexes[m_data[v4].faceCount++] = 1 + (squareID << 1);
	m_data[v1].faceIndexes[m_data[v1].faceCount++] = 1 + (squareID << 1);
}

//==========================================================================

inline void setAAPixel(uint32 *data, int32 intPart, uint32 fixedPart, int nextPixPitch, uint32 color) {

	int32 fraction  = (intPart - fixedPart) >> 8;
	int32 iFraction = 0xff - fraction;
	
	__asm {
		
		mov			edi, data
		mov			esi, data
		sub			esi, nextPixPitch
		pxor		mm7, mm7
		movq		mm0, fraction
		movq		mm1, iFraction
		
		punpcklwd	mm1, mm1	// unpack inversed fraction
		punpckldq	mm1, mm1	
		
		punpcklwd	mm0, mm0	// unpack fraction
		punpckldq	mm0, mm0
		
		movd		mm3, color
		movd		mm4, color

		punpcklbw	mm3, mm7	// extract colors into words
		punpcklbw	mm4, mm7	// - || -
		
		pmullw		mm3, mm0
		pmullw		mm4, mm1

		psrlw		mm3, 8
		psrlw		mm4, 8

		packuswb	mm3, mm3
		packuswb	mm4, mm4
			
		movd		[edi], mm4
		movd		[esi], mm3
	}
}

void Grid::drawLine(BaseImage32 &dest, int32 x1, int32 y1, int32 x2, int32 y2,  uint32 attr1, uint32 attr2) {
	
	int32 deltax = x2 - x1;
	int32 deltay = y2 - y1;
	
	int32 fx1 = FIXED_CEIL(x1);
	int32 fx2 = FIXED_CEIL(x2);
	int32 fy1 = FIXED_CEIL(y1);
	int32 fy2 = FIXED_CEIL(y2);
	
	int32 scanLines = abs(fy2 - fy1) >> 16;
	int32 scanWidth = abs(fx2 - fx1) >> 16;
	
	int32 prestepY = 0x10000 - (fy1 - y1);
	int32 prestepX = 0x10000 - (fx1 - x1);

	int32 divLen;
	int32 length;
	int32 tdy;
	int32 tdx;
	uint32 *pixels = dest.get();
  
	tdx = deltax;

	if (deltax < 0)
		tdx = -deltax;

	tdy = deltay;

	if (deltay < 0)
		tdy = -deltay;

	length = scanLines;
	divLen = tdy >> 16;

	if (tdx > tdy) {

		length = scanWidth;
		divLen = tdx >> 16;
	}
	if (length == 0 || divLen == 0)
		return;

	deltax /= divLen;
	deltay /= divLen;
		
	if (tdy > tdx) {
		y1 = fy1;
		x1 += (prestepY * deltax) >> 16;
	}
	else {
		x1 = fx1;
		y1 += (prestepX * deltay) >> 16;
	}

	int32 scPitch  = dest.getPitch();
	int32 scWidth  = dest.getWidth();
	int32 scHeight = dest.getWidth();

	for (int n=0; n<length; n++) {
		
		int sx = FIXED_CEIL(x1) >> 16;
		int sy = y1 >> 16;

		if ((sx > 0) && (sx < scWidth ) && (sy > 0) && (sy < scHeight)) {
			
			if (tdy > tdx)
				setAAPixel(&(pixels[(( (FIXED_CEIL(x1)) >> 16) + ((y1 >> 16) * scWidth))]), FIXED_CEIL(x1), x1, 4, 0xffffff);
			else if (tdy < tdx)
				setAAPixel(&(pixels[((x1 >> 16) + ((FIXED_CEIL(y1)>>16) * scWidth))]), FIXED_CEIL(y1),y1, scPitch, 0xffffff);
			else
				pixels[x1 + (y1>>16) * scWidth] = 0xffffff;
		}

		x1+=deltax;
		y1+=deltay;
	}

	if (tdy != tdx)
		__asm { emms }
}

//==========================================================================

void blur32(BaseImage32 &image) {

	uint32 *dst = (uint32*)image.get();
	int		count = 512 * 384 - 512;

	_asm
	{
		mov edi, dst
		mov esi, edi
		mov ecx, count
		add esi, 2048
		add edi, 2048
		//mov eax, 0x002a2a1a
		mov eax, 0x000a0a02
		movd mm3, eax

		LP:
			pxor mm5, mm5
			pxor mm2, mm2

	
			movq mm1, [esi+16]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
			movq mm1, [esi+8]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
			movq mm1, [esi+28]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
			
			movq mm1, [esi-8]
			punpcklbw mm1, mm5
			paddusw mm2, mm1

			movq mm1, [esi-16]
			punpcklbw mm1, mm5
			paddusw mm2, mm1

			movq mm1, [esi + 24]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
			movq mm1, [esi - 24]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
			movq mm1, [esi - 28]
			punpcklbw mm1, mm5
			paddusw mm2, mm1



			psrlw mm2,3
			packuswb mm2,mm2
			psubusb mm2,mm3

			movd  [edi], mm2

			add esi, 4
			add edi, 4
			dec ecx
			jnz LP
		
		emms
	}
}

//==========================================================================

void generateLense(BaseImage32 &image) {

	uint32 *pixel = (uint32*)image.get();
	float32 xorg  =	- (image.getWidth() / 2);
	float32 yorg  =	- (image.getHeight() / 2);
	float32 wdiv2 =	(image.getWidth() / 2);
	float32 hdiv2 =	(image.getHeight() / 2);

	for (int y = 0; y < image.getHeight(); y++) {
		
		xorg = - (image.getWidth() / 2);

		for (int x=0; x < image.getWidth(); x++) {
			
			float32 d = 1.0f - sqrtf((xorg / wdiv2) * (xorg / wdiv2) + (yorg / hdiv2) * (yorg / hdiv2)); 
			
			if (d < 0.0f)
				d = 0.0f;
			
			uint32 attr = (uint32)(d * 255.0f);
			attr = (attr << 16) + (attr << 8) + (attr);
			pixel[y * image.getWidth() + x] = attr; //(x % 2) == 0 ? 0x00ff00 : 0xff0000;
			xorg++;
		}

		yorg++;
	}
}

//==========================================================================

void darkenImage(BaseImage32 &image, float32 percent) {

	uint32 *pixels  = (uint32*)image.get();

	for (int y = 0; y < image.getHeight(); y++) {

		for (int x = 0; x < image.getWidth(); x++) {

			int r = ((float)(RGB_TO_R((*pixels))) * percent);			
			int g = ((float)(RGB_TO_G((*pixels))) * percent);			
			int b = ((float)(RGB_TO_B((*pixels))) * percent);	
			*pixels = (r <<16) | (g<<8) | (b); 
			pixels++;
		}
	}
}

//==========================================================================
