#include "ms_field.h"
#include <stdio.h>
#include <math.h>
#include <windows.h>

using namespace Helper;
using namespace MSquares;

//=======================================================================


DensityField::DensityField (int32 width, int32 height) : m_minX(NULL), m_maxX(NULL), m_data(NULL), m_width(0), m_height(0) {

	if (width && height)
		resize(width, height);
}

//=======================================================================

DensityField::~DensityField() {

	if (m_data)
		release();
}

		
//=======================================================================

void DensityField::resize(int32 width, int32 height) {

	if (m_data)
		release();
	
	m_width = width;
	m_height = height;
	m_data = new float32 [m_width * m_height];
}


//=======================================================================

void DensityField::release() {

	if (m_data) 
		delete[] m_data;

	m_data = NULL;
	m_width = 0;
	m_height = 0;
}

//=======================================================================

const int32 DensityField::getWidth() const {

	return m_width;
}


//=======================================================================

const int32 DensityField::getHeight() const {

	return m_height;
}

//=======================================================================

void DensityField::fill(const float32 fval) {

	int index=0;

	while (index < m_width * m_height) {
		m_data[index] = fval;
		index++;
	}
}


//=======================================================================

void DensityField::addEntiry (int32 xpos, int32 ypos, float32 strength) {

	int yoffs = 0;

	for (int y = 0; y < m_height; y++) {

		for (int x = 0; x < m_width; x++) {

			float32 distance = (x - xpos) * (x - xpos) + (y - ypos) * (y - ypos) + 0.0001;
			//distance2;
			m_data[yoffs + x] += strength / distance;//((distance != 0.0) ? distance : 1.0f);
		}
		
		yoffs += m_width;
	}
}

//=======================================================================

void DensityField::setThreshold(const float32 threshold) {

	m_threshold = threshold;
}

//=======================================================================

const float32 DensityField::getThreshold() const { 

	return m_threshold;
}

//=======================================================================

void DensityField::draw(BaseImage32 &image, BaseImage32 &backGround) {

	float32 imageWidth = (float32)image.getWidth();
	float32 imageHeight = (float32)image.getHeight();
	float32 scaleX = imageWidth / (float32)m_width;
	float32 scaleY = imageHeight / (float32)m_height;

	float * temp = m_data;
	
	int32 * minx = m_minX;

	/*__asm {

		mov edi, minx
		mov ecx, 240
		mov eax, 640
		movd mm0, eax
		psllq mm0, 32
		movd mm0, eax
		
		VL_MIN:
		movd mm0, eax
		movq [edi], mm0
		add edi, 8
		dec ecx
		jnz VL_MIN

	}*/

/*	int32 * maxx = m_maxX;
	
	__asm {

		mov edi, minx
		mov ecx, 240
		pxor mm0, mm0

		VL_MAX:
		movd mm0, eax
		movq [edi], mm0
		add edi, 8	
		dec ecx
		jnz VL_MAX

		emms
	}
*/
	for (int y = 0; y < m_height-1; y++) {
	
		for (int x = 0; x < m_width-1; x++) {
			
			uint32  bitmask = 0;
			float32 x1 = 0;
			float32 y1 = 0;
			float32 x2 = 0;
			float32 y2 = 0;
			float32 u1 = 0;
			float32 v1 = 0;
			float32 u2 = 0;
			float32 v2 = 0;

			int32 lines = 0;

			if (temp[x+0] >= m_threshold)
				bitmask |= 1;
			if (temp[x+1] >= m_threshold)
				bitmask |= 2;
			if (temp[x+m_width+1] >= m_threshold)
				bitmask |= 4;
			if (temp[x+m_width] >= m_threshold)
				bitmask |= 8;

			switch (bitmask) {


			case 13:
			case 2:
				x1 = (float32)x + calcIntersection(temp[x+0], temp[x+1]); 
				x2 = (float32)x + 1.0f;
				y1 = (float32)y;
				y2 = (float32)y + calcIntersection(temp[x+1], temp[x+m_width + 1]);
				lines = 1;
			break;

			case 9:
			case 6:
				x1 = (float32)x + calcIntersection(temp[x+0], temp[x+1]); 
				x2 = (float32)x + calcIntersection(temp[x+m_width], temp[x+m_width + 1]);
				y1 = (float32)y;
				y2 = (float32)y + 1.0f;
				lines = 1;
			break;

			case 1:
			case 14:
				x1 = (float32)x + calcIntersection(temp[x+0], temp[x+1]);
				x2 = (float32)x;
				y1 = (float32)y;
				y2 = (float32)y + calcIntersection(temp[x+0], temp[x+m_width]);
				lines = 1;
			break;

			case 5:
			case 10:
				x1 = (float32)x + calcIntersection(temp[x+0], temp[x+1]);
				y1 = (float32)y;
				x2 = (float32)x;
				y2 = (float32)y + calcIntersection(temp[x+0], temp[x+m_width]);

				// second line
				u1 = (float32)x + 1.0f;
				v1 = (float32)y + calcIntersection(temp[x+1], temp[x+m_width+1]);
				u2 = (float32)x + calcIntersection(temp[x+m_width], temp[x+m_width+1]);
				v2 = (float32)y + 1.0;
				lines = 2;
			break;

			case 4:
			case 11:
				x1 = (float32)x+1.0f;
				y1 = (float32)y + calcIntersection(temp[x + 1], temp[x + m_width + 1]);
				x2 = (float32)x + calcIntersection(temp[x+m_width], temp[m_width+1+x]);
				y2 = (float32)y+1.0f;
				lines = 1;
			break;

			case 7:
			case 8:
				x1 = (float32)x;
				y1 = (float32)y + calcIntersection(temp[x], temp[x + m_width]);
				x2 = (float32)x + calcIntersection(temp[x+m_width], temp[m_width+1+x]);
				y2 = (float32)y+1.0f;
				lines = 1;
			break;

			case 12:
			case 3:
				x1 = x;
				y1 = (float32)y + calcIntersection(temp[x], temp[x + m_width]);
				x2 = x + 1.0f;
				y2 = (float32)y + calcIntersection(temp[x+1], temp[x + m_width + 1]);
				lines = 1;
			}

			if (lines--)
				drawLine(x1 * scaleX,y1 * scaleY, x2 * scaleX, y2 * scaleY, image.get(), imageWidth, imageHeight);
			if (lines)
				drawLine(u1 * scaleX,v1 * scaleY, u2 * scaleX, v2 * scaleY, image.get(), imageWidth, imageHeight);
		}	

	
		temp += m_width;
	}

	uint32 * dst = backGround.get();

/*	for (int i=1; i < 480-2; i++) {

		if (m_minX[i] == 640 || m_maxX[i] == 0)
			continue;
		
		int x1 = m_minX[i];
		int x2 = m_maxX[i];
		memcpy (image.get() + i * 640 + x1,dst + i * 640 + x1,4*(x2 - x1));
	}*/

}


//=======================================================================

//=======================================================================

