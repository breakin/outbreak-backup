#ifndef __EFFECTS_MARCHING_SQUARES_FIELD_INC__
#define __EFFECTS_MARCHING_SQUARES_FIELD_INC__

#include <helper\core\typedefs.h>
#include <helper\core\image32.h>

using namespace Helper;

namespace MSquares {

	#define FIXED_CEIL(x) (((x + 0xffff) >> 16) << 16)


	class DensityField 
	{
	public:

		DensityField (int32 width = 0, int32 height= 0);
		~DensityField();
		
		void resize(int32 width, int32 height);
		void release();
	
		/// get width properties
		const int32 getWidth() const;
		const int32 getHeight() const;

		/// fill grid with <fval>
		void fill(const float32 fval);

		/// indexing operator
		float32 * operator[] (int index) { return m_data + index * m_width; }
	
		/// draw field
		void draw(BaseImage32 &image, BaseImage32&);

		/// add entity to field
		void addEntiry (int32 xpos, int32 ypos, float32 strength);

		/// set/get threashold
		void setThreshold(const float32 threshold);
		const float32 getThreshold() const;

	protected:

		float calcIntersection(float a, float b);
		void drawLine(float32 x1, float32 y1, float32 x2, float32 y2, uint32 * dst, int32 width, int32 height);
		
		int32		m_width;	///< Field height
		int32		m_height;	///< Field width
		float32 *	m_data;		///< Field data
		float32		m_threshold;///< Field density threshold
		int32	*	m_minX;		///< Min x values
		int32	*	m_maxX;		///< Max x values

	};


	__forceinline float DensityField::calcIntersection(float a, float b) {
	
		// calc (t) at intersection of threshold
		return (m_threshold - a) / (b - a);
	}

	__forceinline void DensityField::drawLine(float32 x1, float32 y1, float32 x2, float32 y2, uint32 * dst, int32 width, int32 height) {

	int32 fx1 = (x1 * 65536);
	int32 fy1 = (y1 * 65536);
	int32 fx2 = (x2 * 65536);
	int32 fy2 = (y2 * 65536);

	int32 deltax = (fx2 - fx1);
	int32 deltay = (fy2 - fy1);

	int32 tdx = deltax;
	int32 tdy = deltay;

	if (tdx < 0)
		tdx = - tdx;

	if (tdy < 0)
		tdy = - tdy;

	int32 length = tdx;

	if (length < tdy) {
		
		length = tdy;

		// calc deltas
		length >>= 16;

		if (length == 0)
			return;

		deltay/=(length);
		deltax/=(length);
		int32 oy = fy1;
		fy1 = FIXED_CEIL(fy1);
		fx1 += (deltay * (0x10000 - (fy1 - oy)))>>16;
	}
	else {

		// calc deltas
		length >>= 16;

		if (length == 0)
			return;

		deltax/=(length);
		deltay/=(length);		
		int32 ox = fx1;
		fx1 = FIXED_CEIL(fx1);
		fy1 += (deltax * (0x10000 - (fx1 - ox)))>>16;		
	}


	// calc loop addition to offset
	int i = 0; 

	if (tdy > tdx)
		while (i < (length+1)) {
		
			int32 spx = FIXED_CEIL(fx1);

		//	if ((spx >> 16) < m_minX[fy1 >> 16])
		//		m_minX[fy1>>16] = spx >> 16;
		//	if ((spx >> 16) > m_maxX[fy1 >> 16])
		//		m_maxX[fy1>>16] = spx >> 16;
			
			dst[(spx >> 16) + (fy1 >> 16) * width] = 0xffffff;
			
			fx1 += deltax;
			fy1 += deltay;
			i++;
		}
	else
		while (i < (length)) {
		
			int32 spy = FIXED_CEIL(fy1);

		//	if ((fx1 >> 16) < m_minX[spy >> 16])
		//		m_minX[spy>>16] = fx1 >> 16;
		//	if ((fx1 >> 16) > m_maxX[spy >> 16])
		//		m_maxX[spy>>16] = fx1 >> 16;

			dst[(fx1 >> 16) + (spy >> 16) * width] = 0xffffff;
			
			fx1 += deltax;
			fy1 += deltay;
			i++;
		}

}

//=======================================================================

}

#endif
