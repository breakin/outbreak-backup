#include "ms_field.h"

#include <helper\directx\dx_device2d.h>
#include <helper\core\message.h>
#include <helper\core\imagedrawer\imagedrawer.h>
#include <helper\core\archive\archivedirectory.h>

#include <math.h>

using namespace Helper;
using namespace MSquares;

int WINAPI WinMain(HINSTANCE hi, HINSTANCE pi, LPSTR cmdLine, int cmdShow) {

	try {

	ImageDrawer imageDrawer;
	DirectDrawDevice2D device;
	Msg	msg;
	
	device.config("width","640");
	device.config("height","480");
	device.config("bpp","32");
	device.config("fullscreen","false");
	device.config("title","Marching Squares");
	Helper::ArchiveDirectory	a(".");
	Helper::Image32	texture;
	Helper::Image32 backg;

	a.load(texture, "tunnel.jpg");

	device.open();

	DensityField field(640/2, 480/2);
	field.fill(0.0);
	
	field.setThreshold(10.0);
	Image32 backBuffer;
	backBuffer.resize(640,480);
	backg.resize(640,480);
	bool run = true;
	float32 deg = 0.0;
	
	imageDrawer.draw(texture, texture.getArea(), backg, backg.getArea(),ImageDrawer::BLIT_NORMAL);
	while (run) {

		if (device.getMessage(msg)) {

			switch (msg.message) {

			case Msg::MSG_KEYDOWN:
			case Msg::MSG_CLOSE:
				run = false;
			break;

			}
		}
		
		field.setThreshold(310.0);
		field.fill(300.0);
		field.addEntiry(120+20*cos(deg),100+40*sin(deg),800.0f);
	//	field.addEntiry(15+7*sin(deg),10+50*cos(deg),1000+cos(deg)*20.0);
	//	field.addEntiry(13+10*cos(deg),12+60*cos(deg),900.0);
		field.addEntiry(100+70*sin(deg),100+3*sin(deg/2),800.0f);
		field.draw(backBuffer,backg);
		imageDrawer.draw(backBuffer, backBuffer.getArea(), device.getBackBuffer(), backBuffer.getArea(), ImageDrawer::BLIT_NORMAL);
		device.update();
		imageDrawer.clear(backBuffer,device.getBackBuffer().getArea());
		deg += 0.2;
	}
	}
	catch (Exception &e) {

		MessageBox(NULL, e.what(), "Exception!!", MB_OK);
	}


	return 0;
}
