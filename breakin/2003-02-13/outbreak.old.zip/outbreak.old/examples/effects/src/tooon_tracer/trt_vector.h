#ifndef __TOOON_RAYTRACE_VECTOR_INC__
#define __TOOON_RAYTRACE_VECTOR_INC__

#include <math.h>
#include "trt_typedef.h"

namespace Trazer {
	
	class Vector3
	{		
	public:
	
		union {

			struct {
			
				float32	x;
				float32 y;
				float32 z;
				float32 w;
			};

			struct {

				float32 r;
				float32 g;
				float32 b;
				float32 a;
			};
		};
		
		// constructors
		explicit Vector3 (float32 x=0,float32 y=0,float32 z=0) : x(x), y(y), z(z), w(1.0f){} ;
		Vector3 (const Vector3 &init, const Vector3 &term);

		// make vector methods
		void make(float32 px, float32 py, float32 pz);
		void setX(float32 px) { x = px;}
		void setY(float32 py) { y = py;}
		void setZ(float32 pz) { z = pz;}
		void setW(float32 pw) { w = pw;}
		
		// get vector components
		float32 getX() const { return x; }
		float32 getY() const { return y; }
		float32 getZ() const { return z; }
		float32 getW() const { return w; }

		// calculates and return length of vector
		float32 getLength() const;

		// calculates and return length of vector ^2
		float32 getLengthBy2() const;

		// returns a vector with the same direction, but with length 1.0
		Vector3 getNormalized() const;
		
		// calculates and return <this> reflection vector against <normal>
		Vector3 getReflection(const Vector3 &normal) const;

		// normalizes and scales down vector to length = 1.0
		void normalize();

		// overloaded self modified operators
		void operator += (const Vector3 &other);
		void operator -= (const Vector3 &other);
		void operator /= (const Vector3 &other);
		void operator %= (const Vector3 &other);
		void operator *= (const float32 scalar);
		
		bool operator == (const Vector3 &other) {

			return (x == other.x) && (z == other.z) && (y == other.y);
		}

		void fromInt(uint32 color) {

			r = (float)((color >> 16 ) & 0xff)/ 255.0f;
			g = (float)((color >>  8 ) & 0xff) / 255.0f;
			b = (float)(color  & 0xff) / 255.0f;
		}

		operator uint32() {

			if (r > 1.0) r = 1.0;
			if (g > 1.0) g = 1.0;
			if (b > 1.0) b = 1.0;
			return ((uint32)(r * 255.0) << 16) | ((uint32)(g * 255.0) << 8) | ((uint32)(b * 255.0));
		}

		// operator[] - returns the vector component [1] - x, [2] - y, [3] - z, [4] - w
		float32& operator[] (int i);

		// overloaded aritmethic operators
		float32	  operator * (const Vector3 &other) const;	
		Vector3 operator - () const;
		Vector3 operator * (const float32 scalar) const;
		Vector3 operator % (const Vector3 &other) const;
		Vector3 operator / (const Vector3 &other) const;
		Vector3 operator + (const Vector3 &other) const;
		Vector3 operator - (const Vector3 &other) const;
	
		friend Vector3  operator*(float32 scalar, const Vector3 &v);
	
	};


// ====================================================================================================

__inline Vector3 Vector3::getReflection(const Vector3 &normal) const {
	
	return ((normal * 2) % (*this % normal)) - *this;
}
// ====================================================================================================

__inline Vector3::Vector3 (const Vector3 &init, const Vector3 &term) {
	
	// make vector from init->term
	make(term.x - init.x, term.y - init.y, term.z - init.z);
}

// ====================================================================================================

__inline void Vector3::make(float px, float py, float pz) {

	x = px; y = py; z = pz;
}

// ====================================================================================================

__inline float32 Vector3::getLength() const {

	return (sqrtf(x * x + y * y + z * z));
}

// ====================================================================================================

__inline float32 Vector3::getLengthBy2() const {

	return (x * x + y * y + z * z);
}

// ====================================================================================================

__inline Vector3 Vector3::getNormalized() const {

	Vector3 res(*this);
	res.normalize();
	return res;
}

// ====================================================================================================

__inline void Vector3::normalize() {

	float l = getLength();
	x /= l;
	y /= l;
	z /= l;
}

// ====================================================================================================

__inline Vector3 Vector3::operator-() const {

	return Vector3(-x,-y,-z);
}

// ====================================================================================================

__inline Vector3 Vector3::operator*(const float32 scalar) const {
	
	return Vector3(x * scalar, y * scalar, z * scalar);
}

// ====================================================================================================

__inline Vector3 Vector3::operator%(const Vector3 &other) const {

	return Vector3 (
		y * other.z - z * other.y, 
		z * other.x - x * other.z,
		x * other.y - y * other.x );
}

// ====================================================================================================

__inline Vector3 Vector3::operator/(const Vector3 &other) const {
	
	return Vector3(x / other.x, y / other.y, z / other.z);
}

// ====================================================================================================

__inline Vector3 Vector3::operator+(const Vector3 &other) const {

	return Vector3(x + other.x, y + other.y, z + other.z);
}

// ====================================================================================================

__inline Vector3 Vector3::operator-(const Vector3 &other) const {
	
	return Vector3(x - other.x, y - other.y, z - other.z);
}

// ====================================================================================================

__inline void Vector3::operator*=(const float32 scalar) {

	x*=scalar;
	y*=scalar;
	z*=scalar;
}

// ====================================================================================================

__inline void Vector3::operator+=(const Vector3 &other) {

	x+=other.x;
	y+=other.y;
	z+=other.z;
}

// ====================================================================================================

__inline void Vector3::operator-=(const Vector3 &other) {

	x-=other.x;
	y-=other.y;
	z-=other.z;
}

// ====================================================================================================

__inline void Vector3::operator /= (const Vector3 &other) {

	x /= other.x;
	y /= other.y;
	z /= other.z;
	w /= other.w;
}

// ====================================================================================================

__inline void Vector3::operator%=(const Vector3 &other) {

	make(y * other.z - z * other.y, 
		z * other.x - x * other.z, 
		x * other.y - x * other.y);
}

// ====================================================================================================

__inline float32 Vector3::operator*(const Vector3 &other) const {

	return x * other.x + y * other.y + z * other.z;
}

// ====================================================================================================

__inline Vector3 operator*(float32 scalar, const Vector3 &v) {

	return Vector3(v.x * scalar, v.y * scalar, v.z * scalar);
}

// ====================================================================================================

__inline float32& Vector3::operator[] (int i) {

	return *((float*)&x + i); 
}
// ====================================================================================================

} // end namespace

#endif
