#ifndef __TOOON_RAYTRACER_SCENE_INC__
#define __TOOON_RAYTRACER_SCENE_INC__

#include "trt_typedef.h"
#include "trt_vector.h"
#include "trt_objects.h"
#include <helper\core\image32.h>

namespace Trazer {

	class Scene 
	{
	public:
		
		/// constructor with viewport dimensions
		Scene(int32 width = 0, int32 height = 0);
		~Scene();
		
		void create(int32 vpWidth, int32 vpHeight);
		void release();

		/// add object and lights to scene
		void addLight(Light * light) { m_lights.push_back(light); }
		void addObject(Object * object) { m_objects.push_back(object); }
		
		/// trace scene and render, note that rendertarget
		/// must be of same dimensions as the scene
		void rayTrace(Helper::BaseImage32 &renderTarget);

	protected:

		// precalculate direction table
		void calculateDirTable();

		Vector3*	m_dirTable;		///< precalculated direction table for each pixel
		ObjectList	m_objects;		///< Object list
		LightList	m_lights;		///< Light list
		int32		m_width;
		int32		m_height;
	};
}

#endif
