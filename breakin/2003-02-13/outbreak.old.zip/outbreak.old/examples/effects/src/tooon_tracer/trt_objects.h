#ifndef __TOOON_RAYTRACER_INC__
#define __TOOON_RAYTRACER_INC__

#include <helper\core\image32.h>
#include "trt_vector.h"
#include "trt_typedef.h"
#include "trt_rgb.h"
#include "trt_ray.h"
#include "trt_light.h"

namespace Trazer {

	/// forw decl.
	class Object;

	/***
	 * Object list
	 */
	typedef std::vector<Object*> ObjectList;

	/**
	 * Base scene object interface
	 */
	class Object 
	{
	public:
		
		enum {

			MAX_RAYTRACE_DEPTH = 32,
		};

		Object(uint32 id = 0) : m_id(id), m_reflection(0) {}
		virtual ~Object() {}
		
		// calc time of ray intersection
		virtual float32 getRayIntersection(const Ray &ray) = 0;
		
		virtual void setTexture(Helper::Image32 &image) { m_texture = & image;}
		/// perform raytracing, assume ray's been defined as collide
		virtual Color rayTrace(const Ray &ray, const float32 t, ObjectList * list, LightList * lights, int depth) = 0;

		/// get/set surface color
		virtual Color getColor() const { return m_color; }
		virtual void setColor(const Color &color) { m_color = color; }

		/// get/set reflection factor
		virtual float32 getReflection() const { return m_reflection; }
		virtual void setReflection(const float32 reflection) { m_reflection = reflection; }

		uint32 getID() const { return m_id; }
		void setID(const uint32 id) { m_id = id;}

	protected:
		
		uint32	m_id;			///< Unique object id
		float32	m_reflection;	///< Reflection factor
		Color	m_color;		///< Object color
		Helper::Image32 * m_texture;	///< Object texture material
	};


	/***
	 * Sphere object
	 */
	class Sphere : public Object
	{
	public:
		
		Sphere(uint32 id = 0) : Object(id) {}

		float32 getRayIntersection(const Ray &ray);
		Color rayTrace(const Ray &ray, const float32 t, ObjectList * list, LightList * lights, int depth);
		
		void setPos(const Vector3 &pos) { m_pos = pos; }
		Vector3 getPos() const { return m_pos; }

		float32 getRadius() const  {return m_radius; }
		void setRadius(const float32 r) { m_radius = r; }

	protected:
		
		Vector3	m_pos;
		float32		m_radius;
	};

	/**
	 * Plane object
	 */
	class Plane : public Object
	{
	public:
		
		Plane(uint32 id = 0) : Object(id) {}

		float32 getRayIntersection(const Ray &ray);
		Color rayTrace(const Ray &ray, const float32 t, ObjectList * list, LightList * lights, int depth);
		
		void set(const Vector3 &normal, const float32 d) {

			m_normal = normal;
			m_d = d;
		}

		void set(const Vector3 &a, const Vector3 &b, const Vector3 c) {

			Vector3 v1 = b - a;
			Vector3 v2 = c - a;

			m_normal = v1 % v2;
			
			m_normal.normalize();
			
			m_d = m_normal * v1;
		}

		void set(const float32 a, const float32 b, const float32 c, const float32 d) {

			m_normal.x = a;
			m_normal.y = b;
			m_normal.z = c;
			m_d = d;
		}

		Vector3  m_normal;
		float32	 m_d;
		float32	m_reflect;
	};

}

#endif
