#ifndef __TOOON_RAYTRACE_RAY_INC__
#define __TOOON_RAYTRACE_RAY_INC__

#include "trt_typedef.h"
#include "trt_vector.h"

namespace Trazer {

	class Ray 
	{
	public:

		/// constructors
		Ray() {};
		Ray (const Vector3 &pos, const Vector3 &dir) : m_pos(pos), m_dir(dir) {}

		// get/set direction and position
		Vector3 getDir() const { return m_dir; }
		Vector3 getPos() const { return m_pos; }
		void setDir(const Vector3 &dir) { m_dir = dir; }
		void setPos(const Vector3 &pos) { m_pos = pos; }

		/// leve data public for easier management
		Vector3	m_dir;	///< ray's direction
		Vector3	m_pos;	///< ray's position
	};
}

#endif
