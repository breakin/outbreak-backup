#ifndef __TOOON_RAYTRACE_TYPEDEF_INC__
#define __TOOON_RAYTRACE_TYPEDEF_INC__

namespace Trazer {

	typedef float float32;
	typedef double float64;
	typedef short int16;
	typedef long  int32;
	typedef char  int8;
	typedef unsigned char uint8;
	typedef unsigned short uint16;
	typedef unsigned long uint32;

}

#endif
