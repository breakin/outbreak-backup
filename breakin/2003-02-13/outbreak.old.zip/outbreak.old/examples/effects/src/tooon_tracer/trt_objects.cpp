#include "trt_objects.h"

using namespace Trazer;

//===========================================================

float32 Sphere::getRayIntersection(const Ray &ray) {

	// calculate vector from origin to centre
	Vector3 rayToCentre = m_pos - ray.m_pos;
	
	float32 length = rayToCentre * ray.m_dir;

	// if less than 0, the ray does not intersect
	if (length < 0)
		return -1.0f;

	// dot now contains org->centre projected on ray
	// find distance from |ray| to |centrevect|
	// |dot|^2 + |x|^2 = |centrevect|^2
	float32 length2 = length * length;
	float32 rtcLength2 = rayToCentre.getLengthBy2();
	float32 distance2 = rtcLength2 - length2;
	float32 radius2 = m_radius * m_radius;

	// set radius as hyponenuse and recalc
	// d2 + r2 should result in a positive value
	// and that value is the intersection delta
	// x^2 = r2 - distance2
	float32 t = radius2 - distance2;

	// if less than zero, distance to ray in larger
	// than radius and thus outside sphere
	if (t < 0)
		return -1.0;

	t = sqrt(t);

	return (length - t);
}

//===========================================================

Color Sphere::rayTrace(const Ray &ray, const float32 t, ObjectList * objects, LightList *lights, int depth) {

	LightList &lightList = *lights;
	ObjectList &objectList = *objects;
	Color diffuse = m_color;

	// calculate point of intersection
	Vector3 intersection = ray.getPos() + (ray.getDir() * t);
	Vector3 intersectionNormal = intersection - m_pos;
	intersectionNormal.normalize();

	Vector3 reflection = intersection.getReflection(intersectionNormal);

	float32 strength = 0.0;
	float32 reflectStrength = 0.0;

	for (int i=0; i < lights->size(); i++) {

		// cast a ray to the lightsource
		Vector3 lightDir = lightList[i]->m_pos - intersection;
		float32 lightLen = lightDir.getLength();
		float32 lightLen2 = lightLen * lightLen;
		bool	inShadow = false;

		// check if light reaches to our object, or intersects with
		// another one before
		if (lightLen < lightList[i]->m_attenuation) {

			lightDir.normalize();
			inShadow = false;

			// check if point is in shadow
			for (int j = 0; j < objectList.size(); j++) {

				// dont check for collision on the object itself
				if (!(objectList[j]->getID() == m_id)) {

					Ray ray(intersection, lightDir);
					
					float t = objectList[j]->getRayIntersection(ray);
					
					if (t > 0) {

						Vector3 isVect = ray.getDir() * t;
						float32 isLen2 = isVect.getLengthBy2();

						if (isLen2 < lightLen2) {

							inShadow = true;
							break;
						}
					}
				}
			}
			
			// check if point is in shadow
			if (inShadow)
				continue;
			
			// calc fallof
			float32 falloff = (1.0 - (lightLen/lightList[i]->m_attenuation * lightList[i]->m_attenuation));
			float32 tempStrength = reflection * lightDir * falloff;
			
			// increate reflection factor
			if (tempStrength > 0.0f) {

				reflectStrength += tempStrength;
			}

			// calc diffuse light strengt on intersecion point
			tempStrength = intersectionNormal * lightDir * falloff;
			
			// increate diffuse light factor
			if (tempStrength > 0)
				strength += tempStrength;		
		}
	}

		// for now, support only one lightsource
	// TODO: Add support for more ;)
	Color diffuseComp = diffuse * strength; //((strength <= 1.0) ? strength : 1.0f);
	
	if (depth == Object::MAX_RAYTRACE_DEPTH)
		return diffuseComp;

//	return diffuseComp;
	if (m_reflection == 0.0) //|| strength == 0.0)
		return diffuseComp;

	// calc reflective light
	Vector3 normal = intersection - m_pos;
	normal.normalize();

	Vector3 reflectVect = ray.getDir().getReflection(normal);
	Ray reflectRay(intersection, reflectVect);

	// find closest intersection part
	float32 objDistance = 20000;
	int		objIndex = -1;
	float32 _t;

	for (int n=0; n < objectList.size(); n++) {

		if (objectList[n]->getID() == m_id)
			continue;

		_t =	objectList[n]->getRayIntersection(reflectRay);
	
		if (_t < objDistance && (_t >= 0.0f)) {
			
			// Helper::Debug::log("Scene::rayTrace", "Object intersected at t = %f\n",t);
			objIndex = n;
			objDistance = _t;
		}
	}

	Color colReflection = diffuseComp;
	// objDistance now contains minuim distance to a sphere,
	// and objIndex contains object of intersection
	if (objIndex != -1)
		colReflection = objectList[objIndex]->rayTrace(reflectRay, objDistance, objects, lights, depth + 1);

	colReflection = colReflection * (reflectStrength * reflectStrength * m_reflection);

	// calc intersection with reflection and lights

	float32 invReflection = 1.0 - m_reflection;
	colReflection = (colReflection * m_reflection) + (diffuseComp * invReflection);

	return colReflection;
}

//===========================================================

float32 Plane::getRayIntersection(const Ray &ray) {
	
	float32 dot = ray.m_dir * m_normal;
	
	// prevent division by zero
	if (dot == 0.0f)
		return -1;

	return ((m_normal * ray.m_pos) - m_d) / dot;
}

//===========================================================
Color Plane::rayTrace(const Ray &ray, const float32 t, ObjectList * objects, LightList * lights, int depth) {

	LightList &lightList = *lights;
	ObjectList &objectList = *objects;

	// calculate point of intersection
	Vector3 intersection = ray.getPos() + (ray.getDir() * t);
	Vector3 intersectionNormal = m_normal;
	intersectionNormal.normalize();

	int32 u = int32(intersection.x) & 0xff;
	int32 v = int32(intersection.z) & 0xff;

	m_color.fromInt(m_texture->get()[(v << 8) + u]);
	Color diffuse = m_color;

	Vector3 reflection = intersection.getReflection(intersectionNormal);

	float32 strength = 0.0;
	float32 reflectStrength = 0.0;

	for (int i=0; i < lights->size(); i++) {

		// cast a ray to the lightsource
		Vector3 lightDir = lightList[i]->m_pos - intersection;
		float32 lightLen = lightDir.getLength();
		float32 lightLen2 = lightLen * lightLen;
		bool	inShadow = false;

		// check if light reaches to our object, or intersects with
		// another one before
		if (lightLen < lightList[i]->m_attenuation) {

			lightDir.normalize();
			inShadow = false;

			// check if point is in shadow
			for (int j = 0; j < objectList.size(); j++) {

				// dont check for collision on the object itself
				if (!(objectList[j]->getID() == m_id)) {

					Ray ray(intersection, lightDir);
					
					float t = objectList[j]->getRayIntersection(ray);
					
					if (t > 0) {

						Vector3 isVect = ray.getDir() * t;
						float32 isLen2 = isVect.getLengthBy2();

						if (isLen2 < lightLen2) {

							inShadow = true;
							break;
						}
					}
				}
			}
			
			// check if point is in shadow
			if (inShadow)
				continue;
			
			// calc fallof
			float32 falloff = (1.0 - (lightLen/lightList[i]->m_attenuation));
			float32 tempStrength = reflection * lightDir * falloff;
			
			// increate reflection factor
			if (tempStrength > 0.0f) {

				reflectStrength += tempStrength;
			}

			// calc diffuse light strengt on intersecion point
			tempStrength = intersectionNormal * lightDir * falloff;
			
			// increate diffuse light factor
			if (tempStrength > 0)
				strength += tempStrength;		
		}
	}

		// for now, support only one lightsource
	// TODO: Add support for more ;)
	Color diffuseComp = diffuse * strength; //((strength <= 1.0) ? strength : 1.0f);
	
	if (depth == Object::MAX_RAYTRACE_DEPTH)
		return diffuseComp;

//	return diffuseComp;
	if (m_reflection == 0.0) //|| strength == 0.0)
		return diffuseComp;

	// calc reflective light
	Vector3 normal = m_normal;
	normal.normalize();

	Vector3 reflectVect = ray.getDir().getReflection(normal);
	Ray reflectRay(intersection, reflectVect);

	// find closest intersection part
	float32 objDistance = 20000;
	int		objIndex = -1;
	float32 _t;

	for (int n=0; n < objectList.size(); n++) {

		if (objectList[n]->getID() == m_id)
			continue;

		_t =	objectList[n]->getRayIntersection(reflectRay);
	
		if (_t < objDistance && (_t >= 0.0f)) {
			
			// Helper::Debug::log("Scene::rayTrace", "Object intersected at t = %f\n",t);
			objIndex = n;
			objDistance = _t;
		}
	}

	Color colReflection = diffuseComp;
	// objDistance now contains minuim distance to a sphere,
	// and objIndex contains object of intersection
	if (objIndex != -1)
		colReflection = objectList[objIndex]->rayTrace(reflectRay, objDistance, objects, lights, depth + 1);

	colReflection = colReflection * (reflectStrength * m_reflection);

	// calc intersection with reflection and lights

	float32 invReflection = 1.0 - m_reflection;
	colReflection = (colReflection * m_reflection) + (diffuseComp * invReflection);

	return colReflection;
}

/*
Color Plane::rayTrace(const Ray &ray, const float32 t, ObjectList * objects, LightList * lights, int depth) {

	LightList &lightList = *lights;
	ObjectList &objectList = *objects;
	Color diffuse = m_color;

	// calculate point of intersection
	Vector3 intersection = ray.getPos() + (ray.getDir() * t);
	
	float32 strength = 0.0;

	for (int i=0; i < lights->size(); i++) {

		// cast a ray to the lightsource
		Vector3 lightDir = lightList[i]->m_pos - intersection;
		float32 lightLen = lightDir.getLength();
		float32 lightLen2 = lightLen * lightLen;
		bool	inShadow = false;

		// check if light reaches to our object, or intersects with
		// another one before
		if (lightLen < lightList[i]->m_attenuation) {

			lightDir.normalize();
			inShadow = false;

			// check if point is in shadow
			for (int j = 0; j < objectList.size(); j++) {

				// dont check for collision on the object itself
				if (!(objectList[j]->getID() == m_id)) {

					Ray ray(intersection, lightDir);
					
					float t = objectList[j]->getRayIntersection(ray); 
					if (t > 0.0f) {
	
						Vector3 isVect = ray.getDir() * t;
						float32 isLen2 = isVect.getLengthBy2();

						if (isLen2 < lightLen2) {

							inShadow = true;
							break;
						}
					}
				}
			}
			
			if (inShadow)
				continue;

			// calc normal at intersection point,
			// basically just intersecton - origin/centre of sphere
			Vector3 normal = m_normal;;
			
			// calc light strengt on intersecion point
			float32 tempStrength = normal * lightDir * (1.0 - lightLen/lightList[i]->m_attenuation);
			
			if (tempStrength>0)
				strength += tempStrength;		
		}
	}

		// for now, support only one lightsource
	// TODO: Add support for more ;)
	//return diffuse * ((strength <= 1.0) ? strength : 1.0f);

			// for now, support only one lightsource
	// TODO: Add support for more ;)
	Color diffuseComp = diffuse * strength; //((strength <= 1.0) ? strength : 1.0f);

	if (depth == Object::MAX_RAYTRACE_DEPTH)
		return diffuseComp;

//	return diffuseComp;
	if (m_reflection == 0.0)// || strength == 0.0)
		return diffuseComp;

	// calc reflective light
	Vector3 normal = m_normal;//intersection - m_pos;
	normal.normalize();

	Vector3 reflectVect = ray.getDir().getReflection(normal);
	Ray reflectRay(intersection, reflectVect);

	// find closest intersection part
	
	float32 objDistance = 20000;
	int		objIndex = -1;
	float32 _t;

	for (int n=0; n < objectList.size(); n++) {

		if (objectList[n]->getID() == m_id)
			continue;

		_t =	objectList[n]->getRayIntersection(reflectRay);
	
		if (_t < objDistance && (_t >= 0.0f)) {
			
			// Helper::Debug::log("Scene::rayTrace", "Object intersected at t = %f\n",t);
			objIndex = n;
			objDistance = _t;
		}
	}

	if (objIndex == -1)
		return diffuseComp;

	// objDistance now contains minuim distance to a sphere,
	// and objIndex contains object of intersection
	Color colReflection = objectList[objIndex]->rayTrace(reflectRay, objDistance, objects, lights, depth + 1);

	float32 invReflection = 1.0 - m_reflection;
	colReflection = (colReflection * m_reflection) + (diffuseComp * invReflection);

	return colReflection;
};
*/
//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================

//===========================================================
