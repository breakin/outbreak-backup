#ifndef __TOOON_RAYTRACER_ARGB_INC__
#define __TOOON_RAYTRACER_ARGB_INC__

#include "trt_typedef.h"
#include "trt_vector.h"

namespace Trazer {

	typedef Vector3 Color;
/*
	struct Color
	{
		/// constructor / destructor
		Color() : r(0.0f), g(0.0f), b(0.0f), a(1.0f) {}
		Color(float32 r, float32 g, float32 b, float32 a = 1.0f) :
		r(r), g(g), b(b), a(a) {}

		/// operator col * coffiecient
		Color operator * (float32 coff) const {

			if (coff > 1.0)
				coff = 1.0f;

			return Color(r * coff, g * coff, b * coff);
		}
		
		/// col * coff on <this>
		Color& operator *= (float32 coff) {
			
			if (coff > 1.0)
				coff = 1.0;

			*this = *this * coff;
			return *this;
		}

		/// friend operator
		friend Color operator * (const float32 coff, const Color &color) {
			return color.operator * (coff);
		}

		operator uint32() {

			return ((uint32)(r * 255.0) << 16) | ((uint32)(g * 255.0) << 8) | ((uint32)(b * 255.0));
		}

		float32 r;
		float32 g;
		float32	b;
		float32 a;
	};
	*/
}

#endif
