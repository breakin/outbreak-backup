#include <math.h>
#include <helper\core\image32.h>
#include <helper\directx\dx_device2d.h>
#include <helper\core\imagedrawer\imagedrawer.h>
#include <helper\core\archive\archivedirectory.h>

// tracer includes
#include "trt_scene.h"
#include "trt_ray.h"
#include "trt_rgb.h"
#include "trt_vector.h"
#include "trt_objects.h"


using namespace Trazer;

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hprecvInstance, LPSTR cmdLine, int cmdShow) {
	
	try {
	
		Helper::DirectDrawDevice2D	device;
		Helper::ImageDrawer			imageDrawer;
		Helper::Msg					msg;
		Helper::ArchiveDirectory	a(".");
		Helper::Image32						texture;


		a.load(texture, "tunnel.jpg");

		// config device
		device.config("width", "320");
		device.config("height", "200");
		device.config("bpp", "32");
		device.config("fullscreen", "false");
		device.config("title", "Tooon Raytracer");
		
		device.open();

		bool run = true;



		// initalize scene objects
		Sphere * sphere = new Sphere(1);
		Sphere * sphere2 = new Sphere(2);
		Sphere * sphere3 = new Sphere(4);
		Sphere * sphere4 = new Sphere(8);
		Plane * plane = new Plane(3);
		Plane * plane2 = new Plane(6);
		
		Light * light = new Light;
		Light * light2 = new Light;
		Light * light3 = new Light;

		sphere3->setColor(Color(0.8f,0.8f, 1.0f));
		sphere3->setPos(Vector3(-150.0,60.0f, 420.0f));
		sphere3->setReflection(0.2);
		sphere3->setRadius(55.0f);
		
		sphere->setColor(Color(0.8f,0.9f,1.0f));
		sphere->setPos(Vector3(-80,60.0f,200.0f));
		sphere->setRadius(40.0f);
		sphere->setReflection(0.6f);
		
		sphere2->setColor(Color(0.5f,0.5f,1.0f));
		sphere2->setPos(Vector3(0.0f,60.0f,100.0f));
		sphere2->setRadius(40.0f);
		sphere2->setReflection(0.6f);

		sphere4->setColor(Color(0.7f,0.7f,0.8f));
		sphere4->setPos(Vector3(-10.0f,60.0f,100.0f));
		sphere4->setRadius(10.0f);
		sphere4->setReflection(0.4f);
		

		plane->setReflection(0.0);
		plane->setColor(Color(1.0f, 1.0f, 1.0f));
		plane->set(0,-1.0,0.0f,90.0f);
		
		plane2->setReflection(0.0);
		plane2->setColor(Color(0.4f, 0.4f, 1.0f));
		plane2->set(0.0f,0.0,-1.0f,950.0f);

		light->m_attenuation = 630.0f;
		light2->m_attenuation = 290.0f;

		light->m_pos.z = 400.0f;
		light->m_pos.y = 0;
		light->m_pos.x = 0;
		
		light2->m_pos.z = 300.0f;
		light2->m_pos.y = -200;// cos(deg) * 300;
		light2->m_pos.x = 100;

		
		light3->m_pos.z = 100.0f;
		light3->m_pos.x = -100.0f;
		light3->m_pos.y = -102.0f;
		light3->m_attenuation = 320.0f;

		Scene scene(320,200);
		
		scene.addObject(sphere3);
		scene.addObject(sphere2);
	//	scene.addLight(light);
		scene.addObject(sphere);
		scene.addLight(light2);
		scene.addObject(sphere4);
	//	scene.addLight(light3);
		scene.addObject(plane);
	//	scene.addObject(plane2);

		plane->setTexture(texture);
		plane2->setTexture(texture);


		Helper::BaseImage32 & backBuffer = device.getBackBuffer();

		float32 deg = 0;

		
		uint32 offs;
		while (run) {
		
			sphere2->setPos(Vector3(100 * cos(deg), 20 * cos(deg), 300));

			/// check device for messages
			if (device.getMessage(msg)) {

				/// process message
				switch (msg.message) {

				case Helper::Msg::MSG_CLOSE:
					run = false;
				break;
				
				case Helper::Msg::MSG_KEYDOWN:
					
					if (msg.param == VK_ESCAPE)
						run = false;
				break;

				break;
				}
			}
			
			scene.rayTrace(backBuffer);
						
			//deg+=0.03;

			//imageDrawer.draw(texture,texture.getArea(), backBuffer, backBuffer.getArea(), ImageDrawer::BLIT_NORMAL);
			device.update();
		}

	
		device.close();
	}
	catch (Helper::Exception & e) {

		MessageBox(NULL, e.what(), "Application Exception", MB_OK);

	}
	
	return 1;
}
