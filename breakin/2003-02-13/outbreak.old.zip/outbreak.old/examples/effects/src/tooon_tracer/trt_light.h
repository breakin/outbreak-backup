#ifndef __TOOON_RAYTRACE_LIGHT_INC__
#define __TOOON_RAYTRACE_LIGHT_INC__

#include "trt_vector.h"
#include "trt_typedef.h"
#include "trt_rgb.h"

#include <vector>

namespace Trazer {

	struct Light
	{
		float32		m_attenuation;	/// Radius, not used
		Color		m_color;		/// Color of light
		Vector3		m_pos;			/// Position of light
	};

	typedef std::vector<Light*> LightList;

}

#endif
