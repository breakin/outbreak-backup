#include "trt_scene.h"
#include <helper\core\debug\debug.h>

using namespace Trazer;

//===========================================================

void Scene::calculateDirTable() {

	for (int y = 0; y < m_height; y++) {

		for (int x = 0; x < m_width; x++) {

			Vector3 dir;

			// set direction 
			dir.x = x - (m_width / 2);
			dir.y = y - (m_height / 2);
			dir.z = 256.0;
	
			// normalize direction vector
			dir.normalize();

			m_dirTable[x + m_width * y] = dir;
		}	
	}
}

//===========================================================

Scene::Scene(int32 vpWidth, int32 vpHeight) : m_dirTable(NULL) {

	if (vpWidth && vpHeight)
		create(vpWidth, vpHeight);
}

//===========================================================

Scene::~Scene() {

	release();

	delete[] m_dirTable;
}

//===========================================================

void Scene::create(int32 vpWidth, int32 vpHeight) {

	if (m_dirTable) 
		release();

	// set viewport dimensions
	m_width = vpWidth;
	m_height = vpHeight;

	m_dirTable = new Vector3[vpWidth * vpHeight];
	calculateDirTable();
}

//===========================================================

void Scene::release() {

	if (m_dirTable)
		delete[] m_dirTable;

	m_width = 0;
	m_height = 0;

	// delete all objects
	int i = 0;
	while (i < m_objects.size()) {

		delete m_objects[i];
		++i;
	}

	m_objects.clear();

	// delete all objects
	i = 0;
	while (i < m_lights.size()) {

		delete m_lights[i];
		++i;
	}

	m_lights.clear();
}

//===========================================================

void Scene::rayTrace(Helper::BaseImage32 &renderTarget) {

	if ((renderTarget.getWidth() != m_width) || 
		(renderTarget.getHeight() != m_height))
		throw std::exception("Invalid format on rendertarget!");
			
	uint32 * pixels = (uint32*) renderTarget.get();

	// set vewpoint
	Vector3 viewPoint(0,0,-1);
	Ray		ray(viewPoint,Vector3(0,0,0));
	int offs = 0;

	for (int y=0; y < m_height; y++) {
		
		for (int x = 0; x < m_width; x++) {

			
			ray.setDir(m_dirTable[offs + x]);
			float	t;
			float	objDistance = 100000.f; // 
			int		objIndex = -1;
			/// find smallest distance of intersection
			for (int i=0; i < m_objects.size(); i++) {

				t =	m_objects[i]->getRayIntersection(ray);
			
				
				if (t < objDistance && (t >= 0.0f)) {
					
					// Helper::Debug::log("Scene::rayTrace", "Object intersected at t = %f\n",t);
					objIndex = i;
					objDistance = t;
				}
			}

			// only perform the actual trace if there was any obects interseted 
			// by the ray
			pixels[offs + x] = 0x000000;

			if (objDistance > 0 && (objIndex != -1)) {
		
				Color col = m_objects[objIndex]->rayTrace(ray, objDistance, &m_objects, &m_lights, 0);				
				pixels[offs + x] = uint32(col);
				
			}
		}
	
		offs+=m_width;
	}
}

//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
//===========================================================
