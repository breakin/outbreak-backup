#include <math.h>
#include <helper\directx\dx_device2d.h>
#include <helper\win32\win32_device2d.h>
#include <helper\core\image32.h>
#include <helper\core\imagedrawer\imagedrawer.h>
#include <helper\core\imagetool\imagetool.h>
#include <helper\core\archive\archivedirectory.h>
#include <math\e3d_matrix.h>
#include <math\e3d_vector.h>
#include <e3d_vertex.h>
#include <e3d_sysdef.h>

using namespace Helper;

struct LookupEntry {

	uint32 offset;
	uint32 shade;
};

LookupEntry *lookup = new LookupEntry[640 * 480];

void generateLookup(LookupEntry *lut);
void drawLookup(LookupEntry *lut, int startPadd, int offs1, int offs2, BaseImage32 &texture, BaseImage32&);
void blur32(BaseImage32 &image, int offs, int numLines);

int WINAPI WinMain(HINSTANCE hInstance , HINSTANCE pPrevInstace, LPSTR cmdLine, int show) {

	try {
		
	// appl. objects
	DirectDrawDevice2D	device;
	Msg					msg;
	ImageDrawer			drawer;
	Image32				texture;
	Image32				texture2;
	Image32				back;
	float32				deg = 0;
	float32				degadd = 0.02f;
	bool				run = true;
	ArchiveDirectory	a(".");
	ImageTool			tool;

	// setup device
	device.config("width"		,"512");
	device.config("height"		,"384");
	device.config("bpp"			,"32");
	device.config("fullscreen"	,"false");
	device.config("title"		,"Coolie Tunnel Effect");
	device.open();

	// get device's backbuffer
	BaseImage32 &backBuffer = device.getBackBuffer();
	back.resize(640,480);
	
	a.load(texture , "texture10.JPG");
	
	generateLookup(lookup);

	int offs1 = 0;
	int offs2 = 512 * 200;
	
	back.resize(512,384);
	
	drawer.setScaleMode(drawer.SCALE_BILINEAR);		
	
	float width	 = (float)texture.getWidth() / 20.0 / 2.0;
	float height = (float)texture.getHeight() / 20.0 / 2.0;

	float32 w = width;
	float32 h = height;
	

	while (run) {
		
		if (device.getMessage(msg,true)) {

			switch (msg.message) {

			case Msg::MSG_CLOSE:
			case Msg::MSG_KEYDOWN:
			run = false;
			}
		}
		
		if (h < texture.getHeight() * 2) {

			w+=2.5f;
			h+=2.5f;
		}

		//drawLookup(lookup,1,offs1,offs2,texture,back);
		//blur32(back, 100, 264); //er.clear(device.getBackBuffer(),backBuffer.getArea());
//		int offs = 100 + (sin(deg) * 99.0);
		drawer.draw(texture,texture.getArea(), back, AreaInt((256.0 - ceil(w)), (192.0 - ceil(h)), (ceil(w) * 2.0), (ceil(h) *2.0)), drawer.BLIT_NORMAL);
//		drawer.draw(texture,texture.getArea(), back, back.getArea(),drawer.BLIT_NORMAL);
	//	drawer.setScaleMode(drawer.SCALE_LINEAR);
	//	drawer.draw(texture,AreaInt(0,0, 100 + (sin(deg) * 99.0),100 + (sin(deg) * 99.0)), back, AreaInt(0,100,100,100),drawer.BLIT_NORMAL);
		
		drawer.copy(back,backBuffer);
	//	drawer.clear(back,back.getArea());
		device.update();
		
		deg += 0.2;
	}

	}
	catch (exception &e) {

		MessageBox(NULL, e.what(), "EXCEPTION!", MB_OK);
	}
	return 1;

}


void generateLookup(LookupEntry *lut) {

	
	for (int y = 0; y < 264; y++) {

		for (int x=0; x < 640; x++) {

			float32 fx = (float)(x - 320);
			float32 fy = (float)(y - 132);

			float32 len = sqrt (fx*fx + fy*fy);
			float32 deg = atan2(fx,fy);
			
			float32 u = (deg / Eternity::E3D_PI * 128.0);
			float32 v = 1000.0 / len;

			fx /= 320.0;
			fy /= 132.0;
			float32 normLen	= 1.0 - sqrt (fx*fx + fy*fy);
			
			if (normLen < 0)
				normLen = 0;

			uint32 iShade = (normLen * normLen * 255.0);
			lut[y * 640 + x].shade = (iShade << 8) | (iShade << 16) | (iShade);


			lut[y * 640 + x]. offset = ((int)u + (int)v * 256);
		}
	}
}

void drawLookup(LookupEntry *lut,  int startPadd, int offs1, int offs2, BaseImage32 &texture, BaseImage32 &backBuffer) {

	uint32* textPixels  = texture.get();
	uint32* backPixels  = backBuffer.get();
	uint32  subMask		= 0x000aff02;
	int wideScreenStart = 640 * 100;

	int i = 0; //wideScreenStart;
	backPixels += wideScreenStart;
	int screenSize = 640 * 264;
	
	while (i < screenSize) {

		uint32 offs   = lut[i].offset;
		uint32 shade  = lut[i].shade;
		uint32 color1 = textPixels[0xffff & (offs + offs1)];
		uint32 color2 = textPixels[0xffff & (offs + offs2)];
		
		__asm {
			
			mov		edi, backPixels
			movd	mm0, color1
			movd	mm1, color2
			movd	mm3, shade
			//psrl	mm1,2
			paddusb  mm0, mm1
		//	paddusb	mm0, mm1
		//	pand	mm1, subMask
			paddusb mm0, mm3
//			paddusb	mm0, mm1
			
			movd	[edi], mm0
		}

		backPixels++;
		i++;
	}

	_asm { emms }
}

void blur32(BaseImage32 &image, int offsLine, int numLines) {

	uint32 *dst = (uint32*)image.get();
	offsLine = offsLine * image.getWidth() * 4;
	numLines = numLines * image.getWidth();
	
	_asm
	{
		mov edi, dst
		mov esi, edi
		mov ecx, numLines
		add esi, offsLine
		add edi, offsLine
		//mov eax, 0x002a2a1a
		mov eax, 0x00050a04
		movd mm3, eax

		LP:
			pxor mm5, mm5
			pxor mm2, mm2

	
			movq mm1, [esi+4]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
			movq mm1, [esi-4]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
			movq mm1, [esi+8]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
			
			movq mm1, [esi-8]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
/*
			movq mm1, [esi-16]
			punpcklbw mm1, mm5
			paddusw mm2, mm1

			movq mm1, [esi + 24]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
			movq mm1, [esi - 24]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
			movq mm1, [esi - 28]
			punpcklbw mm1, mm5
			paddusw mm2, mm1
*/


			psrlw mm2,2
			packuswb mm2,mm2
			psubusb mm2,mm3

			movd  [edi], mm2

			add esi, 4
			add edi, 4
			dec ecx
			jnz LP
		
		emms
	}
}