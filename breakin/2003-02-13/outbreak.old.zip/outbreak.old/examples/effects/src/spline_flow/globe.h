#ifndef __EFFECTS_GLOBE_INC__
#define __EFFECTS_GLOBE_INC__

#include <e3d_vertex.h>

namespace Tooon {


	class CircularObject
	{
	public:

		CircualEntity();
		virtual ~CircularEntity();

		virtual void setRadius(float32 radius);
		virtual void setVertexCount(int32 vertexCount);
		virtual void init() = 0;
		
	protected:

		CVertexBuffer		m_vertices;		///< Amount of vertices in entiry
		float32				m_radius;		///< Radius of object
		Eternity::CMatrix	m_matrix;
	};

	class Shere : Circle 
	{
	public:
		
		Globe();
		~Globe();

		virtual void init()

	protected:
	
	};


}

#endif