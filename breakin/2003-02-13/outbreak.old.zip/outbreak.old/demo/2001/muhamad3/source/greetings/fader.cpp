#include "fader.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectFader::EffectFader(MuhamadGlobals *initGlobals) : globals(initGlobals) {
	outbreak = globals->imageTool->decode(globals->archive->getFile("greetings/outbreak.jpg"));
	group    = globals->imageTool->decode(globals->archive->getFile("greetings/greetings.jpg"));
	people   = globals->imageTool->decode(globals->archive->getFile("greetings/people.jpg"));

	outbreakShow=false;
	outbreakPercent = 0.0;

	outbreakMoveShow=false;
	outbreakMovePercent = 0.0;

	peopleShow=false;
	peoplePercent = 0.0;
	peopleIndex = 0;
	
	groupShow=false;
	groupPercent = 0.0;
	groupIndex = 0;

	outbreaky = (globals->screen->getHeight()>>1) - outbreak.getHeight();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectFader::executeTrigger(const std::string& name, const std::string& value) {
	if (name=="outbreak") {
		if (value=="show") {
			outbreakShow  = true;
			outbreakPercent = 0.0;
		}
		if (value=="hide") {
			outbreakShow  = false;
			outbreakPercent = 1.0;
		}
	}

	if (name=="outbreakmove") {
		outbreakMovePercent=0.0;
		outbreakMoveShow = true;
	}
	
	if (name=="people") {
		int nr = atoi(value.c_str());
		if (nr!=-1) {
			// Fade in
			peopleShow = true;
			peoplePercent = 0.0;
			peopleIndex = nr;
		} else {
			// Fade out
			peopleShow = false;
			peoplePercent = 1.0;
		}
	}

	if (name=="group") {
		int nr = atoi(value.c_str());
		if (nr!=-1) {
			// Fade in
			groupShow = true;
			groupPercent = 0.0;
			groupIndex = nr;
		} else {
			// Fade out
			groupShow = false;
			groupPercent = 1.0;
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectFader::update(const float64 timer, const float64 delta, const float64 percent) {
	uint32 x,y;

	// Clear background.
	globals->imageDrawer->clear(*globals->screen, globals->screen->getArea());

	// --- Draw outbreak logo. ----------
	if (outbreakShow==true) {
		if (outbreakPercent<1.0) {
			outbreakPercent += delta*4;
			if (outbreakPercent>1.0) outbreakPercent=1.0;
		}
	}

	if (outbreakShow==false) {
		if (outbreakPercent>0.0) {
			outbreakPercent -= delta*1.2;
			if (outbreakPercent<0.0) outbreakPercent=0.0;
		}
	}

	if (outbreakMoveShow==true) {
		if (outbreakMovePercent<1.0) {
			outbreakMovePercent += delta;
			if (outbreakMovePercent>1.0) outbreakMovePercent=1.0;
		}
	}

	globals->imageDrawer->setAlphaMode(ImageDrawer::ALPHA_CONSTANT, outbreakPercent*255);
	x = (globals->screen->getWidth()>>1) - (outbreak.getWidth()>>1);
	globals->imageDrawer->draw(outbreak, outbreak.getArea(), *globals->screen, x, outbreaky+outbreakMovePercent*50, ImageDrawer::BLIT_ALPHABLEND);

	// --- Draw personal greetings.
	if (peopleShow==true) {
		if (peoplePercent<1.0) {
			peoplePercent += delta;
			if (peoplePercent>1.0) peoplePercent=1.0;
		}
	}

	if (peopleShow==false) {
		if (peoplePercent>0.0) {
			peoplePercent -= delta*1.2;
			if (peoplePercent<0.0) peoplePercent=0.0;
		}
	}

	globals->imageDrawer->setAlphaMode(ImageDrawer::ALPHA_CONSTANT, peoplePercent*255);
	y = (globals->screen->getHeight()>>1) + 5;
	AreaInt area(0,peopleIndex*50,640,50);
	globals->imageDrawer->draw(people, area, *globals->screen, 0, y, ImageDrawer::BLIT_ALPHABLEND);

	// --- Draw group greetings.
	if (groupShow==true) {
		if (groupPercent<1.0) {
			groupPercent += delta;
			if (groupPercent>1.0) groupPercent=1.0;
		}
	}

	if (groupShow==false) {
		if (groupPercent>0.0) {
			groupPercent -= delta*1.2;
			if (groupPercent<0.0) groupPercent=0.0;
		}
	}

	globals->imageDrawer->setAlphaMode(ImageDrawer::ALPHA_CONSTANT, groupPercent*255);
	area.setTop(groupIndex*100);
	globals->imageDrawer->draw(group, area, *globals->screen, 0, 5, ImageDrawer::BLIT_ALPHABLEND);
	area.setTop(groupIndex*100+50);
	globals->imageDrawer->draw(group, area, *globals->screen, 0, 425, ImageDrawer::BLIT_ALPHABLEND);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
