#include "intro.h"
#include <math.h>

using namespace Helper;
using namespace std;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectIntro::EffectIntro(MuhamadGlobals *initGlobals) : globals(initGlobals) {

	iLogo       = globals->imageTool->decode(globals->archive->getFile("intro/logo.tga"));
	iLogoShadow = globals->imageTool->decode(globals->archive->getFile("intro/logo-shadow.tga"));

	iWallLight  = globals->imageTool->decode(globals->archive->getFile("intro/wall-light.tga"));
	iFlare      = globals->imageTool->decode(globals->archive->getFile("intro/flare.tga"));

	lightsMoving=false;
	glowing=false;
	theColor=0;

	lightLeftX =-iFlare.getWidth()/2.0;
	lightRightX=globals->screen->getWidth()+iFlare.getWidth()/2.0;
	lightLeftY =globals->screen->getHeight()/2.0-iLogo.getHeight()/4.0;
	lightRightY=globals->screen->getHeight()/2.0+iLogo.getHeight()/4.0;

	blackie=false;

	for (int C=0; C<8; C++) {
		blaBlaList[C].active=false;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectIntro::executeTrigger(const std::string& name, const std::string& value) {
	if (name == "startlights") {
		lightsMoving=true;

	} else if (name=="black") {

		blackie=true;

	} else if (name=="glow") {
		/*glowing=true;
		lightsMoving=false;*/
	} else if (name == "letter") {

		const int hejsan=atoi(value.c_str());

		blaBlaList[hejsan].active=true;
		blaBlaList[hejsan].startTime=globals->music->getTimer();
		blaBlaList[hejsan].x=(hejsan<4) ? lightLeftX : lightRightX;
		blaBlaList[hejsan].y=(hejsan<4) ? lightLeftY : lightRightY;

		blaBlaList[hejsan].area=AreaInt(hejsan*iLogo.getWidth()/8, 0, iLogo.getWidth()/8, iLogo.getHeight());
//		blaBlaList[hejsan].areaShadow=AreaInt(hejsan*iLogoShadow.getWidth()/8, 0, iLogoShadow.getWidth()/8, iLogoShadow.getHeight());
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectIntro::update(const float64 timer, const float64 delta, const float64 percent) {

	globals->imageDrawer->clear(*globals->screen, globals->screen->getArea());

	if (!blackie) {

		const float64 screenWidth =globals->screen->getWidth();
		const float64 screenHeight=globals->screen->getHeight();
		const float64 speedX=0.15;
		const float64 speedY=0.008;
		const float64 perspective=4.0;

		if (lightsMoving) {
			lightLeftX +=delta*speedX*screenWidth;
			lightRightX-=delta*speedX*screenWidth;
			lightLeftY +=delta*speedY*screenHeight;
			lightRightY-=delta*speedY*screenHeight;
		}

		/*if (glowing) {
			theColor+=delta*1.0;
			if (theColor>1.0) theColor=1.0;
		}*/

		const float64 leftShadowX  =screenWidth/2.0-(lightLeftX -screenWidth/2.0)/perspective;
		const float64 rightShadowX =screenWidth/2.0-(lightRightX-screenWidth/2.0)/perspective;

		const float64 leftShadowY  =screenHeight/2.0-(lightLeftY-screenHeight/2.0)/perspective;
		const float64 rightShadowY =screenHeight/2.0-(lightRightY-screenHeight/2.0)/perspective;

		// ------------------

		if (lightsMoving) {
			// Draw the logo
			for (int C=0; C<8; C++) {
				if (blaBlaList[C].active) {

					float64 t=(globals->music->getTimer()-blaBlaList[C].startTime)/2.0;
					if (t>1.0) t=1.0;

					int		zoomWidth    = (t * iLogo.getWidth() / 8.0);
					int		zoomHeight   = (t * (float)iLogo.getHeight());
					int		shZoomWidth  = (t * iLogoShadow.getWidth() / 8.0);
					int		shZoomHeight = (t * (float)iLogoShadow.getHeight());

					//float64 x=blaBlaList[C].x*(1.0-t)+((screenWidth/2.0-iLogo.getWidth()/2.0)+iLogo.getWidth()*C/8.0)*t       -iLogo.getWidth()/8.0/2.0;
					//float64 y=blaBlaList[C].y*(1.0-t)+screenHeight/2.0*t-iLogo.getHeight()/2.0;
					float64 x=blaBlaList[C].x*(1.0-t)+((screenWidth/2.0-iLogo.getWidth()/2.0)+iLogo.getWidth()*C/8.0)*t;//-zoomWidth/2.0;
					float64 y=blaBlaList[C].y*(1.0-t)+screenHeight/2.0*t-zoomHeight/2.0;
					float64 shLeftX  = x - (lightLeftX  - x)/8.0;//(screenWidth  / 2.0) / 8.0;
					float64 shLeftY  = y - (lightLeftY  - y)/8.0;//(screenHeight / 2.0) / 8.0;
					float64 shRightX = x - (lightRightX - x)/8.0;//(screenWidth  / 2.0) / 8.0;
					float64 shRightY = y - (lightRightY - y)/8.0;//(screenHeight / 2.0) / 8.0;
					
					int		alpha		= (t * 255.0);
					
					blaBlaList[C].screenArea.set(x,y, zoomWidth, zoomHeight);
					blaBlaList[C].shadowAreaLeft.set(shLeftX, shLeftY, shZoomWidth, shZoomHeight);
					blaBlaList[C].shadowAreaRight.set(shRightX, shRightY, shZoomWidth, shZoomHeight);

					//globals->imageDrawer->draw(iLogo, blaBlaList[C].area, *globals->screen, x,y, ImageDrawer::BLIT_ALPHABLEND);
					//globals->imageDrawer->setAlphaMode(ImageDrawer::ALPHA_CONSTANT,alpha);
					
				}
			}
		}
		


		if (lightsMoving) {
			// Draw lighs on the wall
			globals->imageDrawer->draw(iWallLight, iWallLight.getArea(), *globals->screen, lightLeftX -iWallLight.getWidth()/2,  lightLeftY-iWallLight.getHeight()/2,ImageDrawer::BLIT_SATURATION);
			globals->imageDrawer->draw(iWallLight, iWallLight.getArea(), *globals->screen, lightRightX-iWallLight.getWidth()/2,  lightRightY-iWallLight.getHeight()/2,ImageDrawer::BLIT_SATURATION);

			//globals->imageDrawer->draw(iLogoShadow, iLogoShadow.getArea(), *globals->screen, leftShadowX -iLogoShadow.getWidth()/2, leftShadowY -iLogoShadow.getHeight()/2,ImageDrawer::BLIT_ALPHABLEND);
			//globals->imageDrawer->draw(iLogoShadow, iLogoShadow.getArea(), *globals->screen, rightShadowX-iLogoShadow.getWidth()/2, rightShadowY-iLogoShadow.getHeight()/2,ImageDrawer::BLIT_ALPHABLEND);
			globals->imageDrawer->setScaleMode(ImageDrawer::SCALE_LINEAR);

			for (int J=0; J < 8; J++) {
				
				if (blaBlaList[J].active) {
					
					globals->imageDrawer->draw(iLogoShadow, AreaInt(J * iLogoShadow.getWidth() / 8.0 ,0,iLogoShadow.getWidth() / 8.0, iLogoShadow.getHeight()), *globals->screen, blaBlaList[J].shadowAreaLeft, ImageDrawer::BLIT_ALPHABLEND);//rightShadowX-iLogoShadow.getWidth()/8.0/2, rightShadowY-iLogoShadow.getHeight()/8.0/2.0,ImageDrawer::BLIT_ALPHABLEND);
					globals->imageDrawer->draw(iLogoShadow, AreaInt(J * iLogoShadow.getWidth() / 8.0 ,0,iLogoShadow.getWidth() / 8.0, iLogoShadow.getHeight()), *globals->screen, blaBlaList[J].shadowAreaRight, ImageDrawer::BLIT_ALPHABLEND);//rightShadowX-iLogoShadow.getWidth()/8.0/2, rightShadowY-iLogoShadow.getHeight()/8.0/2.0,ImageDrawer::BLIT_ALPHABLEND);
				}
			}

			for (int C=0; C < 8; C++) {
				if (blaBlaList[C].active) 	
					globals->imageDrawer->draw(iLogo, blaBlaList[C].area, *globals->screen, blaBlaList[C].screenArea, ImageDrawer::BLIT_ALPHABLEND);
			}

			globals->imageDrawer->setAlphaMode(ImageDrawer::ALPHA_PERPIXEL);				
			globals->imageDrawer->setScaleMode(ImageDrawer::SCALE_BILINEAR);

		}


		/*if (glowing) {
			// Draw the logo
			
			globals->imageDrawer->setAlphaMode(ImageDrawer::ALPHA_CONSTANT, (1.0-theColor)*255.0);
			globals->imageDrawer->draw(iLogo, iLogo.getArea(), *globals->screen, screenWidth/2-iLogo.getWidth()/2, screenHeight/2-iLogo.getHeight()/2,ImageDrawer::BLIT_ALPHABLEND);

			globals->imageDrawer->setAlphaMode(ImageDrawer::ALPHA_CONSTANT, theColor*255.0);
			globals->imageDrawer->draw(iLogoBlur, iLogoBlur.getArea(), *globals->screen, screenWidth/2-iLogoBlur.getWidth()/2, screenHeight/2-iLogoBlur.getHeight()/2,ImageDrawer::BLIT_ALPHABLEND);
			globals->imageDrawer->setAlphaMode(ImageDrawer::ALPHA_PERPIXEL, 0);
		}*/
		
		if (lightsMoving) {
			// Draw the flares
			globals->imageDrawer->draw(iFlare, iFlare.getArea(), *globals->screen, lightLeftX -iFlare.getWidth()/2, lightLeftY -iFlare.getHeight()/2,ImageDrawer::BLIT_SATURATION);
			globals->imageDrawer->draw(iFlare, iFlare.getArea(), *globals->screen, lightRightX-iFlare.getWidth()/2, lightRightY-iFlare.getHeight()/2,ImageDrawer::BLIT_SATURATION);
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -