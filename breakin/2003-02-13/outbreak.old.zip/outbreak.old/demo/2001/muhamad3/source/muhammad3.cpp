/*
	Owner   : Albert Sandberg (thec^outbreak)
	Purpose : Demo

	Todo    : Music implementation, screenshot's (screenshot/screenshot<sec>.tga), pause demo.
	        : Fast forward/backward (setTime doesn't exist right now).
*/

// Helper includes
#include <helper/helper.h>
#include <helper/win32/win32_device2d.h>
#include <helper/directx/dx_device2d.h>
#include "globals.h"

// Standard includes
#include <fstream>
#include <conio.h>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <math.h>

// Effect includes
#include "intro/intro.h"
#include "slideshow/slideshow.h"
//#include "credits/credits.h"
#include "greetings/fader.h"
#include "end/end.h"

// Namespaces
using namespace Helper;
using namespace std;

// ---------------------------------------------------------------------------

namespace Helper {

	class MuhamadGlobals_Impementation : public MuhamadGlobals {
	public:

		MuhamadGlobals_Impementation() {
			archive=new ArchiveRAR("muhamad3.rar");
			//archive=new ArchiveDirectory(".");
			setup=new XmlParser(archive->getFile("setup.xml").get());
			
			Setup general(setup, "general");
			device2D=new DirectDrawDevice2D;
			device2D->config("width",      general.getAttribute("width"));
			device2D->config("height",     general.getAttribute("height"));
			device2D->config("title",      general.getAttribute("title"));
			device2D->config("bpp",        "32");
			device2D->config("caption",    general.getAttribute("caption"));

			#ifdef _DEBUG
				device2D->config("fullscreen", "false");
			#else
				device2D->config("fullscreen", general.getAttribute("fullscreen"));
			#endif

			imageTool=new ImageTool;
			imageDrawer=new ImageDrawer;
			music=new Music;

			device2D->open();

			screen=new Image32(device2D->getWidth(), device2D->getHeight());
			imageDrawer->clear(*screen, screen->getArea());

			Image32 loading = imageTool->decode(archive->getFile("common/loading.jpg"));
			imageDrawer->draw(loading, loading.getArea(), *screen, (screen->getWidth()>>1)-(loading.getWidth()>>1), (screen->getHeight()>>1)-(loading.getHeight()>>1), ImageDrawer::BLIT_NORMAL);

			device2D->update(*screen);
		}

		~MuhamadGlobals_Impementation() {
			delete music;
			delete device2D;
			delete imageDrawer;
			delete imageTool;
			delete screen;
			delete setup;
			delete archive;		
		}
	};
}

// ---------------------------------------------------------------------------

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevinst, LPSTR cmdline, int showstate) {
	try {
		Debug::log("Main()", "Demo started...");

		ArchiveDirectory screenShots("screenshots");
		MuhamadGlobals_Impementation globals;
		
		// - - - - - - - -
		// Create effects.
		// - - - - - - - - - -
		EffectIntro     effectIntro(&globals);
		EffectSlideshow effectSlideshow(&globals);
		EffectFader     effectFader(&globals);

		// - - - - - - - -
		// Initialize script, the effects are drawn in the order they are entered!
		// In-script order is primary, this order is secondary if the effects not found in script.
		// With other words, don't trust this order, trust the script!
		// - - - - - - - - - -
		Script script(XmlParser(globals.archive->getFile("script.xml").get()));

		script.addCallback("intro"     , "intro"    , &effectIntro);
		script.addCallback("slideshow" , "slideshow", &effectSlideshow);
		script.addCallback("greetings" , "fader"    , &effectFader);

		globals.music->load("muhamad3.mp3");
		globals.music->play();

		// Create timer, replace with music's timer later!
		Clock timer;
		bool  exit = false;

		while (1) {
			if (!script.update(timer)) return 0;

			globals.device2D->update(*globals.screen, true);

			Msg msg;
			if (globals.device2D->getMessage(msg)) {
				if (msg.message == Helper::Msg::MSG_CLOSE) return 2;

				if (msg.message == Helper::Msg::MSG_KEYDOWN) {

					Debug::log("WinMain()", "Key param:%d, extra:%d", msg.param, msg.extra);
					
					if (msg.param == 27) return 3;     // Escape, abort demo!

					if ((msg.param == 'p') || (msg.param == 'P')) {         // Pause demo
						// *will* pause the demo ;)
						Debug::log("WinMain()", "Pause requested!");
					}

					if ((msg.param == 's') || (msg.param == 'S')) {

						char fileName[256];
						const int min=int(timer.get()/60.0);
						const int sec=int(timer.get())%60;
						const int hun=int(timer.get()*100.0)%100;
						
						sprintf(fileName, "(%d.%02d.%02d).jpg", min,sec,hun);

						ImageCoder::EncodeSettings e;
						e.saveAlphaChannel=false;

						Debug::log("main()", "Saving screenshot [%s].", fileName);

						screenShots.createFile(fileName, globals.imageTool->encode(*globals.screen, fileName, e));
					}

					if (msg.param == 37) {
						// Left arrow, jump back 5 seconds
						float tid = timer.get();
						tid -=5.0f;
						if (tid<0) tid=0;
						//timer.set(tid);
					}

					if (msg.param == 39) {
						// Right arrow, forward 5 seconds.
						float tid = timer.get();
						tid +=5.0f;
						//timer.set(tid);
					}
				}
			}
		}
	}
	
	// Catch exceptions.
	catch (const Helper::Exception &e) {
		MessageBox(NULL, e.what(), "Helper::Exception", MB_OK);
	}

	// Catch unknown exceptions.
	catch (...) {
		MessageBox(NULL, "Unknown exception", "(...)::Exception", MB_OK);
	}

	// Return the answer :-D
	return 42;
}