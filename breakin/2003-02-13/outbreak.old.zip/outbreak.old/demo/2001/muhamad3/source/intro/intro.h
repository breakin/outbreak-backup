#ifndef MUHAMMED_EFFECT_INTRO_H
#define MUHAMMED_EFFECT_INTRO_H

/*
	Owner   : Albert Sandberg (thec^outbreak)
	Purpose : Demo

	Todo    : The whole thing :)
*/

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectIntro : public Effect {
private:
	
	// Effect specific data.
	Image32 iLogo;
	Image32 iLogoShadow;
	Image32 iLogoBlur;
	Image32 iFlare;
	Image32 iWallLight;

	float64 lightLeftX,lightRightX;
	float64 lightLeftY,lightRightY;
	bool    lightsMoving, glowing, blackie;
	float64 theColor;

	struct BlaBla {
		float64 x, y;
		float64 startTime;
		bool active;
		AreaInt area,shadowAreaLeft,shadowAreaRight;
		AreaInt screenArea;

	} blaBlaList[8];

	// Demo backbuffer image.
	MuhamadGlobals* globals;

public:
	
	EffectIntro(MuhamadGlobals *globals);

	void executeTrigger(const std::string& name, const std::string& value);

	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif