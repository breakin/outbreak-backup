#ifndef MUHAMMED_EFFECT_SLIDESHOW_H
#define MUHAMMED_EFFECT_SLIDESHOW_H

/*
	Owner   : Albert Sandberg (thec^outbreak)
	Purpose : Demo
*/

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectSlideshow : public Effect {
private:
	std::string textString;
	MuhamadGlobals *globals;

	Image32 slideShow[20];
	uint8   lastPage;
	uint8   currentPage;

public:
	EffectSlideshow(MuhamadGlobals *globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif