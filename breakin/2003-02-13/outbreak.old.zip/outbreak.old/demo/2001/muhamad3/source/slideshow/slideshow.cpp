#include "slideshow.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectSlideshow::EffectSlideshow(MuhamadGlobals *initGlobals) : globals(initGlobals) {
	slideShow[ 0] = globals->imageTool->decode(globals->archive->getFile("slideshow/muhamad3.jpg"));
	slideShow[ 1] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide1.jpg"));
	slideShow[ 2] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide2.jpg"));
	slideShow[ 3] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide3.jpg"));
	slideShow[ 4] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide4.jpg"));
	slideShow[ 5] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide5.jpg"));
	slideShow[ 6] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide6.jpg"));
	slideShow[ 7] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide7.jpg"));
	slideShow[ 8] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide8.jpg"));
	slideShow[ 9] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide9.jpg"));
	slideShow[10] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide10.jpg"));
	slideShow[11] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide11.jpg"));
	slideShow[12] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide12.jpg"));
	slideShow[13] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide13.jpg"));
	slideShow[14] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide14.jpg"));
	slideShow[15] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide15.jpg"));
	slideShow[16] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide16.jpg"));
	slideShow[17] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide17.jpg"));
	slideShow[18] = globals->imageTool->decode(globals->archive->getFile("slideshow/slide18.jpg"));
	slideShow[19] = globals->imageTool->decode(globals->archive->getFile("slideshow/credits.jpg"));

	currentPage = 0;
	lastPage    = 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectSlideshow::executeTrigger(const std::string& name, const std::string& value) {
	if (name=="next") {
		lastPage = currentPage;
		currentPage = atoi(value.c_str());
	}

	if (name=="last") {
		lastPage = atoi(value.c_str());
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectSlideshow::update(const float64 timer, const float64 delta, const float64 percent) {

	globals->imageDrawer->clear(*globals->screen, globals->screen->getArea());

	if (currentPage!=lastPage) {
		// Fade in the new picture, start with copying the last image. FIX!
		if (lastPage>=0) {
			globals->imageDrawer->draw(slideShow[lastPage], slideShow[lastPage].getArea(), *globals->screen, 320-(slideShow[lastPage].getWidth()>>1), 10, ImageDrawer::BLIT_NORMAL);
		}

		globals->imageDrawer->setAlphaMode(ImageDrawer::ALPHA_CONSTANT, percent*255);
		globals->imageDrawer->draw(slideShow[currentPage], slideShow[currentPage].getArea(), *globals->screen, 320-(slideShow[currentPage].getWidth()>>1),10, ImageDrawer::BLIT_ALPHABLEND);

	} else {
		if (lastPage>=0) {
			globals->imageDrawer->draw(slideShow[lastPage], slideShow[lastPage].getArea(), *globals->screen, 320-(slideShow[lastPage].getWidth()>>1),10,ImageDrawer::BLIT_NORMAL);
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
