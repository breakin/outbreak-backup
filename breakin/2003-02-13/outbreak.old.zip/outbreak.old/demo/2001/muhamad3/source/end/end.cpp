#include "end.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectEnd::EffectEnd(MuhamadGlobals *initGlobals) : globals(initGlobals) {
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectEnd::update(const float64 delta, const float64 percent) {
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
