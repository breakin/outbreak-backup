#ifndef MUHAMMED_EFFECT_FADER_H
#define MUHAMMED_EFFECT_FADER_H

/*
	Owner   : Albert Sandberg (thec^outbreak)
	Purpose : Fades in texts. Simply, not more, just this
*/

#include <helper/core/imagedrawer/imagedrawer.h>

#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectFader : public Effect {
private:
	int             outbreaky;
	Helper::Image32 outbreak;
	bool            outbreakShow;
	Helper::float64 outbreakPercent;
	
	bool            outbreakMoveShow;
	Helper::float64 outbreakMovePercent;

	Helper::Image32 group;
	int             groupIndex;
	bool            groupShow;
	Helper::float64 groupPercent;

	Helper::Image32 people;
	int             peopleIndex;
	bool            peopleShow;
	Helper::float64 peoplePercent;

	MuhamadGlobals *globals;

public:
	
	EffectFader(MuhamadGlobals *globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif