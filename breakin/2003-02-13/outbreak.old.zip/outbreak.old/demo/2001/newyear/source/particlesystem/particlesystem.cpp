#include "particlesystem.h"

void CParticleSystemNormal::create(int num) {

	numParticles = num;
	//if(particles) particles = NULL;
	particles = new CParticle[numParticles];
	init();

}

void CParticleSystemNormal::init() {

	if(!numParticles) return;
	
	for(int i=0;i<numParticles-1;i++) {
		particles[i].pNext = &particles[i+1];
	}
	particles[numParticles-1].pNext = NULL;

	m_deadParticles = &particles[0];
	m_liveParticles = NULL;

	m_numAlive=0;

}
CParticleSystemNormal::CParticleSystemNormal() {

	

}

void CParticleSystemNormal::setDefaultInfo() {

	m_doCollision = FALSE;
	m_alwaysAlive = FALSE;
	m_spread = 4.5f;
	m_gravity = -1.0f;
	m_dampening = 0.99f;
	m_color = CVector3d(220,180,0);
	m_emitterPos = CVector3d(0,0,0);
	m_emitterTargetPos = CVector3d(0,0,0);
	m_emitterVel = CVector3d(0,0,0);
	m_falloff = 0.2f;
	m_active = false;
	m_continousEmitting = false;
	m_isEmitting = false;
	m_birthInterval = 0.009f; //seconds..
	m_nextBirth = 0;
	m_speed = 5.0f;

	
}


void CParticleSystemNormal::update(float64 delta) {

	if(!m_active) return;
	int n = m_numAlive;

	m_numAlive=0;

	CParticle *pPrev=NULL,*pThis = m_liveParticles;

	float rate = delta*m_speed;
	
	if(n) {

		while(pThis) {
			
			
			pThis->lastpos	 = pThis->pos;
			pThis->pos		+= pThis->vel * rate;
			
			pThis->vel.y		+= m_gravity * rate;
			pThis->vel			*= m_dampening;
			pThis->energy		-= m_falloff * rate;



			// Kill old particles
			
			if(pThis->energy <= 0) pThis->alive=false;
				
			if( !pThis->alive)
			{

				CParticle *pNext = pThis->pNext;

				// Put the dead particle in the list of free particles
				pThis->pNext = m_deadParticles;
				m_deadParticles = pThis;

				// Reconnect list
				if( pPrev )	
					pPrev->pNext = pNext;

				if( pThis == m_liveParticles ) 
					m_liveParticles = pNext;
				//pPrev = pThis;
				pThis = pNext;
			}
			else
			{
				m_numAlive++;

				pPrev = pThis;
				pThis = pThis->pNext;
			}



		}

	}

	// (maybe :) Emit new particles
	if( m_isEmitting && m_continousEmitting)
	{
		//CVector3d EmitterSpeed = m_emitterTargetPos - m_emitterPos;


		float fTimeLeft = delta;
		while( fTimeLeft > 0 )
		{
			if( fTimeLeft > m_nextBirth )
			{
				// Move emitter 
				//m_EmitterPos += EmitterSpeed * m_fNextBirth / fDeltaTime;

				fTimeLeft -= m_nextBirth;
				m_nextBirth = m_birthInterval;

				if( m_deadParticles )
				{

					// Grab a particle from the list of free particles
					CParticle *pNew = m_deadParticles;
					m_deadParticles = m_deadParticles->pNext;

					// Initialize it
					pNew->alive = true;
					pNew->pos     = m_emitterPos;
					pNew->energy = 1.0f;

					// Initial speed
					float fAlpha = 2 * 3.141592f * rand()/RAND_MAX;
					float fBeta  = 3.141592f * ((float)rand()/RAND_MAX - 0.5f); 
					pNew->vel.x  = m_spread*(float)(cos(fBeta) * sin(fAlpha));
					pNew->vel.y  = m_spread*(float)sin(fBeta);
					pNew->vel.z  = m_spread*(float)(cos(fBeta) * cos(fAlpha));

					pNew->color = m_color;

					// Insert the particle into the list of live particles
					pNew->pNext = m_liveParticles;
					m_liveParticles = pNew;

					m_numAlive++;
				}
				
			}
			else
			{
				// Move emitter 
				//m_EmitterPos = m_TargetEmitterPos;

				m_nextBirth -= fTimeLeft;
				fTimeLeft = 0;
			}
		}

	}





}

void CParticleSystemNormal::render(BaseImage32* dest) {

	if(!m_active) return;

	uint32* buf = dest->get();
	//int sx,sy;
	float sx,sy;
	int height=dest->getHeight();
	int width=dest->getWidth();
	int halfwidth = dest->getWidth()/2;
	int halfheight = dest->getHeight()/2;

	const float FOV = 256.0f;
	
	CParticle *pThis = m_liveParticles;

	while(pThis) {

		if(pThis->alive && pThis->pos.z >= 0) {

			sx = halfwidth + (pThis->pos.x*FOV)/pThis->pos.z;	
			sy = halfheight + ((-(pThis->pos.y))*FOV)/pThis->pos.z;

			if (sx>2 && sx<width-3 &&
				sy>2 && sy<height-3) {
				
				CVector3d tmp = pThis->color*pThis->energy;
				wuPixel(buf,width,sx,sy,tmp);

			}
			else{
				pThis->alive = false;
				m_numAlive--;
			}
		}
		pThis = pThis->pNext;

	}
}


void CParticleSystemNormal::explosion() {

		m_continousEmitting = false;
		m_isEmitting = false;

		int i = 0;

		while (m_deadParticles){
			i++;
			CParticle *pThis = m_deadParticles;
			m_deadParticles = m_deadParticles->pNext;


			srand(i+2345*i);
			pThis->alive=true;
			pThis->pos = m_emitterPos;
			pThis->vel = CVector3d(-1.0f+(float)((rand()%20000))*0.0001,-1.0f+(float)((rand()%20000))*0.0001,-1.0f+(float)((rand()%20000))*0.0001);
			pThis->vel.normalize();
			pThis->vel *= m_spread;
			pThis->color = m_color;
			pThis->energy = 1.0f;

			pThis->pNext = m_liveParticles;
			m_liveParticles = pThis;
			
		}
		
		m_numAlive = numParticles;

}

void CParticleSystemNormal::spin() {


	for(int i=0;i<numParticles-1;i++) {
		particles[i].pNext = &particles[i+1];
	}
	particles[numParticles-1].pNext = NULL;
	m_deadParticles = &particles[0];

	m_continousEmitting = true;
	m_isEmitting = true;

	m_numAlive = 0;	

}
