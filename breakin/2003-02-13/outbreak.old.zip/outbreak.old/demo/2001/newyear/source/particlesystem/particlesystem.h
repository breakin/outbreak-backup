#ifndef NEWYEAR_PARTICLESYSTEM
#define NEWYEAR_PARTICLESYSTEM

#include <helper/helper.h>
#include <helper/core/imagedrawer/imagedrawer.h>
#include "../globals.h"
#include <math/e3d_vector.h>
#include <math/e3d_fpu.h>

class CParticle {

public:
	CParticle() {}
	~CParticle() {}

	CVector3d pos;
	CVector3d vel;
	CVector3d lastpos;
	float energy;
	BOOL alive;
	CVector3d color;
	CParticle* pNext;



};

class CParticleSystem {

public:

	virtual void update(float64 delta) = 0;
	virtual void render(BaseImage32* dest) = 0;

	CParticle* particles;

protected:
	int numParticles;
};


class CParticleSystemNormal : public CParticleSystem {
public:
	
	CParticleSystemNormal();
	~CParticleSystemNormal() {if(particles)delete [] particles;}

	void init();
	void update(float64 delta);
	void render(BaseImage32* dest);
	void create(int num);
	void explosion();
	void spin();
	void setDefaultInfo();
	
	bool		m_isEmitting;
	bool		m_continousEmitting;
	bool		m_doCollision;
	bool		m_alwaysAlive;
	float		m_spread;
	float		m_gravity;
	float		m_dampening;
	CVector3d	m_color;
	CVector3d	m_emitterPos;
	CVector3d	m_emitterVel;
	CVector3d	m_emitterTargetPos;
	float		m_falloff;
	int			m_numAlive;
	bool		m_active;
	float		m_birthInterval;
	float		m_nextBirth;
	float		m_speed;

	CParticle	*m_liveParticles;
	CParticle	*m_deadParticles;

};

/*
__forceinline void wuPixel(uint32* buf,int width,float wx,float wy, CVector3d color) {
		buf[(int)wx+(int)wy*width] = ((int)color.x<<16) | ((int)color.y<<8) | ((int)color.z);
}
*/
__forceinline void wuPixel(uint32* buf,int width,float wx,float wy, CVector3d color) {

	int x,y;
	CVector3d btl,btr,bbl,bbr;
	float fx,fy;

	x = (int)wx;
	y = (int)wy;
	fx = wx - x;
	fy = wy - y;

	btl = (1-fx) * (1-fy) * color;
	btr =  (fx)  * (1-fy) * color;
	bbl = (1-fx) *  (fy) * color;
	bbr =  (fx)  *  (fy) * color;

	buf[x+y*width] = ((int)btl.x<<16) | ((int)btl.y<<8) | ((int)btl.z);
	buf[1+x+y*width] = ((int)btr.x<<16) | ((int)btr.y<<8) | ((int)btr.z);
	buf[x+(y+1)*width] = ((int)bbl.x<<16) | ((int)bbl.y<<8) | ((int)bbl.z);
	buf[1+x+(y+1)*width] = ((int)bbr.x<<16) | ((int)bbr.y<<8) | ((int)bbr.z);


}

/*
__forceinline void wuPixel(uint32* buf,int width,float wx,float wy, CVector3d color) {
	int x,y;
	CVector3d btl,tr,bbl,bbr;
	float fx,fy;
	static uint32 ix16;
	static uint32 iy8;
	static uint32 iz;
	int32 offset;

	E3D_FLOAT_TO_INT(wx,x);
	E3D_FLOAT_TO_INT(wy,y);
	
	offset = x + y * width;
	fx = wx - x;
	fy = wy - y;

	btl = (1.0f-fx) * (1.0f -fy) * color;
	tr =  (fx)   * (1.0f - fy) * color;
	bbl = (1.0f -fx) *  (fy)  * color;
	bbr =  (fx)  *  (fy)  * color;

	
	E3D_FLOAT_TO_INT(btl.x, ix16);
	E3D_FLOAT_TO_INT(btl.y, iy8);
	E3D_FLOAT_TO_INT(btl.z, iz);
	ix16 <<= 16;
	iy8 <<= 8;
	
	buf[offset] = (ix16) | (iy8) | (iz);
	
	E3D_FLOAT_TO_INT(tr.x, ix16);
	E3D_FLOAT_TO_INT(tr.y, iy8);
	E3D_FLOAT_TO_INT(tr.z, iz);
	ix16 <<= 16;
	iy8 <<= 8;

	buf[1+offset] = (ix16) | (iy8) | (iz);

	E3D_FLOAT_TO_INT(bbl.x, ix16);
	E3D_FLOAT_TO_INT(bbl.y, iy8);
	E3D_FLOAT_TO_INT(bbl.z, iz);
	ix16 <<= 16;
	iy8 <<= 8;

	buf[offset + width] = (ix16) | (iy8) | (iz);

	E3D_FLOAT_TO_INT(bbr.x, ix16);
	E3D_FLOAT_TO_INT(bbr.y, iy8);
	E3D_FLOAT_TO_INT(bbr.z, iz);
	ix16 <<= 16;
	iy8 <<= 8;
	
	buf[1+offset+width] = (ix16) | (iy8) | (iz);


}
*/
#endif