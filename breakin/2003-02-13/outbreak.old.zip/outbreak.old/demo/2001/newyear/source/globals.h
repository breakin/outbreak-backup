#ifndef NEWYEAR_GLOBALS_H
#define NEWYEAR_GLOBALS_H

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Globals
	@ Brief       : Passed to all classes to make a common helperbase.
  =============================================================================
*/

#include <helper/helper.h>
#include <math\e3d_vector.h>
using namespace Helper;
using namespace Eternity;
// ---------------------------------------------------------------------------

struct NewyearGlobals {
	Helper::int32 centerX;
	Helper::int32 centerY;

	Helper::Device2D*		device2D;
	Helper::Archive*		archive;
	Helper::ImageTool*		imageTool;
	Helper::ImageFilter*    imageFilter;
	Helper::ImageDrawer*	imageDrawer;

	Helper::BaseImage32*    backbuffer;
	Helper::BaseImage32*    screen;
};

// ---------------------------------------------------------------------------

#endif