#include "config.h"		

#include <helper/directx/dx_device2d.h>
#include <helper/core/dialog/dialog.h>
#include <helper/core/utils/commandlineparser.h>

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

NewyearConfig::NewyearConfig(NewyearGlobals& inGlobals) : globals(inGlobals) {
	// Reset globals
	globals.device2D=NULL;
	globals.archive=NULL;
	globals.imageDrawer=NULL;
	globals.imageTool=NULL;

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

NewyearConfig::~NewyearConfig() {
	// Delete globals
	if (globals.device2D!=NULL) delete globals.device2D;
	if (globals.archive!=NULL) delete globals.archive;
	if (globals.imageDrawer!=NULL) delete globals.imageDrawer;
	if (globals.imageTool!=NULL) delete globals.imageTool;

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const bool NewyearConfig::runConfig() {
	// Sets up a config device
	DirectDrawDevice2D device;
	device.config("width", "512");
	device.config("height", "384");
	device.config("bpp", "32");
	device.config("fullscreen", "true");
	device.config("caption", "false");
	device.config("title", "meh ch�ft");
	
	// Open config window
	device.open();

	// Get screenbuffer
	BaseImage32& screen = device.getBackBuffer();
		
	// Set up config backbuffer.
	Image32 configBackbuffer(512,384);
	globals.imageDrawer->clear(configBackbuffer, configBackbuffer.getArea());

	// Set up dialog with the buttons and all.
	Image32 background;
	globals.archive->load(background, "config/background.jpg");

	// Set up background and mainframe for all items
	Frame frame;
	frame.setArea("Mainframe", screen.getArea());
	frame.init(*globals.imageDrawer, *globals.archive, false); // false mean don't load normal images.
	frame.setOwnBackground(background);

	// Set up "play"
	ImageButton ibPlay;
	ibPlay.setArea("play", AreaInt(50,85));
	ibPlay.setImageNormal((*globals.archive), std::string("config/buttonPlay.tga"));
	ibPlay.setImageHighlight((*globals.archive), std::string("config/buttonPlayHighlight.tga"));
	frame.add(&ibPlay);

	// Set up "info"
	ImageButton ibInfo;
	ibInfo.setArea("info", AreaInt(153,85));
	ibInfo.setImageNormal((*globals.archive), std::string("config/buttonInfo.tga"));
	ibInfo.setImageHighlight((*globals.archive), std::string("config/buttonInfoHighlight.tga"));
	frame.add(&ibInfo);

	// Set up "web"
	ImageButton ibWeb;
	ibWeb.setArea("web", AreaInt(256,85));
	ibWeb.setImageNormal((*globals.archive), std::string("config/buttonWeb.tga"));
	ibWeb.setImageHighlight((*globals.archive), std::string("config/buttonWebHighlight.tga"));
	frame.add(&ibWeb);

	// Set up "exit"
	ImageButton ibExit;
	ibExit.setArea("exit", AreaInt(359,85));
	ibExit.setImageNormal((*globals.archive), std::string("config/buttonExit.tga"));
	ibExit.setImageHighlight((*globals.archive), std::string("config/buttonExitHighlight.tga"));
	frame.add(&ibExit);

	Msg message;
	while (true) {
		// Handle messages
		if (device.getMessage(message)) {
			// If alt+f4 or simular, exit.
			if (message.message==Msg::MSG_CLOSE) {
				return false;
			}

			if (message.message==Msg::MSG_KEYDOWN) {
				// Escape pressed, exit demo
				if (message.param==27) {
					return false;
				}

				// Space pressed, run demo
				if (message.param==32) {
					return true;
				}
			}

			// Handle events in dialog
			std::string event = frame.processEvent(message, configBackbuffer.getArea());

			if (event != "") {
				// Play
				if (event == "play") {
					return true;
				}

				// Info
				if (event == "info") {
					ShellExecute(NULL, "open", "readme.txt", NULL, NULL, SW_SHOWNORMAL);
				}

				// Web
				if (event == "web") {
					ShellExecute(NULL, "open", "http://www.outbreak.nu", NULL, NULL, SW_SHOWNORMAL);
				}

				// Exit
				if (event == "exit") {
					return false;
				}
			}
		}

		// Update dialog
		AreaInt changedArea = frame.update(device.getMousePosition(), configBackbuffer.getArea());

		// Only redraw if something happened.
		if (!changedArea.isEmpty()) {
			// Draw dialog to backbuffer
			frame.draw(configBackbuffer, configBackbuffer.getArea(), changedArea);
		}		

		// Blit backbuffer to screen
		globals.imageDrawer->draw(configBackbuffer, configBackbuffer.getArea(), screen, 0, 0, ImageDrawer::BLIT_NORMAL);

		// Update device
		device.update();
	}

	// Close config window
	device.close();

	// We want to run demo, keep going!
	return true;
}
	
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const bool NewyearConfig::run() {
	// Set up command line parser
	CommandLineParser cmd;

	// Set up imagetool
	globals.imageTool = new ImageTool;

	// Set up archive.
	globals.archive = new ArchiveDirectory(".");
	if (globals.archive->isExist("newyear.rar")) {
		delete globals.archive;
		globals.archive = new ArchiveRAR("newyear.rar");
	}

	// Set up imagedrawer & imageFilter
	globals.imageFilter = new ImageFilter;
	globals.imageDrawer = new ImageDrawer;
	
	globals.imageDrawer->setScaleMode(ImageDrawer::SCALE_LINEAR);



	// Set up demo device
	globals.device2D = new DirectDrawDevice2D;

	// Enumerate devices and find best resolution equal or higher than 512x384 in 32 bit.
	DisplayModeList displayModes = globals.device2D->getDisplayModeList();

	bool foundOne=false;
	int i=0;
	// Loop through the modes.
	while (i<displayModes.size()) {
		// Set up at least 512�384 in 32bit mode.
		if ((displayModes[i].width>=512 ) &&
			(displayModes[i].height>=384) &&
			(displayModes[i].bpp == 32)) {
			
			// Set up strings instead of numbers
			char strWidth[10];
			char strHeight[10];

			itoa(displayModes[i].width, strWidth, 10);
			itoa(displayModes[i].height, strHeight, 10);

			// Center view
			globals.centerX = (displayModes[i].width -512)/2;
			globals.centerY = (displayModes[i].height-384)/2;

			// Set device properties
			globals.device2D->config("width",  strWidth);
			globals.device2D->config("height", strHeight);
			globals.device2D->config("bpp", "32");

			// Fullscreen!
			globals.device2D->config("fullscreen", "true");

			// Stop looking
			foundOne=true;
			break;
		}

		// Move to next displaymode
		i++;
	}

	// No displaymode found or in debug, set windowed mode.
	if (!foundOne || cmd.isEntity("windowed")) {
		// Set device
		globals.centerX = 0;
		globals.centerY = 64;

		globals.device2D->config("width", "512");
		globals.device2D->config("height", "384");
		globals.device2D->config("bpp", "32");

		globals.device2D->config("fullscreen", "false");
	}

	// Set title of the window.
	globals.device2D->config("title", "Meh ch�ft skaffa egna pixlar");

	// Open device
	globals.device2D->open();

	// Get direct x surface and clear.
	globals.screen = &globals.device2D->getBackBuffer();
	globals.imageDrawer->clear(*globals.screen, globals.screen->getArea());

	// Set&clear backbuffer
	globals.backbuffer = new Image32(512,384);
	globals.imageDrawer->clear(*globals.backbuffer, globals.backbuffer->getArea());

	// Load "Loading..." image and blit to background
/*	Image32 loading;
	globals.archive->load(loading, "system/loading.png");

	// Load to both surfaces on direct surface...
	globals.imageDrawer->draw(loading, loading.getArea(), *globals.screen, globals.centerX, globals.centerY, ImageDrawer::BLIT_NORMAL);
	globals.device2D->update();*/


	return true;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


