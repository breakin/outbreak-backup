#ifndef NEWYEAR_FYRVERKERI
#define NEWYEAR_FYRVERKERI

#include <helper/helper.h>
#include <helper/core/imagedrawer/imagedrawer.h>
#include "globals.h"
#include <math/e3d_vector.h>
#include "particlesystem/particlesystem.h"


class CRocket {
public:
	CRocket();
	~CRocket();
	void init(float falloff, CVector3d forces, CVector3d pos, CVector3d vel);
	void update(BaseImage32 *where,float delta);
	void explode();

	CParticleSystemNormal m_tail;
	CParticleSystemNormal m_explosion;
	float m_energy;
	CVector3d m_forces;
	CVector3d m_pos;
	CVector3d m_vel;
	float m_falloff;
	bool m_alive;
	bool m_exploding;
	bool m_active;
};



#endif