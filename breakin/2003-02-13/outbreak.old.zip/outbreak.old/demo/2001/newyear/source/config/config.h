#ifndef NEWYEAR_EFFECT_CONFIG
#define NEWYEAR_EFFECT_CONFIG

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Config
	@ Brief       : Run first by demo to initialize helper
  =============================================================================
*/

#include <helper/helper.h>

#include "../globals.h"

using namespace Helper;

class NewyearConfig {
private:
	NewyearGlobals &globals;

public:
	NewyearConfig(NewyearGlobals &globals);
	~NewyearConfig();

	// Returns false if to quit demo.
	const bool runConfig();

	// Returns false if to quit demo.
	const bool run();
};

#endif