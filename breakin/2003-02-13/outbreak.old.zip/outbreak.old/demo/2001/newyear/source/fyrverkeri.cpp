#include "fyrverkeri.h"
CRocket::CRocket() {
	m_tail.create(50);
	m_explosion.create(200);
}

CRocket::~CRocket() {

}

void CRocket::init(float falloff, CVector3d forces, CVector3d pos, CVector3d vel) {

	m_falloff = falloff;
	m_forces = forces;
	m_pos = pos;
	m_vel = vel;
	m_alive = true;
	m_energy = 1.0f;
	m_exploding = false;
	m_active = false;
	
	m_tail.setDefaultInfo();
	m_tail.m_continousEmitting = true;
	m_tail.m_isEmitting = true;
	
	m_tail.m_color = CVector3d(220,180,0);
	m_tail.m_falloff = 0.31f;
	m_tail.m_gravity = -0.01f;
	m_tail.m_birthInterval = 0.01f;
	m_tail.m_spread = 1.0f;
	m_tail.m_active = true;

	
}

void CRocket::update(BaseImage32 *where,float delta) {

	if(!m_alive) return;
	if(!m_active) return;

	float rate=delta*5;

	m_pos += m_vel * rate;
	m_vel += m_forces * rate;
	m_vel *= 0.999f; //dampening
	m_energy -= m_falloff*rate;
	m_tail.m_emitterPos = m_pos;	


	if (m_exploding && m_explosion.m_numAlive<=0) {
		m_alive = false;
	}

	if(m_energy<=0 && !m_exploding) explode();


	if(m_exploding) {
		m_explosion.update(delta);
		m_explosion.render(where);
	} else {
		m_tail.update(delta);
		m_tail.render(where);
	}

}

void CRocket::explode() {

	m_exploding=true;

	m_explosion.setDefaultInfo();
	m_explosion.m_color = CVector3d(128+(float)(rand()%127),128+(float)(rand()%127),128+(float)(rand()%127));
	m_explosion.m_emitterPos = m_pos;
	m_explosion.m_gravity = -0.15f;
	m_explosion.m_falloff = 0.006f + ((float)(rand() % 250)*0.0001f);
	m_explosion.m_spread = 4.3f + ((float)(rand() % 350)*0.01f);
	m_explosion.m_active = true;

	m_explosion.explosion();

}

