/*
  =============================================================================
  = Air Demo. (c) Outbreak 2001
  =============================================================================
    @ Responsible : Thec
    @ Class       : Air Demo Stub
    @ Brief       : First of all it runs the demo. It loads the effects, initiates the 
                    script and runs the effects. It has the responsible of pausing the 
                    demo, taking screenshots and moving forward and backwards within
                    the demo.

    @ Features : 
      * 'p' Pauses the demo
      * 'f' Runs fps counter
      * Left arrow rewinds
      * Right arrow fast forwards

	  Command Line Paramets:
	  /skipconfig    - Skip's the setup box.
	  /windowed      - Run in windowed mode.
	  /time:10.00    - Fast forwards 10 seconds when the demo starts. /time=10.00 does the same thing.

  =============================================================================
*/


// Helper includes
#include <helper/helper.h>
#include <helper/win32/win32_device2d.h>
#include <helper/directx/dx_device2d.h>

#include <helper/core/utils/commandlineparser.h>

// Standard includes
#include <fstream>
#include <conio.h>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <math.h>

// Globals
#include "globals.h"

// Config
#include "config/config.h"



// Namespaces
using namespace Helper;
using namespace std;

#define PI 3.1415926535f
#define RADIANS PI/180

// Particle system
#include "particlesystem/particlesystem.h"

#include "fyrverkeri.h"

#include <xlib/fmod/inc/fmod.h>

// ---------------------------------------------------------------------------

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevinst, LPSTR cmdline, int showstate) {
		int8 temp[100];
			FMUSIC_MODULE *mod;
	try {


   
	if (!FSOUND_Init(44100, 32, FSOUND_INIT_GLOBALFOCUS))
	{
		//printf("%s\n", FMOD_ErrorString(FSOUND_GetError()));
		exit(1);
	}

   
	mod = FMUSIC_LoadSong("newyear.xm");
	if (!mod)
	{
		printf("DET CEPADE");
		exit(1);
	}







		Debug::log("Main()", "CH�FT...");

		CommandLineParser cmd;

		//ArchiveDirectory screenShots("screenshots");
		NewyearGlobals globals;

		// Run config first
		NewyearConfig config(globals);
		if (!config.run()) return 0;
		


		Image32 logo;
		Image32 logo2;
		Image32 background;

		globals.archive->load(logo, "otbny2.png");
		globals.archive->load(logo2, "otbny2.png");
		globals.archive->load(background, "newyear-background.png");

		uint32* logobuf = logo.get();
		uint32* logo2buf = logo.get();

		
		// Demo variables
		bool  exit = false;
		Msg msg;

		// Fps variables
		bool fpstoggle=false;
		float64 startTime=0;
		float64 fps=0;

		uint32 frames=0;
		uint32 totalFrames=0;

		// Pause variables
		bool pauseToggle=false;

		float64 current=0;
		int bQuit = 0;

		float64 started = timeGetTime();
		float64 delta,oldcurrent;
		
		oldcurrent=0;
		delta=0;
		const int numsystems = 15;
		const int numrockets = 17;
		int x;
		CParticleSystemNormal particlesystem[numsystems];
		
		
		CRocket rocket[numrockets];
		
		for(x=0;x<numrockets;x++) {
			rocket[x].init(((float)(rand()%4000)*0.00001f) + 0.06f,
				CVector3d(-0.4f+((float)(rand()%8000)*0.0001f),0.2f,0.15f*cosf(current)),
				CVector3d(-120.0f+(float)(rand()%240),-140.0f,200),
				CVector3d(0,15.0f,0));

		}

		

		for(x=0;x<numsystems;x++) {

			particlesystem[x].setDefaultInfo();
			
			particlesystem[x].create(50);
			
			srand(current+x*342);
			particlesystem[x].m_color = CVector3d((float)(rand()%255),(float)(rand()%255),(float)(rand()%255));
			particlesystem[x].m_emitterPos = CVector3d(-130.0f+(float)(rand()%260),-130.0f+(float)(rand()%260),150.0f+(float)(rand()%100));
			particlesystem[x].m_falloff = 0.04f + ((float)(rand() % 250)*0.001f);
			particlesystem[x].m_spread = 3.0f + ((float)(rand() % 250)*0.01f);
			particlesystem[x].m_active = false;

			particlesystem[x].explosion();
		}


		Image32 scrollerimage;
		globals.archive->load(scrollerimage,"scroller.png");

		Image32 dezin1(512,10);
		Image32 dezin2(512,10);
		Image32 dezin3(512,10);

		uint32* dezinb1 = dezin1.get();
		uint32* dezinb2 = dezin2.get();
		uint32* dezinb3 = dezin3.get();

		for(int k=0;k<512*10;k++) {
			dezinb1[k] = 0xC01f3259;
			dezinb2[k] = 0xA01f3259;
			dezinb3[k] = 0x791f3259;
		}
		float scrollerxpos=-20.0f;

		
		uint32* pixel = globals.backbuffer->get();
		
		float start_time,end_time;
		start_time = timeGetTime();
		frames=0;

		bool bounce = false;

		FMUSIC_PlaySong(mod); // spela skitmusik

		while (1) {
			
			oldcurrent=current;
			current = (timeGetTime()-started)/1000;
			delta=current-oldcurrent;
			
			for(x=0;x<numrockets;x++) {
				
				if(current>(float)(x*0.6f))
					rocket[x].m_active = true;
			}

			for(x=0;x<numsystems;x++) {
				
				if(current>(float)(x*0.3f))
					particlesystem[x].m_active = true;
			}
			

			// Check for messages.
			if (globals.device2D->getMessage(msg)) {
				// Someone desperatly want to shut down quick :)
				if (msg.message == Helper::Msg::MSG_CLOSE) {

						FMUSIC_FreeSong(mod);
						FSOUND_Close();
					
					return 2;
				}

				// Keyboard hit
				if (msg.message == Helper::Msg::MSG_KEYCHAR) {

					Debug::log("WinMain()", "Key param:%d, extra:%d", msg.param, msg.extra);
					
					// Escape!
					if (msg.param == 27) {
						end_time = timeGetTime();
						fps = (float)frames*1000.0f / (end_time - start_time);
						
						sprintf(temp, "fps: %.2f", fps);
						//MessageBox(NULL,temp,"fps",MB_OK);
						
						FMUSIC_FreeSong(mod);
						FSOUND_Close();

						return 3;
					}
					if (msg.param == ' ') {
						bounce=!bounce;
					}


				}

			}
				frames++;
		//	}
		
			
/////////////////////////////////////////


//			globals.imageDrawer->draw(background, background.getArea(), *globals.backbuffer, 0, 0, ImageDrawer::BLIT_NORMAL);
			
			memcpy(globals.backbuffer->get(),background.get(),4*512*384);

			for(int x=0;x<numsystems;x++) {
				
							
					particlesystem[x].update(delta);
					particlesystem[x].render(globals.backbuffer);


				if (particlesystem[x].m_numAlive<=0) {
					
					srand(current+x*342);
					particlesystem[x].m_color = CVector3d((float)(rand()%180),(float)(rand()%180),(float)(rand()%180));
					particlesystem[x].m_emitterPos = CVector3d(-130.0f+(float)(rand()%260),-130.0f+(float)(rand()%260),200.0f+(float)(rand()%100));
					particlesystem[x].m_falloff = 0.06f + ((float)(rand() % 200)*0.001f);
					particlesystem[x].m_spread = 3.5f + ((float)(rand() % 250)*0.01f);
					particlesystem[x].explosion();
				}
				
			}

			for(x=0;x<numrockets;x++) {
				rocket[x].update(globals.backbuffer,delta);
			
				rocket[x].update(globals.backbuffer,delta);
				
				if(!rocket[x].m_alive) {
					rocket[x].init(((float)(rand()%4000)*0.00001f) + 0.06f,
									CVector3d(-0.8f+((float)(rand()%16000)*0.0001f),0.2f,0.15f*cosf(current)),
									CVector3d(-120.0f+(float)(rand()%240),-140.0f,200),
									CVector3d(0,15.0f,0));
				}
			}

			//DEZIN
			int deziny1 =  340 + (15*sinf(current));
			int deziny2 =  340 + (15*cosf(current));
			int deziny3 =  340 + (10*-cosf(current/2));
			
			int scrollery = 340 + (15*sinf(current*1.1f));


			globals.imageDrawer->draw(dezin1,dezin1.getArea(),*globals.backbuffer, 0,deziny1,Helper::ImageDrawer::BLIT_ALPHABLEND);
			globals.imageDrawer->draw(dezin2,dezin2.getArea(),*globals.backbuffer, 0,deziny2,Helper::ImageDrawer::BLIT_ALPHABLEND);
			globals.imageDrawer->draw(dezin3,dezin3.getArea(),*globals.backbuffer, 0,deziny3,Helper::ImageDrawer::BLIT_ALPHABLEND);
			

			int logoy = 25;
			
			if(bounce) logoy -= abs(-cosf(current*2.2f)*10);

			globals.imageDrawer->draw(logo,logo.getArea(),*globals.backbuffer, 256-logo.getWidth()/2,logoy,Helper::ImageDrawer::BLIT_ALPHABLEND);

			scrollerxpos-=delta*30;
	
			globals.imageDrawer->draw(scrollerimage,scrollerimage.getArea(),*globals.backbuffer, (int)scrollerxpos,scrollery,Helper::ImageDrawer::BLIT_NORMAL);

			if(scrollerxpos < -(scrollerimage.getWidth()-512))
				scrollerxpos = -20.0f;
    

///////////////////////////////////////////////

			// Update device.
			globals.imageDrawer->draw(*globals.backbuffer, globals.backbuffer->getArea(), *globals.screen, 0, 0, ImageDrawer::BLIT_NORMAL);

			globals.device2D->update();
			

			
		}

	}
	
	// Catch known exceptions.
	catch (const Helper::Exception &e) {
		MessageBox(NULL, e.what(), "Helper::Exception", MB_OK);
	}

	// Catch unknown exceptions.
	catch (...) {
		MessageBox(NULL, "Unknown exception", "(...)::Exception", MB_OK);
	}
	
	FMUSIC_FreeSong(mod);
	FSOUND_Close();
	// Return the answer :-D
	return 44-2;
}
