#ifndef EXPERIMENTAL_EFFECT_MEDITATE
#define EXPERIMENTAL_EFFECT_MEDITATE

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectMeditate : public Effect {
private:
	ExperimentalGlobals &globals;
	Image32 med;

public:
	EffectMeditate(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
