#include "stars.h"
#include <helper/core/debug/debug.h>

using std::string;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectStars::EffectStars(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	Image32 temp;
	for (int i = 0; i <= 15; i++) {
		string a = "stars/test00";
		if (i < 10) a += "0";

		char b[10];
		itoa(i, b, 10);
		a += b;
		a += ".png";

		globals.archive->load(man[i], a);
	}

	// Clear filter
	for (i=0; i<128; i++) filter[i]=0;

	// Set default filter
	mode = 2;

	// Set default timestamp
	timestamp = 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectStars::executeTrigger(const std::string& name, const std::string& value) {
	
	// Set mode
	if (name=="mode") {
		mode = atoi(value.c_str());
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectStars::update(const float64 timer, const float64 delta, const float64 percent) {

	// Motionblur every 1/20th of a second.
	if (timer>timestamp+0.05 || timer<timestamp) {
		for (int i=0; i<128; i++) {
			filter[i]++;
			if (filter[i]>15) filter[i]=15;
		}

		timestamp = timer;
	}

	// Mode==1, just put random head sizes.
	if (mode==1) {
		for (int i=0; i<5; i++) filter[rand()%128]=rand()%15;
	}

	// Mode==2, make a horisontal bar go down
	if (mode==2) {
		int y = int(percent*16);

		if (y<8) {
			int ypos = y << 4;
			for (int y2 = y; y2 < 8; y2++) 
				for (int x=0; x<16; x++)
					filter[ypos++]=0;
		}
	}

	// Mode==3, make a horisontal bar go up
	if (mode==3) {
		int y = int(percent*16);

		if (y<8) {
			for (int x=0; x<16; x++) filter[(7-y)*16+x]=16;
		}
	}

	AreaInt tmp(14, 14, 36, 36);
	// Draw images through filter.
	for (int y=0; y<8; y++) {
		for (int x=0; x<16; x++) {
	
			// Get image size through filter.
			uint8 size = filter[y*16+x];

			// Draw image with correct size.
			if (size>0 && size < 17) {
				globals.imageDrawer->draw(man[size], tmp, *globals.backbuffer, 
										  x*36, y*36,
										  ImageDrawer::BLIT_SATURATION);
			}
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
