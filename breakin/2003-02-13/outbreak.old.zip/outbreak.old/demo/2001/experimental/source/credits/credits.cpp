#include "credits.h"

#include <helper/core/debug/debug.h>
#include <math.h>
#define PI 3.1415926535f

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectCredits::EffectCredits(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	globals.archive->load(texture, "credits/man64x64.tga");
	zoomTime = -2;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectCredits::executeTrigger(const std::string& name, const std::string& value) {
	if (name == "zoom") {
		zoomTime = -1;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectCredits::update(const float64 _timer, const float64 delta, const float64 percent) {
	// Hook pixelbuffer
	uint32* pixel = globals.backbuffer->get();
	uint32* source = texture.get();

	float64 timer = 0;

	if (zoomTime == -1) zoomTime = _timer;
	if (zoomTime != -2) timer = _timer - zoomTime;

	float zoom = 0.7f + timer * 4;

	double cosrot = cos(-timer*2) * zoom;
	double sinrot = sin(-timer*2) * zoom;

	int tw2 = texture.getWidth()  >> 1;
	int th2 = texture.getHeight() >> 1;
	float xopt = texture.getWidth()  / (float) globals.backbuffer->getWidth();
	float yopt = texture.getHeight() / (float) globals.backbuffer->getHeight();

	int dxu = (xopt * cosrot) * 2048;
	int dxv = (xopt * sinrot) * 2048;
	int xu = -(tw2 * cosrot) * 2048;
	int xv = -(tw2 * sinrot) * 2048;

	int yopt2 = 0;
	float y2 = -th2;

	for (int y = 0; y < globals.backbuffer->getHeight(); y++) {
		int ycos = xv +  (y2 * cosrot)  * 2048;
		int ysin = xu - ((y2 * sinrot)) * 2048;

		for (int x = 0; x < globals.backbuffer->getWidth(); x++) {
			int32 u = (32 + (ysin >> 11))%64;
			int32 v = (32 + (ycos >> 11))%64;
			if (u < 0) u += 64;
			if (v < 0) v += 64;

			pixel[yopt2++] = source[(v << 6) + (u)];
			ysin += dxu;
			ycos += dxv;
		}
		y2 += yopt;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
