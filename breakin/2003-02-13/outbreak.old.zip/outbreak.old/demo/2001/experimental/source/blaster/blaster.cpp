#include <math.h>
#include "blaster.h"

#define for if(0);else for 

EffectBlaster::EffectBlaster(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	globals.archive->load(blaster, "blaster/blaster.png");
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectBlaster::executeTrigger(const std::string& name, const std::string& value) {
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectBlaster::update(const float64 timer, const float64 delta, const float64 percent) {
	float _percent = 0.2 + percent * percent*0.9;
	AreaInt tmp(256 - (blaster.getWidth()*_percent)/2, 400 - (blaster.getHeight()*_percent) + sin(-3.1415 + percent*4) *250,  (blaster.getWidth() * _percent),  (blaster.getHeight() * _percent));
	globals.imageDrawer->draw(blaster, blaster.getArea(), *globals.backbuffer, tmp, Helper::ImageDrawer::BLIT_ALPHABLEND);
}