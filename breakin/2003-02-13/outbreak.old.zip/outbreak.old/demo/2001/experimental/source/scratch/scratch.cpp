#include <math.h>
#include "scratch.h"

#define for if(0);else for 

using namespace std;
EffectScratch::EffectScratch(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	for (int i = 1; i <= 4; i++) {
		string a = "scratch/left";
		string b = "scratch/right";

		char tmp[10];
		itoa(i, tmp, 10);
		a += tmp;
		b += tmp;

		a += ".png";
		b += ".png";

		globals.archive->load(lscratch[i-1], a);
		globals.archive->load(rscratch[i-1], b);
	}
	lcurrent = 0;
	ltarget = rand()%3;
	int ldelta = ltarget - lcurrent;
	lpitch = ldelta == 0 ? 0 : ldelta > 0 ? 1 : -1;

	rcurrent = 0;
	rtarget = rand()%3;
	int rdelta = rtarget - rcurrent;
	rpitch = rdelta == 0 ? 0 : rdelta > 0 ? 1 : -1;

	lastUpdate = 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectScratch::executeTrigger(const std::string& name, const std::string& value) {
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectScratch::update(const float64 timer, const float64 delta, const float64 percent) {

	if (timer - lastUpdate > 0.1) {
		lcurrent += lpitch;
		rcurrent += rpitch;

		if (lcurrent == ltarget) {
			ltarget = rand()%3;
			int delta = ltarget - lcurrent;
			lpitch = delta == 0 ? 0 : delta > 0 ? 1 : -1;
		}
		if (rcurrent == rtarget) {
			rtarget = rand()%3;
			int delta = rtarget - rcurrent;
			rpitch = delta == 0 ? 0 : delta > 0 ? 1 : -1;
		}
		lastUpdate = timer;
	}
	globals.imageDrawer->draw(lscratch[lcurrent], lscratch[lcurrent].getArea(), *globals.backbuffer, globals.backbuffer->getArea(), -64, 0, Helper::ImageDrawer::BLIT_ALPHABLEND);
	globals.imageDrawer->draw(rscratch[rcurrent], rscratch[rcurrent].getArea(), *globals.backbuffer, globals.backbuffer->getArea(), 256, 0, Helper::ImageDrawer::BLIT_ALPHABLEND);
}