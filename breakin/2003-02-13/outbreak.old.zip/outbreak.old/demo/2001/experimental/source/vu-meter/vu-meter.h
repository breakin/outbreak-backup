#ifndef EXPERIMENTAL_EFFECT_VUMETER
#define EXPERIMENTAL_EFFECT_VUMETER

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectVumeter : public Effect {
private:
	Image32 staplar;
	ExperimentalGlobals &globals;
	int frame;
	float currentVUL;
	float currentVUR;
	float lastUpdate;


public:
	EffectVumeter(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
