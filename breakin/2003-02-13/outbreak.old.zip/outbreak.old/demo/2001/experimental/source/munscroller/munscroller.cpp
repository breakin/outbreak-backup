#include "munscroller.h"

#include <helper/core/debug/debug.h>
#include <math.h>

#define for if(0);else for 

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectMunscroll::EffectMunscroll(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	globals.archive->load(fg, "munscroll/scream_foreground.png");
	globals.archive->load(bg, "munscroll/scream_background.png");
	globals.archive->load(scroll, "munscroll/scroller_text.png");
	mun_time = scroll_time = -2;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectMunscroll::executeTrigger(const std::string& name, const std::string& value) {
	// Set mode
	if (name == "mun") {
		if (value == "in") {
			mun_time = -1;
			slide = true;
		} else if (value == "out") {
			mun_time = -1;
			slide = false;
		}
	} else if (name == "scroll") {
		if (value == "start") {
			scroll_time = -1;
		} else if (value == "stop") {
			scroll_time = -2;
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

inline int blend(int source, int target, int fade) {
	if (fade == 0) return source;
	else if (fade == 255) return target;

	int inv = 255 - fade;

	return  (((source & 0x00ff00ff) * inv  >> 8) & 0xff00ff) +
			(((target & 0x00ff00ff) * fade >> 8) & 0xff00ff) |
			(((source & 0x0000ff00) * inv  >> 8) & 0x00ff00) +
			(((target & 0x0000ff00) * fade >> 8) & 0x00ff00);

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectMunscroll::update(const float64 timer, const float64 delta, const float64 percent) {
	uint32* pixels = globals.backbuffer->get();
	uint32* scroll_pix = scroll.get();

	int xoff;

	int ypos = 0;
	int spos = 0;

	if (mun_time == -1) mun_time = timer;
	if (scroll_time == -1) scroll_time = timer;

	if (mun_time != -2) {
		if (slide) xoff = 512 - (int) ((timer - mun_time)*100);
		else xoff = 512 - fg.getWidth() + ((timer - mun_time)*100);

		if (xoff < 512 -fg.getWidth()) xoff = 512 - fg.getWidth();

		globals.imageDrawer->draw(bg, bg.getArea(), *globals.backbuffer, AreaInt(xoff, 0, bg.getWidth(), 256), Helper::ImageDrawer::BLIT_ALPHABLEND);
	}

	if (scroll_time != -2) {
		// scroller
		ypos = 116 * 512;
		spos = 0;
		int scrollOff = 512 - ((timer - scroll_time) * 0.25 * 512);
		int scrollOff2 = 0;

		if (scrollOff < 0) {
			scrollOff2 = - scrollOff;
			scrollOff = 0;
		}

		for (int i = 1; i < 512; i++) {
			sineTable[i] = sineTable[i-1]*0.99;
		}

		sineTable[0] = sin(timer*10.7)*60;



		for (int y = 0; y < 25; y++) {
			ypos += scrollOff;
			spos = y * scroll.getWidth() + scrollOff2;

			for (int x = scrollOff; x < 443; x++, ypos++, spos++) {
				int realypos = ypos + int(sineTable[x])*512;
				pixels[realypos] = blend(pixels[realypos], scroll_pix[spos], (scroll_pix[spos] >> 24) & 0xff);
			}
			ypos += 512 - 443;
		}
	}

	if (mun_time != -2) {
		// foreground face
		globals.imageDrawer->draw(fg, fg.getArea(), *globals.backbuffer, AreaInt(xoff, 0, fg.getWidth(), 256), Helper::ImageDrawer::BLIT_ALPHABLEND);
	}

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
