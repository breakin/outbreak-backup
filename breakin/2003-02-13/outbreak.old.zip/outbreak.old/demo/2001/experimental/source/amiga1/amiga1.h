#ifndef EXPERIMENTAL_EFFECT_AMIGA1
#define EXPERIMENTAL_EFFECT_AMIGA1

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectAmiga1 : public Effect {
private:
	ExperimentalGlobals &globals;
	Image32 texture;
	float64 start;
	int mode;

	int sintab1[2048];
	int sintab2[2048];
	int sintab3[2048];


public:
	EffectAmiga1(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
