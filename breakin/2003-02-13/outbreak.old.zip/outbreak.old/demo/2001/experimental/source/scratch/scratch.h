#ifndef EXPERIMENTAL_EFFECT_SCRATCH
#define EXPERIMENTAL_EFFECT_SCRATCH

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectScratch : public Effect {
private:
	ExperimentalGlobals &globals;
	Image32 lscratch[4];
	Image32 rscratch[4];

	int32 lcurrent;
	int32 rcurrent;
	int32 ltarget;
	int32 rtarget;
	int32 lpitch;
	int32 rpitch;

	float64 lastUpdate;

public:
	EffectScratch(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
