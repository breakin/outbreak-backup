#include "vu-meter.h" 
#include <fmod/inc/fmod.h>

#define for if(0); else for

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectVumeter::EffectVumeter(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	globals.archive->load(staplar, "vu-meter/staplar.png");
	lastUpdate = -1;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectVumeter::executeTrigger(const std::string& name, const std::string& value) {
	if (name == "setVU") {
		currentVUR = 0.8f + (rand()%20) / 100.0f;
		currentVUL = 0.8f + (rand()%20) / 100.0f;
		lastUpdate=-1;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectVumeter::update(const float64 timer, const float64 delta, const float64 percent) {
	uint32* pixels = globals.backbuffer->get();
	if (lastUpdate == -1) lastUpdate = timer;

	float64 diff = timer - lastUpdate;

	if (diff > 0.004f) {
		currentVUR -= diff;
		currentVUL -= diff;

		if (currentVUL < 0) currentVUL = 0;
		if (currentVUR < 0) currentVUR = 0;
		lastUpdate = timer;
	}
	float left = 256 - currentVUL * 256;
	float right = 256 + currentVUR * 256;

	AreaInt tmp = staplar.getArea();
	tmp.setWidth(currentVUL * 256 + currentVUR * 256);
	tmp.setLeft(256 - currentVUL * 256);

	globals.imageDrawer->draw(staplar, staplar.getArea(), *globals.backbuffer, tmp, 0, 0, Helper::ImageDrawer::BLIT_ALPHABLEND);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
