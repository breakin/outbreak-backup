#include <math.h>
#include <helper/core/dialog/font/font.h>
#include "endscroll.h"

// man bara �lskar msvc eller hur? ;)
#define for if(0);else for 

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectEScroll::EffectEScroll(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	Image32 fontTmp;
	globals.archive->load(fontTmp, "system/font.tga");
	font.createFont(fontTmp, 2);

	temp2.resize(512, 70);
	temp.resize(320, 40);

	std::string scroll = "default setting";
	fontImage.resize(font.len(scroll)+320+320, 40);
	uint32 *pix = fontImage.get();

	for (int i = 0; i < fontImage.getHeight() * fontImage.getWidth(); i++) pix[i] = 0x660000;
	font.draw(fontImage, 320, 16, scroll);
	for (int i = 0; i < fontImage.getHeight() * fontImage.getWidth(); i++) pix[i] |= 0x88 << 24;

	// create panorama lookup table
	int imHeight = 40;
	int imWidth = 320;

	int grHeight = 100;
	int grWidth = 512;

	float radius = imWidth  / (6.28f);

	int viw2 = grWidth >> 1;
	int irh2 = imHeight >> 1;
	int irw2 = imWidth >> 1;
	int vih2 = grHeight >> 1;

	int ywid = 0 * grWidth;
	int renderx = -viw2;

	int lasty = 70 * grWidth;

	float prop = 65536 * ((float) imHeight / (float) (grHeight));
	float bradius = irw2; // + timer * radius;

	for (int x = 0; x < grWidth; x++, ywid++, lasty++, renderx++) {
		float a = atanf(renderx / radius);

		int sourcex = (int) ((a * radius + bradius)) % imWidth;
		if (sourcex < 0) sourcex += imWidth;

		int dsourcey = (int) ( sin((x/(float)grWidth)*(3.141592f/2)) * cosf(a) * prop);
		int sourcey = ((+4+irh2) << 16) - vih2 * dsourcey;

		for (int index = ywid; index < lasty; index += grWidth, sourcey += dsourcey) {
			lookup[index] = (sourcey >> 16) * imWidth + sourcex;
		}
	}

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectEScroll::executeTrigger(const std::string& name, const std::string& value) {

	if (name == "text") {
		std::string scroll = value;
		fontImage.resize(font.len(scroll)+320+320, 40);
		uint32 *pix = fontImage.get();

		for (int i = 0; i < fontImage.getHeight() * fontImage.getWidth(); i++) pix[i] = 0x660000;
		font.draw(fontImage, 320, 16, scroll);
		for (int i = 0; i < fontImage.getHeight() * fontImage.getWidth(); i++) pix[i] |= 0x88 << 24;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectEScroll::update(const float64 timer, const float64 delta, const float64 percent) {
//	uint32* font = fontImage.get();

	globals.imageDrawer->draw(fontImage, fontImage.getArea(), temp, -timer*100, 0, Helper::ImageDrawer::BLIT_NORMAL);
//	globals.imageDrawer->draw(fontImage, fontImage.getArea(), *globals.backbuffer, -timer*100, 0, Helper::ImageDrawer::BLIT_NORMAL);
	uint32* image = temp.get();
	uint32* t2 = temp2.get();

	int blah = globals.backbuffer->getHeight() * globals.backbuffer->getWidth();



	// scroll
	int ywid = 0;
	for (int y2 = 0; y2 < 70; y2++) {
		for (int x = 0; x < 512; x++) {
			t2[ywid] = image[lookup[ywid]];
			ywid++;
		}
	}

	// move up and down
	int y = 92 + sin(timer*2) * 80;

	for (int i = 0; i < 512; i++) {
		t2[i] = 0xffeeee00;
		t2[(69 << 9) + i] = 0xffeeee00;
	}

	globals.imageDrawer->draw(temp2, temp2.getArea(),*globals.backbuffer, 0,y, Helper::ImageDrawer::BLIT_ALPHABLEND);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
