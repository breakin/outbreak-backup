#include "thx.h"

#define for if(0);else for 

EffectTHX::EffectTHX(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	globals.archive->load(thx, "thx/thx.png");
	globals.archive->load(listen, "thx/thx_listen.png");
	thx_time = listen_time = -2;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectTHX::executeTrigger(const std::string& name, const std::string& value) {
	// Set mode
	if (name=="start") {
		if (value == "thx") thx_time = -1;
		else if (value == "listen") listen_time = -1;
	}

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectTHX::update(const float64 timer, const float64 delta, const float64 percent) {
	if (thx_time == -2) return;
	else if (thx_time == -1) thx_time = timer;

	uint32 alpha = ((int) (((timer - thx_time) / 4) * 255)); // thec �r ett A.S / zantac 
	if (alpha > 255) alpha = 255;
	alpha = 255 - alpha;
	alpha = alpha << 16 | alpha << 8 | alpha;

	globals.imageFilter->crossfadeToColor(*globals.backbuffer, globals.backbuffer->getArea(), thx, thx.getArea(), 0, alpha, 0xffffff);

	if (listen_time == -2) return;
	globals.imageDrawer->draw(listen, listen.getArea(), *globals.backbuffer, AreaInt(0, 256 - listen.getHeight(), 512, listen.getHeight()), Helper::ImageDrawer::BLIT_NORMAL);
}