/*
  =============================================================================
  = Air Demo. (c) Outbreak 2001
  =============================================================================
    @ Responsible : Thec
    @ Class       : Air Demo Stub
    @ Brief       : First of all it runs the demo. It loads the effects, initiates the 
                    script and runs the effects. It has the responsible of pausing the 
                    demo, taking screenshots and moving forward and backwards within
                    the demo.

    @ Features : 
      * 'p' Pauses the demo
      * 'f' Runs fps counter
      * Left arrow rewinds
      * Right arrow fast forwards

	  Command Line Paramets:
	  /skipconfig    - Skip's the setup box.
	  /windowed      - Run in windowed mode.
	  /time:10.00    - Fast forwards 10 seconds when the demo starts. /time=10.00 does the same thing.

  =============================================================================
*/

/*
script:
[01:25:22] <thec> 1. thx
[01:25:29] <thec> 2. stars
[01:25:41] <thec> 3. munscroll
[01:25:58] <thec> 4. vu
[01:26:06] <thec> 5. amiga
[01:26:27] <thec> 6. rotocredz
[01:26:35] <thec> 7. end
[01:27:07] <thec> 1.5. tunneln =)

  * invert
  * br�nna dc-load-skiva till breakin
*/

// Helper includes
#include <helper/helper.h>
#include <helper/win32/win32_device2d.h>
#include <helper/directx/dx_device2d.h>
#include <helper/core/dialog/font/font.h>
#include <helper/core/utils/commandlineparser.h>

// Standard includes
#include <fstream>
#include <conio.h>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <math.h>

// Globals
#include "globals.h"

// Config
#include "config/config.h"

// Effect includes
#include "background/background.h"
#include "credits/credits.h"
#include "stars/stars.h"
#include "grid/grid.h"
#include "amiga1/amiga1.h"
#include "vu-meter/vu-meter.h"
#include "munscroller/munscroller.h"
#include "endscroll/endscroll.h"
#include "tunnel/tunnel.h"
#include "thx/thx.h"
#include "flares/flares.h"
#include "invert/invert.h"
#include "xor/xor.h"
#include "blaster/blaster.h"
#include "water/water.h"
#include "scratch/scratch.h"
#include "credz/credz.h"
#include "meditate/meditate.h"
#include "theend/theend.h"

// Namespaces
using namespace Helper;
using namespace std;

// ---------------------------------------------------------------------------

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevinst, LPSTR cmdline, int showstate) {
	try {
		Debug::log("Main()", "Demo started...");

		CommandLineParser cmd;

		//ArchiveDirectory screenShots("screenshots");
		ExperimentalGlobals globals;

		// Run config first
		ExperimentalConfig config(globals);
		if (!config.run()) return 0;
		
		// Load font for fps
		Font font;
		// Make sure fontTexture gets temporary.
		if (true) {
			Image32 fontTexture;
			globals.archive->load(fontTexture, "system/font.tga");
			font.createFont(fontTexture, 2);
		}

		// Create effects
		EffectBackground effectBackground(globals);
		EffectCredits    effectCredits(globals);
		EffectStars      effectStars(globals);
		EffectGrid       effectGrid(globals);
		EffectAmiga1	 effectAmiga1(globals);
		EffectVumeter	 effectVumeter(globals);
		EffectMunscroll  effectMunscroll(globals);
		EffectEScroll	 effectEScroll(globals);
		EffectTunnel	 effectTunnel(globals);
		EffectTHX		 effectTHX(globals);
		EffectFlares	 effectFlares(globals);
		EffectInvert	 effectInvert(globals);
		EffectXOR		 effectXOR(globals);
		EffectWater		 effectWater(globals);
		EffectBlaster	 effectBlaster(globals);
		EffectScratch	 effectScratch(globals);
		EffectCredz		 effectCredz(globals);
		EffectMeditate	 effectMeditate(globals);
		EffectTheEnd	 effectTheEnd(globals);

		// Load script
		XmlParser xmlfile;
		xmlfile.parse(globals.archive->getFile("script.odml").get());
		Script script(xmlfile);

		// Add Callbacks
		script.addCallback("background"	, &effectBackground);
		script.addCallback("credits"	, &effectCredits);
		script.addCallback("stars"		, &effectStars);
		script.addCallback("grid"		, &effectGrid);
		script.addCallback("amiga1"		, &effectAmiga1);
		script.addCallback("vumeter"	, &effectVumeter);
		script.addCallback("munscroll"	, &effectMunscroll);
		script.addCallback("endscroll"	, &effectEScroll);
		script.addCallback("tunnel"		, &effectTunnel);
		script.addCallback("thx"		, &effectTHX);
		script.addCallback("flares"		, &effectFlares);
		script.addCallback("invert"		, &effectInvert);
		script.addCallback("xor"		, &effectXOR);
		script.addCallback("blaster"	, &effectBlaster);
		script.addCallback("water"		, &effectWater);
		script.addCallback("scratch"	, &effectScratch);
		script.addCallback("credz"		, &effectCredz);
		script.addCallback("meditate"	, &effectMeditate);
		script.addCallback("the end"	, &effectTheEnd);

		// Load&play music
		globals.music->load("dangerous outbreaks.mp3");
		globals.music->play();

		// If /time:xx.xx is specified on the command line, move time.
		if (cmd.isEntity("time")) {

			// Get time
			const int time = atof(cmd.getEntity("time").c_str());
			
			// Set time.
			if (time>0)	globals.music->setTimer(time);
		}

		// Demo variables
		bool  exit = false;
		Msg msg;

		// Fps variables
		bool fpstoggle=false;
		float64 startTime=0;
		float64 fps=0;
		int8 temp[100];
		uint32 frames=0;
		uint32 totalFrames=0;

		// Pause variables
		bool pauseToggle=false;
		float64 pauseTime;

		float64 current;

		while (1) {
			// Current time
			if (pauseToggle) {
				current = pauseTime;
			} else {
				current = globals.music->getTimer();
			}

			// Run script, end when finished.
			if (!script.update(current)) return 0;

			// Check for messages.
			if (globals.device2D->getMessage(msg)) {
				// Someone desperatly want to shut down quick :)
				if (msg.message == Helper::Msg::MSG_CLOSE) return 2;

				// Keyboard hit
				if (msg.message == Helper::Msg::MSG_KEYCHAR) {

					Debug::log("WinMain()", "Key param:%d, extra:%d", msg.param, msg.extra);
					
					// Escape!
					if (msg.param == 27) return 3;

					// Pause demo
					if ((msg.param == 'p') || (msg.param == 'P')) {
						// Toggle pause
						pauseToggle = !pauseToggle;

						// Pause/Play music
						if (pauseToggle) {
							// Save time, do this before pausing for accurate time...
							pauseTime = globals.music->getTimer();

							// Pause stream
							globals.music->pause();
						} else {
							// Set time
							globals.music->setTimer(pauseTime);

							// Play stream
							globals.music->play();
						}

						// Reset fps
						if (fpstoggle) {
							frames=0;
							startTime = globals.music->getTimer();
						}
					}

					// Toggle fps
					if ((msg.param == 'f') || (msg.param == 'F')) {
						fpstoggle = !fpstoggle;

						// Reset fps
						if (fpstoggle) {
							frames=0;
							startTime = globals.music->getTimer();
						}
					}

					// Take screenshot
					if ((msg.param == 's') || (msg.param == 'S')) {

						char fileName[256];
						const int min=int(globals.music->getTimer()/60.0);
						const int sec=int(globals.music->getTimer())%60;
						const int hun=int(globals.music->getTimer()*100.0)%100;
						
						sprintf(fileName, "Air(%d.%02d.%02d).jpg", min,sec,hun);

						ImageCoder::EncodeSettings e;
						e.saveAlphaChannel=false;

						//screenShots.createFile(fileName, globals.imageTool->encode(*globals.screen, fileName, e));
					}
				}

				// Keyboard hit
				if (msg.message == Helper::Msg::MSG_KEYDOWN) {
				
					// Left arrow, jump back 1 second
					if (msg.param == 37) {
						// Only if not outside scope
						if (current-1>0) {
							// Set timer
							if (pauseToggle) {
								pauseTime -= 1;
							} else {
								globals.music->setTimer(globals.music->getTimer() - 1);
							}
						}
					}

					// Right arrow, forward 1 second.
					if (msg.param == 39) {
						// Only if not outside scope...

						// Set timer
						if (current+1<script.getScriptEnd()) {
							if (pauseToggle) {
								pauseTime += 1;
							} else {
								globals.music->setTimer(globals.music->getTimer() + 1);
							}
						}
					}
				}
			}

			// Pixelbuffer to draw on.
			uint32* pixel = globals.backbuffer->get();

			// If fps is toggled, draw
			if (fpstoggle) {
				// Fix fps-string.
				if (pauseToggle) {
					sprintf(temp, "fps: n/a");
				} else {
					sprintf(temp, "fps: %.2f", fps);
				}

				// Clear behind font
				for (int y=2; y<11; y++) {
					for (int x=2; x<55; x++) {
						pixel[y*512+x] = 0x550000;
					}
				}

				// Draw with font.
				font.draw(*globals.backbuffer, 4, 0, temp);

				// Recalculate each 5th frame
				if (frames==5) {
					// Calculate fps
					fps = frames/(globals.music->getTimer()-startTime);

					// Reset fps vaiables
					frames=0;
					startTime = current-0.05;
				}

				// Increase one frame
				frames++;
			}

			// If pause is toggled, draw scene-end-indication bar.
			if (pauseToggle) {
				for (int y=248; y<254; y++) {
					for (int x=4; x<508; x++) {
						pixel[y*512+x] = 0x550000;

						uint32 offset = uint32( current*508/script.getScriptEnd() );
						if (y!=248 && y!=253) {
							if ((x-4<offset) && (x>offset)) {
								pixel[y*512+x] = 0x00ff00;
							}
						}
					}
				}
			}

			// If first frames, clear WHOLE surface
			/*
			if (totalFrames<10) {
				globals.imageDrawer->clear(*globals.screen, globals.screen->getArea());
				totalFrames++;
			}
			*/
			globals.imageDrawer->clear(*globals.screen, globals.screen->getArea());

			// Copy backbuffer to screen. May be modified later, you never know.
			globals.imageDrawer->draw(*globals.backbuffer, globals.backbuffer->getArea(), *globals.screen, globals.centerX, globals.centerY, ImageDrawer::BLIT_NORMAL);

			// Update device.
			globals.device2D->update();
		}
	}
	
	// Catch known exceptions.
	catch (const Helper::Exception &e) {
		MessageBox(NULL, e.what(), "Helper::Exception", MB_OK);
	}

	// Catch unknown exceptions.
	catch (...) {
		MessageBox(NULL, "Unknown exception", "(...)::Exception", MB_OK);
	}

	// Return the answer :-D
	return 42;
}
