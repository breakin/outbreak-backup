#include "background.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectBackground::EffectBackground(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectBackground::executeTrigger(const std::string& name, const std::string& value) {
	if (name=="color") {
		if (value == "white") color = 0xffffff;
		else if (value == "black") color = 0;
		else if (value == "star") color = 0x118844;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectBackground::update(const float64 timer, const float64 delta, const float64 percent) {
	// Clear with black color
	if (color == 0) {
		globals.imageDrawer->clear(*globals.backbuffer, globals.backbuffer->getArea());
	} else {
		uint32* pixels = globals.backbuffer->get();
		int size = globals.backbuffer->getHeight() * globals.backbuffer->getWidth();
		for (int i = 0; i < size; i++) {
			pixels[i] = color;
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
