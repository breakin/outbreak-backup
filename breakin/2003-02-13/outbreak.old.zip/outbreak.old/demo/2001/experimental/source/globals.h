#ifndef EXPERIMENTAL_GLOBALS_H
#define EXPERIMENTAL_GLOBALS_H

/*
  =============================================================================
  = Helper Library. (c) Outbreak 2001
  =============================================================================
	@ Responsible : Thec
	@ Class       : Globals
	@ Brief       : Passed to all classes to make a common helperbase.
  =============================================================================
*/

#include <helper/helper.h>

// ---------------------------------------------------------------------------

struct ExperimentalGlobals {
	Helper::int32 centerX;
	Helper::int32 centerY;

	Helper::Device2D*		device2D;
	Helper::Music*			music;
	Helper::Archive*		archive;
	Helper::ImageTool*		imageTool;
	Helper::ImageFilter*    imageFilter;
	Helper::ImageDrawer*	imageDrawer;

	Helper::BaseImage32*    backbuffer;
	Helper::BaseImage32*    screen;
};

// ---------------------------------------------------------------------------

#endif