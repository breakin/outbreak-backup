#include <math.h>
#include "credz.h"

#define for if(0);else for 

using namespace std;
EffectCredz::EffectCredz(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	globals.archive->load(credz[0], "credz/code.png");
	globals.archive->load(credz[1], "credz/pixel.png");
	globals.archive->load(credz[2], "credz/photo.png");
	globals.archive->load(credz[3], "credz/addcode.png");
	globals.archive->load(credz[4], "credz/music.png");
	globals.archive->load(credz[5], "credz/bliss.png");

	current = 0;
	mode = 0;
	lastUpdate = -1;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectCredz::executeTrigger(const std::string& name, const std::string& value) {
	if (name == "picadd") {
		current++; // = atoi(value.c_str());
		lastUpdate = -1;
	} else if (name == "mode") {
		mode = atoi(value.c_str());
		lastUpdate = -1;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectCredz::update(const float64 timer, const float64 delta, const float64 percent) {
	if (lastUpdate == -1) lastUpdate = timer;

	int32 alpha = 0;
	if (mode <= 1) {
		alpha = (timer - lastUpdate)*255*0.9;
		if (alpha > 255) alpha = 255;
		if (mode == 0) alpha = 255 - alpha;
		alpha = alpha << 16 | alpha << 8 | alpha;

		globals.imageFilter->crossfadeToColor(*globals.backbuffer, globals.backbuffer->getArea(), credz[current], credz[current].getArea(), 0, alpha);
	} else  if (mode == 2) {
		int x = 512 - (timer - lastUpdate) * 80;
		if (x < 118) x = 118;
		globals.imageDrawer->draw(credz[5], credz[5].getArea(), *globals.backbuffer, globals.backbuffer->getArea(), x, 88, Helper::ImageDrawer::BLIT_ALPHABLEND);
	} else if (mode == 3) {
		float64 pos = (timer - lastUpdate);

		int x = (timer - lastUpdate) * 200;
		AreaInt target(118 - pos * 128-x, 88 - pos * 64, 276 + pos * 128*2-x, 79 + pos * 64*2);
		globals.imageDrawer->draw(credz[5], credz[5].getArea(), *globals.backbuffer, target, Helper::ImageDrawer::BLIT_ALPHABLEND);
	}
//		globals.imageDrawer->draw(credz[current], credz[current].getArea(), *globals.backbuffer, globals.backbuffer->getArea(), Helper::ImageDrawer::BLIT_ALPHABLEND);
}