#include "theend.h"

#define for if(0);else for 

EffectTheEnd::EffectTheEnd(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	globals.archive->load(theEnd, "theend/theend.png");
	theend=false;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectTheEnd::executeTrigger(const std::string& name, const std::string& value) {
	if (name=="stop") {
		theend=true;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectTheEnd::update(const float64 timer, const float64 delta, const float64 percent) {

	if (!theend) {
		globals.imageDrawer->setAlphaMode(ImageDrawer::ALPHA_CONSTANT, int(percent*255.0f));
		
		globals.imageDrawer->draw(theEnd, theEnd.getArea(), *globals.backbuffer, 0, 0, Helper::ImageDrawer::BLIT_ALPHABLEND);

		globals.imageDrawer->setAlphaMode(ImageDrawer::ALPHA_PERPIXEL);
	} else {
		globals.imageDrawer->draw(theEnd, theEnd.getArea(), *globals.backbuffer, 0, 0, Helper::ImageDrawer::BLIT_ALPHABLEND);
	}
}