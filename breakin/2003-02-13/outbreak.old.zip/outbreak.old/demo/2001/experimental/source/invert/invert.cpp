#include "invert.h"

#define for if(0);else for 

EffectInvert::EffectInvert(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	mode = 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectInvert::executeTrigger(const std::string& name, const std::string& value) {
	if (name == "mode") {
		if (value == "normal") mode = 0;
		else if (value == "invert") mode = 1;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectInvert::update(const float64 timer, const float64 delta, const float64 percent) {
	if (mode != 0)
		globals.imageFilter->invert(*globals.backbuffer, globals.backbuffer->getArea(), *globals.backbuffer, globals.backbuffer->getArea());
}