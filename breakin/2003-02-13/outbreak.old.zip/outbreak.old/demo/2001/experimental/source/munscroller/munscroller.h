#ifndef EXPERIMENTAL_EFFECT_MUNSCROLL
#define EXPERIMENTAL_EFFECT_MUNSCROLL

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectMunscroll : public Effect {
private:
	ExperimentalGlobals &globals;

	Image32 bg;
	Image32 fg;
	Image32 scroll;
	float sineTable[512];

	float mun_time;
	float scroll_time;
	bool	slide;


public:
	EffectMunscroll(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
