#include <math.h>
#include "meditate.h"

#define for if(0);else for 

using namespace std;

EffectMeditate::EffectMeditate(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	globals.archive->load(med, "meditate/meditate.png");
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectMeditate::executeTrigger(const std::string& name, const std::string& value) {
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectMeditate::update(const float64 timer, const float64 delta, const float64 percent) {
	int y = 128-105 + sin(timer) * 20;
	int x = 256-83 + cos(timer * 0.74) * 20;
	globals.imageDrawer->draw(med, med.getArea(), *globals.backbuffer, globals.backbuffer->getArea(), x, y, Helper::ImageDrawer::BLIT_ALPHABLEND);
}