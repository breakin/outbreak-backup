#include "xor.h"

#define for if(0);else for 

EffectXOR::EffectXOR(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	xor.resize(512, 256);
	uint32 *xpix = xor.get();

	int z = 0;
	for (int y = 0; y < 256; y++) {
		for (int x = 0; x < 512; x++) {
			int tmp = (x^y)+z++;
			xpix[(y << 9) + x] = tmp << 16 | tmp << 8 | tmp;
		}
	}

	mode = 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectXOR::executeTrigger(const std::string& name, const std::string& value) {
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectXOR::update(const float64 timer, const float64 delta, const float64 percent) {
	uint32 *xpix = globals.backbuffer->get();

	for (int y = 0; y < 256; y++) {
		int r = (int) (timer*100);
		int g = (int) (timer*50);
		int b = (int) (timer*10);
		for (int x = 0; x < 512; x++) {
			int tmp = (x^y);
			xpix[(y << 9) + x] = (tmp+r++) << 16 | (tmp+g++) << 8 | (tmp+g++);
		}
	}

//	globals.imageDrawer->draw(xor, xor.getArea(), *globals.backbuffer, globals.backbuffer->getArea(), 0, 0, Helper::ImageDrawer::BLIT_NORMAL);
//	if (mode != 0)
//		globals.imageFilter->invert(*globals.backbuffer, globals.backbuffer->getArea(), *globals.backbuffer, globals.backbuffer->getArea());
}