#ifndef EXPERIMENTAL_EFFECT_WATER
#define EXPERIMENTAL_EFFECT_WATER

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

#define dampfactor 3

using namespace Helper;

class EffectWater : public Effect {
private:
	ExperimentalGlobals &globals;
	short *hm1;
	short *hm2;

	Image32 tmp;
	int32 mode;

	float64 lastTime;
	void putDrip(int ypos);

public:
	EffectWater(ExperimentalGlobals &globals);
	~EffectWater();

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
