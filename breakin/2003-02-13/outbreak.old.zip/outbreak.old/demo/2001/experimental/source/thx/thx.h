#ifndef EXPERIMENTAL_EFFECT_THX
#define EXPERIMENTAL_EFFECT_THX

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectTHX : public Effect {
private:
	ExperimentalGlobals &globals;
	Image32 thx;
	Image32 listen;
	float64 thx_time;
	float64 listen_time;


public:
	EffectTHX(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
