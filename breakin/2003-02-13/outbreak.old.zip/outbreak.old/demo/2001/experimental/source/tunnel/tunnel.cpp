#include <math.h>
#include <helper/core/dialog/font/font.h>
#include "tunnel.h"

// man bara �lskar msvc eller hur? ;)
#define for if(0);else for 

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectTunnel::EffectTunnel(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	Image32 tmp;
	Image32 tmp2;
	globals.archive->load(tmp2, "tunnel/tunnel.jpg");
	tunnelImage.resize(512, 512);
	tmp.resize(512, 256);

	globals.imageDrawer->draw(tmp2, tmp2.getArea(), tmp, tmp2.getArea(), Helper::ImageDrawer::BLIT_NORMAL);
	AreaInt blah(256, 0, 256, 256);
	globals.imageDrawer->draw(tmp2, tmp2.getArea(), tmp, blah, Helper::ImageDrawer::BLIT_NORMAL);

	uint32* p1 = tmp.get();
	uint32* p2 = tunnelImage.get();

	for (int i = 0; i < 512 * 256; i++) {
		p2[i] = p1[i];
		p2[i+512*256] = p1[i];
	}

	for (int x = 0; x < 512; x++) {
		for (int y = 0; y < 256; y++) {
			double u = atan2((double) y - 256 / 2.0,(double) x - 512 / 2.0) * 512 / 2.0 / 3.14;
			double v = 4000 / sqrt((x - 512 / 2) * (x - 512 / 2) + (y - 256 / 2) * (y - 256 / 2));

			int offset = (((int) v) << 9) + (int) u;
			offset %= 256*512;
			if (offset < 0) offset += 512;

			lookup[(y << 9) + x] = offset;
		}
	}

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectTunnel::executeTrigger(const std::string& name, const std::string& value) {
	if (name == "fade") {
		fade = atoi(value.c_str());
		if (fade != -1)
			fade = fade << 16 | fade << 8 | fade;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectTunnel::update(const float64 timer, const float64 delta, const float64 percent) {
	uint32* pixels = globals.backbuffer->get();
	uint32* p2 = tunnelImage.get();
	int offset = (int) ((-512 * int(timer *50)) + (timer *100)) % (512*256);
	if (offset < 0) offset += 512*256;

	for (int i = 0; i < 512 * 256; i++) {
		pixels[i] = p2[offset + lookup[i]];
	}
	if (fade != -1)
		globals.imageFilter->crossfadeToColor(*globals.backbuffer, globals.backbuffer->getArea(), *globals.backbuffer, globals.backbuffer->getArea(), 0, fade);
}  
