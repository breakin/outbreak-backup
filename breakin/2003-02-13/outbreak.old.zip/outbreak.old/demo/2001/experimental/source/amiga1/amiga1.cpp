#include "amiga1.h" 
#include <math.h>

#define PI 3.141592f

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectAmiga1::EffectAmiga1(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	globals.archive->load(texture, "amiga1/amiga1.png");

	for (int i = 0; i < 2048; i++) {
		sintab1[i] = (int) 40 * sinf(i * PI / 256.0f);
		sintab2[i] = (int) 44 * cosf(i * PI / 512.0f);
		sintab3[i] = (int) 58 * cosf(i * PI / 1024.0f);
	}
	mode = false;
	start=-2;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectAmiga1::executeTrigger(const std::string& name, const std::string& value) {
	if (name == "mode") {
		mode = true;
		start = -1;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectAmiga1::update(const float64 timer, const float64 delta, const float64 percent) {
	// s� att bilden hamnar i centrum
	int center = 128 - (texture.getHeight() >> 1);

	uint32* pixels = globals.backbuffer->get();
	uint32* pixels2 = texture.get();

	int t1 = (int) (timer*650);
	int t2 = (int) (timer*350);
	int t3 = (int) (timer*500);

	int ypos = 0;

	if (start == -1) start = percent;

	// hur mycket vi ska distorta... typ
	float64 inv;
	if (!mode) inv = 1.0 - (percent) * 6;
	else inv = (percent-start) * 12;

	if (inv < 0) inv = 0;

	// bara kopiera bilden rakt av om vi inte ska distorta n�got
	if (inv == 0) {
		ypos = center*512;
		for (int i = 0; i < 512*147; i++) {
			int alpha = pixels2[i] >> 24;
			pixels[ypos] = pixels2[i]; //blend(pixels[ypos], pixels2[i], alpha);
			ypos++;
		}
	} else {
		for (int y = 0; y < 256; y++) {
			for (int x = 0; x < 512; x++) {
				int dx = (x + int((sintab1[((y - x)*4 + t3) & 2047] + sintab2[(x*6 + t2) & 2047]) * inv))&511;
				int dy = (y - center + int((sintab3[((y)*3 + t2) & 2047] + sintab2[((y+x)*3 + t1) & 2047]) * inv));

//				dx = dx < 0 ? 0 : dx > 511 ? 511 : dx;
				dy = dy < 0 ? 0 : dy > 146 ? 146 : dy;

				int ypos2 = dx + (dy << 9);

//				int alpha = pixels2[ypos2] >> 24;
//				pixels[ypos] = blend(pixels[ypos], pixels2[ypos2], alpha);
				pixels[ypos] = pixels2[ypos2];
				ypos++;
			}
		}
	}

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
