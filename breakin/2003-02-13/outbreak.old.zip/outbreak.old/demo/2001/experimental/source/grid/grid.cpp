#include "grid.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectGrid::EffectGrid(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	color = 0xeeffee;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectGrid::executeTrigger(const std::string& name, const std::string& value) {
	if (name=="color") {
		color = atoi(value.c_str());
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectGrid::update(const float64 timer, const float64 delta, const float64 percent) {
	uint32* pixels = globals.backbuffer->get();

	pixels[5120 + uint32(percent*511)] = color;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
