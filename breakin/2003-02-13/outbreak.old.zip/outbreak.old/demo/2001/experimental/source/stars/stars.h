#ifndef EXPERIMENTAL_EFFECT_STARS
#define EXPERIMENTAL_EFFECT_STARS

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectStars : public Effect {
private:
	ExperimentalGlobals &globals;

	int32   mode;
	float32 timestamp;

	Image32 man[16];

	int32 filter[128];

public:
	EffectStars(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif