#include <math.h>
#include "water.h"

#define for if(0);else for 

EffectWater::EffectWater(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	tmp.resize(512, 256);
	hm1 = new short[512*256];
	hm2 = new short[512*256];
	for (int i = 0; i < 512*256; i++) {
		hm1[i] = 0;
		hm2[i] = 0;
	}

	lastTime = 0;
	mode = 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

EffectWater::~EffectWater() {
	delete[] hm1;
	delete[] hm2;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectWater::executeTrigger(const std::string& name, const std::string& value) {
	if (name == "stopdrip") {
		mode = 1;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

inline void EffectWater::putDrip(int y) {
	int b = 128;
	hm1[y-512]   = b;
	hm1[y-1]     = b;
	hm1[y]       = b;
	hm1[y+1]     = b;
	hm1[y+512]   = b;

	hm1[y-1024]  = b;
	hm1[y-2]     = b;
	hm1[y+2]     = b;
	hm1[y+1024]  = b;

	hm1[y-512-1] = b;
	hm1[y-512+1] = b;

	hm1[y+512-1] = b;
	hm1[y+512+1] = b;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectWater::update(const float64 timer, const float64 delta, const float64 percent) {
	globals.imageDrawer->draw(*globals.backbuffer, globals.backbuffer->getArea(), tmp, tmp.getArea(), Helper::ImageDrawer::BLIT_NORMAL);

	uint32 *buffer = globals.backbuffer->get();
	uint32 *tpix = tmp.get();

	if (timer < lastTime) lastTime = 0;
	if ((timer - lastTime) > 0.005) {
		// put a drip in the water heightmap
		if (!mode) {
			int y = 10 + rand() % 236;

			putDrip((y << 9) + (10 + rand()%492));
		}

		// update the water
		int pos = 512 + 1;
		for (int y = 1; y < 256 - 2; y++) {
			pos += 3;
			for (int x = 1; x < 512 - 2; x++) {
				int tmp = (
							hm1[pos + 1] +
							hm1[pos - 1] +
							hm1[pos - 512] +
							hm1[pos + 512]
				) >> 1;

				tmp -= hm2[pos];
				tmp -= tmp >> dampfactor;
				hm2[pos] = (short) (tmp);
				tpix[pos] = buffer[pos - tmp];
				pos++;
			}
		}

		short *tmp = hm2;
		hm2 = hm1;
		hm1 = tmp;

		lastTime = timer;
	} else {
		// just paint the water without updating
		int pos = 0;
		for (int i = 0; i < 512*256; i++) {
			tpix[pos] = buffer[pos - hm2[pos]];
		}
/*
		int pos = 512 + 1;
		for (int y = 1; y < 256 - 2; y++) {
			pos += 3;
			for (int x = 1; x < 512 - 2; x++) {
				tpix[pos] = buffer[pos - hm2[pos]];
				pos++;
			}
		}
*/
	}

	globals.imageDrawer->draw(tmp, tmp.getArea(), *globals.backbuffer, globals.backbuffer->getArea(), Helper::ImageDrawer::BLIT_NORMAL);
}