#ifndef EXPERIMENTAL_EFFECT_BLASTER
#define EXPERIMENTAL_EFFECT_BLASTER

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectBlaster : public Effect {
private:
	ExperimentalGlobals &globals;
	Image32 blaster;

public:
	EffectBlaster(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
