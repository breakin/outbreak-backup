#ifndef EXPERIMENTAL_EFFECT_INVERT
#define EXPERIMENTAL_EFFECT_INVERT

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectInvert : public Effect {
private:
	ExperimentalGlobals &globals;
	int mode;

public:
	EffectInvert(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
