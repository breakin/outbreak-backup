#include <math.h>
#include "flares.h"

#define for if(0);else for 

EffectFlares::EffectFlares(ExperimentalGlobals &initGlobals) : globals(initGlobals) {
	uint32 *map = new uint32[256*256];

	int w2 = 256 >> 1;
	int h2 = 256 >> 1;

	for (int y = 0; y < 256; y++) {
		for (int x = 0; x < 256; x++) {
			int intensity = (int) (sqrt((x - w2) * (x - w2) + (y - h2) * (y - h2))*2);
			intensity = intensity < 0 ? 0 : intensity > 255 ? 255 : intensity;

			intensity = 255 - intensity;
			map[y * 256 + x] = intensity;
		}
	}

	int color[] =  { 0xffffff, 0xffff00, 0x888811, 0x777777 };
	for (int i = 0; i < 4; i++) {
		flare[i].resize(256, 256);
		uint32 *pix = flare[i].get();

		for (int j = 0; j < 256 * 256; j++) {
			int b = ((map[j]) * (color[i] &0xff)) >> 8;
			int g = ((map[j]) * ((color[i]>>8) &0xff)) >> 8;
			int r = ((map[j]) * ((color[i]>>16)&0xff)) >> 8;
			pix[j] = r << 16 | g << 8 | b;
		}
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectFlares::executeTrigger(const std::string& name, const std::string& value) {
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

inline void EffectFlares::draw_flare(double x, double y, double z, int texture) {
	int size = 64 + z * 32;
	int size2 = size >> 1;
	AreaInt tmp(256 + x * 256-size2, 128 + y * 128-size2, size, size);
	globals.imageDrawer->draw(flare[texture], flare[texture].getArea(), *globals.backbuffer, tmp, Helper::ImageDrawer::BLIT_SATURATION);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void EffectFlares::update(const float64 timer, const float64 delta, const float64 percent) {
	for (int i=0; i<balls-1; i++) {
		float ti = timer - (i * 0.0534);
		float x = sin((ti)*1.6346);
		float y = cos(3.12415/2 + (ti)*1.48)*sin((ti)*4);
		float z = sin((ti)*1.2346); //cos(timer*timer);

		draw_flare(x, y, z, i&3);
	}
}