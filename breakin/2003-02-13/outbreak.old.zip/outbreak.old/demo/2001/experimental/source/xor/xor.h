#ifndef EXPERIMENTAL_EFFECT_XOR
#define EXPERIMENTAL_EFFECT_XOR

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectXOR : public Effect {
private:
	ExperimentalGlobals &globals;
	Image32 xor;
	int mode;

public:
	EffectXOR(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
