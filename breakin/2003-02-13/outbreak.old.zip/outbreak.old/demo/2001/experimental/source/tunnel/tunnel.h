#ifndef EXPERIMENTAL_EFFECT_TUNNEL
#define EXPERIMENTAL_EFFECT_TUNNEL

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectTunnel : public Effect {
private:
	ExperimentalGlobals &globals;
	int lookup[256*512];
	int fade;
	Image32 tunnelImage;


public:
	EffectTunnel(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
