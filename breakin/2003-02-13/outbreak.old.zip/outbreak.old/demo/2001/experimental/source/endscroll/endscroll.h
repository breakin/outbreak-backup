#ifndef EXPERIMENTAL_EFFECT_ENDSCROLL
#define EXPERIMENTAL_EFFECT_ENDSCROLL

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectEScroll : public Effect {
private:
	ExperimentalGlobals &globals;
	Font font;
	int lookup[512*70];
	Image32 fontImage;
	Image32 temp;
	Image32 temp2;


public:
	EffectEScroll(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
