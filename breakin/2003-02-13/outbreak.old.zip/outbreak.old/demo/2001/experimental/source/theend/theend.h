#ifndef EXPERIMENTAL_EFFECT_THEEND
#define EXPERIMENTAL_EFFECT_THEEND

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectTheEnd : public Effect {
private:
	ExperimentalGlobals &globals;

	Image32 theEnd;
	bool theend;
public:
	EffectTheEnd(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
