#ifndef EXPERIMENTAL_EFFECT_GRID
#define EXPERIMENTAL_EFFECT_GRID

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

using namespace Helper;

class EffectGrid : public Effect {
private:
	ExperimentalGlobals &globals;

	uint32 color;

public:
	EffectGrid(ExperimentalGlobals &globals);

	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif