#ifndef EXPERIMENTAL_EFFECT_FLARES
#define EXPERIMENTAL_EFFECT_FLARES

#include <helper/core/imagedrawer/imagedrawer.h>
#include <helper/core/demo/script/effect.h>
#include <helper/core/demo/script/script.h>

#include "../globals.h"

#define balls 16

using namespace Helper;

class EffectFlares : public Effect {
private:
	ExperimentalGlobals &globals;
	Image32 flare[4];

public:
	EffectFlares(ExperimentalGlobals &globals);

	inline void draw_flare(double x, double y, double z, int texture);
	void executeTrigger(const std::string& name, const std::string& value);
	void update(const float64 timer, const float64 delta, const float64 percent);
};

#endif
